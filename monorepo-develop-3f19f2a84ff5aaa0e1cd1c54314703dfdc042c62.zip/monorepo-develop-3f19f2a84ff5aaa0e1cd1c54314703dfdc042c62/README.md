# MBazaar Web Monorepo

The [Monorepo Strategy](https://en.wikipedia.org/wiki/Monorepo) has a lot of advantages, the primary ones here being:
1. Ease of code reuse
2. Simplified dependency management
5. Collaboration across teams

This monorepo is build using [yarn workspaces](https://yarnpkg.com/lang/en/docs/workspaces/).

The majority of the code is written in [TypeScript](https://www.typescriptlang.org/) which enforces static typing and enables the latest ECMAScript standards.
This requires transpilation, and is handled out-of-the-box thanks to the frameworks.  

To install all dependencies, run `yarn` in the root of the folder. 

## Packages

There are currently two packages in this Monorepo.
1. `core`
  This contains all common code that can be shared between packages.
  Currently it has:
  1. `src/ui` 
    This contains all UI related React components that can be used to build pages and layouts. 
    The [Docz](http://docz.site/) UI Library can be started using the command `yarn docz:dev` inside `packages/core`. 
    1. `components`
      This is the set of components. 

2. `portal`
  This is a [After.js](https://github.com/jaredpalmer/after.js) based project that is hosted on [weddingbazaar.com](weddingbazaar.com)
  We're using `After.js` as it gives [Server Side Rendering](https://github.com/zeit/next.js) out of the box, and uses a simple-to-grasp [ReactRouter](https://github.com/reacttraining/react-router). 
  The directories inside `src` are pages that use the `core` for `ui`.
  To start the server run `yarn start` inside `packages/portal`.


## Installing dependencies
For the first install, run `yarn` in the base directory. 
To add any dependencies to a package, run `yarn add *dependency package*` in the respective package base. 

## Running 
1. Compiling the `core`
  Inside `packages/core`
  `yarn watch`
  `yarn build`
2. Using Docz in the `core`
  Inside `packages/core`
  `yarn docz:dev`
  `yarn docz:build`
3. Running the dev server for the `portal`
  Inside `packages/portal`
  `yarn start`
4. Generating optimised files for deployment of the `portal`
  Inside `packages/core`
  `yarn build`
5. Starting the production server for the `portal`
  Inside `packages/core`
  `yarn start:prod`