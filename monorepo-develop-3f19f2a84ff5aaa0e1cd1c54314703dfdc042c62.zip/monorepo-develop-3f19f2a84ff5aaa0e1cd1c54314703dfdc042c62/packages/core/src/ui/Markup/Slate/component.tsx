import * as React from "react";
import { createEditor, Editor, Range, Transforms } from "slate";
import {
  Editable,
  ReactEditor,
  RenderElementProps,
  RenderLeafProps,
  Slate,
  useEditor,
  useFocused,
  useSelected,
  useSlate,
  withReact
} from "slate-react";
import styled from "styled-components";
import action from "./actions";

const LIST_TYPES = [action.ol.format, action.ul.format];

interface FormatButtonProps {
  format: string;
  name: string;
}

interface ToggleProps {
  editor: ReactEditor;
  format: string;
}
interface InsertProps {
  editor: ReactEditor;
  url: any;
}

const DivButton = styled("div")<{ active: boolean }>`
color: ${props =>
  props.active ? props.theme.colors.white : props.theme.colors.black}
padding: 0.5rem;
border: ${props => `1px solid ${props.theme.colors.primary}`};
background-color: ${props =>
  props.active ? props.theme.colors.primary : props.theme.colors.primaryFill}
`;

const Icon = styled("span")``;

/**
 * MARK ELEMENT HELPER FUNCTION
 *
 */
export const MarkButton = ({ format, name }: FormatButtonProps) => {
  const editor = useSlate();
  return (
    <DivButton
      active={isMarkActive({ editor, format })}
      onMouseDown={event => {
        event.preventDefault();
        toggleMark({ editor, format });
      }}
    >
      <Icon>{name}</Icon>
    </DivButton>
  );
};

const isMarkActive = ({ editor, format }: ToggleProps) => {
  const marks = Editor.marks(editor);
  return marks ? marks[format] === true : false;
};
export const toggleMark = ({ editor, format }: ToggleProps) => {
  const isActive = isMarkActive({ editor, format });

  if (isActive) {
    Editor.removeMark(editor, format);
  } else {
    Editor.addMark(editor, format, true);
  }
};
/** MARK ELEMENT END */

/**
 * BLOCK ELEMENT HELPER FUNCTION
 *
 */
export const BlockButton = ({ format, name }: FormatButtonProps) => {
  const editor = useSlate();
  return (
    <DivButton
      active={isBlockActive({ editor, format })}
      onMouseDown={event => {
        event.preventDefault();
        toggleBlock({ editor, format });
      }}
    >
      <Icon>{name}</Icon>
    </DivButton>
  );
};
const isBlockActive = ({ editor, format }: ToggleProps) => {
  const [match] = Editor.nodes(editor, {
    match: n => n.type === format
  });

  return !!match;
};

const toggleBlock = ({ editor, format }: ToggleProps) => {
  const isActive = isBlockActive({ editor, format });
  const isList = LIST_TYPES.includes(format);

  Transforms.unwrapNodes(editor, {
    match: (n: any) => LIST_TYPES.includes(n.type),
    split: true
  });

  Transforms.setNodes(editor, {
    type: isActive ? "paragraph" : isList ? "list-item" : format
  });

  if (!isActive && isList) {
    const block = { type: format, children: [] };
    Transforms.wrapNodes(editor, block);
  }
};
/** BLOCK ELEMENT END */

/**
 * link Element helper
 *
 */
export const LinkButton = ({ format, name }: FormatButtonProps) => {
  const editor = useSlate();
  return (
    <DivButton
      active={isLinkActive({ editor })}
      onMouseDown={event => {
        event.preventDefault();
        const url = window.prompt("Enter the URL of the link:");
        if (!url) {
          return;
        }
        insertLink({ editor, url });
      }}
    >
      <Icon>{name}</Icon>
    </DivButton>
  );
};
const isLinkActive = ({ editor }: { editor: ReactEditor }) => {
  const [link] = Editor.nodes(editor, {
    match: n => n.type === action.link.format
  });
  return !!link;
};

const insertLink = ({ editor, url }: { editor: ReactEditor; url: string }) => {
  if (editor.selection) {
    wrapLink({ editor, url });
  }
};
export const wrapLink = ({ editor, url }: InsertProps) => {
  if (isLinkActive({ editor })) {
    unwrapLink({ editor });
  }

  const { selection } = editor;
  const isCollapsed = selection && Range.isCollapsed(selection);
  const link = {
    type: action.link.format,
    url,
    children: isCollapsed ? [{ text: url }] : []
  };

  if (isCollapsed) {
    Transforms.insertNodes(editor, link);
  } else {
    Transforms.wrapNodes(editor, link, { split: true });
    Transforms.collapse(editor, { edge: "end" });
  }
};
const unwrapLink = ({ editor }: { editor: ReactEditor }) => {
  Transforms.unwrapNodes(editor, {
    match: n => n.type === action.link.format
  });
};
/** END OF LINK ELEMENT */

/**
 * IMAGE ELEMENT HELPER FUNCTIONS
 *
 */
export const ImageButton = ({ format, name }: FormatButtonProps) => {
  const editor = useEditor();
  // const editor = useSlate();

  return (
    <DivButton
      active={isMarkActive({ editor, format })}
      onMouseDown={(event: any) => {
        event.preventDefault();
        const url = window.prompt("Enter the URL of the image:");
        if (!url) {
          return;
        }
        insertImage({ editor, url });
      }}
    >
      <Icon>{name}</Icon>
    </DivButton>
  );
};
export const ImageElement = ({ attributes, children, element }: any) => {
  const selected = useSelected();
  const focused = useFocused();
  return (
    <div {...attributes}>
      <div contentEditable={false}>
        <img
          loading="lazy"
          {...attributes}
          src={element.url}
          style={{
            display: "inline",
            // maxWidth: "100%",
            maxHeight: "20em",
            boxShadow: `${selected && focused ? "0 0 0 3px #B4D5FF" : "none"}`
          }}
        />
      </div>
      {children}
    </div>
  );
};
export const insertImage = ({ editor, url }: InsertProps) => {
  const text = { text: "" };
  const image = { type: action.image.format, url, children: [text] };
  Transforms.insertNodes(editor, image);
};
/** END OF IMAGE ELEMENT */

/**
 * Video Elemnent helper
 *
 */
export const VideoButton = ({ format, name }: FormatButtonProps) => {
  const editor = useEditor();
  // const editor = useSlate();

  return (
    <DivButton
      active={isMarkActive({ editor, format })}
      onMouseDown={(event: any) => {
        event.preventDefault();
        const url = window.prompt("Enter the URL of the video:");
        if (!url) {
          return;
        }
        insertVideo({ editor, url });
      }}
    >
      <Icon>{name}</Icon>
    </DivButton>
  );
};
export const VideoElement = ({ attributes, children, element }: any) => {
  const { url } = element;
  return (
    <div {...attributes}>
      <div contentEditable={false}>
        <div
          style={{
            padding: "75% 0 0 0",
            position: "relative"
          }}
        >
          <iframe
            src={`${url}?title=0&byline=0&portrait=0`}
            frameBorder="0"
            style={{
              position: "absolute",
              top: "0",
              left: "0",
              width: "100%",
              height: "100%"
            }}
          />
        </div>
      </div>
      {children}
    </div>
  );
};
export const insertVideo = ({ editor, url }: InsertProps) => {
  const text = { text: "" };
  const video = { type: action.embedVideo.format, url, children: [text] };
  Transforms.insertNodes(editor, video);
};
/** END OF VIDEO ELEMENT  */
