import imageExtensions from "image-extensions";
import isHotkey from "is-hotkey";
import isUrl from "is-url";
import * as React from "react";
import { createEditor, Editor, Range, Transforms } from "slate";
import { withHistory } from "slate-history";
import {
  Editable,
  ReactEditor,
  RenderElementProps,
  RenderLeafProps,
  Slate,
  useEditor,
  useFocused,
  useSelected,
  useSlate,
  withReact
} from "slate-react";
import action from "./actions";

import styled from "styled-components";
import { H1, H2, H3, H4, Paragraph, Text } from "../../atoms";
import {
  BlockButton,
  ImageButton,
  ImageElement,
  insertImage,
  insertVideo,
  LinkButton,
  MarkButton,
  toggleMark,
  VideoButton,
  VideoElement,
  wrapLink
} from "./component";

interface RichTextAreaProps {
  value: any;
  isEditable: boolean;
  placeholder?: string;
  onChange?: (data: any) => void;
  onSave?: (data: any) => void;
}

const Toolbar = styled("div")`
  display: flex;
  flex-wrap: wrap;
`;

const isImageUrl = (url: any) => {
  if (!url) {
    return false;
  }
  if (!isUrl(url)) {
    return false;
  }
  const ext: string = new URL(url).pathname.split(".").pop() || "";
  return imageExtensions.includes(ext);
};

const BUTTONS = [
  {
    component: MarkButton,
    buttons: [
      action.bold,
      action.italic,
      action.underline,
      action.strikeThrough,
      action.subscript,
      action.superscript
    ]
  },
  {
    component: ImageButton,
    buttons: [action.image]
  },
  {
    component: VideoButton,
    buttons: [action.embedVideo]
  },
  {
    component: LinkButton,
    buttons: [action.link]
  },
  {
    component: BlockButton,
    buttons: [action.h1, action.h2, action.h3, action.h4]
  },
  {
    component: BlockButton,
    buttons: [action.blockquote, action.ol, action.ul]
  },
  {
    component: BlockButton,
    buttons: [action.left, action.right, action.center, action.justify]
  }
  // { paragraph: ['formatOLSimple', 'formatOL', 'formatUL'] },
  // { rich: ['insertLink', 'insertImage', 'insertVideo', 'insertTable', 'emoticons', 'fontAwesome', 'specialCharacters', 'embedly', 'insertFile', 'insertHR'] },
];
const blankSlateValue = [{ type: "paragraph", children: [{ text: "" }] }];
export const RichTextArea: React.FC<RichTextAreaProps> = props => {
  const renderElement = React.useCallback(ps => <Element {...ps} />, []);
  const renderLeaf = React.useCallback(ps => <Leaf {...ps} />, []);
  const editor = React.useMemo(
    () =>
      withEmbedVideo(
        withImages(withLinks(withHistory(withReact(createEditor()))))
      ),
    []
  );
  const [nodeValues, setnodeValues] = React.useState(
    props.value || blankSlateValue
  );
  return (
    <Slate
      editor={editor}
      value={nodeValues}
      onChange={(sd: any) => {
        // console.log("CDH___", sd);
        setnodeValues(sd);
        if (props.onChange) {
          props.onChange(sd);
        }
      }}
    >
      {props.isEditable && (
        <Toolbar>
          {BUTTONS.map(group => {
            const Comp = group.component;
            return group.buttons.map(button => (
              <Comp key={button.name} {...button} />
            ));
          })}
          <Text color="gray2" margin="auto major-1" fontSize={100}>
            {nodeValues !== blankSlateValue && props.value !== nodeValues
              ? "unsaved changes"
              : ""}
          </Text>
        </Toolbar>
      )}
      <Editable
        readOnly={!props.isEditable}
        renderElement={renderElement}
        renderLeaf={renderLeaf}
        placeholder={
          props.placeholder ? props.placeholder : "Enter some rich text…"
        }
        spellCheck={true}
        autoFocus={true}
        onKeyDown={event => {
          if (props.onSave && isHotkey(SAVE_KEY)(event as any)) {
            event.preventDefault();
            props.onSave(nodeValues);
          }
          for (const hotkey in HOTKEYS) {
            if (isHotkey(hotkey)(event as any)) {
              event.preventDefault();
              const mark = HOTKEYS[hotkey];
              toggleMark({ editor, format: mark });
            }
          }
        }}
      />
    </Slate>
  );
};
const SAVE_KEY = "mod+s";

const HOTKEYS = {
  "mod+b": action.bold.format,
  "mod+i": action.italic.format,
  "mod+u": action.underline.format,

  "mod+ctrl+i": action.blockquote.format
};

const Element = ({ attributes, children, element }: RenderElementProps) => {
  // console.log("EL", element, attributes);
  switch (element.type) {
    case action.blockquote.format:
      return <blockquote {...attributes}>{children}</blockquote>;
    case action.ul.format:
      return <ul {...attributes}>{children}</ul>;
    case action.li.format:
      return <li {...attributes}>{children}</li>;
    case action.ol.format:
      return <ol {...attributes}>{children}</ol>;
    case action.left.format:
      return (
        <Paragraph style={{ textAlign: "left" }} {...attributes}>
          {children}
        </Paragraph>
      );
    case action.right.format:
      return (
        <Paragraph style={{ textAlign: "right" }} {...attributes}>
          {children}
        </Paragraph>
      );
    case action.center.format:
      return (
        <Paragraph style={{ textAlign: "center" }} {...attributes}>
          {children}
        </Paragraph>
      );
    case action.justify.format:
      return (
        <Paragraph style={{ textAlign: "justify" }} {...attributes}>
          {children}
        </Paragraph>
      );
    case action.link.format:
      return (
        <a {...attributes} href={(element.url as unknown) as string}>
          {children}
        </a>
      );
    case action.image.format:
      return <ImageElement {...{ attributes, children, element }} />;
    case action.embedVideo.format:
      return <VideoElement {...{ attributes, children, element }} />;
    case action.h1.format:
      return <H1 {...attributes}>{children}</H1>;
    case action.h2.format:
      return <H2 {...attributes}>{children}</H2>;
    case action.h3.format:
      return <H3 {...attributes}>{children}</H3>;
    case action.h4.format:
      return <H4 {...attributes}>{children}</H4>;
    default:
      return <Paragraph {...attributes}>{children}</Paragraph>;
  }
};

const Leaf = ({ attributes, children, leaf }: RenderLeafProps) => {
  const { text, ...styles } = leaf;
  // console.log("LEAF::::", styles, leaf, attributes);

  Object.keys(styles).forEach(style => {
    children = (
      <Text as={style as keyof JSX.IntrinsicElements}>{children}</Text>
    );
  });

  return (
    <Text as="span" {...attributes}>
      {children}
    </Text>
  );
};

const withLinks = (editor: ReactEditor) => {
  const { insertData, insertText, isInline } = editor;

  editor.isInline = element => {
    return element.type === action.link.format ? true : isInline(element);
  };

  editor.insertText = text => {
    if (text && isUrl(text)) {
      wrapLink({ editor, url: text });
    } else {
      insertText(text);
    }
  };

  editor.insertData = data => {
    const text = data.getData("text/plain");

    if (text && isUrl(text)) {
      wrapLink({ editor, url: text });
    } else {
      insertData(data);
    }
  };

  return editor;
};
const withImages = (editor: ReactEditor) => {
  const { insertData, isVoid } = editor;
  editor.isVoid = (element: any) => {
    return element.type === action.image.format ? true : isVoid(element);
  };
  editor.insertData = (data: any) => {
    const text = data.getData("text/plain");
    const { files } = data;
    if (files && files.length > 0) {
      for (const file of files) {
        const reader = new FileReader();
        const [mime] = file.type.split("/");
        if (mime === "image") {
          reader.addEventListener("load", () => {
            const url = reader.result;
            insertImage({ editor, url });
          });
          reader.readAsDataURL(file);
        }
      }
    } else if (isImageUrl(text)) {
      insertImage({ editor, url: text });
    } else {
      insertData(data);
    }
  };
  return editor;
};
const withEmbedVideo = (editor: ReactEditor) => {
  const { insertData, isVoid } = editor;
  editor.isVoid = (element: any) => {
    return element.type === action.embedVideo.format ? true : isVoid(element);
  };
  editor.insertData = (data: any) => {
    const text = data.getData("text/plain");
    const { files } = data;
    if (files && files.length > 0) {
      for (const file of files) {
        const reader = new FileReader();
        const [mime] = file.type.split("/");
        if (mime === "video") {
          reader.addEventListener("load", () => {
            const url = reader.result;
            insertVideo({ editor, url });
          });
          reader.readAsDataURL(file);
        }
      }
    } else if (isImageUrl(text)) {
      insertVideo({ editor, url: text });
    } else {
      insertData(data);
    }
  };
  return editor;
};
