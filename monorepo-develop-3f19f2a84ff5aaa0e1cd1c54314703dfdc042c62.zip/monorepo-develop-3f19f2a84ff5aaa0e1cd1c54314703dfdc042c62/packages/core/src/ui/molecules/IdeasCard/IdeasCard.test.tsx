import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { IdeasCard, IdeasCardProps } from "./IdeasCard";

afterEach(cleanup);

const props: IdeasCardProps = {
  image: { url: "https://picsum.photos/id/1047/700" },
  title: "Wedding photography",
  content: `While time travel remains a distant dream, we do have the luxury of
      mimicking it through photos and videos. Boon or bane, our memory is
      short lived`,
  onAction: () => null
};

describe("IdeasCard:", () => {
  it("renders correctly", () => {
    const { container } = render(<IdeasCard {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
