import * as React from "react";
import styled from "styled-components";
import { defaultStyles, DefaultStyles } from "../../../utils/ui.utils";
import { Button } from "../../atoms/Button/Button";
import { Pane } from "../../atoms/Pane/Pane";
import { PictureTag } from "../../atoms/PictureTag/PictureTag";
import { Text } from "../../atoms/Typography/Typography";
import { Media } from "../../types";

export interface IdeasCardProps {
  image?: Media;
  title: string;
  content: string | JSX.Element;
  onAction?: () => void;
}

const StyledPane = styled(Pane)`
  display: grid;
  // grid-template-rows: 2fr 1fr;
  grid-template-areas:
    "pane-image"
    "pane-content"
    "pane-action";
  ${props => props.theme.media.mobile} {
    grid-template-areas:
      "pane-image"
      "pane-content"
      "pane-action";
  }
`;
const IdeasCardImage = styled("div")`
  grid-area: pane-image;
  overflow: hidden;
`;
export const IdeasCardContent = styled("div")<DefaultStyles>`
  ${defaultStyles}
  grid-area: pane-content;
  & > ${Text}:first-child {
    text-align: center;
  }
`;
export const IdeasCardAction = styled.div<DefaultStyles>`
  ${defaultStyles}
  text-align: center;
`;
export const IdeasCard: React.FC<IdeasCardProps> = React.memo(
  ({ title, content, image, onAction }) => {
    return (
      <StyledPane>
        {image && (
          <IdeasCardImage>
            <PictureTag image={image.url} alt={image.alt} />
          </IdeasCardImage>
        )}
        <IdeasCardContent padding="major-1">
          <Text
            fontSize={200}
            fontWeight="medium"
            color={"primary"}
            padding="major-1 major-0"
          >
            {title}
          </Text>
          <Text
            fontSize={150}
            fontWeight="regular"
            color={"gray1"}
            textAlign="center"
          >
            {content}
          </Text>
          <IdeasCardAction padding="major-1">
            <Button palette="secondary">
              {!!onAction && (
                <Text fontWeight="medium" fontSize={150} onClick={onAction}>
                  Read now
                </Text>
              )}
            </Button>
          </IdeasCardAction>
        </IdeasCardContent>
      </StyledPane>
    );
  }
);
