import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { CarouselBanner, CarouselBannerProps } from "./CarouselBanner";

afterEach(cleanup);

const props: CarouselBannerProps = {
  title: "Title"
  // moreAction: ()=> null;
};

describe("CarouselBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(<CarouselBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
