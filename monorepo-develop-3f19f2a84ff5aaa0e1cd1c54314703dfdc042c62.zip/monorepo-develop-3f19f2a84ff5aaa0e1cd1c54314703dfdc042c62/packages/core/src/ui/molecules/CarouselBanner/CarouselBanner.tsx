import * as React from "react";
import styled from "styled-components";
import { Button, H3, Pane } from "../..";
import { Carousel } from "../../components/Carousel/Carousel";
import { ThemeColors } from "../../types/theme";
export interface CarouselBannerProps {
  title: string | React.ReactNode;
  more?: { action: () => void; text: string };
  background?: keyof ThemeColors;
  showIndicators?: boolean;
  autoChangeIn?: number | null;
}

const CarouselBannerDiv = styled("div")<{ background?: keyof ThemeColors }>`
  background-color: ${props => props.theme.colors[props.background || "white"]};
  text-align: center;
  padding: 1rem;
  ${props => props.theme.media.desktop} {
    margin: 0 -12.5%;
    padding: 2rem 20vw;
  }
  ${Pane} {
    padding: 1rem;
  }
`;

export const CarouselBanner: React.FC<CarouselBannerProps> = React.memo(
  props => (
    <CarouselBannerDiv background={props.background}>
      <H3 margin="major-4 major-1">{props.title}</H3>
      <Carousel
        showControls={false}
        autoChangeIn={props.autoChangeIn || null}
        showIndicators={props.showIndicators || false}
        showPreviews="desktop"
      >
        {props.children as React.ReactNodeArray}
      </Carousel>
      {props.more && (
        <Button margin="major-4 major-1" onClick={props.more.action}>
          {props.more.text}
        </Button>
      )}
    </CarouselBannerDiv>
  )
);
