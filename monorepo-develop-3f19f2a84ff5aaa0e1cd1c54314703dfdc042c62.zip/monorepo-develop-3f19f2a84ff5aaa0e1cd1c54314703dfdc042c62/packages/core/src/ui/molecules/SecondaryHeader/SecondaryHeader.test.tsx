import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { SecondaryHeader, SecondaryHeaderProps } from "./SecondaryHeader";

afterEach(cleanup);

const props: SecondaryHeaderProps = {
  title: "am fancy header",
  showMore: { text: "more", url: "/more" }
};

describe("SecondaryHeader:", () => {
  it("renders correctly", () => {
    const { container } = render(<SecondaryHeader {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
