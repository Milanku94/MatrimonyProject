import * as React from "react";
import styled from "styled-components";

import { H2, H3, SiteIcon, StyledLink } from "../../atoms";

export interface SecondaryHeaderProps {
  title: string;
  showMore?: { text: string; url: string };
}
const SecondaryHeaderContainer = styled("div")``;
const TitleDiv = styled("div")<{ showMore?: boolean }>`
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  hr {
    position: absolute;
    border-top: 1px solid ${props => props.theme.colors.gray4};
    width: 100%;
    z-index: 0;
    background: ${props => props.theme.colors.gray5};
    transform: translateY(2px);
    ${props => props.theme.media.mobile} {
      display: none;
    }
  }
  ${H2}, a {
    z-index: 1;
    background: ${props => props.theme.colors.gray5};
  }
  ${H2} {
    padding-right: 0.5rem;
  }
  a {
    padding-left: 0.5rem;
    ${props => props.theme.media.mobile} {
      align-self: flex-end;
      width: 25%;
      text-align: right;
    }
  }
`;

const UnStyledSecondaryHeader: React.FC<SecondaryHeaderProps> = ({
  title,
  showMore
}) => {
  return (
    <SecondaryHeaderContainer>
      <TitleDiv showMore={!!showMore}>
        <H2 fontSize={200} color="black" margin="0">
          {title}
        </H2>
        <hr />
        {showMore && (
          <StyledLink to={showMore.url}>
            <H3 fontSize={100} color="primary" margin="0">
              {showMore.text}
            </H3>
          </StyledLink>
        )}
      </TitleDiv>
    </SecondaryHeaderContainer>
  );
};
export const SecondaryHeader = styled(React.memo(UnStyledSecondaryHeader))``;
