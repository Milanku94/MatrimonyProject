import * as React from "react";
import styled from "styled-components";
import { defaultStyles, DefaultStyles } from "../../../utils/ui.utils";
import { Button } from "../../atoms/Button/Button";
import { Pane } from "../../atoms/Pane/Pane";
import { PictureTag } from "../../atoms/PictureTag/PictureTag";
import { Text } from "../../atoms/Typography/Typography";
import { theme } from "../../theme";
import { Media } from "../../types";

export interface TestimonialCardProps {
  image: Media;
  couple: string;
  location: string;
  content: string;
  onAction?: () => void;
}

const StyledPane = styled(Pane)`
  margin: 0.25rem;
  display: grid;
  // grid-template-rows: 2fr 1fr;
  grid-template-areas:
    "pane-image"
    "pane-content"
    "pane-action";
  ${props => props.theme.media.mobile} {
    grid-template-areas:
      "pane-image"
      "pane-content"
      "pane-action";
  }
`;
const IdeasCardImage = styled("div")<DefaultStyles>`
  ${defaultStyles}
  grid-area: pane-image;
`;
const IdeasCardContent = styled("div")<DefaultStyles>`
  ${defaultStyles}
  grid-area: pane-content;
`;
const IdeasCardAction = styled.div<DefaultStyles>`
  ${defaultStyles}
  text-align: center;
`;
export const TestimonialCard: React.FC<TestimonialCardProps> = React.memo(
  ({ couple, location, image, content, onAction }) => {
    return (
      <StyledPane>
        <IdeasCardImage margin="major-0 auto">
          <PictureTag
            alt={image.alt}
            image={image.url}
            width={"100px"}
            height={"100px"}
            rounded={true}
            forceJPG={true}
            fullWidth={false}
          />
        </IdeasCardImage>
        <IdeasCardContent padding="major-1">
          <Text
            textAlign="center"
            fontSize={200}
            fontWeight="medium"
            color={"black"}
            paddingTop="major-1"
          >
            {couple}
          </Text>
          <Text
            textAlign="center"
            fontSize={150}
            fontWeight="regular"
            color={"gray1"}
          >
            {location}
          </Text>
          <Text
            style={{
              borderTop: `1px solid ${theme.colors.primary}`,
              width: "3rem"
            }}
            textAlign="center"
            fontSize={150}
            fontWeight="regular"
            color="primary"
            margin="major-1 auto"
          />
          <Text
            fontSize={150}
            fontWeight="regular"
            color={"gray1"}
            textAlign="center"
          >
            {content}
          </Text>
          {onAction && (
            <IdeasCardAction padding="major-1">
              <Button palette="secondary" onClick={onAction}>
                <Text fontWeight="medium" fontSize={150}>
                  Read more reviews
                </Text>
              </Button>
            </IdeasCardAction>
          )}
        </IdeasCardContent>
      </StyledPane>
    );
  }
);
