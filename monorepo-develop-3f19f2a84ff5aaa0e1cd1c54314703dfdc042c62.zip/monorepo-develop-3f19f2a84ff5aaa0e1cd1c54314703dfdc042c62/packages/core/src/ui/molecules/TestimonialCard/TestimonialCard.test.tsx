import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { TestimonialCard, TestimonialCardProps } from "./TestimonialCard";

afterEach(cleanup);

const props: TestimonialCardProps = {
  image: { url: "https://picsum.photos/id/1047/700" },
  couple: "Deeps & Samnath",
  location: "Anna nagar, Chennai",
  content: `We were thrilled to find out that Bharat Matrimony could help us with
    wedding planning as well. Our wedding was praised by all our guests and we are
    extremely grateful to WeddingBazaar’s wedding assist team for helping us pull this off.`
};

describe("TestimonialCard:", () => {
  it("renders correctly", () => {
    const { container } = render(<TestimonialCard {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
