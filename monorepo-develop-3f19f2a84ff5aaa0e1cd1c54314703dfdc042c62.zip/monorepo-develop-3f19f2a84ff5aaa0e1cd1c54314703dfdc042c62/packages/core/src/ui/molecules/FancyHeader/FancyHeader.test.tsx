import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { FancyHeader, FancyHeaderProps } from "./FancyHeader";

afterEach(cleanup);

const props: FancyHeaderProps = {
  title: "am fancy header",
  hideHighlight: true,
  showMore: { text: "more", url: "/more" }
};

describe("FancyHeader:", () => {
  it("renders correctly", () => {
    const { container } = render(<FancyHeader {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
