import * as React from "react";
import styled from "styled-components";
import { H2, H3, SiteIcon, StyledLink } from "../../atoms";

export interface FancyHeaderProps {
  title: string;
  showMore?: { text: string; url: string };
  hideHighlight?: boolean;
}
const FancyHeaderContainer = styled("div")``;
const FancyLine = styled("div")`
  ${props => props.theme.media.mobile} {
    display: none;
  }
  text-align: center;
  span {
    display: inline-block;
    position: relative;
    color: ${props => props.theme.colors.primary};
  }
  span:before,
  span:after {
    content: "";
    position: absolute;
    height: 5px;
    border-bottom: 1px solid ${props => props.theme.colors.primary};
    top: 7px;
    width: 5rem;
  }
  span:before {
    right: 100%;
    margin-right: 15px;
  }
  span:after {
    left: 100%;
    margin-left: 15px;
  }
`;
const TitleDiv = styled("div")<{ showMore?: boolean }>`
  display: flex;
  text-align: center;
  justify-content: ${props => (props.showMore ? "space-between" : "center")};
  ${H2} {
    color: ${props => props.theme.colors[props.showMore ? "black" : "primary"]};
  }
  ${props => props.theme.media.mobile} {
    flex-flow: column;
    padding: 1rem 2rem;
    ${StyledLink} {
      display: none;
    }
    ${H2} {
      color: ${props => props.theme.colors.primary};
    }
  }
`;

export const FancyHeader: React.FC<FancyHeaderProps> = ({
  title,
  showMore,
  hideHighlight
}) => (
  <FancyHeaderContainer>
    <TitleDiv showMore={!!showMore}>
      <H2 fontSize={200} margin="0">
        {title}
      </H2>
      {showMore && (
        <StyledLink to={showMore.url}>
          <H3 fontSize={100} color="primary" margin="0">
            {showMore.text}
          </H3>
        </StyledLink>
      )}
    </TitleDiv>
    {!hideHighlight && (
      <FancyLine>
        <span>
          <SiteIcon
            name={"ribbon"}
            style={{
              width: "1rem",
              height: "1rem",
              margin: 0
            }}
          />
        </span>
      </FancyLine>
    )}
  </FancyHeaderContainer>
);
