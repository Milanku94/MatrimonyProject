import * as React from "react";
import styled from "styled-components";
import { DomainContext } from "../../../contexts/DomainContext";
import { defaultStyles, DefaultStyles } from "../../../utils/ui.utils";
import { Paragraph, Text } from "../../atoms/Typography/Typography";

const logoConfig = {
  writer: "writer",
  mbazaar: "WeddingBazaar",
  mphoto: "photography"
};

const LogoDiv = styled.div<LogoProps>`
  ${defaultStyles}
  text-align: ${props => (props.size === "small" ? "none" : "center")};
  span {
    ${props => props.theme.media.desktop} {
      font-weight: ${props => props.theme.fontWeight.semiBold} !important;
    }
  }
`;
export interface LogoProps extends DefaultStyles {
  size: "small" | "large";
  type?: "weddingAssist";
}
const Img = styled.img<LogoProps>`
  height: ${props => (props.size === "large" ? "1.7rem" : "1.3rem")};
  display: block;
  margin: 0 auto;
`;

const UnstyledLogo: React.FC<LogoProps> = React.memo(props => {
  const { domain } = React.useContext(DomainContext);
  if (props.type && props.type === "weddingAssist") {
    return (
      <LogoDiv {...props}>
        <Img
          {...props}
          src="//www.weddingbazaar.com/assets/img/wed-assist-logo.png"
        />
      </LogoDiv>
    );
  }
  return (
    <LogoDiv {...props}>
      <span>
        {domain !== "mbazaar" && (
          <Text as="span" fontWeight="medium" fontSize={300} color="accent2">
            matrimony
          </Text>
        )}
        <Text
          as="span"
          fontWeight="medium"
          fontSize={300}
          color={domain === "mbazaar" ? "primary" : "accent1"}
        >
          {logoConfig[domain]}
        </Text>
      </span>
      <Paragraph
        fontSize={100}
        fontWeight="light"
        marginTop="!minor-2"
        marginBottom="minor-0"
      >
        from Matrimony.com group
      </Paragraph>
    </LogoDiv>
  );
});

export const Logo = styled(UnstyledLogo)``;
