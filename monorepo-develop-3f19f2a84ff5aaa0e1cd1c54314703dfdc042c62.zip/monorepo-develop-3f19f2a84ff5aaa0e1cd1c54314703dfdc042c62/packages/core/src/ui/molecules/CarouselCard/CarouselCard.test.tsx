import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { CarouselCard, CarouselCardProps } from "./CarouselCard";

afterEach(cleanup);

const props: CarouselCardProps = {};

describe("CarouselCard:", () => {
  it("renders correctly", () => {
    const { container } = render(<CarouselCard {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
