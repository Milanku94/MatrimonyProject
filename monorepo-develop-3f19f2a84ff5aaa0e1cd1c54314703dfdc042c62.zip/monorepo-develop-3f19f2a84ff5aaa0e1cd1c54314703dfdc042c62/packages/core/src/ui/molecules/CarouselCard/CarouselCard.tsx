import * as React from "react";
import styled from "styled-components";

import { SiteIcon } from "../../atoms";

export interface CarouselCardProps {
  scrollSteps?: number;
}
const Container = styled("div")`
  display: flex;
  align-items: center;
`;

const CarouselCardDiv = styled("div")`
  margin: 1rem 0;
  overflow-x: hidden;
  display: flex;
  ${props => props.theme.media.mobile} {
    overflow-x: auto;
  }
`;
const NavSpan = styled("span")`
  ${props => props.theme.media.mobile} {
    display: none;
  }
`;
const iconStyle = {
  width: "1.3rem",
  height: "1.3rem",
  margin: ".5rem",
  fill: "white",
  background: "#00000033",
  padding: ".5rem",
  borderRadius: "50%"
};

export const CarouselCard: React.FC<CarouselCardProps> = props => {
  const carouselRef = React.useRef<HTMLDivElement>(null);
  const scrollSteps = props.scrollSteps || 19 * 18;
  const handleNav = (direction: "right" | "left") => {
    carouselRef.current!.scrollLeft =
      carouselRef.current!.scrollLeft +
      scrollSteps * (direction === "right" ? 1 : -1);
  };

  return (
    <Container>
      <NavSpan>
        <SiteIcon
          name={"expand-less"}
          style={iconStyle}
          onClick={() => handleNav("left")}
        />
      </NavSpan>
      <CarouselCardDiv ref={carouselRef}>{props.children}</CarouselCardDiv>
      <NavSpan>
        <SiteIcon
          name={"expand-more"}
          style={iconStyle}
          onClick={() => handleNav("right")}
        />
      </NavSpan>
    </Container>
  );
};
