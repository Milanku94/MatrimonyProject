import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { WeddingCard, WeddingCardProps } from "./WeddingCard";

afterEach(cleanup);

const props: WeddingCardProps = {
  image: { url: "https://picsum.photos/id/1047/700" },
  couple: "Deeps & Samnath",
  location: "Anna nagar, Chennai"
};

describe("WeddingCard:", () => {
  it("renders correctly", () => {
    const { container } = render(<WeddingCard {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
