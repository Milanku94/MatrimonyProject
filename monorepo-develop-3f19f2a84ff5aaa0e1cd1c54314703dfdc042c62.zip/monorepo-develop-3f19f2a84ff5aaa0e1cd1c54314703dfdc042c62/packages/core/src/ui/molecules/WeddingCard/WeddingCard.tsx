import * as React from "react";
import styled from "styled-components";
import { Text } from "../../";
import { defaultStyles, DefaultStyles } from "../../../utils/ui.utils";
import { Button } from "../../atoms/Button/Button";
import { Pane } from "../../atoms/Pane/Pane";
import { PictureTag } from "../../atoms/PictureTag/PictureTag";
import { Media } from "../../types";

export interface WeddingCardProps extends DefaultStyles {
  image: Media;
  couple: string;
  location: string;
}

const StyledPane = styled(Pane)<DefaultStyles>`
  display: grid;
  grid-template-columns: 2fr 1fr;
  grid-template-rows: 2fr 1fr;
  min-width: 25vw;
  height: 13rem;
  grid-template-areas:
    "pane-image pane-image"
    "pane-content pane-action";
  ${props => props.theme.media.mobile} {
    min-width: 75vw;
    grid-template-areas:
      "pane-image pane-image"
      "pane-content pane-content";
  }
  ${defaultStyles}
`;
const WeddingCardImage = styled("div")`
  grid-area: pane-image;
  overflow: hidden;
`;
const WeddingCardContent = styled("div")<DefaultStyles>`
  ${defaultStyles}
  grid-area: pane-content;
  ${Text} {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: calc(16vw - 1rem);
    ${props => props.theme.media.mobile} {
      width: inherit;
    }
  }
  ${Text}:hover {
    overflow: visible;
  }
`;
const WeddingCardAction = styled(Button)<DefaultStyles>`
  ${defaultStyles}
  float: right;
  grid-area: pane-action;
  ${props => props.theme.media.mobile} {
    display: none;
  }
`;
export const WeddingCard: React.FC<WeddingCardProps> = React.memo(
  ({ couple, location, image, ...props }) => {
    return (
      <StyledPane elevation="8" {...props}>
        <WeddingCardImage>
          <PictureTag
            image={image.url}
            alt={image.alt}
            height="250px"
            transition="zoom"
          />
        </WeddingCardImage>
        <WeddingCardContent padding="major-2 major-0 major-2 major-2">
          <Text fontSize={150} fontWeight="medium" title={couple}>
            {couple}
          </Text>
          <Text fontSize={100} fontWeight="regular" color={"gray1"}>
            {location}
          </Text>
        </WeddingCardContent>
        <WeddingCardAction palette="secondary" padding="major-2">
          <Text
            as="span"
            fontWeight="medium"
            textAlign="right"
            fontSize={100}
            color="primary"
          >
            Read Now
            {/* <SiteIcon name="chevron-right" /> */}
          </Text>
        </WeddingCardAction>
      </StyledPane>
    );
  }
);
