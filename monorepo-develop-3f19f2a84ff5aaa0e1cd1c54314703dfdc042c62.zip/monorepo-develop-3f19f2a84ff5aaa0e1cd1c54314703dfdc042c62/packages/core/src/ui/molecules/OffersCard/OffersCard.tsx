import * as React from "react";
import styled from "styled-components";
import { Button } from "../../atoms/Button/Button";
import { SiteIcon } from "../../atoms/Icon/Icon";
import { PictureTag } from "../../atoms/PictureTag/PictureTag";
import { Paragraph, Text } from "../../atoms/Typography/Typography";
import { theme } from "../../theme";
import { ThemeColors } from "../../types/theme";
export interface OffersCardProps {
  title: string;
  description: string;
  endDate: any;
  profileName: string;
  city: string;
  onAction: (args: any) => void;
  category: { name: string; slug: string };
  image: {
    tile?: string;
    cover?: string;
    tc?: string;
    coverDefault: string;
    tileDefault: string;
  };
  code?: string;
  complementaryDesc?: string;
  flatValue?: number;
  percentageValue?: number;
  originalPrice?: number;
  background?: keyof ThemeColors;
  maskColor?: keyof ThemeColors;
}

const OffersCardContent = styled("div")<{ background?: keyof ThemeColors }>`
  background: ${props => props.theme.colors[props.background || "gray5"]};
  padding-bottom: 1rem;
  ${Button} {
    display: flex;
    margin: 0 auto;
  }
`;
const TitleContainer = styled("div")`
  display: flex;
  justify-content: space-between;
`;
const FancyLine = styled("div")<{ maskColor?: keyof ThemeColors }>`
  content: "";
  height: 2rem;
  border-bottom: 2px dashed
    ${props => props.theme.colors[props.maskColor || "gray5"]};
  bottom: 50%;
  display: flex;
  position: relative;
`;
const OffersCardContainer = styled("div")``;
const OffersCardPreviewDiv = styled("div")<{ code: any }>`
  background: ${props => props.theme.colors.white};
  max-height: calc(85vh - 200px);
  overflow-y: auto;
`;

const OfferBasicDiv = styled("div")<{ maskColor?: keyof ThemeColors }>`
  padding: 0.5rem 1rem 0;
  ${Text} {
    display: flex;
    align-items: center;
    text-transform: capitalize;
  }
`;

const OfferDiv = styled("div")<{ code: boolean }>`
  margin: 0.5rem 1rem;
  ${Text} {
    text-transform: capitalize;
  }
`;
const BlankDiv = styled("div")`
  height: 0.5rem;
  background: #ffffff00;
`;

const RedeemDiv = styled("div")<{ code: boolean }>`
  display: flex;
  align-items: center;
  flex-direction: row-reverse;
  margin: 0.5rem 1rem;
  gap: 0.5rem;
  div {
    cursor: pointer;
  }
`;
const OffersDetailDiv = styled("div")`
  padding: 0.5rem 1rem;
  text-align: justify;
  ${Paragraph} {
    line-height: inherit;
  }
`;

const CardRupture = styled("div")<{ maskColor?: keyof ThemeColors }>`
  height: 2rem;
  background: radial-gradient(
      circle at 0 50%,
      ${props => props.theme.colors[props.maskColor || "white"]} var(--r, 12px),
      #ffffff00 0
    ),
    radial-gradient(
      circle at 100% 50%,
      ${props => props.theme.colors[props.maskColor || "white"]} var(--r, 12px),
      #ffffff00 0
    );
`;
const RedeemCode = styled("div")`
  text-align: center;
  border: dashed ${props => props.theme.colors.primary} 1px;
  background: ${props => props.theme.colors.primaryFill};
  max-width: 10rem;
  min-width: 8rem;
`;
const DiscountFragement = styled("span")`
  margin: 0 0.5em;
  s {
    color: ${props => props.theme.colors.gray2};
  }
  span {
    color: ${props => props.theme.colors.primary};
  }
`;
const DiscountHightLightSpan: React.FC<Pick<
  OffersCardProps,
  "flatValue" | "percentageValue" | "originalPrice"
>> = ({ flatValue, percentageValue, originalPrice }) => (
  <DiscountFragement>
    {flatValue && !originalPrice && !percentageValue && (
      <span>₹ {flatValue} Flat Discount</span>
    )}
    {percentageValue && !flatValue && !originalPrice && (
      <span>{Math.ceil(percentageValue)}% Discount</span>
    )}
    {flatValue && percentageValue && !originalPrice && (
      <span>
        ₹ {flatValue} Flat + {percentageValue}% OFF
      </span>
    )}
    {flatValue && originalPrice && (
      <>
        <s>₹ {originalPrice}</s>
        <span> ₹ {flatValue}</span>
      </>
    )}
  </DiscountFragement>
);
export const OffersCard: React.FC<OffersCardProps> = props => {
  const {
    maskColor,
    background,
    category,
    title,
    image,
    complementaryDesc,
    flatValue,
    percentageValue,
    originalPrice,
    endDate,
    code,
    onAction
  } = props;
  return (
    <OffersCardContainer>
      <PictureTag
        height={"200px"}
        image={image.tile || image.tileDefault}
        forceJPG={!!image.tile}
      />
      <OffersCardContent background={background}>
        <OfferBasicDiv>
          <Text fontSize={100}>
            <SiteIcon
              name={"discount"}
              style={{
                height: ".75rem",
                fill: theme.colors.gray1,
                margin: "0.25rem"
              }}
            />
            {title}
            <DiscountHightLightSpan
              originalPrice={originalPrice}
              flatValue={flatValue}
              percentageValue={percentageValue}
            />
          </Text>
          <Text fontSize={100}>
            <SiteIcon
              name={category.slug}
              style={{ margin: "0.25rem", fill: theme.colors.gray1 }}
            />
            {category.name}
          </Text>
          <Text fontSize={100}>
            <SiteIcon
              name={"timer"}
              style={{
                margin: "0.25rem",
                height: ".75rem",
                fill: theme.colors.gray1
              }}
            />
            {`Valid Upto ${new Date(endDate)
              .toDateString()
              .split(" ")
              .slice(1)
              .join(" ")}`}
          </Text>
        </OfferBasicDiv>
        <CardRupture maskColor={maskColor}>
          <FancyLine maskColor={maskColor} />
        </CardRupture>
        <Button palette="primary" onClick={() => onAction(props)}>
          {code ? "Get Offer Code" : "View Offer Details"}
        </Button>
      </OffersCardContent>
    </OffersCardContainer>
  );
};

const OfferDetails = ({
  title,
  endDate,
  code,
  flatValue,
  percentageValue,
  originalPrice
}: Pick<
  OffersCardProps,
  | "title"
  | "endDate"
  | "code"
  | "flatValue"
  | "percentageValue"
  | "originalPrice"
>) => (
  <OfferDiv code={!!code}>
    <Text fontSize={150} fontWeight={"medium"}>
      {" "}
      <SiteIcon
        name={"discount"}
        style={{
          margin: "0.25rem 0.25rem .25rem 0",
          height: ".75rem",
          fill: theme.colors.gray1
        }}
      />
      {title}
      <DiscountHightLightSpan
        originalPrice={originalPrice}
        flatValue={flatValue}
        percentageValue={percentageValue}
      />
    </Text>
    <Text fontSize={100}>
      {" "}
      <SiteIcon
        name={"timer"}
        style={{
          margin: "0.25rem 0.25rem .25rem 0",
          height: ".75rem",
          fill: theme.colors.gray1
        }}
      />
      {`Valid Upto ${new Date(endDate)
        .toDateString()
        .split(" ")
        .slice(1)
        .join(" ")}`}
    </Text>
  </OfferDiv>
);

const handleClipboardCopy = ({ code }: { code: string }) => {
  const textField = document.createElement("textarea");
  textField.innerText = code;
  document.body.appendChild(textField);
  textField.select();
  document.execCommand("copy");
  textField.remove();
  return true;
};
const RedeemCoupon = ({
  code,
  onAction
}: {
  code: string;
  onAction: (args: any) => void;
}) => {
  const [isReveal, setReveal] = React.useState(false);
  const redeemRef = React.useRef<HTMLDivElement>(null);
  return (
    <RedeemDiv code={!!code}>
      {!isReveal && (
        <Button palette="primary" onClick={() => setReveal(true)}>
          Get Offer Code
        </Button>
      )}
      {isReveal && (
        <>
          <div
            onClick={() => handleClipboardCopy({ code }) && onAction({ code })}
          >
            <SiteIcon
              name={"copy-document"}
              style={{
                margin: "0.25rem ",
                height: ".75rem",
                fill: theme.colors.gray1
              }}
            />
          </div>
          <RedeemCode
            ref={redeemRef}
            onClick={() => handleClipboardCopy({ code }) && onAction({ code })}
          >
            {code}
          </RedeemCode>
        </>
      )}
    </RedeemDiv>
  );
};
export const OffersPreview: React.FC<OffersCardProps> = ({
  maskColor,
  complementaryDesc,
  title,
  image,
  profileName,
  description,
  endDate,
  flatValue,
  percentageValue,
  originalPrice,
  city,
  code,
  onAction
}) => {
  return (
    <>
      <OffersCardContainer>
        <PictureTag
          height={"200px"}
          image={image.cover || image.coverDefault}
          forceJPG={!!image.cover}
        />
        <OffersCardPreviewDiv code={code}>
          <TitleContainer>
            <OfferBasicDiv>
              <Text fontSize={150} fontWeight={"medium"}>
                <SiteIcon
                  name={"pointer-icon"}
                  style={{
                    margin: "0 0.25rem 0 0",
                    fill: "none",
                    height: ".75rem",
                    stroke: theme.colors.gray1
                  }}
                />
                {profileName}
              </Text>
              <Text fontSize={100}>
                <SiteIcon
                  name={"location-on"}
                  style={{
                    margin: "0 0.25rem 0 0",
                    fill: "none",
                    height: ".75rem",
                    stroke: theme.colors.gray1
                  }}
                />
                {city}
              </Text>
            </OfferBasicDiv>
            {code && <RedeemCoupon code={code} onAction={onAction} />}
          </TitleContainer>
          <BlankDiv />
          <OfferDetails
            title={title}
            endDate={endDate}
            code={code}
            originalPrice={originalPrice}
            flatValue={flatValue}
            percentageValue={percentageValue}
          />
          <OffersDetailDiv>
            {description && (
              <>
                <Text fontSize={100} fontWeight={"medium"}>
                  Offer Details
                </Text>
                <Paragraph fontSize={50}>{description} </Paragraph>
              </>
            )}
            {complementaryDesc && complementaryDesc !== "" && (
              <>
                <Text fontSize={100} fontWeight={"medium"}>
                  Complementary
                </Text>
                <Paragraph fontSize={50}>{complementaryDesc} </Paragraph>
              </>
            )}
            <Text fontSize={100} fontWeight={"medium"}>
              Terms & Conditions*
            </Text>
            <Paragraph fontSize={50}>
              {`Please read the Terms and Conditions set by ${profileName} carefully.`}
              <br />
              {image.tc && (
                <>
                  <a href={image.tc} target="_blank">{`View T&Cs. `}</a>
                  <br />
                </>
              )}
              {image.tile && (
                <a href={image.tile} target="_blank">
                  View Offer Image
                </a>
              )}
            </Paragraph>
          </OffersDetailDiv>
        </OffersCardPreviewDiv>
      </OffersCardContainer>
    </>
  );
};
