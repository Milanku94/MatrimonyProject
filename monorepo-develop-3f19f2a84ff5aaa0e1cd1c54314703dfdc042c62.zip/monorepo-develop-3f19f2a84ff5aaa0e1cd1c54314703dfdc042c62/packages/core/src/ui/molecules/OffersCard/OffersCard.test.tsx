import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { OffersCard, OffersCardProps } from "./OffersCard";

afterEach(cleanup);

const props: OffersCardProps = {
  title: "title",
  description: "description",
  endDate: "expireDate",
  code: "code",
  city: "LA",
  image: {
    tileDefault:
      "https://stgwww.weddingbazaar.com/assets/images/offer_1_tile.png",
    coverDefault:
      "https://stgwww.weddingbazaar.com/assets/images/offer_1_cover.png"
  },
  category: { name: "category", slug: "category" },
  profileName: "profileName",
  onAction: () => console.log("need to handle Action")
};

describe("OffersCard:", () => {
  it("renders correctly", () => {
    const { container } = render(<OffersCard {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
