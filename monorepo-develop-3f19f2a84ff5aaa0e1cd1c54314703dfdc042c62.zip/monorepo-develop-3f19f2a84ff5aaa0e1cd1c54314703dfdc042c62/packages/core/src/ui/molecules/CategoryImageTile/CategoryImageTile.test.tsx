import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { CategoryImageTile, CategoryImageTileProps } from "./CategoryImageTile";

afterEach(cleanup);

const props: CategoryImageTileProps = {
  slug: "we",
  elementId: "all-categories",
  linkTo: "/ui-atoms-atoms1",
  image: "https://picsum.photos/id/1047/300/300.jpg",
  caption: "caption"
};

describe("CategoryImageTile:", () => {
  it("renders correctly", () => {
    const { container } = render(<CategoryImageTile {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
