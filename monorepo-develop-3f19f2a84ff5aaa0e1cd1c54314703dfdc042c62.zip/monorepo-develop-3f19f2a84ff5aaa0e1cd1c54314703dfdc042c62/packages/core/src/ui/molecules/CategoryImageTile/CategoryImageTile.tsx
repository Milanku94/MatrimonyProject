import * as React from "react";
import styled from "styled-components";
import { backgroundImage, H2, PictureTag, StyledLink, Text } from "../../atoms";

export interface CategoryImageTileProps {
  linkTo: string;
  caption: string;
  image: string;
  elementId: string;
  slug: string;
}

const CategoryImageTileContainer = styled("div")<{ image: string }>`
  ${props => backgroundImage(props.image, "cover", true)}
  border-radius: 3px;
  display: flex;
  align-items: center;
  text-transform: capitalize;
  text-align: center;
  min-width: 9rem;
  min-height: 9rem;
  max-width: 15rem;
  max-height: 15rem;
  ${props => props.theme.media.mobile} {
    min-width: 8rem;
    min-height: 8rem;
  }
`;
export const CategoryImageTile: React.FC<CategoryImageTileProps> = ({
  linkTo,
  caption,
  image,
  elementId,
  slug
}) => {
  return (
    <StyledLink to={linkTo} id={`${elementId}-${slug}`}>
      <CategoryImageTileContainer image={image}>
        <Text fontSize={200} color="white" margin="auto" padding="0 major-1">
          {caption}
        </Text>
      </CategoryImageTileContainer>
    </StyledLink>
  );
};
