import * as React from "react";
// import {
//   TiSocialFacebook,
//   TiSocialGooglePlus,
//   TiSocialInstagram,
//   TiSocialTwitter
// } from "react-icons/ti";
import styled from "styled-components";
import { UserContext } from "../../../contexts/UserContext";
import { Button } from "../Button/Button";
import { StyledLink } from "../Typography";

interface SocialNetworkProps {
  nextUrl?: string;
  loggedIn?: {
    onClick?: () => void;
    label?: string;
  };
}

const SocialNetworkDiv = styled("div")`
  ${StyledLink} {
    display: flex;
    justify-content: center;
    margin: 1rem;
    border-radius: 4px;
    & > span {
      padding: 12px;
      vertical-align: middle;
      color: white;
      font-weight: ${props => props.theme.fontWeight.medium};
    }
  }
`;
const SocialNetworkIcon = styled("div")`
  vertical-align: bottom;
  font-size: xx-large;
  padding: 0 10px;
  border-right: 1px solid ${props => props.theme.colors.white}57;
  color: white;
`;
const meta = [
  {
    baseUrl: "/auth/google",
    label: "Signin with Google",
    // icon: <TiSocialGooglePlus />,
    background: "#DB4437"
  }
  // {
  //   baseUrl: "auth/facebook",
  //   label: "Facebook",
  //   // icon: <TiSocialFacebook />,
  //   background: "#3b5998"
  // },
  // {
  //   baseUrl: "auth/twitter",
  //   label: "Twitter",
  //   // icon: <TiSocialTwitter />,
  //   background: "#00acee"
  // },
  // {
  //   baseUrl: "auth/instagram",
  //   label: "Instagram",
  //   // icon: <TiSocialInstagram />,
  //   background: "#3f729b"
  // }
];
export const SocialNetwork = React.memo((props: SocialNetworkProps) => {
  const { userId } = React.useContext(UserContext);
  if (userId && !!props.loggedIn) {
    return (
      <SocialNetworkDiv>
        <Button
          btnType="secondary"
          btnSize="large"
          onClick={props.loggedIn.onClick}
        >
          {props.loggedIn.label}
        </Button>
      </SocialNetworkDiv>
    );
  }
  return (
    <SocialNetworkDiv>
      {meta.map((each, i) => (
        <StyledLink
          key={i}
          target="popup"
          to={[each.baseUrl, props.nextUrl].join("?next=")}
          style={{ backgroundColor: each.background }}
        >
          {/* <SocialNetworkIcon>{each.icon}</SocialNetworkIcon> */}
          <span>{each.label}</span>
        </StyledLink>
      ))}
    </SocialNetworkDiv>
  );
});
