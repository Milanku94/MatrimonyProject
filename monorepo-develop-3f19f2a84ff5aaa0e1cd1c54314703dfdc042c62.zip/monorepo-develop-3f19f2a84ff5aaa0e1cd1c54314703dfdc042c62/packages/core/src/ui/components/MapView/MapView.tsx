import { GoogleMap, InfoBox, LoadScript, Marker } from "@react-google-maps/api";
import startCase from "lodash/startCase";
import React from "react";
import styled from "styled-components";
import { H3, SiteIcon } from "../..";
import { Secondary } from "../../..";
import { BranchValueType, commaSeperator } from "../ProfileCard/ProfileCard";

export interface MapViewProps {
  googleMapsApiKey?: string;
  coordinates: [ObjectCoordinates];
  profileAddress: any;
  location: string;
  vendorName: string;
}

interface ObjectCoordinates {
  lat: number;
  lng: number;
  info?: string;
  local?: string;
}
const MapviewDiv = styled("div")`
  display: flex;
  ${props => props.theme.media.mobile} {
    flex-direction: column-reverse;
  }
`;

const containerStyle = {
  width: "100%",
  height: "450px"
};

const MapDiv = styled("div")`
  width: 100%;
  ${props => props.theme.media.desktop} {
    width: 75%;
  }
`;

const AddressDiv = styled("div")`
  ul {
    list-style: none;
    padding: 0.5rem 0.5rem 0.5rem 0;
    margin: 0;
    li {
      padding: 0.5rem;
      border-bottom: 1px solid #e6e6e6;
      cursor: pointer;
    }
    li:hover {
      background-color: #ddd;
    }
  }
  ${props => props.theme.media.desktop} {
    width: 25%;
    ul {
      height: 375px;
      overflow: auto;
    }
  }
`;

const TimingsDiv = styled("span")``;

const HeadTitle = styled("p")`
  font-weight: 500;
  color: #e94057;
  font-size: 1rem;
  margin: 0.2rem 0;
`;

const InfoDiv = styled("div")``;

const InfoPopover = styled("div")`
  padding: 6px;
  background: #fff;
  div {
    border-radius: 5px;
    font-weight: 500;
    font-size: 12px;
  }
`;

const CityDiv = styled("span")`
  font-size: 15px;
`;

const makeAddress = (
  branchAddress: BranchValueType | undefined,
  location: string
) => {
  if (!!!branchAddress) {
    return location;
  }
  return `
    ${commaSeperator(branchAddress.buildingName, {})}
    ${commaSeperator(branchAddress.flat, {} /*, { prefix: "No. " }*/)}
    ${commaSeperator(branchAddress.floor, {} /*, { suffix: " floor" }*/)} 
    ${commaSeperator(branchAddress.address, {})} 
    ${commaSeperator(branchAddress.streetName, {})} 
    ${commaSeperator(branchAddress.locality, {})} 
    ${commaSeperator(location, {})} 
    ${commaSeperator(branchAddress.pincode, { comma: false })}
  `;
};

export const UnstyledMapView = React.memo((props: MapViewProps) => {
  const [markerBtn, setMarkerBtn] = React.useState(0);

  return (
    <MapviewDiv>
      <AddressDiv>
        <div>
          <HeadTitle> {props.vendorName} </HeadTitle>
          <CityDiv> {props.location}</CityDiv>
        </div>
        <div>
          <ul>
            {props.profileAddress.map((branch: any, idx: number) => (
              <li key={idx} onClick={() => setMarkerBtn(idx)}>
                <SiteIcon
                  name={"location-on"}
                  style={{
                    width: "16px",
                    fill: "#E94057",
                    height: "16px",
                    verticalAlign: "middle",
                    paddingRight: "1px",
                    margin: "0px 3px 0px 0px"
                  }}
                />
                <span>
                  {startCase(branch.locality)}, {props.location}
                </span>
                {branch.timings && (
                  <TimingsDiv> Timings: {branch.timings}</TimingsDiv>
                )}
                <Secondary as={"div"}>
                  <span>{makeAddress(branch, props.location)}</span>
                </Secondary>
              </li>
            ))}
          </ul>
        </div>
      </AddressDiv>
      <MapDiv>
        <LoadScript googleMapsApiKey={props.googleMapsApiKey || ""}>
          <GoogleMap
            mapContainerStyle={containerStyle}
            center={props.coordinates && props.coordinates[0]}
            zoom={9}
          >
            {props.coordinates.map((data: any, key: number) => (
              <div key={key}>
                <Marker
                  key={key}
                  position={{ ...data }}
                  clickable={true}
                  onClick={() => setMarkerBtn(key)}
                />
                <InfoDiv>
                  {markerBtn === key && (
                    <InfoBox position={{ ...data }}>
                      <InfoPopover>
                        <div> {data.info} </div>
                        <span>
                          {startCase(data.local)}, {props.location}
                        </span>
                      </InfoPopover>
                    </InfoBox>
                  )}
                </InfoDiv>
              </div>
            ))}
          </GoogleMap>
        </LoadScript>
      </MapDiv>
    </MapviewDiv>
  );
});

export const MapView = styled(UnstyledMapView)``;
