import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { CalendarSample, CalendarSampleProps } from "./CalendarSample";

afterEach(cleanup);

const props: CalendarSampleProps = {};

describe("CalendarSample:", () => {
  it("renders correctly", () => {
    const { container } = render(<CalendarSample {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
