import * as React from "react";
import Calendar from "react-calendar/dist/entry.nostyle";
// import Calendar from 'react-calendar';
import styled from "styled-components";

export interface CalendarSampleProps {
  name?: string;
  startDate?: "today";
  endDate?: any;
}

const CalendarSampleDiv = styled("div")``;
const startDate = new Date("toady");

export const CalendarSample = React.memo((props: CalendarSampleProps) => {
  const [date, setDate] = React.useState(new Date());

  const handleToggle = () => {
    setDate(date);
  };

  return (
    <CalendarSampleDiv>
      <Calendar onChange={handleToggle} value={date} />
    </CalendarSampleDiv>
  );
});
