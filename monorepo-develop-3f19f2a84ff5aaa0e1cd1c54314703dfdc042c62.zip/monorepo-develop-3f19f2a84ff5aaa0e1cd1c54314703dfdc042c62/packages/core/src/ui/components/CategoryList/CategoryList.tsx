import * as React from "react";
import styled from "styled-components";
import { CategoryIcon, CategoryType } from "../CategoryIcon/CategoryIcon";
interface CategoryListProps {
  categories: CategoryType[];
  city: string;
  category: string;
}

const CategoryListView = styled("div")`
  text-align: center;
  overflow-x: auto;
  overflow-y: hidden;
  white-space: nowrap;
  ::-webkit-scrollbar {
    height: 4px; /* height of horizontal scrollbar ← You're missing this */
    width: 4px; /* width of vertical scrollbar */
  }

  ::-webkit-scrollbar-thumb:horizontal {
    background: #ddd;
    border-radius: 10px;
  }
`;

const CategoryBorder = styled("hr")`
  border: 0.5px solid rgba(128, 128, 128, 0.11);
  margin-top: -2px;
`;

export const CategoryList = React.memo((props: CategoryListProps) => {
  const catList = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const actCat = props.categories.findIndex(
      cat => props.category === cat.slug
    );
    if (catList && catList.current) {
      catList.current.scrollLeft = 60 * actCat;
    }
  }, [catList.current]);

  return (
    <React.Fragment>
      <CategoryListView ref={catList}>
        {!!props.categories &&
          props.categories.map(cat => (
            <CategoryIcon
              key={cat.id}
              displaytype="list"
              city={props.city}
              {...cat}
              isActive={props.category === cat.slug}
            />
          ))}
      </CategoryListView>
      <CategoryBorder />
    </React.Fragment>
  );
});
