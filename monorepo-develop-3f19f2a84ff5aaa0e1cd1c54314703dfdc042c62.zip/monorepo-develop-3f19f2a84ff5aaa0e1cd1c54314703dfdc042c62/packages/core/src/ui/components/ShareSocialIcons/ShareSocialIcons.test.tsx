import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { ShareSocialIcons, ShareSocialIconsProps } from "./ShareSocialIcons";

afterEach(cleanup);

const props: ShareSocialIconsProps = {
  platforms: { twitter: true },
  subject: "test subject",
  description: "test desc",
  url: "test.com"
};

describe("ShareSocialIcons:", () => {
  it("renders correctly", () => {
    const { container } = render(<ShareSocialIcons {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
