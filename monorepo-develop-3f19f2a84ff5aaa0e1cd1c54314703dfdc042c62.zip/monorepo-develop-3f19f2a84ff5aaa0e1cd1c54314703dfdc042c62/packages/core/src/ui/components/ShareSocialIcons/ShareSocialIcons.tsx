import React from "react";
import styled from "styled-components";
import { SiteIcon } from "../../components/Icon/Icon";

interface SocialShareLinkProps {
  subject: string;
  description: string;
  heroImageURL?: string;
  url: string;
}
interface SocialShareDisplayProps {
  orientation?: "row" | "column";
}
export interface ShareSocialIconsProps
  extends SocialShareLinkProps,
    SocialShareDisplayProps {
  platforms: {
    twitter?: boolean;
    facebook?: boolean;
    whatsapp?: boolean;
    email?: boolean;
  };
}

export const socialLinks = [
  {
    platform: (
      <SiteIcon
        name={"twitter1"}
        style={{
          width: "1.2rem",
          height: "1.2rem"
        }}
      />
    ),
    url: (props: SocialShareLinkProps) =>
      `https://twitter.com/home?status=${props.subject}`,
    label: "twitter"
  },
  {
    platform: (
      <SiteIcon
        name={"whatsapp"}
        style={{
          width: "1.2rem",
          height: "1.2rem"
        }}
      />
    ),
    url: (props: SocialShareLinkProps) =>
      `https://api.whatsapp.com/send?text=${props.subject}. ${props.description}`,
    label: "whatsapp"
  },
  {
    platform: (
      <SiteIcon
        name={"mail1"}
        style={{
          width: "1.2rem",
          height: "1.2rem"
        }}
      />
    ),
    url: (props: SocialShareLinkProps) =>
      `mailto:?subject=${props.subject}&body=${props.description}`,
    label: "email"
  },
  {
    platform: (
      <SiteIcon
        name={"facebook1"}
        viewBox="0 0 10 16"
        style={{
          width: "1.2rem",
          height: "1.2rem"
        }}
      />
    ),
    url: (props: SocialShareLinkProps) =>
      `https://www.facebook.com/sharer/sharer.php?u=${props.url}`,
    label: "facebook"
  },
  {
    platform: (
      <SiteIcon
        name={"pinterest"}
        style={{
          width: "1.2rem",
          height: "1.2rem"
        }}
      />
    ),
    url: (props: SocialShareLinkProps) =>
      `"https://pinterest.com/pin/create/button/?url=${props.subject}&media=${props.heroImageURL}&description=${props.description}`,
    label: "pinterest"
  }
];
const IconsList = styled("ul")<SocialShareDisplayProps>`
  margin: 0;
  padding: 0;
  display: ${props => (props.orientation === "column" ? "none" : "flex")};
  flex-direction: ${props => props.orientation};
  list-style: none;
  ${props => props.theme.media.desktop} {
    display: flex;
    ${props =>
      props.orientation === "column" &&
      `
      position: fixed;
      background-color: rgba(255,255,255,0.3);
      right: 0;
      padding: 1rem 0.25rem;
      clip-path: polygon(0 10%, 100% 0%, 100% 100%, 0 90%);
      top: 50vh;
    `}
  }
`;
export const UnstyledShareSocialIcons = React.memo(
  ({ orientation = "row", platforms, ...props }: ShareSocialIconsProps) => {
    return (
      <IconsList orientation={orientation}>
        {socialLinks.map(social => {
          if (platforms[social.label]) {
            return (
              <li key={social.label}>
                <a
                  href={social.url({ ...props })}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={`Share on ${social.label}`}
                  key={social.label}
                >
                  {social.platform}
                </a>
              </li>
            );
          }
          return null;
        })}
      </IconsList>
    );
  }
);
export const ShareSocialIcons = styled(UnstyledShareSocialIcons)``;
