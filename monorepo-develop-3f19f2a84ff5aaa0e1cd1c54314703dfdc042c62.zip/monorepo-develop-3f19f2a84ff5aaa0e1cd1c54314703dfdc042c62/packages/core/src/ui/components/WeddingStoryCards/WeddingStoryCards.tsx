import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import { Media } from "../../types";
import { ShareSocialIcons } from "../ShareSocialIcons/ShareSocialIcons";
import { StyledLink } from "../Typography";

// interface WeddingStoryCardsProps {
//   stories: Array<StoryCardProps>;
// }

interface WeddingStoryCardsProps {
  id: string;
  name: string;
  heroPhoto: Media;
  couple: any;
  city?: any;
  slug: string;
  url?: string;
}

const Card = styled("div")`
  border-radius: 0.2rem;
  overflow: hidden;
  text-align: center;
  display: block;
`;

const StoryCardDiv = styled("div")<WeddingStoryCardsProps>`
  ${props => backgroundImage(props.heroPhoto && props.heroPhoto.url)}
  background-position: center;
  height: 9rem;
  background-repeat: no-repeat;
  background-size: cover;
`;
const GradientWsDev = styled("div")`
  background: linear-gradient(
    rgba(255, 255, 255, 0) 30%,
    rgba(146, 146, 146, 0.1) 50%,
    rgb(0, 0, 0) 100%
  );
  height: 9rem;
`;

const WeddingStoriesNameDev = styled("div")`
  font-size: ${props => props.theme.fontSize[150]};
  text-align: left;
  color: rgba(255, 255, 255, 1);
  font-weight: ${props => props.theme.fontWeight.semiBold}
  position: relative;
  white-space: nowrap;
  width: 80%;
  overflow: hidden;
  text-overflow: ellipsis;
  bottom: -6.2rem;
  padding: 0 1rem;
  span {
    font-weight: ${props => props.theme.fontWeight.regular}
  }
`;

export const WeddingStoryCards: React.FC<WeddingStoryCardsProps> = React.memo(
  props => {
    const { bride, groom } = props.couple;
    const slugId = `${bride}-${groom}-${props.id}`;
    const url = `https://weddingbazaar.com/ideas/${slugId}`;
    return (
      <React.Fragment>
        <Card>
          <StyledLink to={`/wedding-stories/${slugId}`}>
            <StoryCardDiv {...props}>
              <GradientWsDev>
                <WeddingStoriesNameDev title={`${bride} & ${groom}`}>
                  {bride} & {groom}
                  <br />
                  <span>{props.city}</span>
                </WeddingStoriesNameDev>
              </GradientWsDev>
            </StoryCardDiv>
          </StyledLink>
          <ShareSocialIcons
            url={"https://www.weddingbazaar.com/wedding-stories/"}
            subject={`Our Wedding Stories section is filled with real stories of fairy-tale like weddings! Read on: https://www.weddingbazaar.com/wedding-stories/`}
            description={`Wanna know how others planned their fairy-tale weddings? Want to know which service provider can make your dream wedding come true? Check out: https://www.weddingbazaar.com/wedding-stories/`}
            platforms={{
              facebook: true,
              twitter: true,
              whatsapp: true,
              email: true
            }}
          />
        </Card>
      </React.Fragment>
    );
  }
);
