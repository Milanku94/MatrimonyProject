// import * as React from "react";
// import { cleanup, render } from "../../../utils/test-utils";
// import { StarRatings, StarRatingsProps } from "./StarRatings";

// afterEach(cleanup);

// const props: StarRatingsProps = {};

// describe("StarRatings:", () => {
//   it("renders correctly", () => {
//     const { container } = render(<StarRatings {...props} />);
//     expect(container.firstChild).toMatchSnapshot();
//   });
// });
