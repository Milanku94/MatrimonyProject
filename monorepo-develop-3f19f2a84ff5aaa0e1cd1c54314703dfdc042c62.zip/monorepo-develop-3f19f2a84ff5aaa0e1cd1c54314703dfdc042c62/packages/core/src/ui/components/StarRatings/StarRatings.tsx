import React from "react";
import styled from "styled-components";
import { SiteIcon } from "../../components/Icon/Icon";

interface StarRatingsProps {
  rating: number;
  page?: "listing" | "profile" | "review";
}

const StarsContainer = styled("div")`
  display: flex;
  justify-content: start;
  align-items: center;
  span {
    font-size: 0.75rem;
  }
`;

const getStars = (rating: number, idx: number) => {
  if (idx < Math.floor(rating)) {
    return { name: "star-filled", fill: "#EE9005" };
  } else if (idx + 0.5 <= rating && rating < idx + 1) {
    return { name: "half-star", fill: "#EE9005" };
  } else {
    return { name: "star-border", fill: "#DBDBDB" };
  }
};

export const UnstyledStarRatings = React.memo((props: StarRatingsProps) => {
  if (!props.rating) {
    return null;
  }
  return (
    <StarsContainer {...props}>
      {[...Array(5)].map((n, idx) => {
        const { name, fill } = getStars(props.rating, idx);
        return (
          // tslint:disable-next-line: jsx-key
          <SiteIcon
            name={name}
            style={{
              fill,
              width: "0.8rem",
              height: "0.8rem",
              margin: "0"
            }}
          />
        );
      })}
      {props.page !== "review" && (
        <span>({Number(props.rating).toFixed(1)}/5)</span>
      )}
    </StarsContainer>
  );
});
export const StarRatings = styled(UnstyledStarRatings)``;
