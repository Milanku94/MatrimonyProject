import React from "react";
import { Button } from "../Button/Button";
import { Loader } from "../Loader/Loader";
interface InfiniteScrollProps {
  entries: any;
  onLoadMore: (
    setLoading: React.Dispatch<React.SetStateAction<boolean>>
  ) => any;
  render: (list: any) => any;
  totalCount: any;
}
export const InfiniteScroll: React.FC<InfiniteScrollProps> = React.memo(
  ({ onLoadMore, render, entries, totalCount }) => {
    const [loading, setLoading] = React.useState(false);
    // const handleScroll = () => {
    //   const innerHeight = window.innerHeight;
    //   const scrollTop = document.documentElement.scrollTop;
    //   const offsetHeight = document.documentElement.offsetHeight;
    //   if (innerHeight + scrollTop >= 0.8 * offsetHeight) {
    //     onLoadMore();
    //   }
    // };

    // useEffect(() => {
    //   window.addEventListener("scroll", handleScroll);
    //   return () => window.removeEventListener("scroll", handleScroll);
    // }, []);
    return (
      <React.Fragment>
        {render(entries)}
        {loading && <Loader />}
        {totalCount > entries.length && (
          <Button
            btnSize="large"
            btnType="secondary"
            onClick={() => onLoadMore(setLoading)}
            disabled={loading}
          >
            Load More
          </Button>
        )}
      </React.Fragment>
    );
  }
);
