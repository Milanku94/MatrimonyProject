import * as React from "react";
import styled from "styled-components";

export type CollapsableFunctionType = (
  toggles: boolean[],
  triggers: any
) => JSX.Element;

export type CollapsableChildType = JSX.Element | CollapsableFunctionType;

export interface CollapsableProps {
  header: CollapsableFunctionType;
  children: Array<{
    element: CollapsableChildType;
    open?: boolean;
  }>;
}

export const Show = styled("div")<{ open: boolean }>`
  display: ${props => (props.open ? "block" : "none")};
`;

const CollapsableDiv = styled("div")`
  width: 100%;
`;

const UnstyledCollapsable = React.memo(
  ({ header, children }: CollapsableProps) => {
    const [toggles, setToggles] = React.useState<boolean[]>(
      children.map((c: any) => (c.open ? c.open : false))
    );

    React.useEffect(() => {
      setToggles(() => children.map((c: any) => (c.open ? c.open : false)));
    }, [children]);

    const renderHeader = React.useMemo(() => header(toggles, setToggles), [
      toggles
    ]);

    const renderChild = (element: CollapsableChildType) => {
      if (element instanceof Function) {
        return element(toggles, setToggles);
      }
      return element;
    };

    return (
      <CollapsableDiv>
        {renderHeader}
        {children.map((child, idx: number) => (
          <Show open={toggles[idx]} key={idx}>
            {renderChild(child.element)}
          </Show>
        ))}
      </CollapsableDiv>
    );
  }
);

export const Collapsable = styled(UnstyledCollapsable)<CollapsableProps>``;
