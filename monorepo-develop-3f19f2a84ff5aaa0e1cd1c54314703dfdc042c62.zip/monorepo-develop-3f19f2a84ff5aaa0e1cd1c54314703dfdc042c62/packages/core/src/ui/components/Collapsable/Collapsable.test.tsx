import * as React from "react";
import { cleanup, fireEvent, render } from "../../../utils/test-utils";
import { Collapsable, CollapsableProps } from "./Collapsable";

afterEach(cleanup);

const twoElementProps: CollapsableProps = {
  header: (_, setToggles) => (
    <div>
      <p
        onClick={() => {
          setToggles((toggles: any[]) => [toggles[0], !toggles[1]]);
        }}
      >
        See Details
      </p>
      <p>Filler Text</p>
      <p
        onClick={() => {
          setToggles((toggles: any[]) => [!toggles[0], toggles[1]]);
        }}
      >
        See Actions
      </p>
    </div>
  ),
  children: [
    {
      element: (
        <div key="1" id="action-bar">
          Action Bar
        </div>
      ),
      open: false
    },
    {
      element: (
        <div key="2" id="detail-view">
          Details View
        </div>
      ),
      open: false
    }
  ]
};

describe("Collapsable:", () => {
  it("renders correctly", () => {
    const { container } = render(<Collapsable {...twoElementProps} />);
    expect(container.firstChild).toMatchSnapshot();
  });

  it("when see details clicked", () => {
    const { getByText, container } = render(
      <Collapsable {...twoElementProps} />
    );
    const node1 = container.querySelector("#detail-view");
    const node2 = container.querySelector("#action-bar");
    fireEvent.click(getByText("See Details"));
    expect(node1 && node1.parentNode).toHaveStyle(`display: block`);
    expect(node2 && node2.parentNode).toHaveStyle(`display: none`);
    fireEvent.click(getByText("See Details"));
    expect(node1 && node1.parentNode).toHaveStyle(`display: none`);
    expect(node2 && node2.parentNode).toHaveStyle(`display: none`);
  });
});
