import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { Icon, IconSheetProps } from "../../atoms/Icon/Icon";

afterEach(cleanup);

const props: IconSheetProps = {
  url: "",
  name: ""
};

describe("Icon:", () => {
  it("renders correctly", () => {
    const { container } = render(<Icon {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
