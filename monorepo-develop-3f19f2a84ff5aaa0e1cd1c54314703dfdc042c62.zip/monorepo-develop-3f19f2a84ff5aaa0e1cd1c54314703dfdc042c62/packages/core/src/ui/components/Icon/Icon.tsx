import React from "react";
import {
  Icon,
  IconProps,
  SiteIcon as CoreSiteIcon
} from "../../atoms/Icon/Icon";

export const SiteIcon = CoreSiteIcon;
export const CategoryIcon = React.memo((props: IconProps) => {
  const url = `/assets/icons/categories.svg`;
  return <Icon url={url} {...props} />;
});
