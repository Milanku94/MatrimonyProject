import * as React from "react";
import styled from "styled-components";

interface InterruptionPopupProps {
  showPopup: boolean;
}

const PopupModel = styled("div")<InterruptionPopupProps>`
  display: ${props => (props.showPopup ? "block" : "none")};
  position: fixed;
  z-index: 1;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0, 0, 0);
  background-color: rgba(0, 0, 0, 0.4);
`;

const PopupContent = styled("div")`
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 0;
  width: 90%;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  -webkit-animation-name: animatetop;
  -webkit-animation-duration: 0.4s;
  animation-name: animatetop;
  animation-duration: 0.4s;
`;

const PopupHeader = styled("div")`
  padding: 2px 16px 20px 16px;
  background-color: #fefefe;
  color: ${props => props.theme.colors.primary};
`;

const CloseIcon = styled("p")`
  margin-top: 0px;
  color: #000;
  float: right;
  font-size: 28px;
  font-weight: normal;
  margin-right: 0px;
  cursor: pointer;
`;
const PopupTitle = styled("div")`
  margin-top: 35px;
  font-weight: ${props => props.theme.fontWeight.medium};
  text-align: center;
  color: ${props => props.theme.colors.primary};
`;

const PopupBody = styled("div")`
  padding: 40px 16px;
  background-color: ${props => props.theme.colors.primary};
  color: white;
`;

const BodyContent = styled("div")`
  display: flex;
`;

const InterruptionUser = styled("div")`
  margin-left: 35px;
`;
const ImageIcon = styled("div")`
  border-radius: 25px;
  width: 40px;
  height: 40px;
  background: linear-gradient(to right, #200122, #6f0000);
  color: ${props => props.theme.colors.white};
  border: 2px solid ${props => props.theme.colors.white};
`;

const InterruptionText = styled("div")`
  margin-left: 15px;
`;

const SignUpLink = styled("div")`
  float: right;
  margin-top: 5px;
`;

const SignUpText = styled("a")`
  color: white;
  font-size: 18px;
  text-decoration: none;
`;

export const InterruptionPopup = React.memo((props: InterruptionPopupProps) => {
  const [popup, setPopup] = React.useState(props.showPopup);

  const handlePopup = () => {
    setPopup(!popup);
  };

  return (
    <PopupModel {...props}>
      <PopupContent>
        <PopupHeader>
          <CloseIcon onClick={handlePopup}>×</CloseIcon>
          <div className="clearfix" />
          <PopupTitle>Looks like your planning needs help</PopupTitle>
        </PopupHeader>
        <PopupBody>
          <BodyContent>
            <InterruptionUser>
              {" "}
              <ImageIcon />{" "}
            </InterruptionUser>

            <InterruptionText>
              Let our executive <b> Ramp </b> Help you.
            </InterruptionText>
          </BodyContent>
          <SignUpLink>
            <SignUpText> Signup </SignUpText>
          </SignUpLink>
        </PopupBody>
      </PopupContent>
    </PopupModel>
  );
});
