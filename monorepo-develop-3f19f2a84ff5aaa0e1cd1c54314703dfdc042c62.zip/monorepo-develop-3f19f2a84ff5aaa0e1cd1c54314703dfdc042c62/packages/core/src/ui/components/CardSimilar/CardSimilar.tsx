import React from "react";
import styled from "styled-components";
import { PictureTag } from "../../";

export interface CardSimilarProps {
  imageUrl: string;
  alt: string;
  caption: string;
  subCaption?: string;
  type: "title" | "withSubTitle";
}
interface CardSimilarTitleProps {
  caption: string;
  subCaption?: string;
  type: "title" | "withSubTitle";
}
interface CardType {
  type: "title" | "withSubTitle";
}
const CardSimilarCaption = styled("p")<CardType>`
  color: ${props => props.theme.colors.white};
  font-size: 17px;
  text-align: left;
  position: absolute;
  top: ${props => (props.type === "title" ? "87px" : "76px")};
  margin: 0 0 0 10px;
`;
const CardSimilarSubCaption = styled("p")`
  top: 100px;
  font-size: 12px;
  color: ${props => props.theme.colors.white};
  text-align: left;
  position: absolute;
  margin-left: 10px;
`;
const CardSimilarContainer = styled("div")`
  margin-right: 2px;
  text-align: center;
  display: inline-block;
  width: 75%;
  position: relative;
  display: inline-block;
  background: -moz-linear-gradient(
    bottom,
    rgba(0, 0, 0, 0) 0%,
    rgba(249, 249, 249, 0.89) 100%
  );
  background: -webkit-gradient(
    linear,
    left bottom,
    left bottom,
    color-stop(0%, rgba(0, 0, 0, 0.65)),
    color-stop(100%, rgba(0, 0, 0, 0))
  );
  background: -webkit-linear-gradient(
    top,
    rgba(0, 0, 0, 0) 0%,
    rgba(249, 249, 249, 0.89) 100%
  );
  background: -o-linear-gradient(
    bottom,
    rgba(0, 0, 0, 0) 0%,
    rgba(249, 249, 249, 0.89) 100%
  );
  background: -ms-linear-gradient(
    bottom,
    rgba(0, 0, 0, 0) 0%,
    rgba(249, 249, 249, 0.89) 100%
  );
  background: linear-gradient(
    to bottom,
    rgba(0, 0, 0, 0) 0%,
    rgba(0, 0, 0, 0.59) 100%
  );
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#a6000000', endColorstr='#00000000',GradientType=0 );
  img {
    width: 100%;
    position: relative;
    display: block;
  }
`;
const Title = React.memo((props: CardSimilarTitleProps) => {
  let element = (
    <CardSimilarCaption type={props.type}>{props.caption}</CardSimilarCaption>
  );
  if (props.type === "withSubTitle") {
    element = (
      <React.Fragment>
        <CardSimilarCaption type={props.type}>
          {props.caption}
        </CardSimilarCaption>
        <CardSimilarSubCaption>{props.subCaption}</CardSimilarSubCaption>
      </React.Fragment>
    );
  }
  return element;
});
const UnstyledCardSimilar = React.memo((props: CardSimilarProps) => {
  return (
    <CardSimilarContainer>
      <Title
        caption={props.caption}
        subCaption={props.subCaption}
        type={props.type}
      />
      <span>
        <PictureTag image={props.imageUrl} alt={props.alt} />
      </span>
    </CardSimilarContainer>
  );
});
export const CardSimilar = styled(UnstyledCardSimilar)<CardSimilarProps>``;
