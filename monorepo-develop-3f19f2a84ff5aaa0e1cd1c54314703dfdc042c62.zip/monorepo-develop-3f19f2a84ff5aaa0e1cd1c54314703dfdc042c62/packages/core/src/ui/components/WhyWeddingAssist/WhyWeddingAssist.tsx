import * as React from "react";
import styled from "styled-components";
import { SiteIcon } from "../..";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import {
  Bullet,
  CommonDiv,
  DesktopWhyChooseBazaarProps,
  Header,
  LeftContainer,
  RightContainer,
  SelfContainer
} from "../DesktopWhyChooseBazaar/DesktopWhyChooseBazaar";

export interface WhyWeddingAssistProps {}

export const WeddingAssistCommonDiv = styled(CommonDiv)<
  DesktopWhyChooseBazaarProps
>`
  background-color: none;
  align-items: center;
  padding: 0;
  ${LeftContainer} {
    flex: 1;
    padding: 0;
  }
  ${RightContainer} {
    flex: 2;
    padding: 0;
    border-left: none;
  }
`;

export const UnstyledWhyWeddingAssist = React.memo(
  (props: WhyWeddingAssistProps) => {
    const { domain } = React.useContext(DomainContext);
    if (domain === content.Domains.writer) {
      return <></>;
    }

    const whyAssist = content[domain].whyAssist;
    return (
      <WeddingAssistCommonDiv>
        <LeftContainer>
          <SelfContainer>
            <SiteIcon
              name={whyAssist.icon}
              style={{
                fill: "#FFF",
                width: "auto",
                height: "auto"
              }}
              viewBox="0 0 190.844 187.147"
            />
          </SelfContainer>
        </LeftContainer>
        <RightContainer>
          <Header heading={whyAssist.title} />
          <SelfContainer>
            {whyAssist.points.map(({ strong, icon }: any, idx: any) => (
              <Bullet
                key={idx}
                shape={"no-bullet"}
                point={
                  <SiteIcon
                    name={icon}
                    style={{
                      fill: "#FFF",
                      width: "1.085rem",
                      height: "auto"
                    }}
                  />
                }
                main={strong}
              />
            ))}
          </SelfContainer>
        </RightContainer>
      </WeddingAssistCommonDiv>
    );
  }
);
export const WhyWeddingAssist = styled(UnstyledWhyWeddingAssist)``;
