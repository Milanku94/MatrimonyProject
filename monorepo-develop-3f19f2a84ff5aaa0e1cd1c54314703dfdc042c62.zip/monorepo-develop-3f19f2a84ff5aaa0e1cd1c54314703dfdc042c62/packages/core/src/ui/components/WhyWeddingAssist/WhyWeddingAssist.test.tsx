import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { WhyWeddingAssist, WhyWeddingAssistProps } from "./WhyWeddingAssist";

afterEach(cleanup);
const props: WhyWeddingAssistProps = {};
describe("WhyWeddingAssist:", () => {
  it("renders correctly", () => {
    const { container } = render(<WhyWeddingAssist {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
