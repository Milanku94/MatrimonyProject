import * as React from "react";
import styled from "styled-components";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { SiteIcon } from "../Icon/Icon";

interface WhyChooseMbazaarProps {
  semData?: boolean;
}

const WhyChooseMbDiv = styled("div")`
  display: block;
  padding: 0.5rem 1rem 1rem;
  ${props => props.theme.media.desktop} {
    padding: 1rem 0rem 0rem;
  }
`;

const WhyChooseMbTitleDiv = styled("h2")`
font-size: ${props => props.theme.fontSize.large};
  font-weight: ${props => props.theme.fontWeight.medium};
  color:${props => props.theme.colors.primary}
  text-align: center;
  letter-spacing: 0.8px;
  ${props => props.theme.media.desktop} {
    font-size: ${props => props.theme.fontSize[300]};
    font-weight: ${props => props.theme.fontWeight.medium}
    padding: 0rem 7rem;
  }
`;

const StatisticsDiv = styled("div")`
  width: 100%;
  display: flex;
  flex-direction: column;

  ${props => props.theme.media.desktop} {
    flex-direction: row;
  }
`;

const StatisticsBoxDiv = styled("div")<{
  showInMobile: boolean;
  showInDesktop: boolean;
  semData?: boolean;
}>`
  ${props => (props.showInMobile ? `display: grid` : `display: none`)}
  margin-bottom: 1rem;
  grid-template-columns: ${props => (props.semData ? "auto" : "5rem auto")};
  grid-template-rows: min-content;
  grid-template-areas: ${props =>
    props.semData
      ? `
  "title"
  "description" `
      : `
  "metric title"
  "metric description"`};
  padding-top: 1rem;
  border-top: 1px solid #e94057;
  ${props => props.theme.media.desktop} {
    ${props => (props.showInDesktop ? `display: grid` : `display: none`)}
    grid-gap: 1rem;
    flex: 1;
    grid-template-columns: auto;
    grid-template-areas: ${props =>
      !props.semData &&
      `
      "metric"
      "title"
      "description"`};
    box-shadow: 0 0px 15px rgba(0, 0, 0, 0.1), 0 0px 15px rgb(255, 252, 252);
    padding: ${props => (props.semData ? "1rem 2rem 2.5rem" : "3rem 2rem")};
    margin: 0 0.75rem;
    text-align: center;
    border-top: 2px solid #e94057;
  }
`;

const MetricsCircle = styled("div")`
  grid-area: metric;
  margin: 0px auto;
  width: 4rem;
  height: 4rem;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.primary};
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${props => props.theme.fontSize[200]};
  font-weight: ${props => props.theme.fontWeight.regular}
    ${props => props.theme.media.desktop} {
    width: 5.5rem;
    height: 5.5rem;
    font-size: ${props => props.theme.fontSize[300]};
  }
`;

const StatisticsTitleDiv = styled("div")`
  grid-area: title;
  font-weight: ${props => props.theme.fontWeight.semiBold}
  font-size: ${props => props.theme.fontSize[300]};
  color: ${props => props.theme.colors.primary};

`;

const IconsDiv = styled("div")`
  ${props => props.theme.media.mobile} {
    display: none;
  }
`;

const StatisticsSubTitleDiv = styled("div")`
  grid-area: description;
  font-weight: 500;
  font-size: 0.875rem;
  line-height: 25px;
  color: ${props => props.theme.colors.gray1}
    ${props => props.theme.media.desktop} {
    font-weight: 500;
  }
`;

const UnstyledWhyChooseMbazaar = React.memo(
  ({ semData = false }: WhyChooseMbazaarProps) => {
    const { domain } = React.useContext(DomainContext);
    if (domain === content.Domains.writer) {
      return <></>;
    }

    return (
      <WhyChooseMbDiv>
        <WhyChooseMbTitleDiv>
          {semData
            ? content[domain].covidSemData.title
            : content[domain].howTrustUs.title}
        </WhyChooseMbTitleDiv>
        <StatisticsDiv>
          {content[domain][semData ? "covidSemData" : "howTrustUs"].points.map(
            ({ metric, icon, highlight, desc, showIn }: any, idx: any) => (
              <StatisticsBoxDiv
                key={idx}
                showInMobile={showIn.mobile}
                showInDesktop={showIn.desktop}
                semData={semData}
              >
                {!semData && <MetricsCircle>{metric}</MetricsCircle>}
                <StatisticsTitleDiv>
                  <IconsDiv>
                    <SiteIcon
                      name={icon}
                      style={{
                        width: "4rem",
                        height: "4rem",
                        fill: "#E94057",
                        margin: "0.875rem auto",
                        display: "flex"
                      }}
                    />
                  </IconsDiv>
                  {highlight}
                </StatisticsTitleDiv>
                <StatisticsSubTitleDiv>{desc}</StatisticsSubTitleDiv>
              </StatisticsBoxDiv>
            )
          )}
        </StatisticsDiv>
      </WhyChooseMbDiv>
    );
  }
);
export const WhyChooseMbazaar = styled(UnstyledWhyChooseMbazaar)``;
