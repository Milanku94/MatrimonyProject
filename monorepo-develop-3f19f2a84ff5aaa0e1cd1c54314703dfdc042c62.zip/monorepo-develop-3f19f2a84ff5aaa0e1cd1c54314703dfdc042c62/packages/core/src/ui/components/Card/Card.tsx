import styled from "styled-components";

export const Card = styled("div")`
  overflow: hidden;
  border-radius: 3px;
  // border: 1px solid rgba(214, 214, 214, 1);
  background: ${props => props.theme.colors.white};
  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.13),
    0px 0px 20px 0px rgba(0, 0, 0, 0.02);

  ${props => props.theme.media.mobile} {
    border-top-left-radius: 1px;
  }
`;
