import * as React from "react";
import styled from "styled-components";
import { Button, StyledLink } from "../../atoms";
import { SiteIcon } from "../../components/Icon/Icon";
import { LinkButton } from "../../Markup/Slate/component";
import { Media } from "../../types";
import { Card } from "../Card/Card";
import { Carousel } from "../Carousel/Carousel";
import { ListImage } from "../ListImage/ListImage";

interface VendorCardProps {
  image: Media;
  name: string;
  location?: string;
  desc: string;
  tags: string[]; // Todo: should be object of array with refernce
  isBlogs?: boolean;
  publishedOn?: string;
  slug?: any;
  id?: any;
  linkTo?: string;
}
const LocationSpan = styled("span")`
  display: inline-block;
  font-size: ${props => props.theme.fontSize[150]};
  color: rgba(150, 150, 150, 1);
`;
const TagsList = styled("ul")`
  margin: 4px 0;
  list-style-type: none;
  padding: inherit;
  li {
    float: left;
    padding: 0 2px;
    a {
      padding: 6px 8px 6px 8px;
      color: ${props => props.theme.colors.primary};
      font-size: 12px;
      text-align: center;
      text-decoration: none;
      background-color: rgba(255, 242, 233, 1);
      border-radius: 4px;
    }
  }
`;
const VendorDescContDiv = styled("div")`
  display: flex;
  margin: 0px 7px 7px 0;
`;

const VendorDescDiv = styled("div")`
  margin-top: 14px;
  font-size: ${props => props.theme.fontSize[100]};
  padding-right: 7px;
`;
const QuoteDiv = styled("div")`
  margin: 0 9px;
  font-size: 40px;
  color: #969696;
`;
const MoreDiv = styled("a")`
  margin: 0px 4px;
  color: ${props => props.theme.colors.primary};
  text-decoration: none;
`;
const ReadMorediv = styled("div")`
  font-weight: 500;
  font-size: 12px;
  margin-left: 100px;
  cursor: pointer;
`;
const PublishedDateSpan = styled("div")`
  color: #858585;
  opacity: 1;
  font-size: 10px;
  float: right;
  margin-top: 4px;
  margin-bottom: 2px;
`;
const NameSpan = styled("span")`
font-size: 10px
color: #000
`;
const UnstyledVendorCard = React.memo((props: VendorCardProps) => {
  const isLargeDesc = props.desc.length >= 170;
  const minDesc = isLargeDesc ? props.desc.slice(0, 170) : props.desc;
  const [isExpand, setIsExpand] = React.useState(false);

  return (
    <Card {...props}>
      <ListImage image={props.image}>
        {props.name}
        {!props.publishedOn ? (
          <LocationSpan>
            <SiteIcon name={"location-on"} style={{ width: 12 }} />
            {props.location}
          </LocationSpan>
        ) : (
          <PublishedDateSpan>{props.publishedOn}</PublishedDateSpan>
        )}
        <TagsList>
          {props.tags.map((tag, index) => (
            <li key={index}>
              <a>{tag}</a>
            </li>
          ))}
        </TagsList>
      </ListImage>

      <VendorDescContDiv>
        {props.publishedOn && (
          <ReadMorediv onClick={() => window.open(props.linkTo)}>
            Read more -&gt;
          </ReadMorediv>
        )}
        {!props.publishedOn && (
          <div>
            <QuoteDiv>“</QuoteDiv>
            <VendorDescDiv>
              {isLargeDesc ? (isExpand ? props.desc : minDesc) : props.desc}
              {isLargeDesc && (
                <MoreDiv onClick={() => setIsExpand(!isExpand)}>
                  {isExpand ? "less..." : "more..."}
                </MoreDiv>
              )}
            </VendorDescDiv>
          </div>
        )}
      </VendorDescContDiv>
    </Card>
  );
});
export const VendorCard = styled(UnstyledVendorCard)``;
