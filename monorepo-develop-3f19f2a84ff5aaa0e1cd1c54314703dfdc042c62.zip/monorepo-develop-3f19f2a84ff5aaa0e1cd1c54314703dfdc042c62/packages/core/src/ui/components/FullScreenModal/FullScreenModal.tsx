import React from "react";
import styled from "styled-components";
import { SiteIcon } from "../../components/Icon/Icon";

interface CloseProps {
  close?: () => void;
}
interface ModalProps {
  isFullScreen?: boolean;
  allowScroll?: boolean;
  fullScreenDesktop?: "transparant" | "white";
}
interface HeaderProps extends CloseProps {
  title: string | React.ReactNode;
}
const fullScreenDesktopMeta = {
  transparant: { background: "##00000000" },
  white: { background: "#f3f3f3" }
};
const ModalContainer = styled("div")<ModalProps>`
  z-index: 100;
  background: ${props =>
    props.fullScreenDesktop
      ? fullScreenDesktopMeta[props.fullScreenDesktop].background
      : "#f3f3f3"};
  position: fixed;
  left: ${props => (props.isFullScreen ? "0" : "15%")};
  top: ${props => (props.isFullScreen ? "0" : "11%")};
  width: ${props => (props.isFullScreen ? "100%" : "70%")};
  height: ${props => (props.isFullScreen ? "100vh" : "100%")};
  overflow-y: ${props => (props.allowScroll ? "scroll" : "hidden")};
  bottom: 17%;
  ${props => props.theme.media.desktop} {
    ${props =>
      props.fullScreenDesktop
        ? ``
        : `left: 15%;
      top: 11%;
      width: 70%;
      height: 75%;`}
  }
`;
const Backdrop = styled("div")`
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.9);
  z-index: 99;
`;
const Title = styled("span")`
  color: #363636;
  font-size: 16px;
  margin-left: 7px;
  font-weight: ${props => props.theme.fontWeight.medium};
  margin-top: 2px;
  ${props => props.theme.media.mobile} {
    margin-top: 10px;
  }
`;
const HeaderAction = styled("span")`
  cursor: pointer;
  ${props => props.theme.media.desktop} {
    float: right;
  }
`;

const HeaderInner = styled("div")<{ hidden: boolean }>`
  padding: 0.5rem;
  text-align: center;
  display: flex;
  justify-content: space-between;
  border-bottom: ${props => (props.hidden ? "none" : "1px solid #ddd")};
  background: ${props => (props.hidden ? "none" : props.theme.colors.white)};
  ${props => props.theme.media.desktop} {
  }
`;
const IconDivProvider = styled("div")`
  display: inline-block;
`;

export const Header: React.FC<HeaderProps> = React.memo(props => {
  return (
    <HeaderInner hidden={props.title === ""}>
      <Title>{props.title}</Title>
      <HeaderAction onClick={props.close}>
        <IconDivProvider>
          <SiteIcon
            name={"close"}
            style={{
              width: "1.2rem",
              height: "1.2rem",
              verticalAlign: "middle",
              margin: "0"
            }}
          />
        </IconDivProvider>
      </HeaderAction>
    </HeaderInner>
  );
});
export const Modal: React.FC<ModalProps & CloseProps> = React.memo(props => {
  return (
    <Backdrop onClick={props.close}>
      <ModalContainer {...props}>{props.children}</ModalContainer>
    </Backdrop>
  );
});

export const FullScreenModal: React.FC<ModalProps & CloseProps> = React.memo(
  props => {
    React.useEffect(() => {
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = "inherit";
      };
    });
    return (
      <Modal {...props} isFullScreen={true}>
        {props.children}
      </Modal>
    );
  }
);

export default { Modal, Header, FullScreenModal };
