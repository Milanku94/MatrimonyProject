import styled from "styled-components";

interface GridProps {
  margin?: string;
}
interface CellProps extends GridProps {
  size?: any;
}
export const Row = styled("div")<GridProps>`
  display: flex;
  justify-content: space-between;
  margin: ${props => props.margin};
`;
export const Cell = styled("div")<CellProps>`
  margin: ${props => props.margin};
  float: left;
  padding: 5px;
  width: ${props => (((props.size || 12) / 12) * 100).toFixed(2)}%;
`;
