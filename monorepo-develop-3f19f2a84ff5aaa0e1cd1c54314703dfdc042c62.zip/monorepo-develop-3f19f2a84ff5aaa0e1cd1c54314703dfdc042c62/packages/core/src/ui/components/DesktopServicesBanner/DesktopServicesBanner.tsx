import * as React from "react";
import styled from "styled-components";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";

interface DesktopServicesBannerProps {
  bannerTitle?: string;
}

const ServicesBanner = styled("div")`
  margin-top: 150px;
  ${props => props.theme.media.mobile} {
    display: none;
  }
  .metrics_title {
    font-size: ${props => props.theme.fontSize[300]};
    margin-top: 30px;
    text-align: center;
    font-weight: ${props => props.theme.fontWeight.medium};
  }
  .metrics_subtitle {
    margin: 0.5rem;
    font-size: ${props => props.theme.fontSize[100]};
    text-align: center;
  }
`;

const ServiceBannerTitle = styled("div")`
  line-height: 33px;
  font-size: 22px;
  margin: 0px auto;
  text-align: center;
`;

const BannerMetrics = styled("div")`
  padding-top: 2rem;
  width: 90%;
  margin: 0px auto;
`;

const MetricsInner = styled("div")`
  display: flex;
  margin: 0px auto;
`;

const MetricsBox = styled("div")`
  box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.16);
  margin: 0px auto;
  width: calc(30% - 2rem);
  padding: 1rem;
`;

const MetricsCircle = styled("div")`
  margin: 0px auto;
  width: 4rem;
  height: 4rem;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.primary};
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${props => props.theme.fontSize[200]};
  font-weight: bold;
`;

const UnstyledDesktopServices = React.memo(
  (props: DesktopServicesBannerProps) => {
    const { domain } = React.useContext(DomainContext);
    if (domain === content.Domains.writer) {
      return <></>;
    }

    return (
      <ServicesBanner>
        <ServiceBannerTitle>
          {" "}
          {content[domain].howTrustUs.title}
        </ServiceBannerTitle>
        <div className="clearfix" />
        <BannerMetrics>
          <MetricsInner>
            {content[domain].howTrustUs.points
              .filter(({ showIn }: any) => showIn.desktop)
              .map(({ metric, highlight, desc }: any, idx: any) => (
                <MetricsBox key={idx}>
                  <MetricsCircle>{metric}</MetricsCircle>
                  <div className="metrics_title">{highlight}</div>
                  <div className="metrics_subtitle">{desc}</div>
                </MetricsBox>
              ))}
          </MetricsInner>
        </BannerMetrics>
      </ServicesBanner>
    );
  }
);

export const DesktopServicesBanner = styled(UnstyledDesktopServices)``;
