import * as React from "react";
import styled from "styled-components";

interface InterruptionBannerProps {
  name: string;
  showBanner: boolean;
}

const StyledInterruptionBanner = styled("div")<InterruptionBannerProps>`
  background: ${props => props.theme.colors.primaryFill};
  color: ${props => props.theme.colors.primary};
  padding: 35px 30px;
  display: ${props => (props.showBanner ? "block" : "none")};
`;

const ContentText = styled("div")`
  font-size: ${props => props.theme.fontSize[150]};
  padding-bottom: 10px;
  text-align: center;
`;
const GetQuoteLink = styled("div")`
  font-size: ${props => props.theme.fontSize[200]};
  font-weight: ${props => props.theme.fontWeight.semiBold}
  text-align: center;
`;
const StyledLink = styled("a")`
  color: ${props => props.theme.colors.primary} !important;
  text-decoration: underline;
`;

export const InterruptionBanner = React.memo(
  (props: InterruptionBannerProps) => {
    return (
      <StyledInterruptionBanner {...props}>
        <ContentText> You shortlisted {props.name} </ContentText>
        <GetQuoteLink>
          Great Choice !! - <StyledLink> Get a quote now </StyledLink>
        </GetQuoteLink>
      </StyledInterruptionBanner>
    );
  }
);
