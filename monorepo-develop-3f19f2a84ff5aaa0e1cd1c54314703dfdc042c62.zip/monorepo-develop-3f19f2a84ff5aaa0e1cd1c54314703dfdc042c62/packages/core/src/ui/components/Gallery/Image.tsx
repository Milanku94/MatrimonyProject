import React from "react";
import styled from "styled-components";
import { PictureTag } from "../../..";
import { Media } from "../../types";
import { FullScreenModal as Modal } from "../FullScreenModal/FullScreenModal";
import { SiteIcon } from "../Icon/Icon";
import { GalleryProps } from "./Gallery";
import { MediaTags } from "./MediaTags";
import {
  getYouTubeSlug,
  JustifiedLayoutThumbnails,
  Thumbnails,
  ThumbnailsMedia
} from "./Thumbnails";

interface ImageViewerProps extends GalleryProps {
  viewSlug: string;
  setViewSlug: React.Dispatch<React.SetStateAction<string>>;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  enableJustifiedLayout?: boolean;
}

const Container = styled("div")`
  display: flex;
  flex-direction: column;
  height: 100%;
  ${props => props.theme.media.desktop} {
    flex-direction: row;
  }
`;
const Image = styled("div")`
  display: block;
  position: relative;
  min-height: 70vh;
  background-color: black;
  img {
    max-width: 100%;
    max-height: auto;
    object-fit: contain;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    ${props => props.theme.sizes.desktop} {
      max-width: 100%;
      hight: auto;
    }
  }
  ${props => props.theme.media.desktop} {
    max-height: unset;
    width: 70%;
  }
`;
const Caption = styled("div")`
  padding: 1rem;
  ${props => props.theme.media.desktop} {
    max-height: unset;
    width: 30%;
  }
`;

const OverlayIndicatorDiv = styled("div")<{ type: string }>`
  position: absolute;
  left: ${props => (["prev", "close"].includes(props.type) ? "0" : "")};
  right: ${props => (["next"].includes(props.type) ? "0" : "")};
  top: ${props => (["next", "prev"].includes(props.type) ? "35vh" : "")};
  color: white;
  z-index: 100;
  background: #00000069;
  padding: 0.5rem;
  border-top-left-radius: ${props =>
    ["next", "close"].includes(props.type) ? "50%" : "0"};
  border-top-right-radius: ${props =>
    ["close", "prev"].includes(props.type) ? "50%" : "0"};
  border-bottom-right-radius: ${props =>
    ["close", "prev"].includes(props.type) ? "50%" : "0"};
  border-bottom-left-radius: ${props =>
    ["next", "close"].includes(props.type) ? "50%" : "0"};
  ${props => props.theme.media.desktop} {
    top: ${props => (["next", "prev"].includes(props.type) ? "50vh" : "")};
  }
`;

const OverlayIndicator: React.FC<{
  type: string;
  onClick: () => void;
}> = React.memo(props => {
  const type2svg: { [key: string]: string } = {
    next: "chevron-right",
    prev: "chevron-left",
    close: "close"
  };
  return (
    <OverlayIndicatorDiv {...props}>
      <SiteIcon
        name={type2svg[props.type]}
        style={{
          fill: "white",
          verticalAlign: "middle"
        }}
      />
    </OverlayIndicatorDiv>
  );
});

const RenderMedia = ({ image }: { image: ThumbnailsMedia }) => {
  if (getYouTubeSlug(image.url)) {
    return (
      <iframe
        src={`https://www.youtube.com/embed/${getYouTubeSlug(image.url)}`}
        width="100%"
        height="100%"
        frameBorder="0"
        allow="autoplay; encrypted-media"
        title={image.alt}
      />
    );
  }
  return (
    <PictureTag
      image={image.url}
      alt={image.alt || image.caption}
      fullWidth={true}
    />
  );
};

export const ImageViewer: React.FC<ImageViewerProps> = React.memo(
  ({
    media,
    viewSlug,
    setViewSlug,
    setOpen,
    showTags = false,
    enableJustifiedLayout = false
  }) => {
    const index = media.findIndex((im: Media) => im.slug === viewSlug);
    const image = media[index];

    const nextImage = (e?: any) => {
      if (e) {
        e.stopPropagation();
      }
      const nextIndex = (index + 1) % media.length;
      setViewSlug(media[nextIndex].slug || "");
    };

    const prevImage = (e?: any) => {
      if (e) {
        e.stopPropagation();
      }
      const nextIndex = (media.length + index - 1) % media.length;
      setViewSlug(media[nextIndex].slug || "");
    };

    React.useEffect(() => {
      const timeout = setTimeout(
        nextImage,
        getYouTubeSlug(image.url) ? 2000000 : 5000
      );
      return () => clearTimeout(timeout);
    }, [viewSlug]);

    const neighbours = () => {
      const NEIGHBOUR_LENGTH = 4;
      const neighbourIndex =
        media.length > NEIGHBOUR_LENGTH * 2 ? 4 : (media.length - 1) / 2;
      const [neighbourLeft, neighbourRight] = [
        Math.floor(neighbourIndex),
        Math.ceil(neighbourIndex)
      ];
      const newMedia = [...media, ...media, ...media];
      const newIndex = index + media.length;
      return [
        ...newMedia.slice(newIndex - neighbourRight, newIndex),
        ...newMedia.slice(newIndex + 1, newIndex + neighbourLeft)
      ];
    };

    const ThumbnailsComponent = enableJustifiedLayout
      ? JustifiedLayoutThumbnails
      : Thumbnails;

    return (
      <Modal allowScroll={true}>
        <Container>
          <Image onClick={() => setOpen(false)}>
            <OverlayIndicator
              type="close"
              onClick={() => {
                setOpen(false);
              }}
            />
            <OverlayIndicator type="prev" onClick={prevImage} />
            <RenderMedia image={image} />
            <OverlayIndicator type="next" onClick={nextImage} />
          </Image>
          <Caption>
            <p>{image.caption}</p>
            {image.tags && showTags && (
              <MediaTags
                tags={image.tags}
                show={{ icon: true, name: true }}
                mode="standalone"
              />
            )}
            <ThumbnailsComponent
              media={neighbours()}
              setViewSlug={setViewSlug}
              showTags={false}
            />
          </Caption>
        </Container>
      </Modal>
    );
  }
);
