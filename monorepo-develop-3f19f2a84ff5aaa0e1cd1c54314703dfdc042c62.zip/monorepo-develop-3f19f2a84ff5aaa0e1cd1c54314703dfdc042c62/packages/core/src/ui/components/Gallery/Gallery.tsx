import React from "react";
import { MediaTag } from "../../types";
import { ImageViewer } from "./Image";
import { MediaTags } from "./MediaTags";
import {
  JustifiedLayoutThumbnails,
  Thumbnails,
  ThumbnailsMedia
} from "./Thumbnails";

export interface GalleryProps {
  enableJustifiedLayout?: boolean;
  media: ThumbnailsMedia[];
  showTags?: boolean;
}

export const Gallery: React.FC<GalleryProps> = React.memo(
  ({ media, showTags = false, enableJustifiedLayout = false }) => {
    const mediaWithDimensions: ThumbnailsMedia[] = media.map(image => ({
      ...image,
      imageRef: React.useRef<HTMLImageElement>(null)
    }));
    const [open, setOpen] = React.useState(false);
    const [viewSlug, setViewSlug] = React.useState<string>("");
    const [openTag, setOpenTag] = React.useState("all");
    const tags = media
      .reduce((acc: MediaTag[], image) => {
        if (image.tags) {
          acc.push(...image.tags);
        }
        return acc;
      }, [])
      .reduce((acc: MediaTag[], tag) => {
        if (!acc.map(i => i.id).includes(tag.id)) {
          acc.push(tag);
        }
        return acc;
      }, [])
      .sort((a, b) => +a.id - +b.id);
    const tagsWithAll = [
      {
        id: "0",
        slug: "all",
        name: "All",
        icon: "https://picsum.photos/seed/all/20/20"
      },
      ...tags
    ];
    const header = (
      <MediaTags
        tags={tagsWithAll}
        mode="tabs"
        show={{ icon: true, name: true }}
        onTagClick={tag => setOpenTag(tag)}
      />
    );
    const filterMedia = (image: ThumbnailsMedia) =>
      openTag !== "all"
        ? image.tags && image.tags.map(t => t.slug).includes(openTag)
        : true;

    const ThumbnailsComponent = !!enableJustifiedLayout
      ? JustifiedLayoutThumbnails
      : Thumbnails;

    return (
      <React.Fragment>
        {open ? (
          <ImageViewer
            setOpen={setOpen}
            media={mediaWithDimensions.filter(filterMedia)}
            viewSlug={viewSlug}
            setViewSlug={setViewSlug}
            showTags={showTags}
            enableJustifiedLayout={enableJustifiedLayout}
          />
        ) : null}
        {showTags && header}
        <ThumbnailsComponent
          media={mediaWithDimensions.filter(filterMedia)}
          setViewSlug={index => {
            setViewSlug(index);
            setOpen(true);
          }}
          showTags={false}
        />
      </React.Fragment>
    );
  }
);
