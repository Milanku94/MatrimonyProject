import justifiedLayout from "justified-layout";
import React from "react";
import styled from "styled-components";
import { PictureTag } from "../../..";
import { Media } from "../../types";
import { GalleryProps } from "./Gallery";
import { MediaTags } from "./MediaTags";

// http://flickr.github.io/justified-layout/
interface ThumbnailsProps extends GalleryProps {
  setViewSlug: React.Dispatch<React.SetStateAction<string>>;
  editMedia?: React.Dispatch<React.SetStateAction<any>>;
}
export interface ThumbnailsMedia extends Media {
  imageRef: React.RefObject<HTMLImageElement>;
}

interface DimensionsProps {
  height: number;
  width: number;
}
interface BoxesProps extends DimensionsProps {
  aspectRatio: number;
  top: number;
  left: number;
}
interface JustifiedDimensionsProps {
  containerHeight: number;
  widowCount: number;
  boxes: BoxesProps[];
}

const ThumbnailsContainer = styled("div")<{
  height?: number;
  enableJustifiedLayout?: boolean;
}>`
  ${props =>
    !!props.enableJustifiedLayout
      ? `  
    position: relative;
    transition: height 0.5s ease;
    height: ${(props.height && props.height) || 500}px;
    `
      : `
    display: flex;
    flex-wrap: wrap;
    `}
  flex-direction: column;
  ${props => props.theme.media.desktop} {
    flex-direction: row;
  }
`;
const ThumbnailsItem = styled("div")<{
  dimensions: BoxesProps | false;
  enableJustifiedLayout?: boolean;
}>`
  ${props =>
    !!props.enableJustifiedLayout
      ? `  
    position: absolute;
    transition: all 1s ease;
    height: ${props.dimensions && props.dimensions.height}px;
    width: ${props.dimensions && props.dimensions.width}px;
    top: ${props.dimensions && props.dimensions.top}px;
    left: ${props.dimensions && props.dimensions.left}px;
    `
      : `
    flex: 1;
    margin: 0.25rem;
    ${props.theme.media.desktop} {
      flex: 0 1 calc(33.33% - 0.5rem)    
    }
    `}
`;
const Cover = styled("div")`
  position: absolute;
  display: flex;
  top: 0;
  left: 0;
  margin-left: -0.8rem;
  width: calc(100% + 1.6rem);
  height: 100%;
  z-index: 1;
  background-color: white;
  align-items: center;
  justify-content: center;
`;

export const getYouTubeSlug = (url: string) => {
  const ytSlug = url.match(
    /(http(s)?:\/\/)?((w){3}.)?youtu(?:be\.com\/watch\?v=|\.be\/)([\w\-\_]*)(&(amp;)?‌​[\w\?‌​=]*)?/
  );
  return ytSlug && ytSlug[5];
};
export const getImageURL = (url: string) => {
  if (getYouTubeSlug(url)) {
    return `https://img.youtube.com/vi/${getYouTubeSlug(url)}/0.jpg`;
  }
  return url;
};

export const JustifiedLayoutThumbnails: React.FC<ThumbnailsProps> = React.memo(
  ({ media, setViewSlug, showTags = false }) => {
    const containerRef = React.useRef<HTMLDivElement>(null);
    // const [refsLoaded, setRefsLoaded] = React.useState(0)
    // const [imagesLoaded, setImagesLoaded] = React.useState(0)

    const [justifiedDimensions, setJustifiedDimensions] = React.useState<any>();

    // React.useEffect(() => {
    //   setRefsLoaded(media.reduce((acc, image) => { acc += !!image.imageRef.current ? 1 : 0; return acc }, 0))
    // }, [refsLoaded])

    const refsLoaded = media.every(image => !image.imageRef.current);

    const getDimensions: (
      image: ThumbnailsMedia
    ) => { height: number; width: number } = image => ({
      height: image.imageRef.current!.height || 100,
      width: image.imageRef.current!.width || 100
    });

    const justifyLayout = React.useMemo(
      () => () => {
        if (containerRef.current) {
          setJustifiedDimensions(
            justifiedLayout(media.map(getDimensions), {
              containerWidth: containerRef.current.offsetWidth,
              containerPadding: 0,
              boxSpacing: 0.5 * 16,
              targetRowHeight: 10 * 16
            })
          );
        }
      },
      []
    );

    React.useEffect(() => {
      justifyLayout();
    }, [refsLoaded]);

    React.useEffect(() => {
      justifyLayout();
      window.addEventListener("resize", justifyLayout);
      return () => window.removeEventListener("resize", justifyLayout);
    }, []);

    return (
      <ThumbnailsContainer
        ref={containerRef}
        height={
          !!justifiedDimensions ? justifiedDimensions.containerHeight : 1000
        }
        enableJustifiedLayout={true}
      >
        {media.map((image, index) => (
          <ThumbnailsItem
            key={image.slug}
            dimensions={
              !!justifiedDimensions && justifiedDimensions.boxes[index]
            }
            enableJustifiedLayout={true}
          >
            <PictureTag
              imageRef={image.imageRef}
              image={getImageURL(image.url)}
              alt={image.alt || image.caption}
              fullWidth={true}
              onClick={() => setViewSlug(media[index].slug || "")}
              forceJPG={!!getYouTubeSlug(image.url)}
            />
            {image.tags && showTags ? (
              <MediaTags
                tags={image.tags}
                show={{ icon: true, name: false }}
                mode="overlay"
              />
            ) : null}
          </ThumbnailsItem>
        ))}
      </ThumbnailsContainer>
    );
  }
);

export const Thumbnails: React.FC<ThumbnailsProps> = React.memo(
  ({ media, setViewSlug, showTags = false }) => {
    return (
      <ThumbnailsContainer enableJustifiedLayout={false}>
        {media.map((image, index) => (
          <ThumbnailsItem
            key={image.slug}
            dimensions={false}
            enableJustifiedLayout={false}
          >
            <PictureTag
              image={getImageURL(image.url)}
              alt={image.alt || image.caption}
              fullWidth={true}
              onClick={() => setViewSlug(media[index].slug || "")}
              forceJPG={!!getYouTubeSlug(image.url)}
            />
            {image.tags && showTags ? (
              <MediaTags
                tags={image.tags}
                show={{ icon: true, name: false }}
                mode="overlay"
              />
            ) : null}
          </ThumbnailsItem>
        ))}
      </ThumbnailsContainer>
    );
  }
);
