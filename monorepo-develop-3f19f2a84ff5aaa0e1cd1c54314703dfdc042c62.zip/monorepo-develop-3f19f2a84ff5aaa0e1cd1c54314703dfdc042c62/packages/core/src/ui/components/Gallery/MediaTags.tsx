import React from "react";
import styled from "styled-components";
import { PictureTag } from "../../";
import { MediaTag } from "../../types";
import { Chips } from "../Chips/Chips";

interface ModeProps {
  mode: "standalone" | "overlay" | "tabs";
}

interface MediaTagProps extends ModeProps {
  tags: MediaTag[];
  show: ShowProps;
  style?: any;
  onTagClick?: (tag: string) => void;
}
interface ShowProps {
  icon?: boolean;
  name?: boolean;
}

const TagsContainer = styled("div")<ModeProps>`
  ${props =>
    props.mode === "standalone" &&
    `
display: flex;
flex-wrap: wrap;
margin: 1rem 0;
${TagChips} {
  margin: 0.25rem;
}
`}
  ${props =>
    props.mode === "overlay" &&
    `
max-height: 2rem;
position: absolute;
bottom: 0;
display: flex;
width: inherit;
overflow: hidden;
`}  
${props =>
  props.mode === "tabs" &&
  `
display: flex;
overflow: auto;
margin: 1rem 0;

::-webkit-scrollbar {
  height: 4px;              /* height of horizontal scrollbar ← You're missing this */
  width: 4px;               /* width of vertical scrollbar */
}
::-webkit-scrollbar-thumb:horizontal{
  background: #ddd;
  border-radius: 10px;
}

${TagChips} {
  margin: 0.25rem;
}
`}
`;
const TagChips = styled(Chips)<{
  onlyIcon: boolean;
  onlyName: boolean;
  both: boolean;
}>`
  display: flex;
  background: whitesmoke;
  align-items: center;
  padding: ${props => (props.onlyIcon ? "0" : "0.25rem 0.4rem")};
  width: fit-content;
  height: fit-content;
  margin: ${props => (props.both ? "0.125rem" : "0 0.125rem 0 0")};
  border: ${props => (props.onlyIcon ? "2px solid whitesmoke" : "none")};
  img {
    width: ${props => (props.onlyIcon ? "calc(2rem - 4px)" : "2rem")};
    height: ${props => (props.onlyIcon ? "calc(2rem - 4px)" : "2rem")};
    border-radius: 1rem;
  }
  span {
    margin-left: 0.25rem;
  }
  cursor: ${props => (!!props.both ? "pointer" : "auto")};
`;

export const MediaTags: React.FC<MediaTagProps> = ({
  tags,
  show: { icon = true, name = true },
  mode = "overlay",
  style,
  onTagClick
}) => {
  return (
    <TagsContainer mode={mode} style={style}>
      {tags
        .sort((a, b) => +a.id - +b.id)
        .map(tag => (
          <TagChips
            key={tag.id}
            onlyIcon={icon && !name}
            onlyName={!icon && name}
            both={icon && name}
            onClick={() => onTagClick && onTagClick(tag.slug)}
          >
            {icon && (
              <PictureTag image={tag.icon} alt={tag.name} fullWidth={false} />
            )}
            {name && <span>{tag.name}</span>}
          </TagChips>
        ))}
    </TagsContainer>
  );
};
