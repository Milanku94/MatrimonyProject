import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { Gallery, GalleryProps } from "./Gallery";

afterEach(cleanup);

const props: GalleryProps = { media: [] };

describe("Gallery:", () => {
  it("renders correctly", () => {
    const { container } = render(<Gallery {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
