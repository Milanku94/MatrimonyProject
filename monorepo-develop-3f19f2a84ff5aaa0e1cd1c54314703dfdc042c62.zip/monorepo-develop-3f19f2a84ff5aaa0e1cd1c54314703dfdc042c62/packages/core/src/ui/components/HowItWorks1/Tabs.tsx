import * as React from "react";
import styled from "styled-components";

const TabsContDiv = styled("div")`
  border-radius: 4px;
  margin: 2rem 0;
  overflow: hidden;
  box-shadow: 0 0px 36px rgba(0, 0, 0, 0.1), 0 15px 12px rgba(0, 0, 0, 0.02);
`;
const TabDiv = styled("button")<TabDivProps>`
  border: 0px solid
    ${props =>
      props.active ? props.theme.colors.primary : props.theme.colors.gray3};
  font-weight: ${props => props.theme.fontWeight.medium};
  font-family: ${props => props.theme.fontFamily};
  width: 50%;
  color: ${props => (props.active ? "white" : "inherit")};
  background-color: ${props =>
    props.active ? props.theme.colors.primary : props.theme.colors.white};
  float: left;
  outline: none;
  cursor: pointer;
  padding: 1rem 0.5rem;
  transition: 0.3s;
  font-size: ${props => props.theme.fontSize[150]};
`;

interface TabDivProps {
  active: boolean;
}
interface IntTab {
  value: string;
  label: string;
}
interface TabsProps {
  list: IntTab[];
  active: string;
  onActive: (value: string) => void;
}

const tabs = (props: TabsProps) => {
  // const [ active, setActive ] = React.useState(props.active)
  return (
    <TabsContDiv>
      {props.list.map((each, i) => (
        <TabDiv
          key={i}
          onClick={(e: any) => {
            props.onActive(e.target.value);
          }}
          value={each.value}
          active={props.active === each.value}
        >
          {each.label}
        </TabDiv>
      ))}
    </TabsContDiv>
  );
};

tabs.defaultProps = {
  list: [
    {
      value: "tab1",
      label: "Am Tab One"
    },
    {
      value: "tab2",
      label: "Am Two ;)"
    }
  ],
  active: "tab1"
};
export const Tabs = React.memo(tabs);
