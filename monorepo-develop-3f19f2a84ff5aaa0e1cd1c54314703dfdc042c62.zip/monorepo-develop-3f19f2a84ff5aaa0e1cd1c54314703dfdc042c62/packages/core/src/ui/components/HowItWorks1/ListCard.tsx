import * as React from "react";
import styled from "styled-components";

const ListCardDiv = styled("div")`
  margin-bottom: 35px;
  display: flex;
`;
const ListCardHighLight = styled("div")`
  width: 39px;
  height: 39px;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.primary};
`;
const ListCardHighLightText = styled("div")`
  padding: 8px 10px 0px 9px;
  color: rgba(255, 255, 255, 1);
  font-size: 18px;
  font-weight: ${props => props.theme.fontWeight.medium};
`;
const ListCardContent = styled("div")`
  margin: 0;
  padding: 0;
  box-sizing: border-box;
`;
const ListCardMassContent = styled("div")`
  color: rgba(64, 64, 64, 1);
  margin: 9px 0px 0px 21px;
  font-size: 18px;
`;
const ListCardTitle = styled("div")`
  font-weight: ${props => props.theme.fontWeight.semiBold}
  font-size: 16px;
  color: rgba(49, 49, 49, 1);
  padding-left: 14px;
`;
const ListCardDesc = styled("div")`
  font-size: 14px;
  padding: 6px 10px 0px 14px;
`;

interface ListCardProps {
  highlight: string;
  title: string;
  desc: string;
}
const listCard = (props: ListCardProps) => {
  return (
    <ListCardDiv>
      <ListCardHighLight>
        <ListCardHighLightText>{props.highlight}</ListCardHighLightText>
      </ListCardHighLight>
      {props.desc ? (
        <ListCardContent>
          <ListCardTitle>{props.title}</ListCardTitle>
          <ListCardDesc>{props.desc}</ListCardDesc>
        </ListCardContent>
      ) : (
        <ListCardMassContent>{props.title}</ListCardMassContent>
      )}
    </ListCardDiv>
  );
};
listCard.defaultProps = {
  highlight: "01",
  title: "title"
};

export const ListCard = React.memo(listCard);
