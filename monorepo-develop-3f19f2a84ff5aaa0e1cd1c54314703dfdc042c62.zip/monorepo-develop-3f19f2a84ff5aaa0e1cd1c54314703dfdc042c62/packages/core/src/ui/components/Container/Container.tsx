import * as React from "react";
import styled from "styled-components";

const ContainerDiv = styled("div")`
  margin-top: 42px;
`;

interface ContainerProps {
  children: any;
}

export const Container = React.memo((props: ContainerProps) => {
  return <ContainerDiv>{props.children}</ContainerDiv>;
});
