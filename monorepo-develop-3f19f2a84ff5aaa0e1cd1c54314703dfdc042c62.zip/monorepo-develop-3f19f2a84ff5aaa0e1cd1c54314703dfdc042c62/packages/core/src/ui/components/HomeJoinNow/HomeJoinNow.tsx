/**
 * TODO: move into organisms
 */
import * as React from "react";
import { Helmet } from "react-helmet-async";
import { helmetJsonLdProp } from "react-schemaorg";
import { SoftwareApplication } from "schema-dts";
import styled from "styled-components";
import { backgroundImage, Button, H4, Paragraph, StyledLink } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { theme } from "../../theme";

interface HomeJoinNowProps {
  elementID?: string;
  semData?: boolean;
}

const OnBoardContent = styled("div")`
  text-align: center;
  ${theme.media.mobile} {
    ${backgroundImage(
      "//www.weddingbazaar.com/assets/bg/wedding-assist_m_586.jpg"
    )}
    background-color: ${props => `${props.theme.colors.black}a3 !important`};
    background-blend-mode: overlay;
    color: ${props => props.theme.colors.white};
    padding: 2rem 1rem;
   }
  ${theme.media.desktop} {
    flex: 3;
    margin: 1rem;  
  }
  ${Paragraph} > ${StyledLink} {
    font-weight: ${theme.fontWeight.semiBold}
    color: white;
    ${theme.media.desktop} {
      color: black;
  }
`;
const OnBoardBanner = styled("div")`
  display: none;
  ${theme.media.desktop} {
    flex: 1;
    margin: 1rem;
    width: 100%;
    height: inherit;
    display: block;
    ${backgroundImage(
      "//www.weddingbazaar.com/assets/bg/wedding-assist_m_586.jpg"
    )}
    background-position: center;
    background-size: cover;
  }
`;

const JoinNow = styled("div")`
  ${theme.media.desktop} {
    display: flex;
    margin: 2rem 5vw;
  }
`;

const MailLink = styled("a")`
  color: black;
  text-decoration: none;
  font-weight: 600;
`;

const UnstyledHomeJoin: React.FC<HomeJoinNowProps> = React.memo(props => {
  const { domain } = React.useContext(DomainContext);
  if (domain === content.Domains.writer) {
    return <></>;
  }

  return (
    <JoinNow>
      {domain === content.Domains.mBazaar && (
        <Helmet
          script={[
            { name: "android", platform: "ANDRIOD" },
            { name: "ios", platform: "IOS" }
          ].map(({ platform, name }: any) =>
            helmetJsonLdProp<SoftwareApplication>({
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              name: content[domain].partnerApp.name,
              operatingSystem: platform,
              applicationCategory: "BusinessApplication",
              downloadUrl: content[domain].partnerApp[name],
              aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: 4.6,
                ratingCount: 8864
              },
              offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "INR"
              }
            })
          )}
        />
      )}

      <OnBoardContent>
        <H4>
          {props.semData
            ? content[domain].covidSemBanner.title
            : content[domain].partnerBanner.title}
        </H4>
        <Paragraph fontSize={100}>
          {props.semData
            ? content[domain].covidSemBanner.content
            : content[domain].partnerBanner.content}
          {!props.semData && (
            <MailLink
              id={props.elementID}
              href={`mailto:${content[domain].mail}`}
            >
              &nbsp;
              {content[domain].mail}
            </MailLink>
          )}
        </Paragraph>
        <Button
          palette="primary"
          onClick={() => (window.location.pathname = "/become-a-partner")}
        >
          Sign Up Now
        </Button>
      </OnBoardContent>
      <OnBoardBanner />
    </JoinNow>
  );
});

export const HomeJoinNow = styled(UnstyledHomeJoin)<HomeJoinNowProps>``;
