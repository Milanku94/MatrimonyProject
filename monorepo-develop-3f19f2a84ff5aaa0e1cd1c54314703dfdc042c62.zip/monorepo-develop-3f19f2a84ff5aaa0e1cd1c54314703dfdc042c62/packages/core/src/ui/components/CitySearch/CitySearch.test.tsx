// import * as React from "react";
// import { cleanup, render } from "../../../utils/test-utils";
// import { CitySearch, CitySearchProps } from "./CitySearch";

// afterEach(cleanup);

// const props: CitySearchProps = {};

// describe("CitySearch:", () => {
//   it("renders correctly", () => {
//     const { container } = render(<CitySearch {...props} />);
//     expect(container.firstChild).toMatchSnapshot();
//   });
// });
