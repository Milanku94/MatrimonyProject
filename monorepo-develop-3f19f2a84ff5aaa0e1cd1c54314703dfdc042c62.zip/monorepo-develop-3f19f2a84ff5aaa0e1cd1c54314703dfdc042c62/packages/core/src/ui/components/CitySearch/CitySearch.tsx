import * as React from "react";
import styled from "styled-components";
import { Button as SearchButton } from "../Button/Button";
import { SiteIcon } from "../Icon/Icon";

export interface CitySearchProps {
  location: string;
}

const SearchDiv = styled("div")`
  ${SearchButton} {
    height: 40px;
  }
`;

const UnstyledCitySearch = React.memo((props: CitySearchProps) => {
  return (
    <SearchDiv>
      <SearchButton btnType="primary">
        <SiteIcon
          name={"location-on"}
          style={{ width: "1rem", fill: "white", margin: "0" }}
        />
        <span> {props.location} &#9660;</span>
      </SearchButton>
    </SearchDiv>
  );
});

export const CitySearch = styled(UnstyledCitySearch)``;
