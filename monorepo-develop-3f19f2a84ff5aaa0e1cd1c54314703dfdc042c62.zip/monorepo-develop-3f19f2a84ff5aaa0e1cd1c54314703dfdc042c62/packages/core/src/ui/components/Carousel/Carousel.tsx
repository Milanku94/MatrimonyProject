// upcoming implementation follows this medium article of @ilonacodes
// https://medium.com/@ilonacodes/simple-image-carousel-with-react-5e20933001bf
// only main difference of this implementation: uses React hooks

import React, { useEffect, useState } from "react";
import styled from "styled-components";

interface CarouselProps {
  children: React.ReactNode[];
  showControls: boolean;
  showIndicators: boolean;
  autoChangeIn: number | null;
  activeSlide?: number;
  showPreviews?: "desktop" | "mobile" | "both" | "none";
}
interface PanelProps {
  slides: CarouselProps["children"];
  showPreviews?: CarouselProps["showPreviews"];
  currentSlideId: number;
}
interface PanelProps {
  slides: CarouselProps["children"];
  showPreviews?: CarouselProps["showPreviews"];
  currentSlideId: number;
}
const Container = styled("div")`
  display: flex;
  align-items: center;
`;
const LeftButton = styled("span")`
  user-select: none;
  cursor: pointer;
  // position: absolute;
  top: 50%;
  padding: 1rem;
  margin-top: -1rem;
  color: black;
  font-weight: bold;
  font-size: ${props => props.theme.fontSize[200]};
  transition: 0.6s ease;
  background-color: rgba(0, 0, 0, 0);
  &:hover {
    color: white;
    background-color: rgba(0, 0, 0, 0.8);
  }
`;
const RightButton = styled(LeftButton)`
  right: 0;
`;
const IndicatorBox = styled("div")`
  display: flex;
  justify-content: center;
  margin-top: 3rem;
`;
const StatusText = styled("div")`
  color: ${props => props.theme.colors.gray1};
  font-size: 15px;
  font-weight: ${props => props.theme.fontWeight.medium};
  padding: 0px 30px;
  position: absolute;
  /*text-shadow: 3px 2px 8px #000000;*/
  bottom: 2.5rem;
  /*background: #00000091;*/
  transform: translateY(-50%);
  left: 42%;
  z-index: 10;
  text-align: center;
`;

const ImageContainer = styled("div")`
  margin: 0px 40px 40px 40px;
  animation-name: fade;
  animation-duration: 1.5s;
  border-radius: 4px;
  text-align: center;
  display: table;
  margin: 0 auto;
  @keyframes fade {
    from {
      opacity: 0.4;
    }
    to {
      opacity: 1;
    }
  }
  box-shadow: 0 19px 38px rgba(0, 0, 0, 0.1), 0 15px 12px rgba(0, 0, 0, 0.02);
`;
const Indicator = styled("div")<{ isActive: boolean }>`
  width: ${props => (props.isActive ? "1rem" : "0.75rem")};
  height: 0.25rem;
  border-radius: 0.125rem;
  margin: 0.25rem;
  background-color: ${props => props.theme.colors.primary};
  opacity: ${props => (props.isActive ? "1" : "0.5")};
`;
const CarouselPanel = styled("div")<{
  showPreviews: CarouselProps["showPreviews"];
}>`
  ${props => props.theme.media.mobile} {
    ${props =>
      ["mobile", "both"].includes(props.showPreviews || "none")
        ? `
    display: flex;
    & > * {
      transition: all 1s easy;
      width: 50%;
    }
    & > *:first-child, & > *:last-child {
      display: block;
      transform : scale(0.75, 0.75)
    }
    `
        : `
    display: block;
    & > *:first-child, & > *:last-child {
      display: none;
    }
    `}
  }
  ${props => props.theme.media.desktop} {
    ${props =>
      ["desktop", "both"].includes(props.showPreviews || "none")
        ? `
    display: flex;
    & > * {
      transition: all 1s easy;
      width: 50%;
    & > *:first-child, & > *:last-child {
      display: block;
      transform : scale(0.75, 0.75)
    }
    `
        : `
    display: block;
    & > *:first-child, & > *:last-child {
      display: none;
    }
    `}
  }
`;

const getPanels = (props: PanelProps) => {
  if (!props.showPreviews || props.showPreviews === "none") {
    return props.slides[props.currentSlideId];
  }
  const slidesLength = props.slides.length;
  return (
    <CarouselPanel showPreviews={props.showPreviews || "none"}>
      {props.slides[(slidesLength + props.currentSlideId - 1) % slidesLength]}
      {props.slides[props.currentSlideId]}
      {props.slides[(slidesLength + props.currentSlideId + 1) % slidesLength]}
    </CarouselPanel>
  );
};

export const Carousel: React.FC<CarouselProps> = ({
  activeSlide,
  ...props
}) => {
  const [slides, setSlides] = useState(props.children);
  const length = slides.length;

  const [currentSlideId, setSlideId] = useState(activeSlide || 0);

  const prevSlide = () => {
    const index = (length + currentSlideId - 1) % length;
    setSlideId(index);
  };

  const nextSlide = () => {
    const index = (currentSlideId + 1) % length;
    setSlideId(index);
  };

  useEffect(() => {
    if (props.autoChangeIn) {
      const timeout = setTimeout(() => {
        nextSlide();
      }, props.autoChangeIn);
      return () => clearTimeout(timeout);
    }
  }, [currentSlideId]);

  const prevButton = props.showControls && (
    <LeftButton onClick={prevSlide}>&#10094;</LeftButton>
  );
  const nextButton = props.showControls && (
    <RightButton onClick={nextSlide}>&#10095;</RightButton>
  );

  const indicators = slides.map((slide, id) => (
    <Indicator
      key={id}
      isActive={id === currentSlideId}
      onClick={() => setSlideId(id)}
    />
  ));
  const indicatorBox = props.showIndicators && (
    <IndicatorBox>{indicators}</IndicatorBox>
  );

  return (
    <React.Fragment>
      <Container>
        {prevButton}
        {getPanels({
          slides,
          currentSlideId,
          showPreviews: props.showPreviews
        })}
        {nextButton}
      </Container>
      {indicatorBox}
    </React.Fragment>
  );
};

Carousel.defaultProps = {
  activeSlide: 0,
  showPreviews: "none"
};
