import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";

interface WeddingStoriesProps {
  backgroundImage?: string;
}

const WeddingStoriesDev = styled("div")<WeddingStoriesProps>`
  ${props => backgroundImage(props.backgroundImage || "")}
  height: 585.5px;
  background-size: cover;
  background-repeat: no-repeat;
  font-family: "Quicksand", sans-serif;
  ${props => props.theme.media.desktop} {
    display: none;
  }
`;

const GradientWeddingStoriesDev = styled("div")`
  height: 600px;
  background: linear-gradient(
    rgba(255, 255, 255, 0) 25%,
    rgba(239, 161, 150, 0.19) 50%,
    rgba(70, 22, 31, 0.81) 75%,
    rgba(0, 0, 0, 1) 100%
  );
`;

const WeddingStoriesTitleDev = styled("div")`
  position: relative;
  bottom: -16rem;
  font-size: 22px;
  color: rgba(255, 255, 255, 1);
  font-weight: ${props => props.theme.fontWeight.medium};
  padding: 0 1.5rem;
`;

const WeddingStoriesSubTitleDev = styled("div")`
  position: relative;
  bottom: -16.5rem;
  font-size: 14px;
  padding: 0 1.5rem;
  color: rgba(255, 255, 255, 0.78);
  text-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
`;

const WeddingStoriesSliderDev = styled("div")`
  margin-top: 10px;
`;

const WeddingStoriesListDev = styled("div")`
  padding-left: 25px;
  overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
`;

const CardWsDev = styled("div")`
  margin-right: 5px;
  text-align: center;
  display: inline-block;
`;

const CardBgImgDev = styled("div")<WeddingStoriesProps>`
  ${props => backgroundImage(props.backgroundImage || "")}
  height: 146px;
  width: 290px;
  background-repeat: no-repeat;
  background-size: cover;
`;
const ChildCont = styled("div")`
  position: relative;
  bottom: -17rem;
`;

const GradientWsDev = styled("div")`
  background: linear-gradient(
    rgba(255, 255, 255, 0.06) 30%,
    rgba(146, 146, 146, 0.22) 80%,
    rgba(0, 0, 0, 1) 100%
  );
  height: 146px;
`;

const WeddingStoriesNameDev = styled("div")`
  padding: 115px 0px 0px 14px;
  font-size: 14px;
  text-align: left;
  color: rgba(255, 255, 255, 1);
  font-weight: ${props => props.theme.fontWeight.medium};
`;

export const WeddingStories: React.FC<WeddingStoriesProps> = React.memo(
  props => {
    const { domain } = React.useContext(DomainContext);
    if (domain !== content.Domains.mBazaar) {
      return <></>;
    }
    return (
      <React.Fragment>
        <WeddingStoriesDev
          backgroundImage={
            "//www.weddingbazaar.com/assets/bg/wedding-stories.jpg"
          }
        >
          <GradientWeddingStoriesDev>
            <WeddingStoriesTitleDev>
              {content[domain].weddingStories.title}
            </WeddingStoriesTitleDev>
            <WeddingStoriesSubTitleDev>
              {content[domain].weddingStories.content}
            </WeddingStoriesSubTitleDev>
            <ChildCont>{props.children}</ChildCont>
          </GradientWeddingStoriesDev>
        </WeddingStoriesDev>
      </React.Fragment>
    );
  }
);
