import React from "react";
import styled from "styled-components";

interface ProfilePointListProps {
  title: string;
  points: string[];
}
const Title = styled("h2")`
  margin-top: 0;
  margin-bottom: 0.8rem;
  font-size: ${props => props.theme.fontSize[200]};
  font-size: ${props => props.theme.fontSize[200]};
  color: rgba(42, 44, 52, 1);
`;
const ListContainer = styled.div`
  width: 100%;
  margin-top: 0.5rem;
  margin-bottom: 0.5rem;
`;
const Ul = styled.ul`
  font-size: ${props => props.theme.fontSize[100]};
  list-style: none;
  padding-left: 2em;
  display: grid;
  grid-column-gap: 2rem;
  grid-template-columns: repeat(2, 1fr);
`;
const Li = styled.li`
  box-sizing: border-box;
  line-height: 1rem;
  padding-bottom: 0.25rem;
  padding-top: 0.25rem;
  ::before {
    content: "\u2022";
    font-weight: bolder;
    display: inline-block;
    width: 1em;
    font-size: ${props => props.theme.fontSize[300]};
    margin-left: -1.3rem;
    top: 0.2rem;
    position: relative;
    color: rgba(29, 128, 51, 1);
  }
`;
const UnstyledProfilePointList = React.memo((props: ProfilePointListProps) => {
  return (
    <div>
      <Title>{props.title}</Title>
      <ListContainer>
        <Ul>
          {props.points &&
            props.points.map(point => <Li key={point}>{point}</Li>)}
        </Ul>
      </ListContainer>
    </div>
  );
});
export const ProfilePointList = styled(UnstyledProfilePointList)<
  ProfilePointListProps
>``;
