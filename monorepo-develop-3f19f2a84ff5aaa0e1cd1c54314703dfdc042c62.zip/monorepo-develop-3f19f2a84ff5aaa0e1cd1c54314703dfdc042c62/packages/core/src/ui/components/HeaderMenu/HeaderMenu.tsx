/**
 * TODO: unUsed Component
 */
import * as React from "react";
import styled from "styled-components";
import { PictureTag } from "../../";
import { LocationContext } from "../../../contexts/LocationContext";
import { StyledLink } from "../Typography";

interface HeaderMenuProps {
  close?: any;
}

const StyledHeaderMenu = styled("div")<HeaderMenuProps>`
  width: 100%;
  height: 100%;
  padding-top: 60px;
  position: fixed;
  z-index: 9;
  border-top: 1px solid #f7f6f6;
  box-shadow: 0px 0px 3px rgba(0, 0, 0, 0.16);
  background: rgba(0, 0, 0, 0.4);
`;

const MenuWrapper = styled("div")`
  padding: 20px;
  background-color: ${props => props.theme.colors.white};
`;

const ListImage = styled("div")`
  /*width: 10%;*/
  // padding-left: 10px;
`;

const MenuRow = styled(StyledLink)`
  width: 100%;
  padding: 10px 0px;
  cursor: pointer;
  display: block;
`;
const HeaderLink = styled(StyledLink)`
  width: 100%;
  padding: 10px 0px;
  cursor: pointer;
  display: block;
`;

const LineBar = styled.div`
  width: 100%;
  border: 1px solid #f7f6f6;
  margin-top: 10px;
  margin-bottom: 10px;
`;

// const ListContentDiv = styled.div`
//   margin-top: 20px;
// `;

// const MenuItems = styled.div`
//   margin-left: 25px;
//   display: inline-block;
// `;
const Label = styled.div`
  margin-left: 25px;
  display: inline-block;
`;

// const ListContentPara = styled(StyledLink)`
//   // padding-left: 10px;
//   cursor: pointer;
//   display: block;
//   margin: 15px 0px;
// `;

// const AnchorTag = styled("a")`
//   text-decoration: none;
//   color: inherit;
//   cursor: pointer;
// `;

interface LinkProps {
  to: string;
  label: string;
  type?: string;
  picture?: string;
  external?: boolean;
  desktop?: boolean;
  mobile?: boolean;
}

const links: LinkProps[] = [
  {
    picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
    label: "Services",
    to: "/chennai"
  },
  {
    label: "How it works",
    to: "/how-it-works"
  },
  {
    picture: "//www.weddingbazaar.com/assets/icons/m-wedding-assist.svg",
    label: "Wedding Assist",
    to: "/wedding-assist"
  },
  {
    label: "Ideas and Inspirations",
    to: "/ideas"
  },
  {
    picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
    label: "Wedding Stories",
    to: "/wedding-stories"
  },
  {
    type: "separator",
    to: "string",
    label: "string"
  },
  {
    label: "Submit your Wedding Story",
    to: "//goo.gl/forms/M4jfYYuFVL4FffGk1",
    external: true
  },
  {
    label: "Vendor Sign up",
    to: "//www.weddingbazaar.com/onboard-vendor",
    external: true
  }
];

const HeaderLinks: React.FC<any> = React.memo(props => {
  const renderedLinks = links.map((link, id) => {
    const { city: autoDetectedCity } = React.useContext(LocationContext);
    if (link.type === "separator") {
      return <LineBar key={id} />;
    }
    return (
      <HeaderLink
        key={id}
        to={link.label === "Services" ? `/${autoDetectedCity}` : link.to}
        target={link.external ? "_blank" : undefined}
        rel="noreferrer"
      >
        {link.picture && (
          <PictureTag image={link.picture} alt={link.label} fullWidth={false} />
        )}

        <Label>{link.label}</Label>
      </HeaderLink>
    );
  });
  return <React.Fragment>{renderedLinks}</React.Fragment>;
});

// TODO: change city in MenuRow
export const HeaderMenu = React.memo((props: HeaderMenuProps) => {
  return (
    <StyledHeaderMenu onClick={props.close}>
      <MenuWrapper>
        <HeaderLinks />
      </MenuWrapper>
    </StyledHeaderMenu>
  );
});
