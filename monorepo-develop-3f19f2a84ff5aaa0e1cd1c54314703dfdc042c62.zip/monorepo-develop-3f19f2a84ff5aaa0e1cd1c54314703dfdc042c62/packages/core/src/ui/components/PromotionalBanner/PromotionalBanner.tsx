import * as React from "react";
import styled from "styled-components";
import { Media } from "../../types";
import { Chips } from "../Chips/Chips";
import { SiteIcon } from "../Icon/Icon";
import { Headline, Secondary1 } from "../Typography";

export interface PromotionalBannerProps {
  primary: string;
  secondary: string;
  heroPhoto: Media;
}

const Card = styled("div")`
  border-radius: 0.2rem;
  overflow: hidden;
  text-align: center;
  display: block;
`;

const SponsoredBadge = styled(Chips)`
  background-color: #00a651;
  position: absolute;
  margin: 3px;
  color: #fff;
  font-size: 12px;
  font-weight: ${props => props.theme.fontWeight.semiBold};
`;

const CardDiv = styled("div")<PromotionalBannerProps>`
background-image: url("${props => props.heroPhoto.url}");
background-position: top;
height: 9rem;
background-repeat: no-repeat;
background-size: cover;
`;
const GradientWsDev = styled("div")`
  background: linear-gradient(
    rgba(255, 255, 255, 0.06) 30%,
    rgba(146, 146, 146, 0.22) 60%,
    rgba(0, 0, 0, 0.65) 100%
  );
  height: 9rem;
`;

const SponsorCaptionDiv = styled("div")`
  font-size: ${props => props.theme.fontSize[150]};
  text-align: left;
  color: rgba(255, 255, 255, 1);
  font-weight: ${props => props.theme.fontWeight.semiBold}
  position: relative;
  white-space: nowrap;
  width: 80%;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 0 1rem;
  bottom: -3rem;
`;

export const PromotionalBanner: React.FC<PromotionalBannerProps> = React.memo(
  props => {
    const { primary, secondary } = props;

    return (
      <React.Fragment>
        <Card>
          <CardDiv {...props}>
            <GradientWsDev>
              <SponsoredBadge>
                <SiteIcon
                  name={"verified-tick"}
                  style={{
                    width: "12px",
                    height: "15px",
                    verticalAlign: "sub",
                    fill: "#FFF",
                    margin: "0",
                    paddingRight: "0px"
                  }}
                />
                <span> Sponsored </span>
              </SponsoredBadge>
              <SponsorCaptionDiv title={primary}>
                <Headline
                  as={"h2"}
                  style={{
                    color: "white",
                    textAlign: "left",
                    fontWeight: 600,
                    fontSize: "0.875rem"
                  }}
                >
                  {primary}
                </Headline>
                <Secondary1 style={{ color: "white", fontWeight: 400 }}>
                  {/* <SiteIcon
                  name={"location-on"}
                  style={{
                    width: "13px",
                    fill: "rgb(150,150,150)",
                    height: "13px"
                  }}
                /> */}
                  {secondary}
                </Secondary1>
              </SponsorCaptionDiv>
            </GradientWsDev>
          </CardDiv>
        </Card>
      </React.Fragment>
    );
  }
);
