import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { PromotionalBanner, PromotionalBannerProps } from "./PromotionalBanner";

afterEach(cleanup);

const props: PromotionalBannerProps = {
  primary: "Annapoorni Hotel",
  secondary: "heaven",
  heroPhoto: { url: "https://picsum.photos/id/602/1200/800" }
};

describe("PromotionalBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(<PromotionalBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
