import * as React from "react";
import { Helmet } from "react-helmet-async";
import { helmetJsonLdProp } from "react-schemaorg";
import { BreadcrumbList } from "schema-dts";
import styled from "styled-components";
import { StyledLink } from "../Typography";

export interface BreadCrumbsProps {
  crumbs: any;
}

const BreadCrumbsDiv = styled("div")`
  grid-area: breadcrumbs;
  ${props => props.theme.media.mobile} {
    display: none;
  }
`;

const BreadCrumbsHead = styled("ul")`
  padding-inline-start: 0;
`;

const BreadCrumbsList = styled("li")`
  display: inline;
  font-size: 14px;
`;

const BreadCrumbsText = styled(StyledLink)`
  color: black;
  font-size: 14px;
  text-decoration: none;
  &:hover {
    color: ${props => props.theme.colors.primary};
  }
`;

const BreadCrumbsLast = styled("span")`
  color: black;
  font-size: 14px;
`;
const UnstyledBreadCrumbs: React.FC<BreadCrumbsProps> = props => {
  return (
    <BreadCrumbsDiv>
      <Helmet
        script={[
          helmetJsonLdProp<BreadcrumbList>({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: props.crumbs.map((bc: any, idx: any) => ({
              "@type": "ListItem",
              position: idx + 1,
              name: bc.title,
              item: `https://weddingbazaar.com${bc.url}`
            }))
          })
        ]}
      />

      <BreadCrumbsHead>
        {props.crumbs.length > 0 &&
          props.crumbs.map((bc: any, idx: any) => (
            <BreadCrumbsList key={idx}>
              {idx === props.crumbs.length - 1 ? (
                <BreadCrumbsLast>{bc.title}</BreadCrumbsLast>
              ) : (
                <>
                  <BreadCrumbsText to={bc.url}>{bc.title}</BreadCrumbsText>{" "}
                  <span> / </span>
                </>
              )}
            </BreadCrumbsList>
          ))}
      </BreadCrumbsHead>
    </BreadCrumbsDiv>
  );
};

export const BreadCrumbs = React.memo(styled(UnstyledBreadCrumbs)``);
