import styled from "styled-components";
export { StyledLink } from "../../atoms";
interface TextProps {
  align?: string;
  font?: string;
}
interface HeadlineProps extends TextProps {}
export const Heading1 = styled("div")`
  text-align: center;
  font-size: ${props => props.theme.fontSize[300]};
  font-weight: ${props => props.theme.fontWeight.bold};
  color: ${props => props.theme.colors.black};
`;
export const Headline = styled("h1")<HeadlineProps>`
  font-family: ${props => props.theme.fontFamily};
  font-weight: ${props => props.theme.fontWeight.medium};
  color: ${props => props.theme.colors.black};
  font-size: ${props => props.theme.fontSize[200]};
  line-height: 1.5rem;
  margin: 0;
  text-align: ${props => (props.align ? props.align : "inherit")}
    ${props => props.theme.media.desktop} {

  }
`;

export const Secondary1 = styled("div")`
  font-family: ${props => props.theme.fontFamily};
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize[150]};
  color: ${props => props.theme.colors.black};
`;
export const Secondary = styled("p")`
  font-family: ${props => props.theme.fontFamily};
  font-weight: ${props => props.theme.fontWeight.medium};
  text-align: inherit;
  font-size: ${props => props.theme.fontSize[100]};
  color: rgba(150, 150, 150, 1);
`;
export const Subtitle = styled("div")`
  font-family: ${props => props.theme.fontFamily};
  font-weight: ${props => props.theme.fontWeight.medium};
  margin-right: 8px;
  margin-top: 3px;
  font-size: 12px;
  color: #2a2c34;
`;

export const LinkText = styled("span")`
  font-family: ${props => props.theme.fontFamily};
  font-weight: ${props => props.theme.fontWeight.medium};
  margin-top: 3px;
  float: right;
  color: ${props => props.theme.colors.primary};
  font-size: 10px;
  margin-right: 30px;
`;

export const SubText = styled("span")`
  color: rgba(158, 158, 158, 1);
  font-size: 14px;
  padding: 20px 0px 0px 12px;
`;
