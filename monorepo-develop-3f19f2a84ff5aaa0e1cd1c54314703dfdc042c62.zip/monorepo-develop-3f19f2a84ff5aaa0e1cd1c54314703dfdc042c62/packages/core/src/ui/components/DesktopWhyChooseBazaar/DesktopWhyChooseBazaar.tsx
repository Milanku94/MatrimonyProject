import _padStart from "lodash/padStart";
import * as React from "react";
import { Helmet } from "react-helmet-async";
import { helmetJsonLdProp } from "react-schemaorg";
import { HowTo } from "schema-dts";
import styled from "styled-components";
import { BulletPoint, H2, Paragraph, SiteIcon, Text } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { FancyHeader } from "../../molecules/FancyHeader/FancyHeader";

export interface DesktopWhyChooseBazaarProps {
  semData?: any;
  mode?: "howItCrisilSemWorks" | "howItCovidSemWorks" | "whyUs";
}

export const BulletList = styled("div")`
  display: flex;
`;
export const CommonDiv = styled("div")<DesktopWhyChooseBazaarProps>`
  display: ${props => (props.semData ? "flex" : "none")};
  margin: 0rem auto;
  padding: 3.5rem 2rem;
  width: 80%;
  min-height: 22rem;
  ${props => props.theme.media.desktop} {
    display: flex;
  }
  ${BulletList} {
    align-items: ${props => (props.semData ? "flex-start" : "center")};
    margin-top: 1rem;
  }
`;
export const MainContainer = styled("div")`
  display: flex;
  flex-direction: column;
  flex: 1;
`;
export const LeftContainer = styled(MainContainer)`
  padding-right: 2rem;
`;
export const RightContainer = styled(MainContainer)`
  padding-left: 2rem;
  border-left: solid 0.07rem ${props => props.theme.colors.gray4};
`;
export const HeaderDiv = styled("div")`
  flex: 1;
  margin: 0.5rem 0;
  text-align: center;
`;
export const SelfContainer = styled("div")`
  flex: 3;
  justify-content: space-between;
  display: flex;
  flex-direction: column;
  align-items: start;
`;

const FancyLine = styled("div")`
  ${props => props.theme.media.mobile} {
    display: none;
  }
  text-align: center;
  span {
    display: inline-block;
    position: relative;
    color: ${props => props.theme.colors.primary};
  }
  span:before,
  span:after {
    content: "";
    position: absolute;
    height: 5px;
    border-bottom: 1px solid ${props => props.theme.colors.primary};
    top: 7px;
    width: 5rem;
  }
  span:before {
    right: 100%;
    margin-right: 15px;
  }
  span:after {
    left: 100%;
    margin-left: 15px;
  }
`;
export const Header = React.memo(
  ({
    heading,
    isFancyHeader,
    subHeading
  }: {
    heading: string;
    subHeading?: string;
    isFancyHeader?: boolean;
  }) => {
    return (
      <HeaderDiv>
        {isFancyHeader ? (
          <FancyHeader title={heading} />
        ) : (
          <H2
            fontSize={300}
            margin="major-0 auto"
            fontWeight="medium"
            color="black"
          >
            {heading}
          </H2>
        )}
        {subHeading && (
          <Paragraph fontSize={150} fontWeight="medium" color="gray1">
            {subHeading}
          </Paragraph>
        )}
      </HeaderDiv>
    );
  }
);

export const Bullet = ({
  point,
  main,
  sub,
  shape,
  round
}: {
  point: JSX.Element | string;
  main: string;
  sub?: string;
  shape?: string;
  round?: boolean;
}) => (
  <BulletList>
    {round ? (
      <div> {point}</div>
    ) : (
      <BulletPoint shape="round" margin="minor-1">
        {point}
      </BulletPoint>
    )}
    <Text fontSize={150} fontWeight="bold" margin="major-1" color="primary">
      {main}
      {sub && (
        <Text fontSize={150} fontWeight="medium" color="gray1">
          {sub}
        </Text>
      )}
    </Text>
  </BulletList>
);
const HelmetSchema = React.memo(
  ({
    leftContent,
    rightContent,
    mode
  }: {
    leftContent: any;
    rightContent: any;
    mode: string;
  }) => (
    <Helmet
      script={[
        helmetJsonLdProp<HowTo>({
          "@context": "https://schema.org",
          "@type": "HowTo",
          name: leftContent.title,
          description: leftContent.subtitle,
          supply: "WeddingBazaar from BharatMatrimony",
          tool: mode ? mode : "Why WeddingBazaar",
          totalTime: "PT3M15S",
          image: {
            "@type": "ImageObject",
            url: "https://www.weddingbazaar.com/assets/bg/wa-banner.jpg",
            height: "406",
            width: "305"
          },
          step: [
            {
              "@type": "HowToSection",
              name: leftContent.title,
              description: leftContent.subtitle,
              position: 1,
              image: {
                "@type": "ImageObject",
                url: "https://www.weddingbazaar.com/assets/bg/wa-banner.jpg",
                height: "406",
                width: "305"
              },
              itemListElement: leftContent.steps.map(
                ({ strong, followup: text }: any) => ({
                  "@type": "HowToStep",
                  name: strong,
                  text,
                  url: "https://www.weddingbazaar.com",
                  image: {
                    "@type": "ImageObject",
                    url:
                      "https://www.weddingbazaar.com/assets/bg/wa-banner.jpg",
                    height: "406",
                    width: "305"
                  }
                })
              )
            },
            {
              "@type": "HowToSection",
              name: "how it works",
              description: rightContent.title,
              position: 2,
              itemListElement: rightContent.steps.map(
                ({ long: text, short }: any) => ({
                  "@type": "HowToStep",
                  name: short,
                  text,
                  url: "https://www.weddingbazaar.com",
                  image: {
                    "@type": "ImageObject",
                    url:
                      "https://www.weddingbazaar.com/assets/bg/wa-banner.jpg",
                    height: "406",
                    width: "305"
                  }
                })
              )
            }
          ]
        })
      ]}
    />
  )
);
export const UnstyledDesktopWhyChooseBazaar = React.memo(
  ({ mode = "whyUs" }: DesktopWhyChooseBazaarProps) => {
    const { domain } = React.useContext(DomainContext);
    // const mode = content.Domains.writer.filter((mode:any)=> semData ? semData .includes(mode.semData) : true )
    if (domain === content.Domains.writer) {
      return <></>;
    }
    const isCombined = mode === "whyUs";
    return (
      <CommonDiv mode={mode}>
        <HelmetSchema
          leftContent={content[domain][mode]}
          rightContent={content[domain].howItWorks}
          mode={mode}
        />
        <LeftContainer>
          <Header
            isFancyHeader={!isCombined}
            heading={content[domain][mode].title}
            subHeading={content[domain][mode].subtitle}
          />
          <SelfContainer>
            {content[domain][mode].steps.map(
              ({ strong, followup, icon = true }: any, idx: any) => (
                <Bullet
                  key={idx}
                  point={
                    isCombined ? (
                      _padStart((+idx + 1).toString(), 2, "0")
                    ) : (
                      <SiteIcon
                        name={icon}
                        style={{
                          width:
                            mode === "howItCovidSemWorks" ? "3.085rem" : "1rem",
                          height: "auto"
                        }}
                      />
                    )
                  }
                  main={strong}
                  sub={followup}
                  round={mode === "howItCovidSemWorks"}
                />
              )
            )}
          </SelfContainer>
        </LeftContainer>
        {isCombined && (
          <RightContainer>
            <Header
              heading="How it works"
              subHeading={content[domain].howItWorks.title}
            />
            <SelfContainer>
              {content[domain].howItWorks.steps.map(
                ({ short: desc }: any, idx: any) => (
                  <Bullet
                    key={idx}
                    point={_padStart((+idx + 1).toString(), 2, "0")}
                    main={desc}
                  />
                )
              )}
            </SelfContainer>
          </RightContainer>
        )}
      </CommonDiv>
    );
  }
);

export const DesktopWhyChooseBazaar = styled(UnstyledDesktopWhyChooseBazaar)``;
