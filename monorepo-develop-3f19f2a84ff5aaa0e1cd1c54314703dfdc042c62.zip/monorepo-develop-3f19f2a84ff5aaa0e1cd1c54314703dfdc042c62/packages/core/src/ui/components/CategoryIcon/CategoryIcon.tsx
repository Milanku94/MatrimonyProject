import * as React from "react";
import styled from "styled-components";
import { CategoryIcon as SVGIcon } from "../Icon/Icon";
import { StyledLink } from "../Typography";

interface CategoryIconProps {
  displaytype?: "box" | "list";
  isActive?: boolean;
  name?: string;
}

export interface CategoryType {
  id: string;
  needName: string;
  city?: string;
  slug: string;
  displaytype?: "box" | "list";
  isActive?: boolean;
  elementID?: string;
}

export const CategoryIconWrapper = styled(StyledLink)<CategoryIconProps>`
  background-color: ${props => props.displaytype === "box" && "#FFF"};
  padding: 0.5rem 0.8rem;
  margin: 1px;
  text-align: center;
  height: ${props => props.displaytype === "box" && "5rem"};
  display: ${props => (props.displaytype === "list" ? "inline-block" : "none")};
  ${props => props.theme.media.mobile} {
    width: ${props => (props.displaytype === "box" ? "4rem" : "3.5rem")};
  }
  ${props => props.theme.media.desktop} {
    margin-bottom: ${props => props.displaytype === "list" && "15px"};
    width: ${props => (props.displaytype === "box" ? "5rem" : "3.5rem")};
    &:hover {
      box-shadow: ${props =>
        props.displaytype === "box" &&
        "0 0px 10px rgba(0, 0, 0, 0.1), 0 23px 24px rgba(0, 0, 0, 0.02)"};
      svg {
        fill: ${props =>
          props.displaytype === "box" && props.theme.colors.black};
      }
      p {
        color: ${props =>
          props.displaytype === "box" && props.theme.colors.black};
      }
    }
  }
`;

const Img = styled(SVGIcon)<CategoryIconProps>`
  padding-top: 0.5rem;
  height: ${props => (props.displaytype === "box" ? "2.9rem" : "2.5rem")};
  fill: ${props =>
    props.displaytype !== "box"
      ? props.isActive
        ? props.theme.colors.primary
        : props.theme.colors.gray1
      : props.theme.colors.gray1};
`;
const Name = styled("p")<CategoryIconProps>`
  margin: -0.3rem;
  height: ${props => props.displaytype === "box" && "2rem"};
  border-bottom: ${props =>
    props.isActive &&
    props.displaytype !== "box" &&
    "1.5px solid" + props.theme.colors.primary};
  font-weight: ${props =>
    props.isActive && props.displaytype !== "box" && "500"};
  color: ${props =>
    props.displaytype !== "box"
      ? props.isActive
        ? props.theme.colors.black
        : props.theme.colors.gray1
      : props.theme.colors.gray1};
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: ${props => props.theme.fontSize[100]};
  font-weight: ${props => props.theme.fontWeight.medium};

  padding-bottom: ${props => props.displaytype === "list" && "5px"};
`;
export const UnstyCategoryIcon: React.FC<CategoryType> = React.memo(
  (props: CategoryType) => {
    return (
      <CategoryIconWrapper
        to={"/" + props.city + "/" + props.slug}
        displaytype={props.displaytype}
        id={`${props.elementID}-${props.slug}`}
      >
        <Img
          name={props.slug}
          isActive={props.isActive}
          displaytype={props.displaytype}
        />
        <Name isActive={props.isActive} displaytype={props.displaytype}>
          {props.needName}
        </Name>
      </CategoryIconWrapper>
    );
  }
);

export const CategoryIcon = styled(UnstyCategoryIcon)``;
