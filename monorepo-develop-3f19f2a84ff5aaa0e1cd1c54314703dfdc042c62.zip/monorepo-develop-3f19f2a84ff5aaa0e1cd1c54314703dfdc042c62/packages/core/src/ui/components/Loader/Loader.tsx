import * as React from "react";
import styled from "styled-components";
interface LoaderProps {}

interface DotProps {
  active: boolean;
}

const NUM_DOTS = 3;

const Dot = styled("div")<DotProps>`
width: 1rem;
height: 1rem;
border-radius: 1rem;
display: inline-block
margin: 0.25rem;
background-color: ${props =>
  props.active ? "rgba(245, 130, 32, 1)" : "rgba(245, 130, 32, 0.5)"};
`;
const MB = styled("div")`
  font-size: 4rem;
  span:first-child {
    color: ${props => props.theme.colors.primary};
  }
  span:last-child {
    color: ${props => props.theme.colors.primary};
  }
`;

const drawDot = (index: number, active: boolean) => (
  <Dot key={index} active={active} />
);

const Dots: React.FC<{ activeIndex: number }> = React.memo(props => {
  const dots = Array.from(Array(NUM_DOTS).keys()).map(id =>
    drawDot(id, id === props.activeIndex)
  );

  return <div>{dots}</div>;
});

const LoaderContainer = styled("div")`
  text-align: center;
`;

export const Loader: React.FC<LoaderProps> = React.memo(() => {
  const [index, setIndex] = React.useState(0);

  React.useEffect(() => {
    const timer1 = setTimeout(
      () => setIndex((old: number) => (old + 1) % NUM_DOTS),
      1000
    );
    return () => {
      clearTimeout(timer1);
    };
  }, [index]);

  return (
    <LoaderContainer>
      <MB>
        <span>w</span>
        <span>b</span>
      </MB>
      <Dots activeIndex={index} />
    </LoaderContainer>
  );
});
