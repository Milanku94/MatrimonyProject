import styled from "styled-components";

export const CardBody = styled("div")`
  // border-top: 1px solid #d6d6d6;
  padding: 0 0.5rem;
  background: ${props => props.theme.colors.white};
  grid-area: card-body;
`;
