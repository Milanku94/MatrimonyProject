import * as React from "react";
import { Helmet } from "react-helmet-async";
import { helmetJsonLdProp } from "react-schemaorg";
import { Organization } from "schema-dts";
import styled from "styled-components";
import { Logo, SiteIcon, StyledLink } from "../../";
import * as content from "../../../content";
import {
  DomainContext,
  DomainContextProps
} from "../../../contexts/DomainContext";

interface FooterProps {
  cities?: any;
  minimal?: boolean;
}

const FooterSection = styled("div")`
  background-color: #f2f2f2;
  padding: 2rem 2rem 0rem 2rem;
  display: grid;
  ${Logo} {
    grid-area: mb-logo;
    padding-top: 1rem;
  }
  ${props => props.theme.media.mobile} {
    grid-template-columns: 1fr;

    grid-template-areas:
      "speak-with-us"
      "mb-logo"
      "social"
      "internal-links"
      "city"
      "category"
      "eco-links"
      "tnc";
  }

  ${props => props.theme.media.desktop} {
    grid-template-columns: 1fr 1fr;

    grid-template-areas:
      "mb-logo mb-logo"
      "social social"
      "internal-links internal-links"
      "city city"
      "category category"
      "eco-links tnc";
  }
`;

export const CommonFooter = styled("div")`
  padding-top: 25px;
`;

const MatrimonyLinks = styled("div")`
  padding-bottom: 1.5rem;
  border-bottom: 0.5px solid rgba(0, 0, 0, 0.18);
  display: flex;
  flex-wrap: wrap;
  justify-content: space-evenly
  margin-top: 1.5rem;
  text-align: center;
  grid-area: eco-links;
  ${props => props.theme.media.desktop} {
    border-bottom: none;
  }


`;
const MatrimonyLink = styled("a")`
  list-style-type: none;
  margin-bottom: 1rem;
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize[100]};
  color: ${props => props.theme.colors.primary};
  text-decoration: none;
  min-width: 50%;
  ${props => props.theme.media.desktop} {
    font-size: ${props => props.theme.fontSize[50]};
    min-width: 25%;
    margin: 0;
    padding: 0;
  }

  @media only screen and (min-width: 1300px) {
    font-size: ${props => props.theme.fontSize[100]} !important;
  }
`;
const InternalLinks = styled("div")`
  grid-area: internal-links;
  padding-bottom: 1.5rem;
  border-bottom: 0.5px solid rgba(0, 0, 0, 0.18);
  display: flex;
  flex-wrap: wrap;
  justify-content: space-evenly
  margin-top: 1.5rem;
  text-align: center;
`;
const CityCategoryLink = styled(StyledLink)`
  &:link,
  &:active,
  &:visited,
  &:hover {
    color: #666;
    text-decoration: none;
    font-size: ${props => props.theme.fontSize[100]};
    width: 100%;
    padding: 0.4rem;
  }
`;
const CityCategoryLinks = styled("div")<{ name: string }>`
  grid-area: ${props => props.name || "city"};
  padding-bottom: 1.5rem;
  border-bottom: 0.5px solid rgba(0, 0, 0, 0.18);
  margin-top: 1.5rem;
  text-align: left;
  display: grid;
  grid-column-gap: 0.9rem;
  grid-template-columns: repeat(
    auto-fill,
    minmax(${props => (props.name === "city" ? "100px" : "250px")}, 1fr)
  );
`;
const InternalLink = styled(StyledLink)`
  &:link,
  &:active,
  &:visited,
  &:hover {
    list-style-type: none;
    margin-bottom: 1rem;
    font-weight: ${props => props.theme.fontWeight.medium};
    color: ${props => props.theme.colors.primary};
    font-size: ${props => props.theme.fontSize[200]};
    text-decoration: none;
  }

  ${props => props.theme.media.mobile} {
    &:link,
    &:active,
    &:visited,
    &:hover {
      min-width: 50%;
    }
  }
`;
const SocialLinks = styled("div")`
  padding-top: 25px;
  display: flex;
  justify-content: space-between;
  grid-area: social;

  ${props => props.theme.media.desktop} {
    width: 30%;
    margin: 0 auto;
  }
`;

const ContactHead = styled("a")`
  padding-top: 42px;
  display: block;
  text-decoration: none;
  grid-area: speak-with-us;

  ${props => props.theme.media.desktop} {
    display: none;
  }
`;
const ContactIcon = styled.div`
  margin: 0px auto;
  width: 2rem;
  height: 2rem;
  border-radius: 3px;
  background-color: ${props => props.theme.colors.primary};
  text-align: center;
`;

const ContactTitle = styled.div`
  color: rgba(51, 51, 51, 1);
  font-size: ${props => props.theme.fontSize[150]};
  font-weight: ${props => props.theme.fontWeight.semiBold}
  padding-top: 0.75rem;
  text-align: center;
`;

const ContactSubTitle = styled.div`
  padding-top: 0.25rem;
  width: 35%;
  text-align: center;
  margin: 0px auto;
  font-size: ${props => props.theme.fontSize[100]};
  color: rgba(42, 44, 52, 1);
`;

const TermsConditions = styled.div`
  text-align: center;
  font-size: 0.5px;
  color: rgba(0, 0, 0, 1);
  margin-top: 45px;
`;
const CopyRights = styled.div`
  font-size: ${props => props.theme.fontSize[50]};
  color: rgba(29, 29, 29, 1);
  font-weight: ${props => props.theme.fontWeight.semiBold}
  text-align: center;
  padding: 1rem;
  grid-area: tnc;
  ${props => props.theme.media.mobile} {
    margin-bottom: 2rem;
  }
  ${props => props.theme.media.desktop} {
    margin: 0;
    align-items: center;
    display: flex;
    justify-content: flex-end;
    padding-right: 10px;
    font-size: ${props => props.theme.fontSize[100]};
    padding: 0.4rem;
    font-weight: ${props => props.theme.fontWeight.regular}
    color: #666;
  }

  a {
    margin: 0.5rem 1.5rem;
    color: #666 !important;
    font-weight: ${props => props.theme.fontWeight.medium};
    ${props => props.theme.media.mobile} {
      display: block;
    }
  }
`;

const MatrimonyLinksDesktop = styled("div")`
  padding: 8px 20px 12px 20px;

  @media only screen and (min-width: 799px) and (max-width: 1024px) {
  }
  ${props => props.theme.media.mobile} {
    display: none;
  }
`;

const FooterBottomLinks = styled("ul")`
  float: none;
  text-align: center;
  margin: 5px;
`;
const FooterBottomLink2 = styled("ul")`
  float: none;
  text-align: center;
  margin: 5px;
`;
const FooterListLinks = styled("li")`
  display: inline-block;
  margin-right: 12px;
`;

const FooterListLinks2 = styled("li")`
  margin-right: 12px;
  display: inline-block;
  font-size: 12px;
  color: #969696;
`;
const FooterAnchorTags = styled("a")`
  text-decoration: none;
  color: #2231a7;
  font-size: 12px;
`;

const IconDiv = styled("div")`
verticalAlign: "middle",color: social.color, fontSize: 27
`;

const METRO_CITIES = ["bangalore", "chennai", "hyderabad", "kochi"];

const socialLinksConfig = {
  facebook: {
    name: "facebook",
    fill: "#475993",
    baseUrl: "https://www.facebook.com/"
  },
  twitter: {
    name: "twitter",
    fill: "#32AAE2",
    baseUrl: "https://twitter.com/"
  },
  instagram: {
    name: "instagram",
    fill: "#CD614F",
    baseUrl: "https://instagram.com/"
  },
  pinterest: {
    name: "pinterest",
    fill: "#E60023",
    baseUrl: "https://in.pinterest.com/"
  },
  youtube: {
    name: "youtube",
    fill: "#F60004",
    baseUrl: "https://www.youtube.com/channel/"
  }
};

const SocialIcon = ({
  name,
  fill
}: {
  name: "facebook" | "twitter" | "instagram" | "pinterest" | "youtube";
  fill: string;
}) => (
  <SiteIcon
    name={name}
    style={{
      width: "2rem",
      height: "2rem",
      fill
    }}
  />
);
const ecoLinks: Array<{
  to: string;
  label: string;
  domain?: DomainContextProps["domain"];
}> = [
  {
    to: "https://www.matrimonyphotography.com/",
    label: "MatrimonyPhotography",
    domain: content.Domains.mBazaar
  },
  {
    to: "https://www.weddingbazaar.com/",
    label: "WeddingBazaar",
    domain: content.Domains.mPhoto
  },
  {
    to: "https://www.mandap.com//",
    label: "mandap"
  },
  {
    to: "https://www.bharatmatrimony.com/",
    label: "BharatMatrimony"
  },
  {
    to: "https://www.communitymatrimony.com/",
    label: "CommunityMatrimony"
  }
];

const SpeakWithUs = React.memo(() => {
  const { domain } = React.useContext(DomainContext);
  return (
    <ContactHead
      href={`tel:+91${content[domain].phoneNumber}`}
      id="footer-call"
    >
      <ContactIcon>
        <SiteIcon
          name={"phone-1"}
          style={{
            fill: "#fff"
          }}
        />
      </ContactIcon>
      <ContactTitle> Speak With Us </ContactTitle>
      <ContactSubTitle>
        {" "}
        You can call us on {content[domain].phoneNumber}{" "}
      </ContactSubTitle>
    </ContactHead>
  );
});

export const Footer = React.memo(
  ({ minimal = false, ...props }: FooterProps) => {
    const { domain } = React.useContext(DomainContext);
    if (domain === content.Domains.writer) {
      return <></>;
    }

    return (
      <FooterSection>
        <SpeakWithUs />
        <Logo size="large" />
        <Helmet
          script={[
            helmetJsonLdProp<Organization>({
              "@context": "https://schema.org",
              "@type": "Organization",
              "@id": "#organization",
              legalName: content[domain].legalName,
              name: content[domain].name,
              logo: content[domain].logo,
              url: content[domain].url,
              sameAs: content[domain].socialLinks.map(
                (social: any) =>
                  socialLinksConfig[social.platform].baseUrl + social.id
              )
            })
          ]}
        />

        {!minimal && (
          <React.Fragment>
            <SocialLinks>
              {content[domain].socialLinks.map((social: any) => (
                <a
                  href={socialLinksConfig[social.platform].baseUrl + social.id}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={social.label}
                  key={social.label}
                >
                  <SocialIcon
                    name={socialLinksConfig[social.platform].name}
                    fill={socialLinksConfig[social.platform].fill}
                  />
                </a>
              ))}
            </SocialLinks>
            <InternalLinks>
              {content[domain].links
                .filter(link =>
                  typeof link.footer === "boolean"
                    ? link.footer
                    : link.type !== "separator"
                )
                .map(link => (
                  <InternalLink to={link.to} key={link.label}>
                    {link.label}
                  </InternalLink>
                ))}
            </InternalLinks>
            {props.cities && (
              <React.Fragment>
                <CityCategoryLinks name="city">
                  {props.cities
                    .sort((a: any, b: any) => a.name.localeCompare(b.name))
                    .map((city: any) => (
                      <CityCategoryLink to={`/${city.slug}`} key={city.slug}>
                        {city.name}
                      </CityCategoryLink>
                    ))}
                </CityCategoryLinks>
                {domain === content.Domains.mBazaar && (
                  <CityCategoryLinks name="category">
                    {props.cities
                      .filter((city: any) => METRO_CITIES.includes(city.slug))
                      .map((city: any) => {
                        return (
                          !!city.categories &&
                          city.categories.slice(0, 8).map((category: any) => {
                            return (
                              <CityCategoryLink
                                to={`/${city.slug}/${category.slug}`}
                                key={city.id + "/" + category.id}
                              >
                                {category.name} in {city.name}
                              </CityCategoryLink>
                            );
                          })
                        );
                      })}
                  </CityCategoryLinks>
                )}
              </React.Fragment>
            )}

            <MatrimonyLinks>
              {ecoLinks
                .filter(
                  link =>
                    typeof link.domain === "undefined" || link.domain === domain
                )
                .map(link => (
                  <MatrimonyLink
                    key={link.label}
                    href={link.to}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {link.label}
                  </MatrimonyLink>
                ))}
            </MatrimonyLinks>
          </React.Fragment>
        )}
        <CopyRights>
          <StyledLink to={"/privacy"}>Privacy Policy</StyledLink>
          <StyledLink to={"/terms"}>T&C</StyledLink>
          Copyright © {new Date().getFullYear()}. All rights reserved.
        </CopyRights>
      </FooterSection>
    );
  }
);
