import * as React from "react";
import styled from "styled-components";

export interface RatingsSectionProps {}

const RatingBody = styled("div")``;

const RatingStars = styled("div")`
  display: grid;
  grid-template-columns: 60% 40%;
  border-bottom: 1px solid #eeeeee;
`;

const StarsDiv = styled("div")`
  display: flex;
`;
const HappyCustomersDiv = styled("div")`
  margin: 8px 16px;
  span {
    color: #363636;
    font-size: 0.9375rem;
    font-weight: ${props => props.theme.fontWeight.medium};
  }
  p {
    color: #363636;
    font-size: ${props => props.theme.fontSize[100]};
    font-weight: ${props => props.theme.fontWeight.medium};
    margin: 4px 0px;
  }
`;

const ScaleDiv = styled("span")`
  color: #363636;
  font-size: ${props => props.theme.fontSize[600]};
`;

const StarSec = styled("div")`
  margin: 8px 10px;
  span {
    color: #363636;
    font-size: 0.9375rem;
    font-weight: ${props => props.theme.fontWeight.medium};
  }
`;

const Stars = styled("p")`
  margin: 5px 0px;
`;

const UnstyledRatingsSection = React.memo((props: RatingsSectionProps) => {
  return (
    <RatingBody>
      <RatingStars>
        <StarsDiv>
          <ScaleDiv> 4.9 </ScaleDiv>
          <StarSec>
            <span> Out of 5.0 </span>
            <Stars>*****</Stars>
          </StarSec>
        </StarsDiv>
        <HappyCustomersDiv>
          <span> 250+</span>
          <p> Happy Customers</p>
        </HappyCustomersDiv>
      </RatingStars>
    </RatingBody>
  );
});

export const RatingsSection = styled(UnstyledRatingsSection)<
  RatingsSectionProps
>``;
