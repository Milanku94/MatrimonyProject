import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { RatingsSection, RatingsSectionProps } from "./RatingsSection";

afterEach(cleanup);

const props: RatingsSectionProps = {};

describe("RatingsSection:", () => {
  it("renders correctly", () => {
    const { container } = render(<RatingsSection {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
