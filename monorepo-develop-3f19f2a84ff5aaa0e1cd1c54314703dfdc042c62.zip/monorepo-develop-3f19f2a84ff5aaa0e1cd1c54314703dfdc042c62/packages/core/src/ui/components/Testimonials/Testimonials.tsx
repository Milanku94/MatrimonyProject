/**
 * TODO: move into organisms
 */
import * as React from "react";
import { CarouselBanner, TestimonialCard } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { FancyHeader } from "../../molecules/FancyHeader/FancyHeader";

interface TestimonialsProps {
  reviewAction?: () => void;
  moreAction?: () => void;
}

export const Testimonials: React.FC<TestimonialsProps> = React.memo(
  ({ reviewAction, moreAction }) => {
    const { domain } = React.useContext(DomainContext);
    if (domain === content.Domains.writer) {
      return <></>;
    }

    return (
      <CarouselBanner
        title={<FancyHeader title={"What our customers say"} />}
        more={moreAction && { action: moreAction, text: "View more reviews" }}
        showIndicators={true}
        autoChangeIn={5000}
        background="gray5"
      >
        {content[domain].testimonials.map((testimonial: any, idx: any) => (
          <TestimonialCard
            key={idx}
            image={{ url: testimonial.image }}
            couple={[testimonial.bride, testimonial.groom].join(" and ")}
            location={testimonial.location}
            content={testimonial.story}
            onAction={reviewAction}
          />
        ))}
      </CarouselBanner>
    );
  }
);
