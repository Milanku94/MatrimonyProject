import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { Banner } from "./Banner";

afterEach(cleanup);
describe("Banner:", () => {
  it("renders correctly", () => {
    const { container } = render(
      <Banner image={{ url: "https://picsum.photos/id/722/1200/800" }} />
    );
    expect(container.firstChild).toMatchSnapshot();
  });
});
