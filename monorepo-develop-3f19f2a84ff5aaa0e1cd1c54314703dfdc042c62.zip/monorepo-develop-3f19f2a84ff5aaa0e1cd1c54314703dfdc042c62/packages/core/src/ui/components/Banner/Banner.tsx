import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import { Media } from "../../types";

interface BannerProps {
  image: Media;
}

const BannerContainer = styled("div")`
  height: 220px;
  position: relative;
  overflow: hidden;
`;

const BannerSharp = styled("div")<BannerProps>`
  ${props => backgroundImage(props.image.url)}
  height: 100%;
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center;
  position: absolute;
  width: 100%;
  top: 0;
  left: 0;
`;
const BannerBlur = styled("div")<BannerProps>`
  ${props => backgroundImage(props.image.url)}
  height: 100%;
  filter: blur(0.5rem) grayscale(30%);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
`;

const Gradient = styled("div")`
  background: linear-gradient(
    rgba(255, 255, 255, 0) 0%,
    rgba(20, 20, 20, 0.4) 90%,
    rgba(0, 0, 0, 1) 100%
  );
  position: absolute;
  width: 100%;
  top: 0;
  left: 0;
  height: 100%;
`;

const UnstyledBanner: React.FC<BannerProps> = React.memo(props => (
  <BannerContainer {...props}>
    <BannerBlur image={props.image} />
    <BannerSharp image={props.image} />
    <Gradient />
  </BannerContainer>
));
export const Banner = styled(UnstyledBanner)``;
