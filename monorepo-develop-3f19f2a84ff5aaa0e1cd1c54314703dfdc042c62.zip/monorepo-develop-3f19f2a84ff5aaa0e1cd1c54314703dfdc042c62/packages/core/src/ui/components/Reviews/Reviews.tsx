import * as React from "react";
import styled from "styled-components";
import { backgroundImage, H3 } from "../../";
import { SiteIcon } from "../../components/Icon/Icon";
import { Media } from "../../types";
import { CardBody } from "../CardBody/CardBody";
import { SeeMoreText } from "../CardDescription/CardDescription";
import { CardTitle } from "../CardTitle/CardTitle";
import { SocialNetwork } from "../SocialNetwork/SocialNetwork";
import { StarRatings } from "../StarRatings/StarRatings";
interface FullReview {
  review: Review[];
  rating: number;
  overallRatings: Rating[];
  setModalOpen: () => void;
  nextUrl: string;
  name: string;
}
interface Rating {
  id: string;
  answer: number;
}

interface Review {
  user: any;
  ratings: Rating[];
  review: string;
  overall: number;
}

interface UserAuth {
  name: string;
  profilePicture: Media;
  email: string;
}

// interface OverallReviewProps {
//   reviews: Review[];
//   reviewsCount: number;
//   overallRatings: Rating[];
//   ratingsCount: number;
//   userID?: string;
//   setModalOpen: () => void;
//   nextUrl: string;
// }

const ReviewsDiv = styled("div")`
  // background: ${props => props.theme.colors.gray5};
  font-size: 16px;
  ${props => props.theme.media.desktop} {
    margin: 1rem 2rem 2rem;
  }
  h3{
    padding-bottom: 0.5rem;
    margin-left:0;
  }
`;
const ReviewCardDiv = styled("div")`
//  border-bottom: solid 1px ${props => props.theme.colors.gray1};
//  margin-bottom: 1rem;
  display: grid;
  grid-template-areas: 
    "profile-photo profile-title"
    ". profile-description";
  background-color: white;
  border-bottom: 1px solid lightgray;
  padding-top: 1.5rem;
  padding-bottom: 0.5rem;
  grid-template-columns: 2.5rem auto;

  ${CardTitle} {
    grid-area: profile-title;
    align-items: center;
  }
  ${CardBody} {
    grid-area: profile-description;
    padding: 0.5rem 0.8rem
    p {
      font-size: ${props => props.theme.fontSize[150]};
      margin: 0;
    }
  }
`;
const CardTitleBlock = styled("div")`
  p {
    font-weight: bold;
    margin: 0;
  }
  span {
    color: #969696;
  }
`;
const CardAvatar = styled("div")<{ image: Media }>`
  grid-area: profile-photo;
  width: 2.5rem;
  height: 2.5rem;
  align-self: center;
  border-radius: 2.5rem;
  background-size: contain;
  ${props => backgroundImage(props.image.url)}
`;
const OverallReviewDiv = styled("div")<{ reviewLength: any }>`
  background-color: white;
  margin: 0 -0.75rem;
  padding-bottom: 1rem;
  border-bottom: 0.5rem solid #f3f3f3;
  ${props => props.theme.media.desktop} {
    margin: 0;
    display: grid;
    //border: none;
    // grid-template-columns: 7rem auto;
    border-bottom: 1px solid lightgray;
    grid-template-columns: ${props =>
      props.reviewLength === 0 ? "100%" : "15% 65% 20%"};
  }
`;
const ScoreBlock = styled("div")`
  display: flex;
  align-items: center;
  justify-items: center;
  margin: 0 1rem;
  ${props => props.theme.media.desktop} {
    margin: 0;
    width: 6.5rem;
    height: 6.5rem;
    border: 1px solid lightgray;
    display: flex;
    align-items: center;
    justify-items: center;
    flex-flow: column;
    border-radius: 3px;
  }

  p {
    margin: 0;
  }
  .value {
    font-size: ${props => props.theme.fontSize[700]};
    margin: 0;
  }
`;
const OverallMetricsBlock = styled("div")`
  display: flex;
  flex-wrap: wrap;
`;
const OverallMetricBlock = styled("div")`
  margin: 0rem 1rem 1rem;
  ${props => props.theme.media.desktop} {
    width: 25%;
  }
  div {
    display: flex;
  }
  p {
    margin-top: 0;
  }
`;
const OverallMetricDash = styled("div")<{ filled: boolean }>`
  width: 2.5rem;
  height: 0.5rem;
  margin-right: 0.25rem;
  background-color: ${props => (props.filled ? "#6DC243" : "#eee")};
`;

const WriteReview = styled("div")<{ reviewLength: any }>`
  margin: 1rem 1rem 0rem 1rem;
  text-align: ${props => props.reviewLength === 0 && "center"};
  ${props => props.theme.media.desktop} {
    margin: ${props =>
      props.reviewLength === 0 ? "0rem 16rem" : " 1rem 1rem 0rem 1rem"};
  }
`;

const StarDiv = styled("div")`
  p {
    text-align: center;
  }
  div {
    margin: 0.3rem;
  }
`;

// const Rating: React.FC<{ ratings: Rating[] }> = props => (
//   <React.Fragment>
//     {props.ratings
//       .sort((a, b) => (!a.value && b.value ? 1 : -1))
//       .map(metric =>
//         metric.value
//           ? renderStar(metric, "filled")
//           : renderStar(metric, "border")
//       )}
//   </React.Fragment>
// );

// const Rating = (props: any) => {
//   return (
//     <React.Fragment>
//       {props.overall && renderStar(props.overall, "border")
//       : renderStar(props.overall - 5, "border")
//       }
//     </React.Fragment>
//   );
// };

const ReviewCard = React.memo((props: Review) => {
  return (
    <ReviewCardDiv>
      <CardAvatar
        image={!!props.user.profilePicture && props.user.profilePicture}
      />
      <CardTitle>
        <CardTitleBlock>
          <p>{!!props.user.name && props.user.name}</p>
          {/* <small>{props.date}</small> */}
        </CardTitleBlock>
        <span>{<StarRatings rating={props.overall} page={"review"} />}</span>
      </CardTitle>
      {/* <CardBody>
        <SeeMoreText description={props.review} />
      </CardBody> */}
    </ReviewCardDiv>
  );
});
// const round = (num: number) => Math.round(num * 10) / 10;
const OverallReview: React.FC<FullReview> = React.memo(props => {
  return (
    <OverallReviewDiv reviewLength={props.review.length}>
      {props.review.length > 0 && (
        <>
          <ScoreBlock>
            {props.rating && <p className="value">{props.rating.toFixed(1)}</p>}
            <StarDiv>
              <p>Out of 5.0</p>
              <div>
                {props.rating && (
                  <StarRatings rating={props.rating} page={"review"} />
                )}
              </div>
            </StarDiv>
          </ScoreBlock>
          <OverallMetricsBlock>
            {props.overallRatings &&
              props.overallRatings.map(rating =>
                renderOverallMetric(rating.id, rating.answer)
              )}
          </OverallMetricsBlock>
        </>
      )}
      <WriteReview reviewLength={props.review.length}>
        {props.review.length === 0 && <H3>Be the first to write a review!</H3>}

        <SocialNetwork
          nextUrl={props.nextUrl}
          loggedIn={{ onClick: props.setModalOpen, label: "Write a review" }}
        />
      </WriteReview>
    </OverallReviewDiv>
  );
});
export const Reviews: React.FC<FullReview> = React.memo(props => {
  return (
    <ReviewsDiv>
      {props.review.length > 0 && <H3> Reviews of {props.name}</H3>}
      <OverallReview {...props} />
      {!!props.review &&
        props.review.map((data: any, index: number) => (
          <ReviewCard {...data} key={index} />
        ))}
    </ReviewsDiv>
  );
});

const renderOverallMetric = (id: string, answer: number): JSX.Element => {
  // const score = round(((answer as number) * 5) / ratingsCount);
  return (
    <OverallMetricBlock>
      <p>
        {id.charAt(0).toUpperCase() + id.slice(1)} ({Math.round(answer)})
      </p>
      <div>
        {Array.from(Array(5).keys()).map(arrayId => (
          <OverallMetricDash
            key={arrayId}
            filled={arrayId < Math.round(answer)}
          />
        ))}
      </div>
    </OverallMetricBlock>
  );
};

// const renderStar = (metric: Rating, type: "filled" | "border"): JSX.Element => (
// <SiteIcon
//   name={`star-${type}`}
//   style={{ width: "1rem", height: "1rem", fill: "#ee8f00" }}
//   key={metric.name}
//   altText={metric.name}
// />
// );
