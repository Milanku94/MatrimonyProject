import React from "react";
import { Helmet } from "react-helmet-async";
import { helmetJsonLdProp } from "react-schemaorg";
import { FAQPage } from "schema-dts";
import styled from "styled-components";
import { toReactHTML } from "../../../utils/toReactHTML";
import { SiteIcon } from "../../atoms";
import { FancyHeader } from "../../molecules/FancyHeader/FancyHeader";
import { Collapsable } from "../Collapsable/Collapsable";

const DropDownContent = styled("div")`
  border-bottom: 1px solid #eeeeee;
  cursor: pointer;
  p {
    margin: 0px;
    font-weight: 400;
    padding: 1rem 0.25rem;
    display: inline-flex;
    font-family: inherit;
    width: 100%;
  }
`;
const DropDownDiv = styled("div")`
  background: #f8f8f8;
  border-bottom: 1px solid #eeeeee;
  padding: 0.5rem 0rem;
`;
const ContentDiv = styled("div")`
  ${props => props.theme.media.desktop} {
    background: #f8f8f8;
    color: #666;
    margin: 0rem -12.5% -2rem -12.5%;
    padding: 3rem;
    font-weight: lighter;
  }
  ${DropDownContent} {
    padding: 0.5rem 5%;
    p {
      padding: 0;
      font-weight: 500;
      ${props => props.theme.media.mobile} {
        font-size: 1rem;
      }
    }
    h3 {
      margin: 0;
      color: ${props => props.theme.colors.primary};
    }
  }
  ${DropDownDiv} {
    padding: 0.5rem 5%;
  }
  .Price {
    ${props => props.theme.media.mobile} {
      overflow-x: auto;
      white-space: nowrap;
    }
    table {
      width: 100%;
      text-align: left;
      border-top: 1px solid #eee;
    }
    table,
    th,
    td {
      border-right: 1px solid #eee;
      border-collapse: collapse;
      font-weight: 500;
    }
    th {
      color: ${props => props.theme.colors.primary};
    }
    td {
      color: ${props => props.theme.colors.gray1};
    }
    th,
    td {
      padding: 4px 10px;
      ${props => props.theme.media.mobile} {
        padding: 5px 10px 5px 10px;
      }
    }
    th:nth-child(1) {
      padding-left: 0px;
    }
    td:nth-child(1) {
      padding-left: 0px;
    }
  }
`;
const HeaderComp = styled("div")`
  display: flex;
  justify-content: space-between;
`;

const withCityCategory = (str: string, { cityObject, categoryObject }: any) =>
  str
    .replace(/\<city\>/g, cityObject.name)
    .replace(/\<cityName\>/g, cityObject.name)
    .replace(/\<citySlug\>/g, cityObject.slug)
    .replace(/\<category\>/g, categoryObject.name)
    .replace(/\<categoryName\>/g, categoryObject.name)
    .replace(/\<categorySlug\>/g, categoryObject.slug);

const renderDetail = (
  content: any[],
  cityObject: any,
  categoryObject: any,
  defaultClosed = false
) =>
  content.map((faq: any, idx: number) => {
    const showCollapsable = faq.section === "FAQ";
    return (
      <Collapsable
        key={idx}
        header={(toggles: any, setToggles: any) => (
          <DropDownContent>
            <HeaderComp
              as={showCollapsable ? "div" : "h3"}
              onClick={() => {
                return (
                  showCollapsable && setToggles((tgl: boolean[]) => [!tgl[0]])
                );
              }}
            >
              <div
                {...toReactHTML(
                  withCityCategory(faq.question, { cityObject, categoryObject })
                )}
              />
              {showCollapsable && (
                <div className="right">
                  <SiteIcon
                    name={`expand-${toggles[0] ? "less" : "more"}`}
                    style={{
                      width: "1.5rem",
                      height: "1.5rem",
                      verticalAlign: "middle",
                      fill: "#E94057",
                      margin: "0"
                    }}
                  />
                </div>
              )}
            </HeaderComp>
          </DropDownContent>
        )}
        children={[
          {
            element: (
              <DropDownDiv key={idx}>
                <div
                  className={`content ${faq.section}`}
                  {...toReactHTML(
                    withCityCategory(faq.answer, { cityObject, categoryObject })
                  )}
                />
              </DropDownDiv>
            ),
            open: !(showCollapsable && defaultClosed)
          }
        ]}
      />
    );
  });
const HelmetSchema = ({
  faqTitle,
  faqContent,
  renderJSONLD
}: {
  faqTitle: any;
  faqContent: any;
  renderJSONLD: any;
}) =>
  renderJSONLD && (
    <Helmet
      script={[
        helmetJsonLdProp<FAQPage>({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          name: faqTitle,
          description: "WeddingBazaar",
          mainEntity: faqContent.map(({ question, answer }: any, idx: any) => ({
            "@type": "Question",
            text: question,
            name: `FAQ - ${idx + 1}`,
            answerCount: 1,
            // author: {
            //   "@type": "Person",
            //   name: "Customer"
            // },
            acceptedAnswer: {
              "@type": "Answer",
              text: answer,
              author: {
                "@type": "Person",
                name: "MBazaar Team"
              }
            }
          }))
        })
      ]}
    />
  );
export const FAQContent: React.FC<any> = React.memo(
  ({
    categoryObject,
    cityObject,
    faqTitle = "FAQs",
    defaultClosed = false,
    renderJSONLD = true
  }) => {
    const validContent = categoryObject.content.filter(
      (content: any) => !!content.question && !!content.answer
    );
    const mainContent = validContent.filter(
      (content: any) => content.section === "Main"
    );
    const priceContent = validContent.filter(
      (content: any) => content.section === "Price"
    );
    const faqContent = validContent.filter(
      (content: any) => content.section === "FAQ"
    );
    return (
      <ContentDiv>
        <HelmetSchema
          faqTitle={faqTitle}
          faqContent={faqContent}
          renderJSONLD={renderJSONLD}
        />
        {renderDetail(mainContent, cityObject, categoryObject, defaultClosed)}
        {renderDetail(priceContent, cityObject, categoryObject, defaultClosed)}
        <span>
          <SiteIcon
            name={"faqs"}
            style={{
              width: "100%",
              height: "3rem",
              fill: "#E94057",
              margin: "0px"
            }}
          />
        </span>
        <FancyHeader title={faqTitle} />
        {renderDetail(faqContent, cityObject, categoryObject, defaultClosed)}
      </ContentDiv>
    );
  }
);
