import * as React from "react";
import styled from "styled-components";
import { ShareSocialIcons } from "../../..";
import { Card } from "../Card/Card";
import { CardDescription } from "../CardDescription/CardDescription";
import { StyledLink } from "../Typography";
interface BlogCardsProps {
  name: string;
  excerpt: string;
  slug: string;
  id: string;
  url?: string;
}
interface BlogCardDivProps {
  image?: string;
}

const CardDiv = styled(Card)`
  text-align: initial;
  padding: 25px;
  border: 0px;
  box-shadow: 0 19px 38px rgba(0, 0, 0, 0.1), 0 15px 12px rgba(0, 0, 0, 0.02);
  height: 14rem;
  border-radius: 3px;

  ${props => props.theme.media.desktop} {
    height: 10rem;
  }

  h2 {
    font-weight: ${props => props.theme.fontWeight.medium};
    font-size: ${props => props.theme.fontSize[150]};
    color: ${props => props.theme.colors.primary};
    margin: 10px 0px;
  }

  p {
    font-size: 14px;
    margin: 10px 0px;
    line-height: 25px;
    text-align: initial;
  }
`;

export const BlogCards: React.FC<BlogCardsProps> = React.memo(props => {
  const slugId = `${props.slug}-${props.id}`;
  const url = `https://weddingbazaar.com/ideas/${slugId}`;
  return (
    <CardDiv>
      <StyledLink to={`/ideas/${slugId}`}>
        <h2>{props.name}</h2>
        <CardDescription
          description={props.excerpt}
          maxLength={140}
          fixedText={true}
        />
      </StyledLink>
      <ShareSocialIcons
        url={url}
        subject={`Have you read "${props.name}" ? Check it out: ${url}`}
        description={`${props.name} is a blog post curated by WeddingBazaar. Let us know your thoughts in the comments section. `}
        platforms={{
          facebook: true,
          twitter: true,
          whatsapp: true,
          email: true
        }}
      />
    </CardDiv>
  );
});
