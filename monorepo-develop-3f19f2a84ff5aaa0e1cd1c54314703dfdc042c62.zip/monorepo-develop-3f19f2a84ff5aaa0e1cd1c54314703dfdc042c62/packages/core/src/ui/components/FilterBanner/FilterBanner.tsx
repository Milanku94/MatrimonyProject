import * as React from "react";
import styled from "styled-components";
import { SiteIcon } from "../../components/Icon/Icon";

interface FilterBannerProps {
  title: string;
  subtext: string;
  filtertext: string;
}

const FilterBox = styled("div")`
  background-color: rgba(255, 246, 241, 1);
  height: 119px;
  margin-top: 24px;
`;

const FilterLeft = styled("div")`
  width: 63%;
  float: left;
`;

const FilterRight = styled("div")`
  float: right;
`;

const CloseIcon = styled("div")`
  float: right;
  margin: 10px 16px 0px 0px;
`;

const FilterContent = styled("div")`
  width: 213px;
  padding: 15px 0px 0px 12px;
  font-size: 16px;
  font-weight: ${props => props.theme.fontWeight.medium};
`;

const FilterSubContent = styled("div")`
  color: rgba(158, 158, 158, 1);
  font-size: 14px;
  padding: 12px 0px 0px 12px;
`;

const FilterLink = styled("div")`
  font-weight: ${props => props.theme.fontWeight.medium};
  margin: 81px 16px 0px 0px;
  color: ${props => props.theme.colors.primary};
  font-size: 12px;
`;

export const FilterBanner = React.memo((props: FilterBannerProps) => {
  return (
    <FilterBox>
      <FilterLeft>
        <FilterContent> {props.title}</FilterContent>
        <FilterSubContent> {props.subtext} </FilterSubContent>
      </FilterLeft>
      <FilterRight>
        <CloseIcon>
          <SiteIcon
            name={"close"}
            style={{
              width: "13px",
              height: "13px"
            }}
          />
        </CloseIcon>
        <FilterLink>{props.filtertext}</FilterLink>
      </FilterRight>
    </FilterBox>
  );
});
