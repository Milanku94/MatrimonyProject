import * as React from "react";
import styled from "styled-components";
import { Media } from "../../types";
interface ListImageProps {
  image: Media;
  children: any;
}
const ListImageContDiv = styled("div")`
  display: flex;
`;
const ImageDiv = styled("img")`
  width: 88px;
  height: 88px;
  object-fit: cover;
`;
const ContentDiv = styled("div")`
  margin: 6px 10px;
  font-size: ${props => props.theme.fontSize[200]};
  font-weight: ${props => props.theme.fontWeight.medium};
`;

export const ListImage = React.memo((props: ListImageProps) => {
  return (
    <ListImageContDiv>
      <div style={{ height: "88px" }}>
        <ImageDiv src={props.image.url} />
      </div>
      <ContentDiv>{props.children}</ContentDiv>
    </ListImageContDiv>
  );
});
