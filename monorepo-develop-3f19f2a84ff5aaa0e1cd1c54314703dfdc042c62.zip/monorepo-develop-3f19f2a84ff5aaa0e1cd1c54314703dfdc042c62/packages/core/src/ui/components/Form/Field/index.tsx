import { ErrorMessage } from "formik";
import React from "react";
import styled from "styled-components";

export interface ValidationProps {
  rule: string;
  err: string;
  [propname: string]: any;
}
export interface FieldProps {
  label?: string;
  type: string;
  name: string;
  value?: any;
  validation?: ValidationProps | Array<ValidationProps | undefined>;
  disabled?: boolean;
  [propname: string]: any;
  inlineicon?: string;
}

export interface OptionProps {
  name: string;
  id: string;
  isDefault?: boolean;
}

const StyledLabel = styled("label")`
  font-size: ${props => props.theme.fontSize[100]};
  display: flex;
  justify-content: space-between;
  color: #2d2d2d;
  /*margin-top: 0.825rem;*/
  margin-bottom: 0.5rem;
  font-weight: bold;
`;
const RightLabel = styled("div")`
  display: flex;
  * {
    margin-left: 1rem;
  }
`;
export const StyledInputContainer = styled("div")`
  position: relative;
  align-items: center;
  display: flex;
  width: 100%;
  div {
    width: 100%;
  }
  svg {
    position: absolute;
    // bottom: 1rem;
  }
`;
export const StyledErrorMessage = styled(ErrorMessage)<FieldProps>`
  margin-top: ${props => props.inlineicon && "0"};
  font-size: ${props => (props.inlineicon ? ".6rem" : ".8rem")};
  color: ${props => props.theme.colors.primary};
  font-weight: normal;
`;

export const Label: React.FC<FieldProps> = props => (
  <StyledLabel>
    {props.label}
    <RightLabel>
      {props.children}
      <StyledErrorMessage name={props.name} component={"span"} />
    </RightLabel>
  </StyledLabel>
);

export { DropdownInput } from "./DropdownInput";
export { OtpInput, OtpInputInlineWrapped } from "./OtpInput";
export { SelectInput, ExpandableSelectInput } from "./SelectInput";
export { TextareaInput } from "./TextareaInput";
export { TextInput, TextInputInlineWrapped } from "./TextInput";
export { ToggleInput } from "./ToggleInput";
export { CalendarInput } from "./CalendarInput";
export { AutocompleteInput } from "./AutocompleteInput";
export { StarInput } from "./StarInput";
export { RichTextareaInput } from "./RichTextareaInput";
export { AutocompleteHotInput } from "./AutoCompleteHotInput";
export { CheckboxInput } from "./CheckboxInput";
