import * as React from "react";
import styled from "styled-components";
import { theme } from "../../../index";
import { SiteIcon } from "../../components/Icon/Icon";
import { Label, StyledErrorMessage } from "./Field";
import { renderResend } from "./Field/OtpInput";
const ContDiv = styled("div")`
}`;
const HeaderDiv = styled("span")<{ fieldtype: string }>`
  // border-top: ${props => props.fieldtype === "lead" && "1px solid #dad2d2"};
  display: flex;
  cursor: pointer;
  justify-content: space-between;
  padding-top: 10px
  align-items: center;
  & > span {
    font-size: ${props => props.theme.fontSize[400]};
    // margin-top:0.5rem;
  }
}`;
export const Hoc = (WrapperComponent: any) => {
  return (props: any) => {
    const [toggle, setToggle] = React.useState(true);

    return (
      <div key={props.name}>
        <HeaderDiv {...props}>
          <Label {...props} />
          {props.expandable && (
            <span onClick={() => setToggle(!toggle)}>
              {toggle ? (
                <SiteIcon
                  name={"expand-less"}
                  style={{
                    width: "1.3rem",
                    height: "1.3rem"
                  }}
                />
              ) : (
                <SiteIcon
                  name={"expand-more"}
                  style={{
                    width: "1.3rem",
                    height: "1.3rem"
                  }}
                />
              )}
            </span>
          )}
        </HeaderDiv>
        <ContDiv style={{ display: toggle ? "block" : "none" }}>
          <WrapperComponent {...props} />
        </ContDiv>
      </div>
    );
  };
};

const StyledInputContainer = styled("div")`
  position: relative;
  align-items: center;
  display: flex;
  width: 100%;
  div {
    width: 100%;
  }
  svg {
    position: absolute;
    // bottom: 1rem;
  }
`;

export const InlineWrapper = (WrapperComponent: any) => {
  return (props: any) => {
    if (!props.inlineicon) {
      return (
        <div key={props.name}>
          {props.label && !props.inlineicon && <Label {...props} />}
          <WrapperComponent {...props} />
        </div>
      );
    }

    return (
      <div key={props.name}>
        <StyledInputContainer>
          <SiteIcon
            name={props.inlineicon}
            style={{
              margin: "0 .5rem",
              width: ".8rem",
              height: ".8rem",
              fill: theme.colors.primary
            }}
          />
          <WrapperComponent {...props} />
        </StyledInputContainer>
        <StyledErrorMessage {...props} component={"span"} />
        {props.type === "otp" &&
          renderResend({
            resend: props.resend,
            countdown: props.countdown,
            inlineicon: props.inlineicon
          })}
      </div>
    );
  };
};
