import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps, Label, OptionProps } from ".";
import { SiteIcon } from "../../Icon/Icon";
import { Hoc } from "../Hoc";
interface SelectOptionProps extends OptionProps {
  children: React.ReactNode;
}

interface InputStyleProps {
  multiple: boolean;
  showWidget: boolean;
  fieldtype?: string;
  showBorder?: boolean;
}
interface SelectInputProps extends FieldProps, InputStyleProps {
  options: SelectOptionProps[];
}

interface CustomSelectProps extends SelectInputProps {
  name: string;
  value: string[];
  setFieldValue: (name: any, value: any) => void;
}

interface SelectedProps {
  selected: boolean;
  showWidget: boolean;
  fieldtype?: string;
  showBorder?: boolean;
}

interface CustomOptionsProps extends InputStyleProps {
  name: string;
  isSelected: boolean;
  handleClick: any;
}

const SelectBox = styled("div")<SelectInputProps>`
  display: ${props => props.isMaxScreen && "grid"};
  grid-template-columns: repeat(
    auto-fit,
    minmax(
      ${props =>
        !props.showWidget && props.formType === "lead" ? "20%" : "30%"},
      1fr
    )
  );
  customselectgrid-gap: 0 0.5rem;
  grid-auto-flow: row;
  align-items: center;
  justify-items: center;
  justify-content: center;
  align-content: center;
  word-break: break-word;

  grid-gap: 0.3rem 1rem;
`;

const OptionBox = styled("div")<SelectedProps>`
  box-shadow: ${props =>
    props.showBorder &&
    `0px 0px 10px 0px rgba(0, 0, 0, 0.13),
    0px 0px 10px 0px rgba(0, 0, 0, 0.02);`} 

  -webkit-tap-highlight-color: transparent;
  color: ${props =>
    !props.showWidget && props.selected ? props.theme.colors.white : "#2a2c34"};
  display: flex;
  align-items: center;
  cursor: pointer;
  width: 100%;
  border-radius: ${props => (!props.showWidget ? "3rem" : "3px")};
  border: 0.5px solid #c4c4c4;
  min-height: ${props =>
    !props.showWidget
      ? "2rem !important"
      : !props.showBorder
      ? "0rem"
      : "3rem"};
  margin: 0.25rem 0;
  justify-content: ${props => !props.showWidget && "center"};
  padding: 0.25rem 0;
  border: ${props =>
    props.fieldtype === "lead"
      ? props.showWidget
        ? `transparent`
        : `0px solid ${props.theme.colors.primary}`
      : `0px solid ${props.theme.colors.gray2}`};
  background-color: ${props =>
    props.selected && props.fieldtype === "lead" && !props.showWidget
      ? props.theme.colors.primary
      : props.theme.colors.white};
`;

const SelectIcon = styled("span")<SelectedProps>`
  padding: 0 0.5rem;
  color: ${props => (props.selected ? props.theme.colors.primary : "#2A2C34")};
`;

const SelectBoxText = styled("span")<SelectedProps>`
  font-size: ${props => props.theme.fontSize[150]}
  text-color: ${props =>
    props.selected ? props.theme.colors.primary : "#2A2C34"};
  font-weight: ${props => (props.selected ? 600 : 400)};
  &:only-child {
    padding: 0 1.5rem;
  }
`;

const SelectDiv = styled("div")`
  ${props => props.theme.media.desktop} {
    label {
      display: none;
    }
  }
`;

const CustomOptions: React.FC<CustomOptionsProps> = ({
  name,
  isSelected,
  handleClick,
  multiple,
  showWidget,
  fieldtype,
  showBorder
}) => {
  const unselectedWidget = multiple ? (
    <SiteIcon
      name={"check-box-outline-blank"}
      style={{
        fill: "#E94057",
        margin: "0"
      }}
    />
  ) : (
    <SiteIcon name={"radio-button-unchecked"} />
  );

  const selectedWidget = multiple ? (
    <SiteIcon
      name={"check-box"}
      style={{
        margin: "0"
      }}
    />
  ) : (
    <SiteIcon name={"radio-button-checked"} />
  );

  return (
    <OptionBox
      onClick={handleClick}
      selected={isSelected}
      showWidget={showWidget}
      fieldtype={fieldtype}
      showBorder={showBorder}
    >
      {showWidget && (
        <SelectIcon selected={isSelected} showWidget={showWidget}>
          {isSelected ? selectedWidget : unselectedWidget}
        </SelectIcon>
      )}
      <SelectBoxText selected={isSelected} showWidget={showWidget}>
        {name}
      </SelectBoxText>
    </OptionBox>
  );
};

const CustomSelect: React.FC<CustomSelectProps> = ({
  name,
  options,
  value,
  setFieldValue,
  multiple,
  showWidget,
  fieldtype = "form",
  showBorder
}) => {
  React.useEffect(() => {
    const defaultValues = options.reduce((acc: any, val: any) => {
      if (val.isDefault) {
        acc.push(val.id);
      }
      return acc;
    }, []);
    setFieldValue(name, defaultValues);
  }, [options]);

  const idSelected = (id: string) => {
    if (!!value) {
      return value.indexOf(id) >= 0;
    }
    return false;
  };

  const handleClicked = (id: string) => {
    const idx = value.indexOf(id);
    let val = [];
    if (idx >= 0) {
      val = value.filter(v => v !== id);
    } else {
      val = [...value, id];
    }
    setFieldValue(name, multiple ? val : [id]);
  };

  return (
    <React.Fragment>
      {options.map(d => {
        return (
          <CustomOptions
            {...d}
            key={d.id}
            handleClick={() => handleClicked(d.id)}
            isSelected={idSelected(d.id)}
            multiple={multiple}
            showWidget={showWidget}
            fieldtype={fieldtype}
            showBorder={showBorder}
          />
        );
      })}
    </React.Fragment>
  );
};

export const SelectInput: React.FC<SelectInputProps> = props => (
  <SelectDiv>
    {props.type !== "select" && <Label {...props} />}
    <SelectBox isMaxScreen={props.isMaxScreen}>
      <Field
        name={props.name}
        render={(formikProps: FormikFieldProps) => {
          const { field, form } = formikProps;
          return (
            <CustomSelect
              name={props.name}
              type={props.type}
              options={props.options}
              multiple={props.multiple}
              showWidget={props.showWidget}
              fieldtype={props.fieldtype}
              setFieldValue={form.setFieldValue}
              value={form.values[props.name]}
              showBorder={props.showBorder}
            />
          );
        }}
      />
    </SelectBox>
  </SelectDiv>
);

export const ExpandableSelectInput = Hoc(SelectInput);
