import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import { FieldProps, Label } from ".";
import { RichTextArea } from "../../../Markup/Slate/RichTextArea";

interface RichTextareaInputProps extends FieldProps {}

export const RichTextareaInput: React.FC<RichTextareaInputProps> = ({
  name,
  ...props
}) => (
  <div key={name}>
    <Label {...{ name, ...props }} />
    <Field
      name={name}
      render={(formikProps: FormikFieldProps) => {
        const { field, form } = formikProps;
        return (
          <RichTextArea
            value={form.values[name]}
            onChange={(changed: any) => form.setFieldValue(name, changed)}
            isEditable={true}
          />
        );
      }}
    />
  </div>
);
