import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps } from ".";
import { SiteIcon } from "../../Icon/Icon";

interface StarRatingsProps extends FieldProps {
  description?: string;
}

interface StarProps {
  name: string;
  value: boolean;
  setFieldValue: (value: any) => void;
}

const LabelElement = styled("div")`
  margin-top: 15px;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 15px;
  align-items: center;
`;

const Stars = styled("div")``;

const StarRate = styled("div")`
  display: flex;
  justify-content: space-around;
`;

export const ReviewQuestion = styled("div")`
  font-size: ${props => props.theme.fontSize[150]};
  font-weight: ${props => props.theme.fontWeight.regular}
  padding: 0.1rem 0;
}
`;

const Star = ({ selected = false, onClick = (star: any) => star }) => (
  <Stars onClick={onClick}>
    <SiteIcon
      name={"star-filled"}
      style={{
        fill: selected ? "#EE9005" : "#DBDBDB",
        width: "1.8rem",
        height: "1.8rem",
        margin: "0"
      }}
    />
  </Stars>
);

const StarRatings = (props: StarProps) => {
  const [starSelected, setStarsSelected] = React.useState(0);

  const handleOnClick = (i: any) => {
    setStarsSelected(i + 1);
    props.setFieldValue(i + 1);
  };

  return (
    <StarRate>
      {[...Array(5)].map((n, i) => (
        <Star
          key={i}
          selected={i < starSelected}
          onClick={() => handleOnClick(i)}
        />
      ))}
    </StarRate>
  );
};

export const StarInput: React.FC<StarRatingsProps> = props => (
  <div>
    <LabelElement>
      {props.label}
      <ReviewQuestion>{props.description}</ReviewQuestion>
      <Field
        name={props.name}
        render={(formikProps: FormikFieldProps) => {
          const { form } = formikProps;
          return (
            <StarRatings
              name={props.name}
              value={form.values[props.name]}
              setFieldValue={i => form.setFieldValue(props.name, i)}
            />
          );
        }}
      />
    </LabelElement>
  </div>
);
