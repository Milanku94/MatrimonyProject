import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps } from ".";
import { SiteIcon } from "../../Icon/Icon";
import { ReviewQuestion } from "./StarInput";

interface ToggleInputProps extends FieldProps {}

const LabelElement = styled("div")`
  margin-top: 15px;
  font-size: 14px;
  /*color: #c4c4c4;*/
  font-weight: bold;
  margin-bottom: 15px;
  /*display: flex;*/
  align-items: center;
`;

const ToggleWrapper = styled("div")`
  display: grid;
  grid-template-columns: 4fr 1fr;
`;

interface CustomToggleProps {
  name: string;
  value: boolean;
  setFieldValue: (name: any, value: any) => void;
}

const ToggleButton = styled("div")``;

const CustomToggle: React.FC<CustomToggleProps> = ({
  name,
  value,
  setFieldValue
}) => {
  const [toggleBtn, setToggleBtn] = React.useState(value);

  const handleToggle = () => {
    setToggleBtn(toggle => {
      setFieldValue(name, !toggle);
      return !toggle;
    });
  };

  return (
    <React.Fragment>
      <div onClick={handleToggle}>
        {toggleBtn ? (
          <SiteIcon
            name={"toggle-on"}
            style={{
              width: "1.8rem",
              height: "1.8rem",
              verticalAlign: "middle",
              fill: "#00A651",
              margin: 0
            }}
          />
        ) : (
          <SiteIcon
            name={"toggle-off"}
            style={{
              width: "1.8rem",
              height: "1.8rem",
              verticalAlign: "middle",
              fill: "#ccc",
              margin: 0
            }}
          />
        )}
      </div>
    </React.Fragment>
  );
};

export const ToggleInput: React.FC<ToggleInputProps> = props => {
  return (
    <div>
      <LabelElement>
        <div>{props.label} </div>
        <ToggleWrapper>
          <ReviewQuestion>{props.description}</ReviewQuestion>
          <Field
            name={props.name}
            render={(formikProps: FormikFieldProps) => {
              const { field, form } = formikProps;
              return (
                <CustomToggle
                  name={props.name}
                  value={form.values[props.name]}
                  setFieldValue={form.setFieldValue}
                />
              );
            }}
          />
        </ToggleWrapper>
      </LabelElement>
    </div>
  );
};
