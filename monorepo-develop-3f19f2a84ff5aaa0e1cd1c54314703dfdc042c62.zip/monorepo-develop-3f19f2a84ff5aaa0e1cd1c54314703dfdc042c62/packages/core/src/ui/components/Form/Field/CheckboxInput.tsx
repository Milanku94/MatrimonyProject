import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps } from ".";
import { SiteIcon } from "../../Icon/Icon";

interface CheckboxProps extends FieldProps {}

interface CustomCheckboxProps {
  element?: JSX.Element;
  name: string;
  value: boolean;
  setFieldValue: (name: any, value: any) => void;
}

const IconStyles = styled("div")`
  display: flex;
  margin: 0.7rem 0;
  border: 1px solid #c7c8ca;
  padding: 10px 8px;
  border-radius: 4px;
  margin-bottom: 1rem;
`;

const CustomCheckbox: React.FC<CustomCheckboxProps> = ({
  element,
  name,
  value,
  setFieldValue
}) => {
  const [checkboxBtn, setCheckboxBtn] = React.useState(value);

  const handleChecked = () => {
    setCheckboxBtn(checked => {
      setFieldValue(name, !checked);
      return !checked;
    });
  };

  return (
    <React.Fragment>
      <div onClick={handleChecked}>
        {checkboxBtn ? (
          <IconStyles>
            <div>
              <SiteIcon
                name={"check-box"}
                style={{
                  height: "2.2rem",
                  cursor: "pointer",
                  margin: "0rem 0.5rem"
                }}
              />
            </div>
            {element ? element : name}
          </IconStyles>
        ) : (
          <IconStyles>
            <div>
              <SiteIcon
                name={"check-box-outline-blank"}
                style={{
                  height: "2.2rem",
                  fill: "#E94057",
                  margin: "0rem 0.5rem",
                  cursor: "pointer"
                }}
              />
            </div>
            {element ? element : name}
          </IconStyles>
        )}
      </div>
    </React.Fragment>
  );
};

export const CheckboxInput: React.FC<CheckboxProps> = props => {
  return (
    <div>
      <Field
        name={props.name}
        render={(formikProps: FormikFieldProps) => {
          const { field, form } = formikProps;
          return (
            <CustomCheckbox
              name={props.name}
              value={form.values[props.name]}
              element={props.element}
              setFieldValue={form.setFieldValue}
            />
          );
        }}
      />
    </div>
  );
};
