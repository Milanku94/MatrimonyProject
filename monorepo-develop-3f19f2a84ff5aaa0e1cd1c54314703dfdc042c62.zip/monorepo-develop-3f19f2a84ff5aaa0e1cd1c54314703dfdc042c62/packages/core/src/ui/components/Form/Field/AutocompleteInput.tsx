import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";

import styled from "styled-components";
import { FieldProps, OptionProps } from ".";
import { SiteIcon } from "../../Icon/Icon";
import {
  CustomFieldProps,
  CustomSelectDiv as CustomSelectDivDD,
  CustomSelectDivProps,
  DropdownInputProps,
  DropdownOptionProps,
  FieldDiv,
  Options,
  OverlaySelect,
  renderDisplay,
  renderDropdown,
  renderOptions,
  SelectButton,
  setValue,
  StyledField
} from "./DropdownInput";
import { StyledInputField } from "./TextInput";

// Styling functions
const CustomSelectDiv = styled(CustomSelectDivDD)<CustomSelectDivProps>`
  cursor: text;
  ${FieldDiv} {
    padding: 0.75rem;
  }
  ${StyledInputField} {
    border: none;
    padding: 0;
    margin: 0;
  }
`;
const Closebutton = styled("div")`
  cursor: pointer;
`;

const CustomSelect: React.FC<CustomFieldProps> = props => {
  // declaring the state variable using Hooks
  const { name, options, value, setFieldValue, fieldIcon, placeholder } = props;

  const [isOpen, setIsOpen] = React.useState(false);
  const [text, setText] = React.useState(
    renderDisplay({ options, value, placeholder })
  );
  const filteredOptions = options.filter((option: DropdownOptionProps) =>
    option.name.match(
      new RegExp(text.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1") || "", "i")
    )
  );

  React.useEffect(() => {
    setText(renderDisplay({ options, value, placeholder }));
  }, [value, isOpen]);

  const emptyValue = () => {
    setFieldValue(name, null);
    setText("");
  };

  return (
    <CustomSelectDiv onClick={() => setIsOpen(!isOpen)} value={value}>
      <FieldDiv open={isOpen}>
        {!!fieldIcon && fieldIcon}
        <StyledInputField
          onChange={(e: any) => setText(e.target.value)}
          value={text}
          placeholder="start typing.."
          onClick={() => emptyValue()}
        />

        {text.length > 0 && (
          <SiteIcon
            name={"close"}
            onClick={() => emptyValue()}
            style={{
              color: "#000",
              margin: "none",
              cursor: "pointer",
              position: "absolute",
              right: "1rem"
            }}
          />
        )}
      </FieldDiv>
      {renderOptions({
        options: filteredOptions,
        handleClick: setValue({ setIsOpen, setFieldValue, name }),
        value,
        isOpen
      })}
      {isOpen ? <OverlaySelect onClick={() => setIsOpen(false)} /> : null}
    </CustomSelectDiv>
  );
};

export const AutocompleteInput: React.FC<DropdownInputProps> = props => (
  <StyledField key={props.name}>
    {/* <Label {...props} /> */}
    <Field
      name={props.name}
      render={(formikProps: FormikFieldProps) => {
        const { field, form } = formikProps;

        return (
          <CustomSelect
            {...props}
            setFieldValue={form.setFieldValue}
            value={form.values[props.name]}
          />
        );
      }}
    />
  </StyledField>
);
