import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import Calendar from "react-calendar/dist/entry.nostyle";
import styled from "styled-components";
import { FieldProps } from ".";
import { SiteIcon } from "../../Icon/Icon";

interface CalendarInputProps extends FieldProps {
  startDate?: Date;
  endDate?: Date;
  multiple?: boolean;
  widget?: "popup" | "inline";
}

const CustomCalendar = styled("div")<{ widget: CalendarInputProps["widget"] }>`
  .react-calendar button {
    background: white;
    border: none;
    font-size: ${props => props.theme.fontSize[100]};
  }
  .react-calendar .react-calendar__month-view__weekdays abbr {
    font-weight: ${props => props.theme.fontWeight.medium};
    text-decoration: none;
    align-items: center;
  }
  .react-calendar__navigation button {
    min-width: 44px;
    background: none;
    margin-bottom: 0.9em;
  }

  .react-calendar__month-view__weekdays__weekday {
    text-align: center;
  }

  .react-calendar__navigation__label {
    color: ${props => props.theme.colors.primary};
    font-weight: ${props => props.theme.fontWeight.medium};
  }

  button.react-calendar__tile.react-calendar__month-view__days__day {
    &:hover {
      border-radius: 25px;
      background: #e94075;
      width: 25px;
      height: 25px;
      flex-basis: auto;
    }
  }
`;

const DAYS = "SMTWTFS".split("");

const CalendarSelect: React.FC<CalendarInputProps> = ({
  name,
  value,
  startDate,
  endDate,
  multiple = false,
  widget = "popup",
  setFieldValue
}) => {
  return (
    <CustomCalendar widget={widget}>
      <Calendar
        onChange={date => setFieldValue(name, multiple ? date : [date])}
        next2Label={null}
        // nextLabel={<SiteIcon name={"chevron-right"}/>}
        // prevLabel={<SiteIcon name={"chevron-left"}/>}
        prev2Label={null}
        calendarType="US"
        showNeighboringMonth={false}
        minDetail={"year"}
        formatShortWeekday={(locale, date) => DAYS[date.getDay()]}
      />
    </CustomCalendar>
  );
};

export const CalendarInput: React.FC<CalendarInputProps> = props => (
  <Field
    name={props.name}
    render={(formikProps: FormikFieldProps) => {
      const { field, form } = formikProps;
      return (
        <CalendarSelect
          name={props.name}
          type={props.type}
          multiple={props.multiple}
          setFieldValue={form.setFieldValue}
          value={form.values[props.name]}
        />
      );
    }}
  />
);
