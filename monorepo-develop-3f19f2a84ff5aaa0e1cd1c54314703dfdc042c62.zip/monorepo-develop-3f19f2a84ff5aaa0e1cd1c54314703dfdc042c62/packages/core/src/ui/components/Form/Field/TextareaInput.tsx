import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps, Label } from ".";

interface TextareaInputProps extends FieldProps {}

const StyledTextArea = styled("textarea")<TextareaInputProps>`
  width: 95%;
  height: 84px;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
  outline: none;
  box-sizing: border-box;
  width: 100%;
`;

export const TextareaInput: React.FC<TextareaInputProps> = props => (
  <div key={props.name}>
    <Label {...props} />
    <Field
      name={props.name}
      render={(formikProps: FormikFieldProps) => {
        const { field } = formikProps;
        return (
          <StyledTextArea
            {...field}
            type={props.type}
            placeholder={props.placeholder}
            fieldtype={props.fieldtype}
          />
        );
      }}
    />
  </div>
);
