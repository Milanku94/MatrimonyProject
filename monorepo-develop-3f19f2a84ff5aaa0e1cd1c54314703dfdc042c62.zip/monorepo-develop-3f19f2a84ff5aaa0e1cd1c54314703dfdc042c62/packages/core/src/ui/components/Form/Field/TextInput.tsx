import { ErrorMessage, Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps, Label, StyledErrorMessage } from ".";
import { InlineWrapper } from "../Hoc";

interface TextInputProps extends FieldProps {
  /** Type of input rendered */
  fieldtype: "form" | "landing";
  placeholder: string;
}
interface StyledInputFieldProps extends TextInputProps {
  error: boolean;
}
export const StyledInputField = styled("input")<StyledInputFieldProps>`
  border-radius: ${props => (props.inlineicon ? "0" : "3px")};
  padding: ${props => (props.inlineicon ? "0.75rem 2rem" : "0.75rem")};
  background: ${props => props.theme.colors.white};
  border: ${props => (props.inlineicon ? "transparent" : "1px solid #ddd")};
  border-bottom: ${props =>
    props.inlineicon &&
    "1px solid " +
      (props.error ? props.theme.colors.primary : props.theme.colors.gray3)};

  outline: #ddd;
  -webkit-appearance: none;
  margin: 0.1rem 0;
  font-size: ${props => props.theme.fontSize[150]};
  box-sizing: border-box;
  width: 100%;
  input[type="number"]::-webkit-inner-spin-button,
  input[type="number"]::-webkit-outer-spin-button,
  input[type="number"]:hover::-webkit-outer-spin-button,
  input[type="number"]:hover::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;

export const TextInput: React.FC<TextInputProps> = props => (
  <Field
    name={props.name}
    render={(formikProps: FormikFieldProps) => {
      const {
        field,
        form: {
          touched: { [props.name]: touched },
          errors: { [props.name]: error }
        }
      } = formikProps;
      return (
        <StyledInputField
          {...field}
          error={touched && error}
          inlineicon={props.inlineicon}
          type={props.type}
          placeholder={props.placeholder}
          fieldtype={props.fieldtype}
          disabled={props.disabled && "disabled"}
        />
      );
    }}
  />
);

export const TextInputInlineWrapped = InlineWrapper(TextInput);
