import { Formik } from "formik";
import React from "react";
import styled from "styled-components";
import { Button, ButtonWrapper } from "../Button/Button";
// import { CalendarSample } from "../CalendarSample/CalendarSample";
import { StyledLink } from "../Typography";
import {
  AutocompleteHotInput,
  AutocompleteInput,
  CalendarInput,
  CheckboxInput,
  DropdownInput,
  ExpandableSelectInput,
  FieldProps,
  OtpInputInlineWrapped,
  SelectInput,
  StarInput,
  TextareaInput,
  TextInputInlineWrapped,
  ToggleInput
} from "./Field";
import { RichTextareaInput } from "./Field/RichTextareaInput";

import { validator } from "./rules";

interface FormProps {
  fields: FieldProps[];
  onSubmit?: (data: any) => void;
  onChange?: (data: any) => void;
  onChangeHot?: boolean;
  linkTo?: { pathname: string; search: any } | string;
  enableClear?: boolean;
  submitLabel?: string;
  formType: "inline" | "fullscreen" | "inline2" | "whatsapp";
  formDirection?:
    | "vertical"
    | "horizontal"
    | "sem-page"
    | "get-quote"
    | "review"
    | "book-a-shoot"
    | "listing";
  submitOnChange?: boolean;
  submitId?: string;
  noFieldPlaceholder?: string;
  CalendarSample?: {};
  filterButton?: boolean;
}

interface HTMLFormProps {
  onSubmit: () => void;
  formDirection:
    | "vertical"
    | "horizontal"
    | "sem-page"
    | "get-quote"
    | "review"
    | "book-a-shoot"
    | "listing";
  formType: "inline" | "fullscreen" | "inline2" | "whatsapp";
  filterButton: true;
}

const renderFields = (fields: FieldProps[]) => {
  return fields.map(input => {
    switch (input.type) {
      case "text":
        return (
          <TextInputInlineWrapped
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype}
            {...input}
          />
        );
      case "otp":
        return (
          <OtpInputInlineWrapped
            key={input.name}
            resend={input.resend}
            fieldtype={input.fieldtype}
            {...input}
          />
        );
      case "number":
        const validation = Array.isArray(input.validation)
          ? input.validation
          : [input.validation];
        if (
          validation.findIndex(rule => !!rule && rule.rule === "isNumeric") ===
          -1
        ) {
          validation.unshift({ rule: "isNumeric", err: "Numbers only." });
        }
        return (
          <TextInputInlineWrapped
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype}
            {...input}
            type={"text"}
            validation={validation}
          />
        );
      case "dropdown":
        return (
          <DropdownInput
            key={input.name}
            fieldtype={input.fieldtype}
            options={input.options}
            {...input}
          />
        );
      case "select":
        return (
          <ExpandableSelectInput
            key={input.name}
            options={input.options}
            multiple={!!input.multiple}
            showWidget={!!input.showWidget}
            fieldtype={input.fieldtype}
            showBorder={input.showBorder}
            {...input}
          />
        );
      case "radio":
        return (
          <SelectInput
            key={input.name}
            options={input.options}
            multiple={false}
            showWidget={!!input.showWidget}
            {...input}
          />
        );
      case "checkbox":
        return (
          <SelectInput
            key={input.name}
            options={input.options}
            multiple={true}
            showWidget={!!input.showWidget}
            {...input}
          />
        );
      case "autocomplete":
        return (
          <AutocompleteInput
            key={input.name}
            fieldtype={input.fieldtype}
            options={input.options}
            {...input}
            placeholder={input.placeholder || ""}
          />
        );
      case "autocompletehot":
        return (
          <AutocompleteHotInput
            key={input.name}
            fieldtype={input.fieldtype}
            options={input.options}
            {...input}
            placeholder={input.placeholder || ""}
          />
        );
      case "textarea":
        return (
          <TextareaInput
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype || "form"}
            {...input}
          />
        );
      case "toggle":
        return (
          <ToggleInput
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype}
            {...input}
          />
        );
      case "richtextarea":
        return (
          <RichTextareaInput
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype || "form"}
            {...input}
          />
        );
      case "date":
        return (
          <CalendarInput
            key={input.name}
            multiple={input.multiple || false}
            {...input}
          />
        );
      case "star":
        return (
          <StarInput
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype}
            {...input}
          />
        );
      case "simplecheckbox":
        return (
          <CheckboxInput
            key={input.name}
            fieldtype={input.fieldtype}
            {...input}
          />
        );
      default:
        return (
          <TextInputInlineWrapped
            key={input.name}
            placeholder={input.placeholder || ""}
            fieldtype={input.fieldtype || "form"}
            {...input}
          />
        );
    }
  });
};

const getInitialValues = (fields: FieldProps[]) => {
  const initialValues: { [name: string]: any } = {};
  fields.forEach(field => {
    if (!initialValues[field.name]) {
      initialValues[field.name] = field.value || "";
    }
  });
  return initialValues;
};
const getValidationRules = (fields: FieldProps[]) => {
  const validationRules: { [name: string]: any } = {};
  fields.forEach(field => {
    if (!validationRules[field.name]) {
      validationRules[field.name] = !!field.validation
        ? Array.isArray(field.validation)
          ? field.validation
          : [field.validation]
        : undefined;
    }
  });
  return validationRules;
};
const FieldDiv = styled("div")`
  margin: 0px;
`;
const FormAttrDiv = styled("div")``;

const ButtonDiv = styled("div")``;

const StyledForm = styled("form")<HTMLFormProps>`
  display: flex;  
  flex-direction: column;

  padding: ${props =>
    props.formDirection === "review" && "0rem 1rem 0.5rem 1rem"};
  
  ${props => props.theme.media.desktop} {
    ${props =>
      props.formDirection === "horizontal" &&
      `
    flex-direction: row;
    justify-content: center;
    * {
      border-radius: 0;
    }
    `}
    ${props =>
      props.formDirection === "sem-page" &&
      `    
    display: grid;
    grid-template-columns: 4fr 1fr;
    grid-gap: 1rem;
    align-items: end;
    `}
  }
  
  ${ButtonWrapper} {
    cursor: pointer;
    width: ${props => props.formType === "inline" && "100%"};
    width: ${props => props.formDirection === "review" && "100%"};
    margin: ${props =>
      props.formType === "inline"
        ? "0.2rem 0 0 0"
        : props.formType === "inline2"
        ? "0"
        : "0 -1rem"};
        margin: ${props => props.formType === "whatsapp" && "0"};
    border-radius: ${props =>
      props.formType === "inline" ? "3px" : "inherit"};
    ${props => props.theme.media.desktop} {
      display: flex;
      align-items: center;
      // border: 1px solid #ddd;
      margin: ${props => (props.formType === "inline" ? "2px 0 0 0" : "0")};
      border-radius: ${props =>
        props.formDirection === "sem-page" && "1.25rem"};
    /*${props =>
      props.formDirection === "listing" && `grid-column-start: none`}*/
    ${props => props.formDirection === "sem-page" && ` margin-bottom: 1.25rem`}
     /*display: ${props => (props.filterButton ? "block" : "none")};   */
    }

    ${Button} {
      position: ${props => props.formType === "fullscreen" && "fixed"};
      bottom: 0;
      width: ${props => props.formType === "inline2" && "100%"};
      margin: 0 auto;
      // padding: 0 1rem;
      ${props => props.theme.media.mobile} {
        width: ${props => props.formType === "inline2" && "inherit"};
      }
      border-radius: ${props => props.formType === "whatsapp" && "4px"}; 
      ${props => props.theme.media.desktop} {
        width: ${props =>
          props.formDirection === "listing"
            ? "45%"
            : props.formType === "inline2" && "auto !important"};
            
        border-radius: ${props =>
          props.formDirection === "listing"
            ? "2px"
            : props.formType === "inline2" && "0.3rem"};
         
        
        position: relative;

        height: ${props => props.formDirection === "listing" && "40px"}  

        &:last-child{
          margin-left: ${props => props.formDirection === "listing" && "7%"}
        }
      }
    }
  }
  
  ${FieldDiv} {
    ${props => props.theme.media.desktop} {
      ${props => props.formDirection === "listing" && `grid-row-start: 1;`}
    }
    margin: ${props => props.formDirection === "get-quote" && "8px 0px"};
  }

  ${FormAttrDiv}{
    ${props => props.theme.media.desktop} {
      ${props =>
        props.formDirection === "listing" &&
        `
      display: grid;
      grid-template-columns: 11rem 12rem 11rem`}
      ${props =>
        props.formDirection === "horizontal" &&
        `
      display: flex;`}
    }
  }

  ${ButtonDiv}{
    ${props => props.theme.media.desktop} {
      ${props =>
        props.formDirection === "listing" &&
        `
      text-align:center;
      width:  "14rem";
      margin:  "0rem 8rem auto";
      padding-top: "0.5rem";`}
    }
  }
`;

const PlaceholderNoField = styled("span")`
  margin: 1rem 0;
`;

export const Form: React.FC<FormProps> = props => {
  const {
    fields,
    onSubmit,
    linkTo = "",
    formType = "fullscreen",
    formDirection = "vertical",
    onChange,
    onChangeHot,
    enableClear = false,
    submitOnChange = false,
    filterButton = true,
    submitId = "submit-button",
    noFieldPlaceholder = "no fields available"
  } = props;
  const initialValues = getInitialValues(fields);
  const rules = getValidationRules(fields);
  const stickyBottom = formType === "fullscreen" && {
    sticky: true,
    bottom: true
  };

  const onSubmitHandler = !!onSubmit ? onSubmit : (data: any) => {};
  const onChangeHandler = !!onChange ? onChange : (data: any) => {};

  const clearForm = (event: any, handleReset: any) => {
    event.preventDefault();
    handleReset();
  };

  const renderButton = (form: any) =>
    linkTo ? (
      <StyledLink to={linkTo} id={submitId + "-link"}>
        <ButtonWrapper fullwidth={true}>
          <Button
            disabled={!form.isValid}
            btnType="primary"
            {...stickyBottom}
            id={submitId}
          >
            {props.submitLabel}
          </Button>
        </ButtonWrapper>
      </StyledLink>
    ) : (
      <ButtonWrapper fullwidth={true}>
        {enableClear && (
          <Button
            btnType="secondary"
            onClick={e => clearForm(e, form.handleReset)}
            id={submitId + "-clear"}
          >
            Clear
          </Button>
        )}
        {formType === "whatsapp" ? (
          <Button
            disabled={!form.isValid && form.isDirty}
            btnType="primary"
            id={submitId}
          >
            {props.submitLabel}
          </Button>
        ) : (
          <Button disabled={!form.isValid} btnType="primary" id={submitId}>
            {props.submitLabel}
          </Button>
        )}
      </ButtonWrapper>
    );

  return (
    <Formik
      onSubmit={onSubmitHandler}
      initialValues={initialValues}
      validate={values => validator(rules, values)}
      render={form => {
        if (!onChangeHot) {
          onChangeHandler(form.values);
        }
        return (
          <StyledForm
            onChange={(e: any) => {
              if (onChangeHot) {
                onChangeHandler({
                  ...form.values,
                  [e.target.name]: e.target.value
                });
              }
            }}
            onSubmit={form.handleSubmit}
            formType={formType}
            formDirection={formDirection}
            autoComplete="off"
            filterButton={true}
          >
            <FormAttrDiv>
              {fields.length ? (
                renderFields(fields).map((field: any, idx: number) => (
                  <FieldDiv key={idx}>{field}</FieldDiv>
                ))
              ) : (
                <PlaceholderNoField> {noFieldPlaceholder}</PlaceholderNoField>
              )}
            </FormAttrDiv>
            <ButtonDiv>
              {!submitOnChange && !!onSubmit && renderButton(form)}
            </ButtonDiv>
          </StyledForm>
        );
      }}
    />
  );
};
