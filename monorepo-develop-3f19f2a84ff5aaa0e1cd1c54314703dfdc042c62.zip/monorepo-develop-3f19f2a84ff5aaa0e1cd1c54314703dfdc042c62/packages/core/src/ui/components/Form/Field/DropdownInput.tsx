import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";

import styled from "styled-components";
import { FieldProps, OptionProps } from ".";
import { SiteIcon } from "../../Icon/Icon";

export interface DropdownOptionProps extends OptionProps {}

export interface DropdownInputProps extends FieldProps {
  /** Type of dropdown rendered */
  fieldtype: "listing" | "landing";
  options: DropdownOptionProps[];
  placeholder?: string;
}

export interface FieldDivProps {
  open: boolean;
}

export interface CustomFieldProps {
  fieldtype: "listing" | "landing";
  name: string;
  options: DropdownOptionProps[];
  value: string;
  setFieldValue: any;
  fieldIcon?: any;
  placeholder?: string;
}

export interface CustomSelectDivProps {
  value: string;
}

// Styling functions
export const CustomSelectDiv = styled.div<CustomSelectDivProps>`
  position: relative;
  color: ${props => props.theme.colors.primary};
  background-color: white;
  border-radius: 3px;
  cursor: pointer;
  &:hover {
    background-color: ${props => props.theme.colors.white};
    transition: all 0.2s ease-in-out;
  }
  margin: 0.1rem 0;
  color: ${props =>
    props.value !== "" ? "${props => props.theme.colors.primary}" : ""};
`;

export const FieldDiv = styled.div<FieldDivProps>`
  border: 1px solid #ddd;
  /* box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.13), 0px 0px 10px 0px rgba(0,0,0,0.02);*/
  align-items: center;
  border-radius: 3px;
  display: flex;
  padding: 0.75rem;
  border-bottom-left-radius: ${props => props.open && "0"}
  border-bottom-right-radius: ${props => props.open && "0"}
`;

export const OptionDisplay = styled.div`
  flex: 1;
  font-size: ${props => props.theme.fontSize[150]};
  font-weight: ${props => props.theme.fontWeight.medium};
`;

export const SelectButton = styled.div`
  align-items: center;
  cursor: pointer;
  display: flex;
  margin: -8px;
  padding: 0 12px;
  font-size: 20px;
`;

export const Options = styled.div`
  background: white;
  border: 1px solid #ccc;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
  border-top: 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25);
  left: 0;
  position: absolute;
  /*padding: 8px 0;*/
  right: 0;
  top: 100%;
  z-index: 3;
  height: auto;
  max-height: 250px;
  overflow: auto;
`;

export const OverlaySelect = styled.div`
  bottom: 0;
  left: 0;
  position: fixed;
  right: 0;
  top: 0;
  z-index: 2;
`;

export const SingleOption = styled.div`
  cursor: pointer;
  padding: 0.5rem;
  font-size: ${props => props.theme.fontSize[100]};

  &:hover {
    background: #cdcdcd;
  }
`;

export const BlankSpace = styled.span`
  padding: 0.5rem 0.75rem;
`;

export const renderDisplay = ({ options, value, placeholder = null }: any) => {
  const found = options.find((option: any) => option.id === value);
  if (found) {
    return found.name;
  }
  return placeholder;
};

export function renderOptions({ options, handleClick, value, isOpen }: any) {
  if (!isOpen) {
    return null;
  }
  return (
    <Options>
      {options.map((option: any) => (
        <SingleOption key={option.id} onClick={() => handleClick(option.id)}>
          {option.id === value ? (
            <SiteIcon
              name={"check"}
              style={{
                color: "#000",
                margin: "none",
                marginRight: ".5rem"
              }}
            />
          ) : (
            <BlankSpace />
          )}

          {option.name}
        </SingleOption>
      ))}
    </Options>
  );
}

export const setValue = ({ setIsOpen, setFieldValue, name }: any) => (
  value: string
) => {
  setIsOpen(false);
  setFieldValue(name, value);
};

export const renderDropdown = (isOpen: boolean) => (
  <SelectButton>
    {isOpen ? (
      <SiteIcon
        name={"expand-less"}
        style={{
          color: "#000",
          margin: "none",
          marginLeft: ".75rem"
        }}
      />
    ) : (
      <SiteIcon
        name={"expand-more"}
        style={{
          color: "#000",
          margin: "none",
          marginLeft: ".75rem"
        }}
      />
    )}
  </SelectButton>
);

const CustomSelect: React.FC<CustomFieldProps> = props => {
  // declaring the state variable using Hooks
  const { name, options, value, setFieldValue, fieldIcon, placeholder } = props;

  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <CustomSelectDiv onClick={() => setIsOpen(!isOpen)} value={value}>
      <FieldDiv open={isOpen}>
        {!!fieldIcon && fieldIcon}
        <OptionDisplay>
          {renderDisplay({ options, value, placeholder })}
        </OptionDisplay>
        {renderDropdown(isOpen)}
      </FieldDiv>
      {renderOptions({
        options,
        handleClick: setValue({ setIsOpen, setFieldValue, name }),
        value,
        isOpen
      })}
      {isOpen ? <OverlaySelect onClick={() => setIsOpen(false)} /> : null}
    </CustomSelectDiv>
  );
};

export const StyledField = styled("div")`
  min-width: 100%;
  flex-basis: 100%;
  ${props => props.theme.media.desktop} {
    margin: 0 0.5rem 0 0;
  }
`;

export const DropdownInput: React.FC<DropdownInputProps> = props => (
  <StyledField key={props.name}>
    {/* <Label {...props} /> */}
    <Field
      name={props.name}
      render={(formikProps: FormikFieldProps) => {
        const { field, form } = formikProps;

        return (
          <CustomSelect
            {...props}
            setFieldValue={form.setFieldValue}
            value={form.values[props.name]}
          />
        );
      }}
    />
  </StyledField>
);
