import { Field, FieldProps as FormikFieldProps } from "formik";
import * as React from "react";
import styled from "styled-components";
import { FieldProps, Label } from ".";
import { InlineWrapper } from "../Hoc";

interface OtpInputProps extends FieldProps {
  fieldtype: "form" | "landing";
  resend: () => void;
  countdown?: number;
  error?: boolean;
}

const StyledOtpField = styled("input")<OtpInputProps>`
  border-radius: 5px;
  padding: ${props => (props.inlineicon ? "10px 15px 10px 2rem" : "10px 15px")};
  background: ${props => props.theme.colors.white};
  border: ${props => (props.inlineicon ? "transparent" : "1px solid #ddd")};
  border-bottom: ${props =>
    props.inlineicon &&
    "1px solid " +
      (props.error ? props.theme.colors.primary : props.theme.colors.gray3)};
  outline: #ddd;
  -webkit-appearance: none;
  margin: 0;
  box-sizing: border-box;
  width: 100%;
  input[type="number"]::-webkit-inner-spin-button,
  input[type="number"]::-webkit-outer-spin-button,
  input[type="number"]:hover::-webkit-outer-spin-button,
  input[type="number"]:hover::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
`;

const Resend = styled("p")<{ disabled: boolean; inlineicon: string }>`
  margin: 0;
  float: ${props => props.inlineicon && "right"};
  color: ${props => (props.disabled ? "f8f8f8" : props.theme.colors.primary)};
  font-size: ${props => props.theme.fontSize[100]};
  cursor: pointer;
  font-weight: bold;
`;

export const renderResend = (props: any) => {
  const initialCountdown = props.countdown || 60;
  const [countdown, setCountdown] = React.useState(initialCountdown);

  React.useEffect(() => {
    if (countdown > 0) {
      setTimeout(() => setCountdown(countdown - 1), 1000);
    }
  });

  const handleResend = () => {
    if (countdown === 0) {
      props.resend();
      setCountdown(initialCountdown);
    }
  };
  let resendText = countdown > 0 ? `Resend (${countdown})` : `Resend now`;
  resendText = countdown > initialCountdown / 2 ? `OTP Sent` : resendText;

  return (
    <Resend
      disabled={countdown > 0}
      onClick={handleResend}
      inlineicon={props.inlineicon}
    >
      {resendText}
    </Resend>
  );
};

export const OtpInput: React.FC<OtpInputProps> = props => {
  return (
    <div key={props.name}>
      {!props.inlineicon && (
        <Label {...props}>
          {renderResend({
            resend: props.resend,
            countdown: props.countdown,
            inlineicon: props.inlineicon
          })}
        </Label>
      )}
      <Field
        name={props.name}
        render={(formikProps: FormikFieldProps) => {
          const {
            field,
            form: {
              touched: { [props.name]: touched },
              errors: { [props.name]: error }
            }
          } = formikProps;
          return (
            <StyledOtpField
              {...field}
              error={touched && error}
              type={props.type}
              placeholder={props.placeholder}
              inlineicon={props.inlineicon}
              fieldtype={props.fieldtype}
              disabled={props.disabled && "disabled"}
            />
          );
        }}
      />
    </div>
  );
};

export const OtpInputInlineWrapped = InlineWrapper(OtpInput);
