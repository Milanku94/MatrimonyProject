import { Field, FieldProps as FormikFieldProps } from "formik";
import _groupBy from "lodash/groupBy";
import * as React from "react";
import styled from "styled-components";
import { FieldProps } from ".";
import { SiteIcon } from "../../Icon/Icon";
import {
  BlankSpace,
  CustomFieldProps,
  CustomSelectDiv as CustomSelectDivDD,
  CustomSelectDivProps,
  DropdownOptionProps,
  FieldDiv,
  Options,
  OverlaySelect,
  renderDisplay,
  setValue,
  SingleOption,
  StyledField
} from "./DropdownInput";
import { StyledInputField } from "./TextInput";

export interface AutocompleteHotInputOptionProps extends FieldProps {
  fieldtype: "listing" | "landing";
  options: Array<{
    icon: string;
    schemaType: string;
    name: string;
    id: string;
    handleClick: () => void;
  }>;
  placeholder?: string;
}

// Styling functions
const CustomSelectDiv = styled(CustomSelectDivDD)<CustomSelectDivProps>`
  cursor: text;
  ${FieldDiv} {
    padding: 0.75rem;
    input {
      border: none !important;
      padding: 0 !important;
      margin: 0;
    }
  }
`;

const GroupHeader = styled("div")<{ clickable?: boolean }>`
  padding: 0.5rem;
  ${props =>
    props.clickable
      ? `
    cursor: pointer;
    &:hover {
      color: ${props.theme.colors.primary};
      background: ${props.theme.colors.gray5};
    }`
      : ``}
`;
const GroupOptions = styled(Options)`
  padding: 0.5rem;
`;
export const GroupOption = styled.div`
  text-transform: capitalize;
  border-bottom: 1px solid ${props => props.theme.colors.gray5};
  font-weight: ${props => props.theme.fontWeight.medium};
  font-size: ${props => props.theme.fontSize[150]};
  color: ${props => props.theme.colors.black};
  ${SingleOption} {
    &:hover {
      color: ${props => props.theme.colors.primary};
      background: ${props => props.theme.colors.gray5};
    }
    span:nth-child(1) {
      padding-left: 0.75rem;
    }
    span:nth-child(2) {
      padding-left: 0.25rem;
      color: ${props => props.theme.colors.gray2};
    }
  }
`;
interface CustomSelectProps extends CustomFieldProps {
  onChange: (e: any) => any;
  name: string;
}
const renderHotOptions = ({ options, handleClick, isOpen, value }: any) => {
  if (!isOpen) {
    return null;
  }
  const groupedOptions = _groupBy(options, (option: any) => option.schemaType);
  return (
    <GroupOptions>
      {Object.keys(groupedOptions).map((groupTitle: any) => (
        <GroupOption key={groupTitle}>
          <GroupHeader
            onClick={() => {
              if (groupedOptions[groupTitle][0].handleCategoryClick) {
                groupedOptions[groupTitle][0].handleCategoryClick({
                  search: value
                });
              }
            }}
            clickable={!!groupedOptions[groupTitle][0].handleCategoryClick}
          >
            <SiteIcon
              name={groupedOptions[groupTitle][0].icon}
              style={{
                height:
                  groupedOptions[groupTitle][0].icon === "category"
                    ? ".75rem"
                    : "1rem",
                color: "#000",
                margin: "none",
                marginRight: ".5rem"
              }}
            />
            {groupTitle}{" "}
            {groupedOptions[groupTitle][0].profilesCount
              ? `(${groupedOptions[groupTitle][0].profilesCount})`
              : ``}
          </GroupHeader>
          {groupedOptions[groupTitle].map(
            (option: any, idx) =>
              option.name && (
                <SingleOption
                  key={idx}
                  onClick={() => {
                    option.handleClick();
                    handleClick(option.id);
                  }}
                >
                  <BlankSpace />
                  {option.name}
                  {option.secondaryName && <span>{option.secondaryName}</span>}
                </SingleOption>
              )
          )}
        </GroupOption>
      ))}
    </GroupOptions>
  );
};
const CustomSelect: React.FC<CustomSelectProps> = props => {
  // declaring the state variable using Hooks
  const { name, options, value, setFieldValue, fieldIcon, placeholder } = props;

  const [isOpen, setIsOpen] = React.useState(false);
  const filteredOptions =
    value && value.length
      ? options.filter(
          (option: DropdownOptionProps) =>
            !option.name ||
            option.name.match(
              new RegExp(
                value.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1") || "",
                "i"
              )
            )
        )
      : options;

  const emptyValue = () => {
    setFieldValue(name, "");
  };

  return (
    <CustomSelectDiv onClick={() => setIsOpen(!isOpen)} value={value}>
      <FieldDiv open={isOpen}>
        {!!fieldIcon && fieldIcon}
        <StyledInputField
          name={props.name}
          onChange={props.onChange}
          value={renderDisplay({ value, options, placeholder: value })}
          placeholder={placeholder || "start typing.."}
        />

        {value && !!value.length && (
          <SiteIcon
            name={"close"}
            onClick={() => emptyValue()}
            style={{
              color: "#000",
              margin: "none",
              cursor: "pointer",
              position: "absolute",
              right: "1rem",
              zIndex: 3
            }}
          />
        )}
      </FieldDiv>
      {!!filteredOptions.length &&
        renderHotOptions({
          options: filteredOptions,
          handleClick: setValue({ setIsOpen, setFieldValue, name }),
          isOpen,
          value
        })}
      {isOpen ? <OverlaySelect onClick={() => setIsOpen(false)} /> : null}
    </CustomSelectDiv>
  );
};

export const AutocompleteHotInput: React.FC<AutocompleteHotInputOptionProps> = props => (
  <StyledField key={props.name}>
    {/* <Label {...props} /> */}
    <Field
      name={props.name}
      render={(formikProps: FormikFieldProps) => {
        const { field, form } = formikProps;

        return (
          <CustomSelect
            {...props}
            name={field.name}
            onChange={field.onChange}
            setFieldValue={form.setFieldValue}
            value={form.values[props.name]}
          />
        );
      }}
    />
  </StyledField>
);
