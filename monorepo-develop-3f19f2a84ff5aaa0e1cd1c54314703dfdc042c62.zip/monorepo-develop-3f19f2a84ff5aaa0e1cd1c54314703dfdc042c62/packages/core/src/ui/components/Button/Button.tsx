import styled from "styled-components";

interface ButtonWrapperProps {
  sticky?: boolean;
  bottom?: boolean;
  fullwidth?: boolean;
}

interface ButtonProps {
  /** Type of the button rendered */
  btnType: "primary" | "secondary";
  btnSize?: "small" | "large";
  disabled?: boolean;
}

export const Button = styled("button")<ButtonProps>`
  height: ${props => (props.btnSize === "small" ? "26px" : "47px")};  
  width: ${props => (props.btnSize === "small" ? "84px" : "100%")}
  padding-left: 16px;
  padding-right: 16px;
  font-size: ${props => props.theme.fontSize[150]};
  cursor: pointer;
  &:disabled {
    cursor: not-allowed;
  }
  font-weight: ${props => props.theme.fontWeight.medium};
  color: ${props =>
    props.btnType === "primary"
      ? props.theme.colors.white
      : props.disabled
      ? props.theme.colors.gray1
      : props.theme.colors.primary};
  background-color: ${props =>
    props.btnType === "primary"
      ? props.disabled
        ? props.theme.colors.gray1
        : props.theme.colors.primary
      : props.theme.colors.white}
  border: ${props =>
    props.btnType === "primary"
      ? "none"
      : `0.5px solid ${
          props.disabled ? props.theme.colors.gray1 : props.theme.colors.primary
        }`};
  border-radius: inherit;
  ${props => props.theme.media.desktop} {
  }  
`;

export const ButtonWrapper = styled("div")<ButtonWrapperProps>`
  z-index: ${props => props.sticky && "9"};
  width: ${props => props.fullwidth && "100%"};
  border-radius: ${props => !props.fullwidth && props.theme.borderRadius};
  position: ${props => props.sticky && "fixed"};
  bottom: ${props => props.bottom && "0"};
  margin: ${props => props.fullwidth && "0"};
  ${props => props.theme.media.mobile}{  
    & > ${Button}:first-child {
    width: 20%;
  }
  & > ${Button}:not(:first-child) {
    left: 20%;
    width: 80%;
  }}
  & > ${Button}:only-child {
    width: 100%;
  }
  /*${props => props.theme.media.desktop} {
    & > ${Button}:first-child {
      width: 40%;
      height: auto;
      padding: 0.7rem;
    }
    & > ${Button}:not(:first-child) {
      left: 10%;
      height: auto;
      width: 40%;
      padding: 0.7rem;
    }
  }/*
`;
