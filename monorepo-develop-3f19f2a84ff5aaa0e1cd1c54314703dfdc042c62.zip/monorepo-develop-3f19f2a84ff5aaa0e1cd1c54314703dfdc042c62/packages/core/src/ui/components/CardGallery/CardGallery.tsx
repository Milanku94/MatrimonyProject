import React, { useState } from "react";
import styled from "styled-components";
import { PictureTag } from "../../";
import { Media } from "../../types";
interface CardGalleryProps {
  gallery: Media[];
}
const ImageCard = styled.div`
  width: 48%;
  margin: 0.125rem;
  align-items: center;
  justify-content: center;
  display: flex;
  img {
    width: 100%;
  }
  span {
    position: absolute;
    text-decoration: none;
    color: rgba(0, 0, 0, 1);
  }
`;

const SeeMoreImageCard = styled(ImageCard)`
  display: block;
  position: relative;
`;
const SeeMore = styled("div")`
  position: absolute;
  background-color: rgba(255, 255, 255, 0.5);
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
`;

const renderImage = (props: Media) => {
  return (
    <ImageCard key={props.url}>
      <PictureTag image={props.url} alt={"image"} />
    </ImageCard>
  );
};
const seeMore = ({ image, length, setHidden }: any) => {
  return (
    <SeeMoreImageCard key={image.url}>
      <SeeMore onClick={() => setHidden(false)}>See all ({length})</SeeMore>

      <PictureTag image={image.url} alt={"image"} />
    </SeeMoreImageCard>
  );
};

const Gallery = styled("div")`
  width: 100%;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
`;

const UnStyledCardGallery = React.memo((props: CardGalleryProps) => {
  const [hidden, setHidden] = useState(true);
  if (props.gallery.length === 0) {
    return <React.Fragment />;
  }
  const minNoOfImg = props.gallery.length <= 4 ? props.gallery.length : 3;
  const noOfImg = hidden ? minNoOfImg : props.gallery.length;
  return (
    <Gallery>
      {props.gallery &&
        props.gallery.slice(0, noOfImg).map(image => renderImage(image))}
      {hidden &&
        seeMore({
          image: props.gallery[3],
          length: props.gallery.length,
          setHidden
        })}
    </Gallery>
  );
});

export const CardGallery = styled(UnStyledCardGallery)<CardGalleryProps>``;
