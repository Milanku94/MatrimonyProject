import * as React from "react";
import styled from "styled-components";
import { H2 } from "../../";
import {
  CategoryIcon,
  CategoryIconWrapper,
  CategoryType
} from "../CategoryIcon/CategoryIcon";
interface WeddingServiceProvidersProps {
  categories: CategoryType[];
  city: string;
  showText?: boolean;
  elementID?: string;
  max?: number;
  isHome?: boolean;
  isServicePage?: boolean;
  isPopOver?: boolean;
}

interface AllCategoriesDivProps {
  isHome?: boolean;
  isServicePage?: boolean;
  isPopOverStyle?: boolean;
}

interface WeddingServiceProvidersDivProps {
  isPopOver?: boolean;
}

const WeddingServiceProvidersDiv = styled("div")<
  WeddingServiceProvidersDivProps
>`
  padding: ${props => (props.isPopOver ? "0rem" : "2rem 0")};
`;

const AllCategoriesDiv = styled("div")<AllCategoriesDivProps>`
  padding-bottom: 2rem;
  flex-wrap: wrap;
  flex-direction: row;
  padding: ${props => (props.isPopOverStyle ? "0rem" : "2rem")};
  display: ${props => (props.isPopOverStyle ? "flex" : "grid")};
  grid-template-columns: repeat(auto-fill, minmax(6rem, 1fr));
  grid-gap: 0.5rem;
  grid-auto-flow: row;
  align-items: center;
  justify-items: center;
  justify-content: center;
  align-content: center;
  ${props =>
    props.isHome
      ? `& > a {
    display: table-cell;
  }
  & > a:last-child {
    display: none;
  }`
      : `& > a {     
    display: table-cell;
  }`}

  ${props =>
    props.isPopOverStyle &&
    `width: 25rem;
    & > a {
      width:6rem;
    }
    & > a{
      svg{
        height: 2.5rem;   
      }
      p{
        overflow: inherit;
      }
    }
    & > a:hover{
      box-shadow: 0 0px 3px rgba(0,0,0,0.2), 0 1px 1px rgba(0,0,0,0.02);
    }
    `}
`;

const AllCategories = styled("p")`
  color: ${props => props.theme.colors.primary};
  font-size: ${props => props.theme.fontSize[200]};
  font-weight: ${props => props.theme.fontWeight.medium};
  margin: 1.5rem 0;
`;

export const WeddingServiceProviders = React.memo(
  ({ max = 11, isHome = false, ...props }: WeddingServiceProvidersProps) => {
    return (
      <WeddingServiceProvidersDiv isPopOver={props.isPopOver}>
        {!props.showText && (
          <H2 fontSize={300} textAlign="center" padding="major-2">
            Find the best wedding service providers near you
          </H2>
        )}
        <AllCategoriesDiv isHome={isHome} isPopOverStyle={props.isPopOver}>
          {props.categories &&
            props.categories
              .slice(0, isHome ? props.categories.length : max)
              .map(cat => (
                <CategoryIcon
                  elementID={props.elementID}
                  displaytype="box"
                  key={cat.needName}
                  {...cat}
                  city={props.city}
                />
              ))}
          {(props.categories.length > max || isHome) && (
            <CategoryIconWrapper
              to={`/${props.city}`}
              displaytype="box"
              id={`${props.elementID}-all`}
            >
              <AllCategories> All Services</AllCategories>
            </CategoryIconWrapper>
          )}
        </AllCategoriesDiv>
      </WeddingServiceProvidersDiv>
    );
  }
);
