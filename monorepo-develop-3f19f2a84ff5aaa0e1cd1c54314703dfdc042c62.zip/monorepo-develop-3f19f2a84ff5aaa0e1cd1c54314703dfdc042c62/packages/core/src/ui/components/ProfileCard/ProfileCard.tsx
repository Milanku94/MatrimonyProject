import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import { SiteIcon } from "../../components/Icon/Icon";
import { Media } from "../../types";
import { Card } from "../Card/Card";
import { CardBody } from "../CardBody/CardBody";
import { CardImage } from "../CardImage/CardImage";
import { CardTitle } from "../CardTitle/CardTitle";
import { Chips } from "../Chips/Chips";
import { ShareSocialIcons } from "../ShareSocialIcons/ShareSocialIcons";
import { StarRatings } from "../StarRatings/StarRatings";
import { Headline, Secondary, StyledLink } from "../Typography";

interface Badges {
  id: string;
  name: string;
}
export interface BranchValueType {
  buildingName?: string;
  flat?: string;
  floor?: string;
  address?: string;
  streetName?: string;
  locality?: string;
  pincode?: string;
  landmark?: string;
  latitude: string;
  longitude: string;
}
interface ProfileCardProps {
  name: string;
  location: string;
  image: Media;
  badges: Badges[];
  attributes: AttributeValueType[];
  slug?: string;
  preventLink?: boolean;
  pageViewCard?: "listing" | "detail";
  paidPremium?: boolean;
  desktopCTA?: JSX.Element;
  mobileCTA?: JSX.Element;
  basePath?: any;
  url?: string;
  branch?: BranchValueType[];
  rating: number;
}
export interface AttributeValueType {
  name: string;
  value: string;
  subtext?: string;
  slug?: string;
  forDistribution?: boolean;
}
const ListName = styled("span")`
color: #1D8033
font-weight: ${props => props.theme.fontWeight.medium};
font-size: ${props => props.theme.fontSize[50]};
text-transform: uppercase;
display:none;
`;
const ListItem = styled("p")`
  font-size: ${props => props.theme.fontSize[100]};
  line-height: 0.85rem
  font-weight: ${props => props.theme.fontWeight.medium};
  color: #707070
  margin: 0.1rem 1rem;
`;
const CardContent = styled("div")<{
  paidPremium: boolean;
  detailCard: boolean;
}>`
  background-color: white;
  ${props => props.theme.media.mobile} {
    ${props =>
      props.detailCard
        ? `
    width: calc(100% - 1rem);
    bottom: -2.5rem;
    left: 0.5rem;
    border-radius: 0.25rem 0.25rem 0 0;
    grid-area: card-content;
    background-color: white;
    position: absolute;
    `
        : `
    `}
  }
  ${props => props.theme.media.desktop} {
    ${props =>
      props.paidPremium
        ? `
      display: block;
      position: absolute;
      min-height: 6rem;
      bottom: 0;
      width: 100%;
      // box-shadow: rgba(41, 41, 41, 0.32) 0px 19px 38px, rgba(0, 0, 0, 0.39) 0px 15px 12px;
      padding: 0 12.5%;
      display: grid;
      grid-template-areas:
      'card-title card-title . '
      'card-body  card-body  card-cta';
    `
        : `
      position: relative;
      grid-area: card-content;
    `}
  }
`;
const cardStyles = (props: ProfileCardProps, theme: any) => {
  switch (props.pageViewCard) {
    case "detail": {
      if (props.paidPremium) {
        return `
          height: 60vh;
          width: 100%;
          ${backgroundImage(props.image.url, "cover", false, "#ffffff")};
          background-repeat: no-repeat;
          background-position: top;
          background-size: contain !important;
          position: relative;   
          margin-bottom: 3rem;
          ${theme.media.mobile} {
              max-height: 22rem;
            }
          ${theme.media.desktop} {
            display: flex;
            align-items: center;  
            height: calc( 100vh - 1rem);
            margin-bottom: 1rem;
          }
        `;
      } else {
        return `
        min-height: 50vh;
        position: relative;
        margin-bottom: 3rem;
        ${theme.media.desktop} {
          display: grid;
          margin: 2rem 0 0.5rem 0;
          grid-template-columns: 2fr 1fr;
          grid-template-areas: "card-image card-content";
          grid-gap: 0.5rem;
        }
      `;
      }
    }
    case "listing": {
      return `
        display: grid;
        margin: 0;
        grid-template-columns: 1fr;
        grid-template-areas: 
          "card-image"
          "card-content";
        grid-gap: 0;  
      `;
    }
  }
};
const CardStyles = styled("div")<ProfileCardProps>`
  ${props => cardStyles(props, props.theme)}
  > div:first-child {
    height: ${props =>
      props.pageViewCard === "listing" ? "10.5rem" : "inherit"};
  }
  ${Headline} {
    width: 100%;
    display: flex;
    flex-direction: column;
    font-size: 17px;
    font-weight: ${props => props.theme.fontWeight.medium};
    color: #2a2c34;
    white-space: ${props =>
      props.pageViewCard === "listing" ? "nowrap" : "normal"};
    overflow: hidden;
    text-overflow: ellipsis;
    margin-right: 1rem;
  }
  ${Secondary} {
    font-size: ${props => props.theme.fontSize[100]};
    color: #2a2c34 !important;
  }
  ${CardTitle} {
    ${props => props.theme.media.desktop} {
      padding: ${props => props.paidPremium && "0.5rem 0rem"};
    }
    padding: ${props => props.paidPremium && "0.5rem 0.5rem"};
  }
  ${CardBody} {
    padding: ${props => (props.paidPremium ? "0" : "0.3rem 0rem")};
    display: flex;
    ${props => props.theme.media.mobile} {
      flex-direction: column;
    }
    flex-direction: ${props =>
      props.pageViewCard === "detail" && props.paidPremium ? "row" : "column"};
  }
  ${props => props.theme.media.desktop} {
    ${Headline} {
      flex-direction: ${props => (props.paidPremium ? "row" : "column")};
    }
  }
`;
const PremiumLabel = styled("div")`
  border-radius: 3px;
  background: ${props => props.theme.colors.white};
  height: 2rem;
  width: 2rem;
  margin-left: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0px 10px rgba(0, 0, 0, 0.1), 0 23px 24px rgba(0, 0, 0, 0.02);
`;
const Spacer = styled("div")`
  height: 2rem;
  width: 2rem;
  margin-left: 1rem;
`;
const PremiumIcon = styled("div")`
  font-size: ${props => props.theme.fontSize[100]};
  color: #2a2c34 !important;
  display: flex;
  align-items: center;
  line-height: 1.5;
  margin: 0 1rem;
  ${StyledLink} {
    color: #2a2c34;
  }
  ${props => props.theme.media.desktop} {
    width: 100%;
  }
`;
const BrandTagPremiumContainer = styled("div")`
  display: none;
  ${props => props.theme.media.desktop} {
    display: flex;
    position: absolute;
    font-weight: ${props => props.theme.fontWeight.medium};
    font-size: ${props => props.theme.fontSize[100]};
    top: -1.5rem;
  }
`;
const BrandTagPremium = styled("div")<{ background: string; color: string }>`
  display: block;
  background: ${props => props.background};
  color: ${props => props.color};
  padding: 0.25rem 1rem;
`;
const MobilePremiumTagContainer = styled("div")`
  position: absolute;
  top: 7px;
  right: 5px;
  display: flex;
  flex-direction: column;
  font-size: 12px;
  font-weight: ${props => props.theme.fontWeight.medium};
  ${props => props.theme.media.desktop} {
    display: none;
  }
`;
const MobilePremiumTag = styled(Chips)<{ color: string }>`
  margin: 0.25rem 0;
  color: ${props => props.color};
  font-size: 12px;
  font-weight: ${props => props.theme.fontWeight.medium};
  background: ${props => props.theme.colors.white};
`;
const SocialIcons = styled("div")<ProfileCardProps>`
  margin: 0;
  padding: ${props => (props.paidPremium ? "0.5rem 0.9rem;" : "0.3rem 0.9rem")};
  p {
    ${props => props.theme.media.desktop} {
      text-align: ${props => props.paidPremium && "center"};
    }
    margin: 0px;
  }
`;

const IconsDiv = styled("div")`
  display: grid;
  grid-template-columns: auto 3rem;
  margin-left: 0.4rem;
`;

const renderAttribute = (attr: any) => {
  if (attr.values.length) {
    return (
      <ListItem key={attr.id}>
        <ListName>{attr.name} :</ListName> {attr.values.join(", ")}
      </ListItem>
    );
  }
};
const renderBudget = (budget: any) => {
  if (budget.values) {
    return (
      <ListItem key={budget.id}>
        <ListName>{budget.name} :</ListName> {budget.values[0]}
      </ListItem>
    );
  }
};
export const commaSeperator = (
  data: string | undefined,
  { prefix = "", suffix = "", comma = true }: any
) => {
  return !!data ? `${prefix}${data}${suffix}` + (comma ? "," : "") : "";
};
export const makeAddress = (
  branchAddress: BranchValueType | undefined,
  location: string
) => {
  if (!!!branchAddress) {
    return location;
  }
  return `
    ${commaSeperator(branchAddress.buildingName, {})}
    ${commaSeperator(branchAddress.flat, {} /*, { prefix: "No. " }*/)}
    ${commaSeperator(branchAddress.floor, {} /*, { suffix: " floor" }*/)} 
    ${commaSeperator(branchAddress.address, {})} 
    ${commaSeperator(branchAddress.streetName, {})} 
    ${commaSeperator(branchAddress.locality, {})} 
    ${commaSeperator(location, {})} 
    ${commaSeperator(branchAddress.pincode, { comma: false })}
  `;
};

const renderVerifiedBadge = (props: ProfileCardProps) => {
  const crisil = props.badges.find(badge =>
    (badge.id || "").includes("crisilBadge")
  );
  const verified = props.badges.some(badge => badge.name === "Verified");

  if (!!crisil) {
    return (
      <PremiumIcon>
        <SiteIcon
          name={"Crisil"}
          // name={`${crisil.name}-crisil`}
          style={{
            width: props.pageViewCard === "listing" ? "1.2rem" : "3rem",
            height: props.pageViewCard === "listing" ? "1.2rem" : "3rem",
            margin: "0.5rem 0.3rem 0.5rem 0rem",
            verticalAlign: "middle"
          }}
        />
        <span>CRISIL Verified</span>
        {/* : {crisil.name} */}
      </PremiumIcon>
    );
  }
  if (verified) {
    return (
      <PremiumIcon>
        <SiteIcon
          name={"verified-ribbon"}
          style={{
            width: "1rem",
            fill: "#3FAC3C",
            height: "1rem",
            margin: "0.5rem 0.3rem 0.5rem 0rem",
            verticalAlign: "middle"
          }}
        />
        <span>Third Party Verified</span>
      </PremiumIcon>
    );
  }
  return <React.Fragment />;
};

export const ProfileWithoutCard = React.memo((props: ProfileCardProps) => {
  const attributes = props.attributes
    .filter(attr => attr.forDistribution)
    .filter(attr => attr.slug !== "budget")
    .slice(0, 2)
    .sort((a, b) => (a.name > b.name ? -1 : 0));
  const budget = props.attributes.filter(attr => attr.slug === "budget");
  const profileYear: any = props.attributes.filter(
    attr => attr.slug === "established-inyear"
  );
  const socialData = props.attributes.filter(
    (each: any) => each.header === "social"
  );
  const branchAddress = props.branch && props.branch[0];
  const covidsafe = props.badges.some(
    (badge: Badges) => badge.name === "COVID-safe"
  );

  return (
    <CardStyles {...props}>
      {!props.paidPremium ? (
        <CardImage
          image={{ ...props.image, alt: props.name }}
          verified={props.badges.some(
            (badge: Badges) => badge.name === "Verified"
          )}
          covidsafe={covidsafe}
          pageViewCard={props.pageViewCard}
        />
      ) : (
        <MobilePremiumTagContainer>
          <MobilePremiumTag color="#d99214">
            <SiteIcon
              name={"premium-icon"}
              style={{
                fill: "#D99214",
                width: "12px",
                height: "14px",
                verticalAlign: "sub",
                paddingRight: "2px",
                margin: "0"
              }}
            />
            <span>Premium</span>
          </MobilePremiumTag>
          {covidsafe && (
            <MobilePremiumTag color="green">
              <SiteIcon
                name={"covidsafeimg"}
                style={{
                  fill: "green",
                  width: "12px",
                  height: "14px",
                  verticalAlign: "sub",
                  paddingRight: "2px",
                  margin: "0"
                }}
              />
              <span>COVID-safe</span>
            </MobilePremiumTag>
          )}
        </MobilePremiumTagContainer>
      )}
      <CardContent
        paidPremium={props.paidPremium || false}
        detailCard={props.pageViewCard === "detail" || false}
      >
        <CardTitle>
          <Headline as={props.pageViewCard === "listing" ? "h2" : "h1"}>
            {props.name}
            <StarRatings rating={props.rating} />
            {!props.paidPremium && (
              <Secondary as={"div"}>
                <SiteIcon
                  name={"location-on"}
                  style={{
                    width: "13px",
                    fill: "#E94057",
                    height: "13px",
                    verticalAlign: "middle",
                    paddingRight: "1px",
                    margin: "0px 3px 0px 0px"
                  }}
                />
                <span>{makeAddress(branchAddress, props.location)}</span>
              </Secondary>
            )}
          </Headline>

          {props.badges.some((badge: Badges) => badge.name === "Premium") ? (
            !props.paidPremium && (
              <PremiumLabel>
                <SiteIcon
                  name={"premium-icon"}
                  style={{
                    width: "0.9rem",
                    height: "0.9rem",
                    fill: "rgb(250, 178, 41)"
                  }}
                />
              </PremiumLabel>
            )
          ) : (
            <Spacer />
          )}
        </CardTitle>
        {props.paidPremium ? (
          <CardBody>
            <PremiumIcon>
              <SiteIcon
                name={"location-on"}
                style={{
                  width: "18px",
                  fill: "#E94057",
                  height: "18px",
                  margin: "0.5rem 0.3rem 0.5rem 0rem",
                  verticalAlign: "middle"
                }}
              />
              <span>
                {props.branch && props.branch.length > 1
                  ? `${props.branch.length} Locations Across ${props.location}`
                  : makeAddress(branchAddress, props.location)}
              </span>
            </PremiumIcon>
            {profileYear.length > 0 && (
              <PremiumIcon>
                <SiteIcon
                  name={"calender-icon"}
                  style={{
                    width: "18px",
                    fill: "#E94057",
                    height: "15px",
                    marginRight: "0.8rem",
                    verticalAlign: "middle"
                  }}
                />
                <span>Since {profileYear[0].values[0]} </span>
              </PremiumIcon>
            )}
            {renderVerifiedBadge(props)}

            <BrandTagPremiumContainer>
              <BrandTagPremium background="#fffae8" color="#d99214">
                <SiteIcon
                  name={"premium-icon"}
                  style={{
                    width: "0.9rem",
                    height: "0.9rem",
                    fill: "#D99214",
                    margin: "0 0.5rem 0 0"
                  }}
                />
                Premium
              </BrandTagPremium>
              {covidsafe && (
                <BrandTagPremium background="lightgreen" color="green">
                  <SiteIcon
                    name={"covidsafeimg"}
                    style={{
                      width: "0.9rem",
                      height: "0.9rem",
                      fill: "green",
                      margin: "0 0.5rem 0 0"
                    }}
                  />
                  COVID-Safe
                </BrandTagPremium>
              )}
            </BrandTagPremiumContainer>
          </CardBody>
        ) : (
          <CardBody>
            {attributes.length > 0 ? (
              attributes.map(renderAttribute)
            ) : (
              <React.Fragment />
            )}
            {budget.length > 0 ? budget.map(renderBudget) : <React.Fragment />}
            {renderVerifiedBadge(props)}
          </CardBody>
        )}
        {props.pageViewCard === "detail" && (
          <SocialIcons {...props}>
            <p>
              {socialData.map((data: any) => (
                <a key={data.name} href={data.values[0]} target="_blank">
                  <SiteIcon
                    name={`social-${data.name}`}
                    style={{
                      width: "1.7rem",
                      height: "1.7rem",
                      margin: "0 0.2rem 0 0"
                    }}
                  />
                </a>
              ))}
            </p>
          </SocialIcons>
        )}
        {props.desktopCTA}
        {props.mobileCTA}
      </CardContent>
    </CardStyles>
  );
});

export const ProfileCard = React.memo(
  ({ preventLink = false, ...props }: ProfileCardProps) => {
    const url = `https://weddingbazaar.com${props.slug}`;

    return (
      <Card>
        {preventLink ? (
          <ProfileWithoutCard {...props} />
        ) : (
          <StyledLink to={props.slug || "#"} target="_blank">
            <ProfileWithoutCard {...props} />
          </StyledLink>
        )}
        {/* <IconsDiv>
          {!preventLink && (
            <ShareSocialIcons
              url={url}
              subject={`${props.name} is one of the best service providers in my city! Check out their profile page here : ${url}`}
              description={`To request a quote from ${props.name}, head over to ${url}.
        WeddingBazaar's handpicked service providers help you plan your dream wedding without any hassles!`}
              platforms={{
                facebook: true,
                twitter: true,
                whatsapp: true,
                email: true
              }}
            />
          )}
        </IconsDiv> */}
      </Card>
    );
  }
);
