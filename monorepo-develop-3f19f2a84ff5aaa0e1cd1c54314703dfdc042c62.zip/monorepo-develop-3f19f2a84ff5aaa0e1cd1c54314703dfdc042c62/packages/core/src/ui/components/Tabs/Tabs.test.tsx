import * as React from "react";
import { cleanup, fireEvent, render } from "../../../utils/test-utils";
import { Tabs, TabsProps } from "./Tabs";

afterEach(cleanup);

const propT: TabsProps = {
  children: [
    {
      title: "test1",
      icon: <span id={"span1"}> * </span>,
      child: <div id={"ct1"}> Content1 </div>
    },
    {
      title: "test2",
      icon: <span id={"span2"}> * </span>,
      child: <div id={"ct2"}> Content2 </div>
    },
    { title: "test3", icon: <span> * </span>, child: <div> Content3 </div> },
    { title: "test4", icon: <span> * </span>, child: <div> Content4 </div> },
    { title: "test5", icon: <span> * </span>, child: <div> Content5 </div> },
    { title: "test6", icon: <span> * </span>, child: <div> Content6 </div> },
    { title: "test7", icon: <span> * </span>, child: <div> Content7 </div> },
    { title: "test8", icon: <span> * </span>, child: <div> Content8 </div> },
    { title: "test9", icon: <span> * </span>, child: <div> Content9 </div> },
    { title: "test10", icon: <span> * </span>, child: <div> Content10 </div> }
  ]
};

describe("Tabs:", () => {
  it("renders correctly", () => {
    const { container } = render(<Tabs {...propT} />);
    expect(container).toMatchSnapshot();
  });

  // clicking on tab
  it("when tab clicked", () => {
    const { getByText, container } = render(<Tabs {...propT} />);

    const childContentdiv1 = container.querySelector("#ct1");
    const childContentdiv2 = container.querySelector("#ct2");

    const spanContent1 = container.querySelector("#span1");
    const spanContent2 = container.querySelector("#span2");
    expect(childContentdiv1 && childContentdiv1.parentNode).toHaveStyle(
      `display: block`
    );
    expect(childContentdiv2 && childContentdiv2.parentNode).toHaveStyle(
      `display: none`
    );
    fireEvent.click(getByText("test2"));
    expect(childContentdiv2 && childContentdiv2.parentNode).toHaveStyle(
      `display: block`
    );
    expect(childContentdiv1 && childContentdiv1.parentNode).toHaveStyle(
      `display: none`
    );
  });

  // clicking on arrow
  // it("when left caret is clicked", () => {
  //   const { getByTestId, container } = render(<Tabs {...propT} />);
  //   const leftCaret = getByTestId("left-caret");
  //   const rightCaret = getByTestId("right-caret");
  //   expect(leftCaret.children).toHaveLength(0);
  //   fireEvent.click(rightCaret);
  //   expect(leftCaret.children).toHaveLength(1);
  // });
});
