import debounce from "lodash/debounce";
import * as React from "react";
import { NavLink, Route, Switch } from "react-router-dom";
import styled from "styled-components";
import { slugify } from "../../../utils/slugify";
import { SiteIcon } from "../../components/Icon/Icon";
import { Show } from "../Collapsable/Collapsable";

export interface TabsProps {
  children: Array<ChildTabProps | undefined>;
  basePath?: string;
}

interface ChildTabProps {
  title: string;
  icon: JSX.Element;
  child: JSX.Element;
  slug?: string;
}

const ComponentSlider = styled("div")`
  background: ${props => props.theme.colors.white};
  font-weight: ${props => props.theme.fontWeight.medium};
  color: #363636;
  overflow: auto;
  white-space: nowrap;

  ${props => props.theme.media.mobile} {
    margin-top: 0.5rem;
    max-width: 96vw;
  }

  ${props => props.theme.media.desktop} {
    width: 100%;
    position: relative;
    width: 100%;
    overflow: hidden;
  }
`;

const ContainerSlide = styled("div")`
  ${props => props.theme.media.desktop} {
    margin: 0 20px;
    overflow: hidden;
  }
`;

const SliderContainer = styled("div")<{ mLeft: any }>`
  margin-left: -${props => props.mLeft}px;
  display: inline-block;
  transition: margin-left 0.15s ease-in;
`;

const HeaderTab = styled("p")<{ active: boolean }>`
  display: inline-block;
  margin: 0 1rem 0 0;
  padding: 10px;
  cursor: pointer;
  border-bottom: ${props =>
    props.active ? `3px solid ${props.theme.colors.primary}` : "0px"}
  text-align: center;
  font-size: ${props => props.theme.fontSize[150]};
  text-decoration: none;
  color: inherit;
`;

const NavHeaderTab = styled(NavLink)`
  display: inline-block;
  margin: 0 1rem 0 0;
  padding: 10px;
  text-align: center;
  font-size: ${props => props.theme.fontSize[150]};
  border-bottom: 0px;
  text-decoration: none;
  color: inherit;

  &.active {
    border-bottom: 3px solid ${props => props.theme.colors.primary};
  }
`;

const ChildContentDiv = styled("div")``;

const Caret = styled("div")<{ direction: "left" | "right" }>`
  ${props => props.theme.media.mobile} {
    display: none;
  }
  width: 20px;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  padding: 0;
  margin: 0;
  background: none;
  border: none;
  cursor: pointer;
  text-align: center;
  font-size: 20px;
  color: #797979;

  ${props => props.direction === "left" && `left: 0;`}

  ${props => props.direction === "right" && `right: 0`}
`;

const leftArrow = () => (
  <SiteIcon
    name={"chevron-left"}
    style={{
      width: "1rem",
      height: "1rem",
      verticalAlign: "middle"
    }}
  />
);

const rightArrow = () => (
  <SiteIcon
    name={"chevron-right"}
    style={{
      width: "1rem",
      height: "1rem",
      verticalAlign: "middle"
    }}
  />
);

const UnstyledTabs = React.memo(({ children, basePath }: TabsProps) => {
  const [tabIndex, setTabIndex] = React.useState(0);

  const [marginLeft, setMarginLeft] = React.useState(0);
  const [sliderW, setSliderW] = React.useState({ slider: 0, content: 0 });

  const [sWidth, setSWidth] = React.useState(0);
  const [sCWidth, setSCWidth] = React.useState(0);
  const sliderRef = React.useRef<HTMLDivElement>(null);
  const sliderContentRef = React.useRef<HTMLDivElement>(null);

  const handleResize: () => any = React.useMemo(
    () => debounce(() => setMarginLeft(0), 200),
    []
  );

  const [tabPosition, setTabPosition] = React.useState(0);

  const scrollPosition = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!!window) {
      window.addEventListener("resize", handleResize());
    }
    if (sliderRef && sliderRef.current) {
      setSWidth(sliderRef!.current!.offsetWidth);
    }

    if (sliderContentRef && sliderContentRef.current) {
      setSCWidth(sliderContentRef!.current!.offsetWidth);
    }
    if (scrollPosition && scrollPosition.current) {
      setTabPosition(scrollPosition!.current!.offsetTop);
    }

    return () => window.removeEventListener("resize", handleResize());
  }, []);

  if (window && window.location && window.location.hash === "#tab") {
    const _ =
      window &&
      window.scrollTo({
        top: tabPosition - 125,
        behavior: "smooth"
      });
  }

  const handleLeftClicked = () => {
    if (marginLeft > sWidth) {
      setMarginLeft(currentMarginLeft => currentMarginLeft - sWidth);
    }
    setMarginLeft(0);
  };

  const remainingWidth = sCWidth - (sWidth - 20) - marginLeft;
  const handleRightClicked = () => {
    if (remainingWidth > 0) {
      if (remainingWidth <= sWidth) {
        setMarginLeft(currentMarginLeft => currentMarginLeft + remainingWidth);
      } else {
        setMarginLeft(currentMarginLeft => currentMarginLeft + sWidth);
      }
    }
  };

  const renderRight = () => {
    return (
      <Caret
        data-testid={"right-caret"}
        onClick={handleRightClicked}
        direction={"right"}
      >
        {remainingWidth > 0 && rightArrow()}
      </Caret>
    );
  };

  return (
    <div ref={scrollPosition}>
      <ComponentSlider ref={sliderRef}>
        <Caret
          data-testid={"left-caret"}
          onClick={handleLeftClicked}
          direction={"left"}
        >
          {marginLeft !== 0 && leftArrow()}
        </Caret>
        <ContainerSlide>
          <SliderContainer ref={sliderContentRef} mLeft={marginLeft}>
            {children
              .filter((child: any) => typeof child !== "undefined")
              .map((child: any, index: number) => {
                if (!!basePath) {
                  const path = `${basePath}${
                    !!child.slug
                      ? child.slug === "/"
                        ? ""
                        : child.slug
                      : "/" + slugify(child.title)
                  }`;
                  return (
                    <NavHeaderTab
                      key={index}
                      isActive={(_, location) => path === location.pathname}
                      to={!!child.slug ? path : `${path}#tab`}
                    >
                      {child.icon} {child.title}
                    </NavHeaderTab>
                  );
                }
                return (
                  <HeaderTab
                    active={tabIndex === index}
                    key={index}
                    onClick={() => setTabIndex(index)}
                  >
                    {child.icon} {child.title}
                  </HeaderTab>
                );
              })}
          </SliderContainer>
        </ContainerSlide>
        {renderRight()}
      </ComponentSlider>

      {!!basePath ? (
        <Switch>
          {children
            .filter((child: any) => typeof child !== "undefined")
            .map((child: any, index: number) => (
              <Route
                path={`${basePath}${
                  !!child.slug ? child.slug : "/" + slugify(child.title)
                }`}
                exact={true}
                key={child.title}
                render={props => {
                  return child.child;
                }}
              />
            ))}
        </Switch>
      ) : (
        <ChildContentDiv>
          {/* {children[tabIndex] && children[tabIndex]["child"]} */}
          {children
            .filter((child: any) => typeof child !== "undefined")
            .map((child: any, index: number) => (
              <Show key={index} open={index === tabIndex}>
                {child.child}
              </Show>
            ))}
        </ChildContentDiv>
      )}
    </div>
  );
});

export const Tabs = styled(UnstyledTabs)``;
