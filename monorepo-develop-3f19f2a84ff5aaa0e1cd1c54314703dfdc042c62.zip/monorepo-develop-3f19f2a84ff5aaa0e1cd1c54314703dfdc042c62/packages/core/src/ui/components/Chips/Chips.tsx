import * as React from "react";
import styled from "styled-components";

export interface ChipsProps {
  children: any;
  onClick?: (props: any) => void;
}

const ChipsContainer = styled("div")<ChipsProps>`
  border-radius: 25px;
  padding: 3px 8px;
  box-shadow: 0px 0px 6px #00000029;
`;

export const Chips: React.FC<ChipsProps> = React.memo(props => {
  return (
    <ChipsContainer {...props}>
      {/* {props.icon && props.icon} {props.content} */}
      {props.children}
    </ChipsContainer>
  );
});
