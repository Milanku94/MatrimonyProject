import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { Chips, ChipsProps } from "./Chips";

afterEach(cleanup);

const props: ChipsProps = {
  children: <span> test </span>
};

describe("Chips:", () => {
  it("renders correctly", () => {
    const { container } = render(<Chips {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
