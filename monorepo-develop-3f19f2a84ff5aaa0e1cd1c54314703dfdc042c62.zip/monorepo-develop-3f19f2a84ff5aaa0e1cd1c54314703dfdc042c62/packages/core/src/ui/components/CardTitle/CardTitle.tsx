import styled from "styled-components";

interface CardTitleProps {}

export const CardTitle = styled("div")<CardTitleProps>`
  display: flex;
  grid-area: card-title;
  justify-content: space-between;
  padding: 0.5rem 0.9rem;
  /*align-items: center;*/
  background: ${props => props.theme.colors.white};
  border-radius: inherit;
`;
