import React, { useState } from "react";
import styled from "styled-components";

export interface CardDescriptionProps {
  description: string;
  maxLength?: number;
  fixedText?: boolean;
}
const Container = styled.div`
  font-size: 14px;
  text-align: justify;
  margin-top: 10px;
  color: rgba(42, 44, 52, 1);
  position: relative;
`;
const SeeMoreSpan = styled("span")<{ fixedText: boolean }>`
  font-size: 14px;
  margin-top: 2px;
  color: ${props => props.theme.colors.primary};
  text-align: center;
  font-weight: ${props => props.theme.fontWeight.medium};
  cursor: pointer;
`;
export const SeeMoreText = ({
  description,
  maxLength = 200,
  fixedText
}: CardDescriptionProps) => {
  const [hidden, setHidden] = useState(true);
  if (!description) {
    return null;
  }

  if (description.length <= maxLength) {
    return <p>{description}</p>;
  }

  const span = hidden ? "See More" : "See Less";

  return (
    <p>
      {hidden ? description.substr(0, maxLength).trim() + "..." : description}
      <SeeMoreSpan
        onClick={() => setHidden(!hidden)}
        fixedText={fixedText || false}
      >
        {span}
      </SeeMoreSpan>
    </p>
  );
};

const UnStyledCardDescription = React.memo((props: CardDescriptionProps) => {
  const [count, setCount] = useState(0);
  return (
    <Container>
      <SeeMoreText
        description={props.description}
        maxLength={props.maxLength}
        fixedText={props.fixedText}
      />
    </Container>
  );
});
export const CardDescription = styled(UnStyledCardDescription)<
  CardDescriptionProps
>``;
