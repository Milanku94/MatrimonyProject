import * as React from "react";
import { cleanup, fireEvent, render } from "../../../utils/test-utils";
import { CardDescription, CardDescriptionProps } from "./CardDescription";

afterEach(cleanup);

const defaultProps: CardDescriptionProps = {
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  maxLength: 222
};
describe("CardDescription:", () => {
  it("renders correctly", () => {
    const { container } = render(<CardDescription {...defaultProps} />);
    expect(container.firstChild).toMatchSnapshot();
  });
  it("renders See More correctly", async () => {
    const { container, getByText } = render(
      <CardDescription {...defaultProps} />
    );

    expect(getByText("See More")).toBeTruthy();
  });

  it("renders See Less correctly", () => {
    const { container, getByText } = render(
      <CardDescription {...defaultProps} />
    );
    fireEvent.click(getByText("See More"));

    expect(getByText("See Less")).toBeTruthy();
  });
});
