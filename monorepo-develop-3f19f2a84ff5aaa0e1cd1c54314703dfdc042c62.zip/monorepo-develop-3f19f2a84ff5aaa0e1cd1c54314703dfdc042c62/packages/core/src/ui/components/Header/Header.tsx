import * as React from "react";
import { RouteComponentProps, withRouter } from "react-router-dom";
import styled from "styled-components";
import { Logo, SiteIcon, StyledLink, Text } from "../../";
import * as content from "../../../content";
import { Domains } from "../../../content/types";
import { DomainContext } from "../../../contexts/DomainContext";
import { LocationContext } from "../../../contexts/LocationContext";
import { UserContext } from "../../../contexts/UserContext";
import { BulletPoint } from "../../atoms";
import { TrackNavLink } from "../../atoms/Typography/Typography";
import { theme } from "../../theme";
interface HeaderProps {
  /** Does the header need to be stuck on top? */
  isSticky: boolean;
  showMenu: boolean;
  showSearch?: boolean;
  renderSearch?: ({ onHide }: { onHide: () => void }) => React.ReactNode;
}

const HeaderContainer = styled("nav")`
  width: 100%;
  position: fixed;
  z-index: 10;
  top: 0;
`;

export const CommonHeader = styled("div")`
  display: flex;
  min-height: 4rem;
  box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.16);
  background: ${props => props.theme.colors.white};
  width: 100%;
  align-items: center;
  justify-content: space-between;
  margin: 0 auto;
  ${props => props.theme.media.desktop} {
    padding: 0 10%;
    min-height: 4rem;
  }
`;

export const LeftHeader = styled("div")<HeaderProps>`
  display: flex;
  align-items: center;
  padding-left: ${props => !props.showMenu && "14px"}
    ${props => props.theme.media.desktop} {

  }
`;

const MobSiteIcon = styled(SiteIcon)``;
const DesktopSiteIcon = styled(SiteIcon)``;

export const RightHeader = styled.div`
  display: flex;
  ${props => props.theme.media.desktop} {
    ${MobSiteIcon} {
      display: none;
    }
    ${DesktopSiteIcon} {
      display: block;
    }
  }
  ${props => props.theme.media.mobile} {
    ${DesktopSiteIcon} {
      display: none;
    }
    ${MobSiteIcon} {
      display: block;
    }
  }
`;

export const HamMenu = styled.div`
  &:hover {
    cursor: pointer;
  }
  ${props => props.theme.media.desktop} {
    display: none;
  }
`;

const DesktopHeader = styled("div")`
  display: none;

  ${props => props.theme.media.desktop} {
    height: 2.4rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0px 1px 3px rgba(0, 0, 0, 0.16);
    background-color: ${props => props.theme.colors.primary};
    margin: 0 auto;
    padding: 0 10%;
  }
`;

interface HeaderMenuProps {
  close?: any;
}

const StyledHeaderMenu = styled("div")<HeaderMenuProps>`
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: 9;
  border-top: 1px solid #f7f6f6;
  background: rgba(0, 0, 0, 0.4);
`;

const MenuWrapper = styled("div")`
  padding: 0 1rem;
  background-color: ${props => props.theme.colors.white};
`;

const HeaderLink = styled(TrackNavLink)`
  cursor: pointer;
  text-decoration: none;
  color: black;
  height: 100%;
  display: flex;
  align-items: center;
  margin: 0 -1rem;
  padding: 1rem 1rem;

  &.active {
    background-color: rgba(233, 64, 87, 0.2);
  }

  ${props => props.theme.media.desktop} {
    color: white;
    padding: 0rem 1rem 0rem 1rem;
    margin: 0;
    font-size: ${props => props.theme.fontSize[150]};
    font-weight: ${props => props.theme.fontWeight.medium};
    &.active {
      background-color: rgba(0, 0, 0, 0.2);
    }
  }
`;

const LineBar = styled.div`
  width: 100%;
  border: 1px solid #f7f6f6;
  margin-top: 10px;
  margin-bottom: 10px;

  ${props => props.theme.media.desktop} {
    display: none;
  }
`;
const CatPopover = styled("div")`
  position: absolute;
  background: ${props => props.theme.colors.white};
  padding: 1rem;
  top: 3.3rem;
`;

const Label = styled.span``;

const HeaderPictureTag = styled("img")`
  padding-right: 1rem;
  ${props => props.theme.media.desktop} {
    display: none;
  }
`;
const RightNavDiv = styled("div")`
  margin-right: 0.5rem;
  padding-left: 0.5rem;
  display: flex;
  align-items: center;
  background-color: ${props => props.theme.colors.gray5};
  ${props => props.theme.media.mobile} {
    background-color: ${props => props.theme.colors.white};
    margin-right: inherit;
  }
`;
const LoginNav = styled(StyledLink)`
  display: flex;
  align-items: center;
  background-color: ${props => props.theme.colors.primary};
  ${props => props.theme.media.mobile} {
    background-color: ${props => props.theme.colors.white};
    margin-right: inherit;
  }
  ${props => props.theme.media.desktop} {
    margin-left: 0.5rem;
    padding: 0 0.5rem;
  }
`;
const RightNavLink = styled("a")`
  display: flex;
  align-items: center;
  background-color: ${props => props.theme.colors.primary};
  ${props => props.theme.media.mobile} {
    background-color: ${props => props.theme.colors.white};
  }
  padding: 0 0.5rem;
  color: initial;
  text-decoration: none;
  &:link {
    color: initial;
    text-decoration: none;
  }
  &:active {
    color: initial;
    text-decoration: none;
  }
  &:visited {
    color: initial;
    text-decoration: none;
  }
  &:hover {
    color: initial;
    text-decoration: none;
  }
`;
const DesktopLabel = styled(Text)`
  display: none;
  ${props => props.theme.media.desktop} {
    margin-right: 1rem;
    display: inline;
  }
`;
const DesktopLabelPhone = styled(Text)`
  display: none;
  color: ${props => props.theme.colors.white};
  ${props => props.theme.media.desktop} {
    display: inline;
  }
`;
const MobileLabelLogin = styled(Text)`
  display: none;
  cursor: pointer;
  display: flex;
  margin: 0 -1rem;
  padding: 1rem 1rem;
  color: ${props => props.theme.colors.black};
  ${props => props.theme.media.mobile} {
    text-decoration: none;
    display: inline;
  }
`;
interface GLoginProps extends RouteComponentProps {
  showMobile?: boolean;
}
const GLogin = React.memo(
  withRouter(({ showMobile, ...props }: GLoginProps) => {
    const { userId } = React.useContext(UserContext);
    const [stateLabel, setStateLabel] = React.useState(
      !userId ? "Login" : "Logout"
    );
    React.useEffect(() => {
      setStateLabel(!userId ? "Login" : "Logout");
    }, [userId]);
    return (
      <LoginNav
        target={userId ? undefined : "popup"}
        to={
          !userId
            ? ["/auth/google", props.location.pathname].join("?next=")
            : `/${props.location.pathname}`
        }
        onClick={() => {
          if (!userId) {
            window.open(
              props.location.pathname,
              "popup",
              "width=600,height=600, top=200, left=450"
            );
          } else {
            document.cookie = `userID=; max-age=1; path=/;`;
          }
        }}
      >
        <DesktopLabelPhone>{stateLabel}</DesktopLabelPhone>
        {showMobile && <MobileLabelLogin>{stateLabel}</MobileLabelLogin>}
      </LoginNav>
    );
  })
);

const HeaderLinks: React.FC<any> = React.memo(props => {
  const { city: autoDetectedCity } = React.useContext(LocationContext);
  const { domain } = React.useContext(DomainContext);

  const renderedLinks = content[domain].links
    .filter(link => (typeof link.header === "boolean" ? link.header : true))
    .map((link, id) => {
      if (link.type === "separator") {
        return <LineBar key={id} />;
      }
      return (
        <HeaderLink
          key={id}
          to={link.label === "Services" ? `/${autoDetectedCity}` : link.to}
          target={link.external ? "_blank" : undefined}
          rel="noreferrer"
        >
          {link.picture && (
            <HeaderPictureTag src={link.picture} alt={link.label} />
          )}

          <Label>{link.label}</Label>
        </HeaderLink>
      );
    });
  return <React.Fragment>{renderedLinks}</React.Fragment>;
});
// TODO: change city in MenuRow
const HeaderMenu = React.memo((props: HeaderMenuProps) => {
  const { domain } = React.useContext(DomainContext);
  const { userName } = React.useContext(UserContext);

  return (
    <StyledHeaderMenu onClick={props.close}>
      <MenuWrapper>
        <HeaderLinks />
        {domain === Domains.writer && (
          <HeaderLink key="auth" to={userName ? "/logout" : "/login"}>
            {" "}
            <Label>{userName ? "Logout" : "Login"}</Label>
          </HeaderLink>
        )}
        {/* <GLogin showMobile={true} /> */}
      </MenuWrapper>
    </StyledHeaderMenu>
  );
});

export const Header = React.memo((props: HeaderProps) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [search, setSearch] = React.useState(false);
  const { domain } = React.useContext(DomainContext);
  const { userName } = React.useContext(UserContext);
  const [user, setUser]: any = React.useState(userName);

  React.useEffect(() => {
    setUser(userName);
  }, [userName]);
  const handleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <HeaderContainer>
      <CommonHeader>
        <LeftHeader {...props}>
          {props.showMenu && (
            <HamMenu onClick={handleMenu}>
              {isOpen ? (
                <SiteIcon name={"close"} />
              ) : (
                <SiteIcon name={"menu"} />
              )}
            </HamMenu>
          )}
          {props.showMenu ? (
            <StyledLink to="/">
              <Logo size="small" />
            </StyledLink>
          ) : (
            <Logo size="small" />
          )}
        </LeftHeader>

        <RightHeader>
          {props.showSearch && (
            <React.Fragment>
              <RightNavDiv
                onClick={() => setSearch(true)}
                id="header-search-icon"
                aria-label="search"
              >
                <DesktopLabel fontSize={150} fontWeight="medium" color="gray1">
                  Search
                </DesktopLabel>
                <DesktopSiteIcon
                  name={"search"}
                  style={{
                    fill: theme.colors.white,
                    background: theme.colors.primary,
                    margin: "0",
                    height: "2rem",
                    width: "2rem",
                    padding: ".5rem"
                  }}
                />
                <MobSiteIcon
                  name={"search"}
                  style={{
                    height: "1.3rem",
                    width: "1.3rem",
                    margin: "0",
                    padding: ".5rem"
                  }}
                />
              </RightNavDiv>
              <RightNavLink
                href={`tel:+91${content[domain].phoneNumber}`}
                id="header-call"
                aria-label="call us"
              >
                <DesktopSiteIcon
                  name={"phone-1"}
                  style={{
                    fill: theme.colors.white,
                    background: theme.colors.primary,
                    margin: "0",
                    height: "2rem",
                    width: "2rem",
                    padding: ".5rem"
                  }}
                />
                {/* <SiteIcon
                  name={"phone-1"}
                  style={{ fill: theme.colors.white }}
                /> */}
                <MobSiteIcon
                  name={"phone-1"}
                  style={{
                    fill: theme.colors.primary,
                    height: "1.3rem",
                    width: "1.3rem",
                    margin: "0",
                    padding: ".5rem"
                  }}
                />
                <DesktopLabelPhone>
                  +91-{content[domain].phoneNumber}
                </DesktopLabelPhone>
              </RightNavLink>
              {/* {domain === Domains.mBazaar && <GLogin />} */}
              {domain === Domains.writer && (
                <BulletPoint
                  margin="0 major-1"
                  style={{ height: "2rem", minWidth: "2rem" }}
                >
                  {user ? (
                    user[0].toUpperCase()
                  ) : (
                    <SiteIcon
                      name={"user"}
                      style={{
                        height: "1.3rem",
                        width: "1.3rem",
                        verticalAlign: "sub",
                        fill: "#ffffff"
                      }}
                    />
                  )}
                </BulletPoint>
              )}
            </React.Fragment>
          )}
        </RightHeader>
      </CommonHeader>
      {props.showMenu && (
        <DesktopHeader>
          <HeaderLinks />
          {domain === Domains.writer && (
            <HeaderLink key="auth" to={userName ? "/logout" : "/login"}>
              {" "}
              <Label>{userName ? "Logout" : "Login"}</Label>
            </HeaderLink>
          )}
        </DesktopHeader>
      )}
      {isOpen && <HeaderMenu close={handleMenu} />}
      {props.renderSearch &&
        search &&
        props.renderSearch({ onHide: () => setSearch(false) })}
    </HeaderContainer>
  );
});
