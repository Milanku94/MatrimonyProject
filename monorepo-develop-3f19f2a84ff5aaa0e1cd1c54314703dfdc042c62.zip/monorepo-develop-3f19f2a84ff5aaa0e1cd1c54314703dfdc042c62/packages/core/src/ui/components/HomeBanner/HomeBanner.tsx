import * as React from "react";
import styled from "styled-components";
import { H1, Paragraph } from "../../";
import {
  backgroundImage,
  ResponsiveImage
} from "../../atoms/PictureTag/PictureTag";

interface HomeBannerProps {
  backgroundImage?: ResponsiveImage;
  bannerTitle?: string;
  bannerContent?: string;
  bannerLogo?: string;
  bannerLogoNeed?: boolean;
  plainImage?: boolean;
  heightSize?: string;
  isWrap?: boolean;
  semPageStyle?: boolean;
  semPageStyleWa?: boolean;
  style?: React.CSSProperties;
}

const HomeBannerDiv = styled("div")<HomeBannerProps>`
  grid-area: banner;
  ${props => props.backgroundImage && backgroundImage(props.backgroundImage)}
  height: ${props =>
    props.plainImage ? props.heightSize : "calc(90vh - 4rem)"};
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  font-family: 'Quicksand', sans-serif;
  ${props => props.theme.media.desktop} {
    height: ${props =>
      props.plainImage ? props.heightSize : "calc(90vh - 2rem)"};
    background-position: ${props => (props.plainImage ? "top" : "center")};
    margin-left: ${props => props.isWrap && "-12.5%"};
    margin-right: ${props => props.isWrap && "-12.5%"};
  }
`;

const GradientBGDiv = styled("div")<HomeBannerProps>`
  display: flex;
  align-items: center;
  height: ${props =>
    props.plainImage ? props.heightSize : "calc(90vh - 4rem)"};
  background: ${props =>
    props.plainImage ? "" : `${props.theme.colors.black}61`};
  ${props => props.theme.media.desktop} {
    height: ${props => (props.plainImage ? "75vh" : "calc(90vh - 2rem)")};
  }
`;

const BannerTitleDiv = styled("div")<HomeBannerProps>`
  width: 285px;
  margin: 0px auto;
  ${props => props.theme.media.desktop} {
    width: 70vw;
    margin-bottom: ${props => props.semPageStyle && "0.7rem"};
  }
`;
const BannerSubTitleDiv = styled("div")`
  font-weight: ${props => props.theme.fontWeight.medium};
  width: 254px;
  padding: 0 0 1rem;
  font-size: 15px;
  text-align: center;
  color: rgba(255, 255, 255, 1);
  margin: 0px auto;
  ${props => props.theme.media.desktop} {
    width: 60vw;
    line-height: 1.5rem;
  }
`;

const SearchBtnBoxDiv = styled("div")`
  margin-top: 8px;
`;
const BannerCont = styled("div")<HomeBannerProps>`
  width: 100%;
  bottom: 2rem;
  ${props => props.theme.media.desktop} {
    bottom: ${props => (props.semPageStyle ? "9rem" : "0rem")};
  }
`;

const LogoImg = styled("img")`
  width: 244px;
  display: block;
  margin: 0 auto;
  padding-bottom: 1rem;
`;
export const HomeBannerWrapper = styled("div")`
  ${props => props.theme.media.desktop} {
    margin-left: -12.5%;
    margin-right: -12.5%;
  }
`;
export const UnstyledHomeBanner: React.FC<HomeBannerProps> = React.memo(
  props => {
    return (
      <HomeBannerDiv
        isWrap={props.isWrap}
        backgroundImage={props.backgroundImage}
        plainImage={props.plainImage}
        heightSize={props.heightSize}
        {...props}
      >
        <GradientBGDiv
          plainImage={props.plainImage}
          heightSize={props.heightSize}
        >
          <BannerCont semPageStyle={props.semPageStyle}>
            {props.bannerTitle && (
              <BannerTitleDiv semPageStyle={props.semPageStyle}>
                {props.bannerLogoNeed && (
                  <LogoImg src={props.bannerLogo} alt="logo" />
                )}
                <H1
                  fontSize={300}
                  margin="major-2"
                  color="white"
                  textAlign="center"
                >
                  {props.bannerTitle}
                </H1>
              </BannerTitleDiv>
            )}
            {props.bannerContent && (
              <BannerSubTitleDiv>
                <Paragraph fontSize={150} color={"white"}>
                  {props.bannerContent}
                </Paragraph>
              </BannerSubTitleDiv>
            )}
            {props.children}
          </BannerCont>
        </GradientBGDiv>
      </HomeBannerDiv>
    );
  }
);

export const HomeBanner = styled(UnstyledHomeBanner)``;
