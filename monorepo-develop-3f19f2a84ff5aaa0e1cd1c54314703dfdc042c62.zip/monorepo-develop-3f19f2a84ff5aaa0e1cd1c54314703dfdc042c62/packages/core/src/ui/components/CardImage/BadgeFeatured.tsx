import React from "react";
import styled from "styled-components";

export const BadgeBlock = styled("div")`
  padding: 0.25rem 0px 0.25rem;
  font-weight: ${props => props.theme.fontWeight.regular}
  font-size: ${props => props.theme.fontSize[100]};
  width: 5rem;
  text-align: center;
  color: white;
  letter-spacing: 1px;
  text-transform: uppercase;
  position: absolute;
  line-height: 1.5rem;
`;

const FeaturedBadge = styled(BadgeBlock)`
  background-color: #0099ff;
  //border-top-right-radius: inherit;
  top: 0;
  right: 0;
`;

export const Featured = React.memo(() => {
  return (
    <React.Fragment>
      <FeaturedBadge>Featured</FeaturedBadge>
    </React.Fragment>
  );
});
