import React from "react";
import styled from "styled-components";
import { Chips } from "../Chips/Chips";
import { SiteIcon } from "../Icon/Icon";
import { CardImageProps } from "./CardImage";

const VerfiedTagDiv = styled("div")<CardImageProps>`
  ${props => props.theme.media.mobile} {
    position: absolute;
    top: 7px;
    left: 5px;
    color: ${props => props.theme.colors.white};
    font-size: 12px;
    font-weight: ${props => props.theme.fontWeight.medium};
  }

  ${props =>
    props.theme.media.desktop &&
    !props.pageViewCard &&
    `
  /*transform: rotate(90deg);
  position: absolute;
  top: -5px;
  right: 15px;*/
  `};
`;
const VerifiedTag = styled(Chips)`
  background-color: ${props => props.theme.colors.accent1};
  ${props => props.theme.media.desktop} {
    position: absolute;
    top: 7px;
    left: 7px;
    color: ${props => props.theme.colors.white};
    font-size: 12px;
    font-weight: ${props => props.theme.fontWeight.semiBold};
  }
`;

export const Verified = React.memo((props: CardImageProps) => {
  return (
    <VerfiedTagDiv {...props}>
      <VerifiedTag>
        <SiteIcon
          name={"verified-tick"}
          style={{
            margin: "0",
            width: "12px",
            height: "15px",
            verticalAlign: "sub",
            fill: "#FFF",
            paddingRight: "0px"
          }}
        />
        <span>Verified</span>
      </VerifiedTag>
    </VerfiedTagDiv>
  );
});
