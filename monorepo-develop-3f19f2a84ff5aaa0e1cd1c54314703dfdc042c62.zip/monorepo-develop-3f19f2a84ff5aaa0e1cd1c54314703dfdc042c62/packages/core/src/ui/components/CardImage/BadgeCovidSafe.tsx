import React from "react";
import styled from "styled-components";
import { SiteIcon } from "../Icon/Icon";

const CovidTagDiv = styled("div")`
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  right: 0;
  padding: 0.25rem;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  background: rgb(0, 0, 0);
  background: linear-gradient(
    45deg,
    rgba(0, 0, 0, 0) 0%,
    rgba(0, 0, 0, 0.1) 80%,
    rgba(0, 0, 0, 1) 100%
  );
  div {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  p {
    font-size: 11px;
    white-space: nowrap;
    color: #ffffff;
    margin: 0.25rem 0 0 0;
  }
`;

export const CovidSafe = React.memo(() => {
  return (
    <CovidTagDiv>
      <div>
        <SiteIcon
          name={"covidsafeimg"}
          style={{
            height: "1rem",
            width: "1rem",
            margin: "0",
            fill: "#ffffff"
          }}
        />
        <p>COVID-Safe</p>
      </div>
    </CovidTagDiv>
  );
});
