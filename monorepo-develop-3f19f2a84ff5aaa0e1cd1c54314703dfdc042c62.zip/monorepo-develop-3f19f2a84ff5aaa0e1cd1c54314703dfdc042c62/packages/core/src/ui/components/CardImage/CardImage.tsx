import React from "react";
import styled from "styled-components";
import { PictureTag } from "../../";
import { Media } from "../../types";
import { CovidSafe } from "./BadgeCovidSafe";
import { Featured } from "./BadgeFeatured";
import { Verified } from "./BadgeVerified";

export interface CardImageProps {
  image: Media;
  verified?: boolean;
  curvedTop?: boolean;
  featured?: boolean;
  pageViewCard?: string;
  covidsafe?: boolean;
}

const StyledCardImage = styled("div")<CardImageProps>`
  position: relative;
  overflow: hidden;
  grid-area: card-image;
  // max-height: ${props =>
    props.pageViewCard === "detail" ? "16rem" : "inherit"}
    picture {
    display: block;
    height: inherit;
  }
  img {
    object-fit: cover;
    object-position: top;
    height: inherit;
  }
`;

export const CardImage = React.memo((props: CardImageProps) => {
  return (
    <StyledCardImage {...props}>
      {props.image && (
        <PictureTag image={props.image.url || ""} alt={props.image.alt} />
      )}
      {props.verified && <Verified {...props} />}
      {props.covidsafe && <CovidSafe />}
      {props.featured && <Featured />}
    </StyledCardImage>
  );
});
