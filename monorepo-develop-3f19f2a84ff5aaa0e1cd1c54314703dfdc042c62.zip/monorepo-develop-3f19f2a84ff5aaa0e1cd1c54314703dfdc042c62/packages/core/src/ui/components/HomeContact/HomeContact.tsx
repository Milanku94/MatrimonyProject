import * as React from "react";
import styled from "styled-components";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { SiteIcon } from "../../components/Icon/Icon";
interface HomeContactProps {}

const ContactHead = styled("a")`
  padding-top: 20px;
  text-align: center;
  background-color: rgba(255, 242, 233, 1);
  height: 175px;
  margin-top: 46px;
  display: block;
  text-decoration: none;
  ${props => props.theme.media.desktop} {
    display: none;
  }
`;

const ContactIcon = styled.div`
  background-color: ${props => props.theme.colors.primary};
  width: 42px;
  height: 42px;
  border-radius: 3px;
  margin: 5px auto;
  text-align: center;
`;
const ContactContent = styled.div`
  margin-top: 11px;
  color: ${props => props.theme.colors.primary};
  font-size: 17px;
  font-weight: ${props => props.theme.fontWeight.medium};
`;
const ContactAddress = styled.div`
  padding-top: 8px;
  width: 15rem;
  font-size: 14px;
  color: ${props => props.theme.colors.primary};
  margin: 0px auto;
  a {
    color: ${props => props.theme.colors.primary};
  }
  p {
    margin: 0;
  }
`;

const UnstyledHomeContact = React.memo(() => {
  const { domain } = React.useContext(DomainContext);
  return (
    <ContactHead href={`tel:+91${content[domain].phoneNumber}`}>
      <ContactIcon>
        <SiteIcon
          name={"phone-1"}
          style={{
            width: "1.125rem",
            height: "1.125rem",
            verticalAlign: "middle",
            fill: "#fff",
            paddingTop: "12px"
          }}
        />
      </ContactIcon>
      <ContactContent>Speak With Us</ContactContent>
      <ContactAddress>
        <p>You can call us on +91-{content[domain].phoneNumber}</p>
      </ContactAddress>
    </ContactHead>
  );
});

export const HomeContact = styled(UnstyledHomeContact)<HomeContactProps>``;
