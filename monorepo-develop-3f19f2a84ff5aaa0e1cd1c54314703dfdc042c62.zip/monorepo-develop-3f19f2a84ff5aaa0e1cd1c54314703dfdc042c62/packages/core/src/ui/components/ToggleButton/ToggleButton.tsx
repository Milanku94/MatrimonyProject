import * as React from "react";
import styled from "styled-components";

interface ToggleButtonProps {
  isChecked: boolean;
}

//  export const ToggleButton = styled("div") `
//  `

const Switch = styled.label`
  /* */
  .switch-container {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate3d(-50%, -50%, 0);
    transform: translate3d(-50%, -50%, 0);
  }

  input[type="checkbox"].switch {
    position: absolute;
    opacity: 0;
  }

  input[type="checkbox"].switch + div {
    vertical-align: middle;
    width: 40px;
    height: 20px;
    border-radius: 25px;
    background-color: #ccc;
    -webkit-transition-duration: 0.4s;
    transition-duration: 0.4s;
    -webkit-transition-property: background-color, box-shadow;
    transition-property: background-color, box-shadow;
    cursor: pointer;
  }

  input[type="checkbox"].switch + div span {
    position: absolute;
    font-size: ${props => props.theme.fontSize[400]};
    color: white;
    margin-top: 12px;
  }

  input[type="checkbox"].switch + div span:nth-child(1) {
    margin-left: 15px;
  }

  input[type="checkbox"].switch + div span:nth-child(2) {
    margin-left: 55px;
  }

  input[type="checkbox"].switch:checked + div {
    width: 35px;
    background-position: 0 0;
    background-color: ${props => props.theme.colors.primary};
  }

  input[type="checkbox"].switch + div {
    width: 35px;
    height: 12px;
  }

  input[type="checkbox"].switch:checked + div {
    background-color: ${props => props.theme.colors.primary};
  }

  input[type="checkbox"].switch + div > div {
    float: left;
    width: 10px;
    height: 10px;
    border-radius: inherit;
    background: ${props => props.theme.colors.white};
    -webkit-transition-timing-function: cubic-bezier(1, 0, 0, 1);
    transition-timing-function: cubic-bezier(1, 0, 0, 1);
    -webkit-transition-duration: 0.4s;
    transition-duration: 0.4s;
    -webkit-transition-property: transform, background-color;
    transition-property: transform, background-color;
    pointer-events: none;
    margin-top: 1px;
    margin-left: 1px;
  }

  input[type="checkbox"].switch:checked + div > div {
    -webkit-transform: translate3d(20px, 0, 0);
    transform: translate3d(20px, 0, 0);
    background-color: ${props => props.theme.colors.white};
  }

  input[type="checkbox"].bigswitch.switch + div > div {
    width: 44px;
    height: 44px;
    margin-top: 1px;
  }

  input[type="checkbox"].switch:checked + div > div {
    -webkit-transform: translate3d(23px, 0, 0);
    transform: translate3d(23px, 0, 0);
  }
`;

export const ToggleButton = React.memo((props: ToggleButtonProps) => {
  const [toggleBtn, setToggleBtn] = React.useState(props.isChecked);

  const handleToggle = () => {
    setToggleBtn(!toggleBtn);
  };

  return (
    <Switch>
      <div className="switch-container">
        <label>
          <input
            checked={toggleBtn}
            onClick={handleToggle}
            className="switch"
            type="checkbox"
          />
          <div>
            <div />
          </div>
        </label>
      </div>
    </Switch>
  );
});
