import * as React from "react";
import { Helmet } from "react-helmet-async";
import { helmetJsonLdProp } from "react-schemaorg";
import { HowTo } from "schema-dts";
import styled from "styled-components";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { SiteIcon } from "../../atoms";

interface WeddingAssistConentProps {
  mode?: "crisilAdvantages" | "whyWeddingAssist";
}
const StyledWeddingAssistConent = styled("div")<WeddingAssistConentProps>`
  th {
    font-weight: normal;
    background-color: #f0f0f0;
    padding: 1rem;
    font-size: ${props => props.theme.fontSize[200]};
    width: 50%;
  }
  th:first-child {
    background-color: ${props => props.theme.colors.primary};
    color: white;
  }
  tr {
    width: 100%;
    display: flex;
    flex-direction: row;
  }
  td {
    flex: 1;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    min-height: 2rem;
    background: #f0f0f066;
  }
  td:first-child {
    background-color: ${props => props.theme.colors.primaryFill} !important;
    color: ${props => props.theme.colors.primary};
  }
  td svg {
    flex: 0
  }
  td p {
    flex: 15
  }

  .title {
    font-size: 27px;
    font-weight: ${props => props.theme.fontWeight.regular}
    text-align: center;
    padding-bottom: 4rem;
    padding-top: 2rem;
    display: none;
  }
  ${props => props.theme.media.desktop} {
    margin: 4rem 0;
    .title {
      display: block;
    }
    table {
      width: 100%;
    }
    th {
      font-weight: ${props => props.theme.fontWeight.medium};
    }
    td {
      padding: 1rem 1.875rem;
      font-size: 14px;
    }
    td svg {
      flex: 1
    }  
  }
`;

export const WeddingAssistConent = React.memo(
  ({ mode = "whyWeddingAssist" }: WeddingAssistConentProps) => {
    const { domain } = React.useContext(DomainContext);
    if (domain !== content.Domains.mBazaar) {
      return <></>;
    }
    return (
      <StyledWeddingAssistConent>
        <Helmet
          script={[
            helmetJsonLdProp<HowTo>({
              "@context": "https://schema.org",
              "@type": "HowTo",
              name: content[domain][mode].title,
              description:
                "How its work between Weddingbazaar and Typical Route",
              supply: "WeddingBazaar from BharatMatrimony",
              tool: "Matrimony Assist",
              totalTime: "PT3M15S",
              step: [
                {
                  "@type": "HowToSection",
                  name: content[domain][mode].content.header.ours,
                  position: 1,
                  itemListElement: (content[domain][mode].content
                    .points as any).map(
                    ({ oursName: name, ours: text }: any) => ({
                      "@type": "HowToStep",
                      name,
                      image:
                        "https://www.weddingbazaar.com/assets/bg/wa-banner.jpg",
                      url: "https://www.weddingbazaar.com/wedding-assist",
                      text
                    })
                  )
                },
                {
                  "@type": "HowToSection",
                  name: content[domain][mode].content.header.typical,
                  position: 1,
                  itemListElement: (content[domain][mode].content
                    .points as any).map(
                    ({ typicalName: name, typical: text }: any) => ({
                      "@type": "HowToStep",
                      name,
                      image:
                        "https://www.weddingbazaar.com/assets/bg/wa-banner.jpg",
                      url: "https://www.weddingbazaar.com/wedding-assist",
                      text
                    })
                  )
                }
              ]
            })
          ]}
        />

        {content[domain][mode].title && (
          <div className="title">{content[domain][mode].title}</div>
        )}
        <table>
          <tbody>
            <tr>
              <th>{content[domain][mode].content.header.ours}</th>
              <th>{content[domain][mode].content.header.typical}</th>
            </tr>
            {(content[domain][mode].content.points as any).map(
              (
                {
                  typical,
                  ours,
                  oursIcon,
                  typicalIcon,
                  oursName,
                  typicalName
                }: any,
                idx: any
              ) => (
                <tr key={idx}>
                  <td>
                    <SiteIcon
                      name={oursIcon}
                      style={{
                        // fill: null,
                        width: "8%",
                        height: "auto"
                      }}
                    />
                    <p>{ours}</p>
                  </td>
                  <td>
                    <SiteIcon
                      name={typicalIcon}
                      style={{
                        fill: "#363636",
                        width: "8%",
                        height: "auto"
                      }}
                    />
                    <p>{typical}</p>
                  </td>
                </tr>
              )
            )}
          </tbody>
        </table>
      </StyledWeddingAssistConent>
    );
  }
);
