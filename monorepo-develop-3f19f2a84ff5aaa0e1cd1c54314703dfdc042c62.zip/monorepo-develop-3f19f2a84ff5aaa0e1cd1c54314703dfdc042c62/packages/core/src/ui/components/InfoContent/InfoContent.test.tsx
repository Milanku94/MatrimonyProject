import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { InfoContent, InfoContentProps } from "./InfoContent";

afterEach(cleanup);

const props: InfoContentProps = {};

describe("InfoContent:", () => {
  it("renders correctly", () => {
    const { container } = render(<InfoContent {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
