import * as React from "react";
import styled from "styled-components";
import { Secondary1 } from "../Typography";

export interface InfoContentProps {
  title?: string;
  infoArr?: any[];
}

const InfoSection = styled("div")`
  ${Secondary1} {
    font-size: ${props => props.theme.fontSize[150]};
    font-weight: ${props => props.theme.fontWeight.medium};
    color: rgb(42, 44, 52);
    border-bottom: 1px solid #e6e6e6;
    padding: 0.5rem 0rem;
  }
`;

const InfoDetail = styled("ul")`
  margin: 0px;
  padding: 0;
  list-style: none;
  border-bottom: 1px solid #eeeeee;
  li {
    display: flex;
    padding: 20px 0px;
  }
  &:last-child {
    border-bottom: 0px;
  }
`;

const InfoSpan = styled("span")`
  width: 50%;
  color: #707070;
  font-size: ${props => props.theme.fontSize[100]};
  font-style: oblique;
  font-weight: ${props => props.theme.fontWeight.medium};
`;

const InfoDiv = styled("div")`
  width: 35%;
  display: inline-flex;
  align-items: center;
  margin-left: 3rem;
  color: #2a2c34;
  font-size: ${props => props.theme.fontSize[100]};
  font-weight: ${props => props.theme.fontWeight.medium};
`;

const UnstyledInfoContent = React.memo((props: InfoContentProps) => {
  return (
    <InfoSection>
      <Secondary1>{props.title}</Secondary1>
      {props.infoArr &&
        props.infoArr.map((info: any, idx: number) => (
          <InfoDetail key={idx}>
            <li>
              <InfoSpan>{info.question} </InfoSpan>
              <InfoDiv> {info.answer} </InfoDiv>
            </li>
          </InfoDetail>
        ))}
    </InfoSection>
  );
});

export const InfoContent = styled(UnstyledInfoContent)<InfoContentProps>``;
