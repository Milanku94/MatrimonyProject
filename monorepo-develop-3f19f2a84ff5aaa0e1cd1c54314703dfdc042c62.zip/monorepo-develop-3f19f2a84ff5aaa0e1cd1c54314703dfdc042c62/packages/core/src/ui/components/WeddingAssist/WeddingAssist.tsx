import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import { StyledLink } from "../Typography";

interface WeddingAssistProps {
  backgroundImage?: { mobile: string; desktop: string } | string;
  title?: string;
  subTitle?: string;
  pageBanner: "homepage" | "assistpage" | "thankyoupage";
  elementID: string;
  handleMore?: () => void;
  hideLink?: boolean;
}

const WhatIsWeddingAssistDiv = styled("div")<WeddingAssistProps>`
/*height: ${props =>
  props.pageBanner === "thankyoupage" ? "260px" : "585px"};*/
${props =>
  typeof props.backgroundImage === "string"
    ? backgroundImage(props.backgroundImage)
    : backgroundImage(props.backgroundImage!.mobile)}
background-size: cover;
background-position: center;
background-repeat: no-repeat;

${props => props.theme.media.desktop} {
  /*height:380px;*/
  ${props =>
    typeof props.backgroundImage === "string"
      ? backgroundImage(props.backgroundImage)
      : backgroundImage(props.backgroundImage!.desktop)}
}
`;

const InnerGradientDiv = styled("div")<WeddingAssistProps>`
  height: ${props => (props.pageBanner === "thankyoupage" ? "260px" : "585px")};
  background: linear-gradient(
    rgba(255, 255, 255, 0.22) 33%,
    rgb(70, 58, 60) 66%,
    rgba(0, 0, 0, 0.95) 100%
  );

  ${props => props.theme.media.desktop} {
    height: 380px;
    background: linear-gradient(
      rgba(255, 255, 255, 0.1) 14%,
      rgb(70, 58, 60) 100%,
      rgba(0, 0, 0, 0.95) 100%
    );
    position: relative;
  }
`;

const WeddingAssistTitleDiv = styled("div")<WeddingAssistProps>`
  font-size: 22px;
  padding: ${props => (props.pageBanner === "thankyoupage" ? "115px" : "349px")}
    0px 0px 22px;
  color: rgba(255, 255, 255, 1);
  font-weight: ${props => props.theme.fontWeight.medium}
    ${props => props.theme.media.desktop} {
    padding: 120px 0px 0px 22px;
  }
`;

const WeddingAssistSubTitleDiv = styled("div")`
  padding: 10px 25px 0px 22px;
  color: rgba(255, 255, 255, 1);
  font-size: 14px;
`;

export const HowItWorksDiv = styled("div")`
  display: flex;
  margin-top: 19px;
`;

export const SingleStripeDiv = styled("div")`
  margin-left: 22px;
  width: 20px;
  border-top: 0.3px solid ${props => props.theme.colors.primary};
  margin-top: 10px;
  margin-right: 10px;
`;

export const HowItWorksTextDiv = styled(StyledLink)`
  &:link,
  &:active,
  &:visited,
  &:hover {
    font-size: 16px;
    color: ${props => props.theme.colors.primary};
    font-weight: ${props => props.theme.fontWeight.medium};
  }
`;
export const HowItWorksTextDiv1 = styled("div")`
  font-size: 16px;
  color: ${props => props.theme.colors.primary};
  font-weight: ${props => props.theme.fontWeight.medium};
  cursor: pointer;
`;

export const WaContextDiv = styled("div")`
  ${props => props.theme.media.desktop} {
    position: absolute;
    bottom: 1.5rem;
  }
`;

const page = {
  homepage: {
    link: "/wedding-assist",
    caption: "Find out more"
  },
  assistpage: {
    link: "/how-it-works",
    caption: "See How it Works"
  },
  thankyoupage: {
    link: "/wedding-assist",
    caption: "Find out more"
  }
};
const UnstyledWeddingAssist = React.memo((props: WeddingAssistProps) => {
  return (
    <WhatIsWeddingAssistDiv backgroundImage={props.backgroundImage} {...props}>
      <InnerGradientDiv {...props}>
        <WaContextDiv>
          <WeddingAssistTitleDiv {...props}>
            {props.title}
          </WeddingAssistTitleDiv>
          <WeddingAssistSubTitleDiv>{props.subTitle}</WeddingAssistSubTitleDiv>
          {!props.hideLink && (
            <HowItWorksDiv>
              <SingleStripeDiv />
              {!!props.handleMore ? (
                <HowItWorksTextDiv1 onClick={props.handleMore}>
                  {page[props.pageBanner].caption}
                </HowItWorksTextDiv1>
              ) : (
                <HowItWorksTextDiv to={page[props.pageBanner].link}>
                  {page[props.pageBanner].caption}
                </HowItWorksTextDiv>
              )}
            </HowItWorksDiv>
          )}
        </WaContextDiv>
      </InnerGradientDiv>
    </WhatIsWeddingAssistDiv>
  );
});
export const WeddingAssist = styled(UnstyledWeddingAssist)``;
