import * as React from "react";
import styled from "styled-components";
import { PictureTag } from "../../";
import { theme } from "../../theme";
import Logo from "./images/logo.png";
interface FooterLogoProps {
  logoSize: string;
}

const BmLogoFooter = styled.div`
  text-align: center;
  padding-top: 45px;
`;

const UnstyledLogo = React.memo((props: FooterLogoProps) => {
  return (
    <BmLogoFooter>
      <PictureTag image={Logo} alt={"logo"} width={props.logoSize} />
    </BmLogoFooter>
  );
});

export const FooterLogo = styled(UnstyledLogo)<FooterLogoProps>``;
