import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import {
  HowItWorksDiv,
  HowItWorksTextDiv,
  HowItWorksTextDiv1,
  SingleStripeDiv
} from "../WeddingAssist/WeddingAssist";
interface WeddingAssistDkBannerProps {
  handleMore?: () => void;
  hideLink?: boolean;
}

const BannerSection = styled("div")`
  ${props => props.theme.media.mobile} {
    display: none;
  }
`;

const WaImage = styled("div")`
  margin-top: 3rem;
  margin-bottom: 5rem;

  background-repeat: no-repeat;
  ${backgroundImage(
    "//www.weddingbazaar.com/assets/bg/wedding-assist-banner.jpg"
  )}
  height: 350px;
  width: 60vw;
  background-size: cover;
  background-position-x: -4rem;
`;
const WaBox = styled("div")`
  position: relative;
  margin-top: 50px;
  width: 40vw;
  background-color: ${props => props.theme.colors.primaryFill};
  float: right;
  right: -19vw;
  ${HowItWorksDiv} {
    margin: 25px 22px 80px;
  }

  ${SingleStripeDiv} {
    margin-right: 7px;
    width: 13px;
  }

  ${HowItWorksTextDiv} {
    font-size: 15px;
  }
`;
const WaBoxTitle = styled("div")`
  margin: 60px 0px 0px 42px;
  font-size: 1.7rem;
  font-weight: ${props => props.theme.fontWeight.regular}
  color: #363636;
`;

const WaBoxSubtitle = styled("div")`
  font-size: 15px;
  line-height: 25px;
  margin-left: 42px;
  margin-top: 15px;
  margin-right: 60px;
`;

const UnstyledWeddingAssistDkBanner = React.memo(
  (props: WeddingAssistDkBannerProps) => {
    const { domain } = React.useContext(DomainContext);
    if (domain !== content.Domains.mBazaar) {
      return <></>;
    }
    return (
      <BannerSection>
        <WaImage>
          <WaBox>
            <WaBoxTitle>{content[domain].weddingAssist.title}</WaBoxTitle>
            <WaBoxSubtitle>
              {content[domain].weddingAssist.content}
            </WaBoxSubtitle>
            <HowItWorksDiv>
              {!props.hideLink && (
                <React.Fragment>
                  <SingleStripeDiv />
                  {!!props.handleMore ? (
                    <HowItWorksTextDiv1 onClick={props.handleMore}>
                      See how it works
                    </HowItWorksTextDiv1>
                  ) : (
                    <HowItWorksTextDiv to={"/wedding-assist"}>
                      See how it works
                    </HowItWorksTextDiv>
                  )}
                </React.Fragment>
              )}
            </HowItWorksDiv>
          </WaBox>
        </WaImage>
      </BannerSection>
    );
  }
);
export const WeddingAssistDkBanner = styled(UnstyledWeddingAssistDkBanner)``;
