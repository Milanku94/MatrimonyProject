import * as React from "react";
import styled from "styled-components";
import { backgroundImage } from "../../";
import { Headline, LinkText, Subtitle } from "../Typography";

interface LeftBannerProps {
  /** URL of the background-image on the left part of the blog banner */
  imageBlog: string;
}

export interface BlogBannerProps extends LeftBannerProps {
  title: string;
  subtitle: string;
  linkText?: string;
}

const LeftBanner = styled("div")<LeftBannerProps>`
  width: 132px;
  background-repeat: no-repeat;
  height: 109px;
  ${props => backgroundImage(props.imageBlog)}
  background-size: contain;
  background-position: center;
  ${props => props.theme.media.desktop} {
    background-size: cover;
    width: 100%;
  }
`;

const RightBanner = styled("div")`
  margin-left: 3px;
  margin-top: 17px;
  ${props => props.theme.media.desktop} {
    margin: 0px;
    padding: 12px 0px;
  }

  ${LinkText} {
    float: none;
    font-size: 16px;
    text-decoration: none;
    color: ${props => props.theme.colors.primary};
    margin-left: 20px;
    font-weight: ${props => props.theme.fontWeight.medium};
  }

  ${Headline} {
    font-size: 22px;
    font-weight: ${props => props.theme.fontWeight.medium};
    margin-left: 20px;
  }
  ${Subtitle} {
    margin-left: 20px;
    margin-top: 10px;
    font-size: 16px;
  }
`;

const BannerBox = styled("div")`
  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.13);
  margin-top: 35px;
  display: flex;
  ${props => props.theme.media.desktop} {
    display: block;
    /*height: 345px;*/
    margin-bottom: 35px;
    /*margin-top: 50px;*/
  }
`;

export const BlogBanner = React.memo((props: BlogBannerProps) => {
  return (
    <BannerBox>
      <LeftBanner imageBlog={props.imageBlog} />
      <RightBanner>
        <Headline as={"p"}>{props.title}</Headline>
        <Subtitle as={"div"}>{props.subtitle}</Subtitle>
        <LinkText>{props.linkText} &gt;</LinkText>
      </RightBanner>
    </BannerBox>
  );
});
