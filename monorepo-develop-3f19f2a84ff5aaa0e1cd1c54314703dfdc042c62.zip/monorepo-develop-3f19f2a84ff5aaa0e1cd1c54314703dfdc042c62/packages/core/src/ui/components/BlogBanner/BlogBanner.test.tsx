import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { BlogBanner, BlogBannerProps } from "./BlogBanner";

afterEach(cleanup);
const props: BlogBannerProps = {
  imageBlog: "https://via.placeholder.com/300.png/09f/fff",
  title: "Lorem ipsum",
  subtitle: "nisi vitae suscipit tellus mauris a diam maecenas"
};

describe("BlogBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(
      <BlogBanner {...props} linkText={"tellus in"} />
    );
    expect(container.firstChild).toMatchSnapshot();
  });
  it("renders correctly without optional props", () => {
    const { container } = render(<BlogBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
