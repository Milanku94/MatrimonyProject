import _padStart from "lodash/padStart";
import * as React from "react";
import styled from "styled-components";
import { BulletPoint, SiteIcon, StyledLink, Text } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
interface HowItWorksProps {
  elementID: string;
  hideLink?: boolean;
}

const HowItWorksBtmDiv = styled("div")`
  margin: 4rem 1rem;
  ${props => props.theme.media.desktop} {
    display: none;
  }
`;

const HowItWorksInfoDiv = styled("div")`
  display: flex;
  flex-direction: column;
  align-items: start;
`;

const HowItWorksTextDiv = styled(StyledLink)`
  &:link,
  &:active,
  &:visited,
  &:hover {
    margin: auto;
  }
`;
const BulletList = styled("div")`
  display: flex;
  margin: 0.5rem 0;
  align-items: center;
`;
const UnstyledHowItWorks = React.memo((props: HowItWorksProps) => {
  const { domain } = React.useContext(DomainContext);
  if (domain === content.Domains.writer) {
    return <></>;
  }

  return (
    <HowItWorksBtmDiv>
      <Text
        fontSize={300}
        textAlign="center"
        fontWeight="medium"
        margin="major-2"
      >
        How it works
      </Text>
      <Text
        fontSize={200}
        textAlign="center"
        fontWeight="medium"
        marginBottom="major-4"
      >
        {content[domain].howItWorks.title}
      </Text>
      <HowItWorksInfoDiv>
        {content[domain].howItWorks.steps.map(
          ({ long: desc }: any, idx: any) => (
            <BulletList key={idx}>
              <BulletPoint shape="round" margin="minor-1">
                {_padStart((+idx + 1).toString(), 2, "0")}
              </BulletPoint>
              <Text
                fontSize={150}
                fontWeight="medium"
                margin="major-1"
                color="gray1"
              >
                {desc}
              </Text>
            </BulletList>
          )
        )}
      </HowItWorksInfoDiv>

      {!props.hideLink && (
        <HowItWorksTextDiv id={props.elementID} to="/how-it-works">
          <Text
            fontSize={150}
            textAlign="center"
            fontWeight="medium"
            margin="major-2"
            color="primary"
          >
            Find out more
            <SiteIcon name="right-arrow" />
          </Text>
        </HowItWorksTextDiv>
      )}
    </HowItWorksBtmDiv>
  );
});

export const HowItWorks = styled(UnstyledHowItWorks)``;
