declare module "insane";
