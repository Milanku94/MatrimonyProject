export interface ThemeFontSize {
  xLarge: string;
  large: string;
  medium: string;
  small: string;
  xSmall: string;

  900: string;
  800: string;
  700: string;
  600: string;
  500: string;
  400: string;
  300: string;
  200: string;
  150: string;
  100: string;
  75: string;
  50: string;
}

export interface ThemeFontWeight {
  light: number;
  regular: number;
  medium: number;
  semiBold: number;
  bold: number;
}

export interface ThemeColors {
  primary: string;
  primaryFill: string;
  accent1: string;
  accent2: string;
  accent3: string;

  black: string;
  white: string;

  gray1: string;
  gray2: string;
  gray3: string;
  gray4: string;
  gray5: string;
}

export interface ThemeDevices {
  mobile: string;
  desktop: string;
}
