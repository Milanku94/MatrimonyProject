export interface Media {
  url: string;
  hero?: boolean;
  caption?: string;
  alt?: string;
  slug?: string;
  tags?: MediaTag[];
}
export interface MediaTag {
  id: string;
  slug: string;
  name: string;
  icon: string;
}
