import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { ServiceableCities, ServiceableCitiesProps } from "./ServiceableCities";

afterEach(cleanup);

const props: ServiceableCitiesProps = {
  cities: [{ slug: "chennai", name: "Chennai" }]
};

describe("ServiceableCities:", () => {
  it("renders correctly", () => {
    const { container } = render(<ServiceableCities {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
