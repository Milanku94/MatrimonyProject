import * as React from "react";
import styled from "styled-components";
import { SiteIcon, StyledLink, Text } from "../../atoms";
export interface ServiceableCitiesProps {
  cities: Array<{ slug: string; [key: string]: any }>;
}
const LegendDiv = styled("div")`
  width: 100%;
  text-align: center;
  border-bottom: 0.15rem solid ${props => props.theme.colors.gray3};
  line-height: 0.1em;
  margin: 10px 0 20px;
  span {
    background: ${props => props.theme.colors.white};
    padding: 0 1rem;
  }
`;
const ServiceableCitiesDiv = styled("div")<ServiceableCitiesProps>`
  ${props => props.theme.media.mobile} {
    padding: 2rem;
  }
  padding: 2rem 0;
`;
const PopularCitiesCotainer = styled("div")`
  ${props => props.theme.media.desktop} {
    margin: 0 10%;
  }
  display: flex;
  justify-content: space-around;
  flex-grow: 2;
  flex-wrap: wrap;
  ${StyledLink} {
    padding: 0.5rem;
    display: flex;
    flex-direction: column;
    svg {
      ${props => props.theme.media.mobile} {
        height: 3rem !important;
      }
    }
  }
`;
const OtherCitiesCotainer = styled("div")`
  ${props => props.theme.media.desktop} {
    margin: 0 10%;
  }

  display: grid;
  grid-template-columns: repeat(5, 1fr);
  ${props => props.theme.media.mobile} {
    grid-template-columns: repeat(2, 1fr);
  }
  ${StyledLink} {
    display: flex;
    padding: 0.25rem;
    flex-direction: column;
  }
`;
const definedPopularCitiesIcons = {
  chennai: "city_chennai",
  bangalore: "city_bangalore",
  hyderabad: "city_hyderabad",
  alappuzha: "city_alappuzha",
  kolkata: "city_kolkata",
  jaipur: "city_jaipur",
  mumbai: "city_mumbai",
  delhi: "city_delhi"
};

export const ServiceableCities: React.FC<ServiceableCitiesProps> = React.memo(
  props => {
    const popularCities = props.cities.filter(({ slug }: any) =>
      Object.keys(definedPopularCitiesIcons).includes(slug)
    );
    return (
      <ServiceableCitiesDiv {...props}>
        <Text textAlign="center" fontWeight="medium" margin="major-3">
          Popular Cities
        </Text>
        <PopularCitiesCotainer>
          {popularCities.map(({ slug, name }: any) => (
            <StyledLink key={slug} to={`\/${slug}`}>
              <SiteIcon
                name={definedPopularCitiesIcons[slug]}
                style={{
                  width: "5rem",
                  height: "5rem",
                  margin: "0rem auto"
                }}
              />
              <Text
                textAlign="center"
                margin="major-1"
                fontSize="medium"
                fontWeight="medium"
              >
                {name}
              </Text>
            </StyledLink>
          ))}
        </PopularCitiesCotainer>
        <Text
          textAlign="center"
          fontWeight="medium"
          marginTop="major-5"
          marginBottom="major-3"
        >
          <LegendDiv>
            <span>Other Cities</span>
          </LegendDiv>
        </Text>
        <OtherCitiesCotainer>
          {props.cities.map(({ name, slug }: any) => (
            <StyledLink key={slug} to={`\/${slug}`}>
              <Text fontSize="medium" fontWeight="medium" color="gray1">
                {name}
              </Text>
            </StyledLink>
          ))}
        </OtherCitiesCotainer>
      </ServiceableCitiesDiv>
    );
  }
);
