export { InquiriesBanner } from "./InquiriesBanner/InquiriesBanner";

export { WeddingAssistBanner } from "./WeddingAssistBanner/WeddingAssistBanner";
export { WeddingStoriesBanner } from "./WeddingStoriesBanner/WeddingStoriesBanner";
export { WhyTrustUsPromo } from "./WhyTrustUsPromo/WhyTrustUsPromo";
export { IdeasAndBlogsBanner } from "./IdeasAndBlogsBanner/IdeasAndBlogsBanner";
export { ServiceableCities } from "./ServiceableCities/ServiceableCities";
export { CategoryImgTileList } from "./CategoryImgTileList/CategoryImgTileList";
