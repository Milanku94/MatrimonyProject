import * as React from "react";
import { CarouselBanner, IdeasCard } from "../../";
import { FancyHeader } from "../../molecules/FancyHeader/FancyHeader";

export interface IdeasAndBlogsBannerProps {
  ideasOrBlogs: any[];
  reviewAction?: (idea: any) => string;
  moreAction?: () => void;
}
export const IdeasAndBlogsBanner: React.FC<IdeasAndBlogsBannerProps> = React.memo(
  ({ reviewAction, moreAction, ideasOrBlogs }) => (
    <CarouselBanner
      title={<FancyHeader title="Ideas and Inspirations" />}
      more={moreAction && { action: moreAction, text: "View more articles" }}
    >
      {ideasOrBlogs.map(
        (idea: any, idx: any) =>
          idea && (
            <IdeasCard
              key={idx}
              title={idea.name}
              content={idea.excerpt}
              onAction={() => reviewAction && reviewAction(idea)}
            />
          )
      )}
    </CarouselBanner>
  )
);
