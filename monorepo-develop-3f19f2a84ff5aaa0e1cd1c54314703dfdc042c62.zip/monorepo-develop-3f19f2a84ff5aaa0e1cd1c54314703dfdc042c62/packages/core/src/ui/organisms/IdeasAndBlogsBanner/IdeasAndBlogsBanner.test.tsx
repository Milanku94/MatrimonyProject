import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import {
  IdeasAndBlogsBanner,
  IdeasAndBlogsBannerProps
} from "./IdeasAndBlogsBanner";

afterEach(cleanup);

const props: IdeasAndBlogsBannerProps = {
  ideasOrBlogs: [
    {
      id: "3",
      name: "Mehndi Artists for Mehndi Ceremony",
      slug: "mehndi-artists-for-mehndi-ceremony",
      excerpt:
        "Weddings are one of the most beautiful, sacred, and important events that have the ability to change one\u2019s life forever. Here at Wedding Bazaar, we like to give importance to the finer details that can make this event as perfect as possible. ",
      heroPhoto: {
        url: null,
        isHero: false,
        caption: "Mehndi Artists for Mehndi Ceremony",
        altText: "Mehndi Artists for Mehndi Ceremony"
      }
    },
    {
      id: "4",
      name: "How to plan a Sangeet Ceremony",
      slug: "how-to-plan-a-sangeet-ceremony",
      excerpt:
        "A typical Sangeet ceremony involves a lot of singing and dancing where the families of both the bride and the groom join hands to make the evening more interesting. \r\n\r\n",
      heroPhoto: {
        url: null,
        isHero: false,
        caption: "How to plan a Sangeet Ceremony",
        altText: "How to plan a Sangeet Ceremony"
      }
    },
    {
      id: "5",
      name: "How to plan and celebrate Haldi Ceremony?",
      slug: "how-to-plan-and-celebrate-haldi-ceremony",
      excerpt:
        "One of the most fundamental and important pre-wedding events in an Indian wedding is the Haldi ceremony.",
      heroPhoto: {
        url: null,
        isHero: false,
        caption: "How to plan and celebrate Haldi Ceremony?",
        altText: "How to plan and celebrate Haldi Ceremony?"
      }
    }
  ]
};

describe("IdeasAndBlogsBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(<IdeasAndBlogsBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
