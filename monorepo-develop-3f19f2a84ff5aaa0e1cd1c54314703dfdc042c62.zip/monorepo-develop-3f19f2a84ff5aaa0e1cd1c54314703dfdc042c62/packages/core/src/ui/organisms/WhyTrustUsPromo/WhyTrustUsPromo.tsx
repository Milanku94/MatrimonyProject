import * as React from "react";
import styled from "styled-components";
import { Pane, SiteIcon, Text } from "../../";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { defaultStyles, DefaultStyles } from "../../../utils/ui.utils";

export interface WhyTrustUsPromoProps {
  icons?: [string];
}
const WhyTrustUsPromoDiv = styled("div")<DefaultStyles>`
  min-width: 15rem;
  width: fit-content;
  ${defaultStyles}
  ${props => props.theme.media.mobile} {
    min-width: inherit;
    width: 95%;
  }
`;

const TrustTag = styled("div")<DefaultStyles>`
  flex: 1;
  display: flex;
  flex-flow: column;
  align-items: center;
  ${defaultStyles};
`;

const TrustTagContainer = styled("div")`
  display: flex;
  flex-flow: row;
  padding: 0.5rem;
  ${TrustTag} {
    border-left: solid 1px ${props => props.theme.colors.gray3};
  }
  ${TrustTag}:first-child {
    border-left: none;
  }
`;
const TrustTagHighlight = styled("div")`
  display: flex;
  flex-flow: column;
  align-items: center;
  ${props => props.theme.media.mobile} {
    flex-flow: row;
  }
`;

export const WhyTrustUsPromo = React.memo(({ icons }: WhyTrustUsPromoProps) => {
  const { domain } = React.useContext(DomainContext);
  if (domain === content.Domains.writer) {
    return <></>;
  }

  const points = content[domain].howTrustUs.points.filter(point =>
    icons ? icons.includes(point.icon) : true
  );
  return (
    <WhyTrustUsPromoDiv margin="!major-6 auto major-2 auto">
      <Pane elevation={"4"}>
        <TrustTagContainer>{points.map(renderIcon(domain))}</TrustTagContainer>
      </Pane>
    </WhyTrustUsPromoDiv>
  );
});

const renderIcon = (domain: content.Domains) => {
  return (point: any) => (
    <TrustTag key={point.icon} padding="minor-1">
      <TrustTagHighlight>
        <SiteIcon
          name={point.icon}
          style={{
            height: "1.6rem",
            width: "1.6rem"
          }}
        />
        <Text fontSize={150} color="primary" fontWeight={"medium"}>
          {point.metric}
        </Text>
      </TrustTagHighlight>
      <Text fontSize={100} fontWeight={"medium"} textAlign="center">
        {point.highlight}
      </Text>
    </TrustTag>
  );
};
