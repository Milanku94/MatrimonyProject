import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { WhyTrustUsPromo, WhyTrustUsPromoProps } from "./WhyTrustUsPromo";

afterEach(cleanup);

const props: WhyTrustUsPromoProps = {};

describe("WhyTrustUsPromo:", () => {
  it("renders correctly", () => {
    const { container } = render(<WhyTrustUsPromo {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
