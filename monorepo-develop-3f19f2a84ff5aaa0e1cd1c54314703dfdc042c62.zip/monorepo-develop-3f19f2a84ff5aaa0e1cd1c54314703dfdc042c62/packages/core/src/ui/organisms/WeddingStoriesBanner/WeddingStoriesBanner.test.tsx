import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import {
  WeddingStoriesBanner,
  WeddingStoriesBannerProps
} from "./WeddingStoriesBanner";

afterEach(cleanup);

const props: WeddingStoriesBannerProps = {
  stories: [
    {
      city: "Tirupati",
      couple: { bride: "Sreelakshmi", groom: "Akhil" },
      heroPhoto: {
        slug: "frqfncteywtff",
        url: "https://picsum.photos/700",
        hero: true,
        caption: "Reception time 1",
        altText: "Reception time photo 1"
      },
      id: "s",
      slug: "hymxvama"
    }
  ],
  storyAction: ({ couple, slug }) =>
    `/wedding-stories/${couple.groom}-${couple.bride}-${slug}`,
  actionMore: () => (window.location.pathname = "/wedding-stories")
};

describe("WeddingStoriesBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(<WeddingStoriesBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
