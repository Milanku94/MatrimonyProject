import React from "react";
import styled from "styled-components";
import { Button, StyledLink, Text, WeddingCard } from "../../";
import * as content from "../../../content";
import { FancyHeader } from "../../molecules/FancyHeader/FancyHeader";
export interface WeddingStoriesBannerProps {
  storyAction: ({ couple, slug }: { couple: any; slug: string }) => string;
  stories: any[];
  actionMore: () => void;
}

const WeddingStoriesBannerDiv = styled("div")`
  margin: 1rem 0;
  & > div:nth-child(even) {
    padding: 1rem 0;
  }
  & > div:nth-child(2) {
    width: 70%;
    ${props => props.theme.media.mobile} {
      display: none;
    }
  }
`;
const WeddingStoriesCardDiv = styled("div")`
  overflow-x: auto;
  display: flex;
`;
const WeddingStoriesActionDiv = styled("div")`
  margin: 0.5rem auto;
  text-align: center;
`;

export const WeddingStoriesBanner: React.FC<WeddingStoriesBannerProps> = React.memo(
  ({ storyAction, stories, actionMore }) => {
    return (
      <WeddingStoriesBannerDiv>
        <FancyHeader title={content.mbazaar.weddingStories.title} />
        <Text
          fontSize={100}
          color="gray1"
          textAlign="center"
          margin="major-0 auto"
        >
          {content.mbazaar.weddingStories.content}
        </Text>
        <WeddingStoriesCardDiv>
          {stories.map(({ id, couple, heroPhoto, city, slug }: any) => (
            <StyledLink
              key={id}
              to={{
                pathname: storyAction({ couple, slug })
              }}
            >
              <WeddingCard
                margin="major-2 major-1"
                image={heroPhoto}
                couple={`${couple.bride} &  ${couple.groom}`}
                location={city}
              />
            </StyledLink>
          ))}
        </WeddingStoriesCardDiv>
        <WeddingStoriesActionDiv>
          <Button textAlign="center" onClick={actionMore}>
            View more stories
          </Button>
        </WeddingStoriesActionDiv>
      </WeddingStoriesBannerDiv>
    );
  }
);
