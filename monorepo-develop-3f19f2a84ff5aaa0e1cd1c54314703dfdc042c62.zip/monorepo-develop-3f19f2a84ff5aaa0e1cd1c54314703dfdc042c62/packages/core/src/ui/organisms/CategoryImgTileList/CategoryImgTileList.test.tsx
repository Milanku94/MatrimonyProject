import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import {
  CategoryImgTileList,
  CategoryImgTileListProps
} from "./CategoryImgTileList";

afterEach(cleanup);

export const categoryImgTileListProps: CategoryImgTileListProps = {
  elementId: "category-icon",
  city: "chennai",
  categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17].map(
    each => ({
      needName: "caption here",
      slug: each.toString()
    })
  )
};

describe("CategoryImgTileList:", () => {
  it("renders correctly", () => {
    const { container } = render(
      <CategoryImgTileList {...categoryImgTileListProps} />
    );
    expect(container.firstChild).toMatchSnapshot();
  });
});
