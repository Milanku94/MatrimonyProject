import * as React from "react";
import styled from "styled-components";
import { Button } from "../../atoms/Button/Button";
import { CategoryImageTile } from "../../molecules/CategoryImageTile/CategoryImageTile";
import { FancyHeader } from "../../molecules/FancyHeader/FancyHeader";

export interface CategoryImgTileListProps {
  elementId: string;
  city: string;
  categories: Array<{ needName: string; slug: string; image?: string }>;
  showMore?: { url: string; text: string };
  title?: string;
}

const CategoryImgTileListContainer = styled("div")`
  margin: 1rem 0;
    ${props => props.theme.media.mobile} {
        margin: 1rem 0.8rem;
        display: flex;
        flex-direction: column;
      }
      ${props => props.theme.media.desktop} {
        ${Button} {
          display: none;
        }
    
`;
const CategoryImgTileListDiv = styled("div")<{
  showMore?: boolean;
  isExpand?: boolean;
  hasOverflowingWidth?: boolean;
}>`
  gap: 1.5rem;
  grid-template-columns: repeat(auto-fill, minmax(9rem, 1fr));
  grid-auto-flow: row;
  padding: 1rem 0;
  ${props => props.theme.media.mobile} {
    flex-flow: row wrap;
    display: grid;
    a: nth-child(6) ~a {
      ${props => (!props.isExpand ? `display: none` : ``)};
    }
  }
  ${props => props.theme.media.desktop} {
    ${props => (props.showMore ? `overflow-x: auto;` : ``)};
    ${props => (props.hasOverflowingWidth ? `` : `justify-content: center`)};
    display: ${props => (props.showMore ? "flex" : "grid")};
  }
`;

export const CategoryImgTileList: React.FC<CategoryImgTileListProps> = ({
  categories,
  city,
  elementId,
  showMore,
  title = "Find the best wedding service providers near you"
}) => {
  const [isExpand, setIsExpand] = React.useState(false);
  const listDivRef = React.useRef<HTMLDivElement>(null);
  const [hasOverflowingWidth, setHasOverflowingWidth] = React.useState(true);
  React.useEffect(() => {
    if (listDivRef.current) {
      setHasOverflowingWidth(
        listDivRef.current.offsetWidth < listDivRef.current.scrollWidth
      );
    }
  }, [categories]);

  return (
    <CategoryImgTileListContainer>
      <FancyHeader
        title={title}
        showMore={hasOverflowingWidth && !!showMore ? showMore : undefined}
        hideHighlight={!!showMore}
      />
      <CategoryImgTileListDiv
        ref={listDivRef}
        showMore={!!showMore}
        isExpand={isExpand}
        hasOverflowingWidth={hasOverflowingWidth}
      >
        {categories.map(({ needName, slug, image }: any) => (
          <CategoryImageTile
            key={slug}
            linkTo={`/${city}/${slug}`}
            image={
              image ||
              `https://www.weddingbazaar.com/assets/icons/img-${slug}.jpg`
            }
            caption={needName}
            slug={slug}
            elementId={elementId}
          />
        ))}
      </CategoryImgTileListDiv>
      {!isExpand && categories.length >= 6 && (
        <Button
          textAlign="center"
          marginTop="major-2"
          onClick={() => setIsExpand(true)}
        >
          View all categories
        </Button>
      )}
    </CategoryImgTileListContainer>
  );
};
