import * as React from "react";
import styled from "styled-components";
import { CarouselBanner, IdeasCard } from "../..";
import { Pane } from "../../atoms/Pane/Pane";
import { Text } from "../../atoms/Typography/Typography";
import { IdeasCardContent } from "../../molecules/IdeasCard/IdeasCard";

export interface InquiriesBannerProps {
  latestInquries: any[];
  reviewAction?: (inquired: any) => string;
  moreAction?: () => void;
  title: string;
}
const StyledCarouselBanner = styled(CarouselBanner)`
  padding: 1rem;
  & > div {
    justify-content: space-around;
  }
`;

const StyledPane = styled(Pane)`
  padding: 0 !important;
  margin: 1rem;
  border: 1px solid lightgray;
  border-radius: 0.25rem;
  ${Text}, ${IdeasCardContent} > ${Text}:first-child {
    text-align: left;
  }
`;

export const InquiriesBanner: React.FC<InquiriesBannerProps> = React.memo(
  ({ latestInquries, moreAction, reviewAction, title }) => (
    <StyledCarouselBanner
      title={title}
      more={moreAction && { action: moreAction, text: "" }}
    >
      {[...latestInquries.slice(1), latestInquries[0]].map(
        (inquired: any, idx: any) => (
          <StyledPane key={idx}>
            <IdeasCardContent padding="major-1">
              <Text
                fontSize={200}
                fontWeight="medium"
                color={"primary"}
                padding="major-1 major-0"
              >
                {`${inquired.name} inquired for ${deslug(inquired.category)}`}
              </Text>
              <Text fontSize={150} fontWeight="regular" color={"gray1"}>
                <React.Fragment>
                  {renderAttributes(inquired.attributes)}
                  {renderDate(inquired.date)}
                </React.Fragment>
              </Text>
            </IdeasCardContent>
          </StyledPane>
        )
      )}
    </StyledCarouselBanner>
  )
);

const renderAttributes = (attributes: {
  map: (
    arg0: (attr: { name: string; selected: string }) => JSX.Element
  ) => void;
}) =>
  attributes.map((attr: { name: string; selected: string }) => (
    <p key={attr.name}>
      <b>{attr.name} </b>
      {attr.selected}
    </p>
  ));
const renderDate = (date: number) => {
  const dateDiff = new Date().getTime() - date;
  if (dateDiff < 60 * 60 * 1000) {
    return <p>Less than an hour ago</p>;
  }
  if (dateDiff < 24 * 60 * 60 * 1000) {
    return <p>Yesterday</p>;
  }
  if (dateDiff < 2 * 24 * 60 * 60 * 1000) {
    return <p>2 days ago</p>;
  }
  if (dateDiff < 7 * 24 * 60 * 60 * 1000) {
    return <p>Last week</p>;
  }
  if (dateDiff < 14 * 24 * 60 * 60 * 1000) {
    return <p>2 weeks ago</p>;
  }
  if (dateDiff < 30 * 24 * 60 * 60 * 1000) {
    return <p>Last month</p>;
  }
  return <p>Long ago</p>;
};

const deslug = (str: string) =>
  str
    .split("-")
    .map((word: string) => word[0].toUpperCase() + word.slice(1))
    .join(" ");
