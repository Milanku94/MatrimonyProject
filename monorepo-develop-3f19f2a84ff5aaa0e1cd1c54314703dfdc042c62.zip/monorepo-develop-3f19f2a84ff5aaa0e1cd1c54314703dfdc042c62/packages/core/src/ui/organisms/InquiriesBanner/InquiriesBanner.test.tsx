import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { InquiriesBanner, InquiriesBannerProps } from "./InquiriesBanner";

afterEach(cleanup);

const props: InquiriesBannerProps = {
  title: "test title",
  latestInquries: [
    {
      id: 1,
      city: "chennai",
      category: "wedding-catering",
      name: "Jay***",
      date: 1585810761000,
      attributes: [
        {
          name: "Preferred cuisine",
          selected: "South Indian"
        },
        {
          name: "Event name",
          selected: "Wedding"
        },
        {
          name: "Budget",
          selected: "Below ₹250 per plate"
        },
        {
          name: "Number of guests",
          selected: "Less than 150"
        },
        {
          name: "Preferred food",
          selected: "Pure vegetarian"
        }
      ]
    },
    {
      id: 2,
      city: "chennai",
      category: "wedding-catering",
      name: "Kar***",
      date: 1585110761000,
      attributes: [
        {
          name: "Preferred cuisine",
          selected: "South Indian"
        },
        {
          name: "Event name",
          selected: "Wedding"
        },
        {
          name: "Budget",
          selected: "Below ₹250 per plate"
        },
        {
          name: "Number of guests",
          selected: "Less than 150"
        },
        {
          name: "Preferred food",
          selected: "Pure vegetarian"
        }
      ]
    },
    {
      id: 3,
      city: "chennai",
      category: "wedding-catering",
      name: "Kir***",
      date: 1515810761000,
      attributes: [
        {
          name: "Preferred cuisine",
          selected: "South Indian"
        },
        {
          name: "Event name",
          selected: "Wedding"
        },
        {
          name: "Budget",
          selected: "Below ₹250 per plate"
        },
        {
          name: "Number of guests",
          selected: "Less than 150"
        },
        {
          name: "Preferred food",
          selected: "Pure vegetarian"
        }
      ]
    },
    {
      id: 4,
      city: "chennai",
      category: "wedding-catering",
      name: "Vag***",
      date: 1581810761000,
      attributes: [
        {
          name: "Preferred cuisine",
          selected: "South Indian"
        },
        {
          name: "Event name",
          selected: "Wedding"
        },
        {
          name: "Budget",
          selected: "Below ₹250 per plate"
        },
        {
          name: "Number of guests",
          selected: "Less than 150"
        },
        {
          name: "Preferred food",
          selected: "Pure vegetarian"
        }
      ]
    }
  ]
};

describe("InquiriesBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(<InquiriesBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
