import * as React from "react";
import styled from "styled-components";
import { backgroundImage, Button, Logo, Pane, Text } from "../../";
import * as content from "../../../content";
import { DefaultStyles, defaultStyles } from "../../../utils/ui.utils";

export interface WeddingAssistBannerProps extends DefaultStyles {
  onAction: () => void;
  actionCaption: string;
}
const WeddingAssistBlock = styled("div")<WeddingAssistBannerProps>`
  img {
    display: block;
  }
  ${props => props.theme.media.desktop} {
    position: relative;
    img {
      display: none;
    }
    ${defaultStyles};
  }
  ${defaultStyles};
`;

const WeddingAssistFgDiv = styled(Pane)`
  margin: -4rem 1rem 1rem 1rem;
  padding: 2rem;
  display: flex;
  flex-flow: column;
  align-items: center;
  img {
    display: none;
  }

  ${props => props.theme.media.desktop} {
    margin: 2vw;
    height: 36vw;
    justify-content: center;
    position: absolute;
    top: 0;
    left: 50%;
    img {
      display: block;
      margin-bottom: 1rem;
    }
  }
`;
const BackgroundImg = styled("div")<{ image: string }>`
  ${props => backgroundImage(props.image)};
  height: 55vw;
  background-size: cover;
  background-position: center;
  transition: all 0.5s;
  ${props => props.theme.media.desktop} {
    height: 40vw;
    :focus,
    :hover {
      transform: scale(1.1);
    }
  }
`;
const BackgroundClr = styled("div")`
  display: none;
  background: ${props => props.theme.colors.gray5};
  ${props => props.theme.media.desktop} {
    display: block;
  }
`;
const WeddingAssistBkDiv = styled("div")`
  overflow: hidden;
  ${props => props.theme.media.desktop} {
    grid-template-columns: 2fr 1fr;
    display: grid;
    grid-template-areas:
      "bk-image"
      "bk-color";
  }
`;
export const WeddingAssistBanner: React.FC<WeddingAssistBannerProps> = React.memo(
  props => {
    return (
      <WeddingAssistBlock {...props}>
        <Logo type="weddingAssist" size="large" margin="major-2 0" />
        <WeddingAssistBkDiv>
          <BackgroundImg image="//www.weddingbazaar.com/assets/bg/wedding-assist-banner.jpg" />
          <BackgroundClr />
        </WeddingAssistBkDiv>
        <WeddingAssistFgDiv elevation="4">
          <Logo type="weddingAssist" size="small" />
          <Text fontSize={200} fontWeight="medium" color="primary">
            {content.mbazaar.weddingAssist.title}
          </Text>
          <Text
            margin="major-2 major-0"
            fontSize={150}
            textAlign="center"
            color="gray1"
          >
            {content.mbazaar.weddingAssist.content}
          </Text>
          <Button onClick={props.onAction}>{props.actionCaption}</Button>
        </WeddingAssistFgDiv>
      </WeddingAssistBlock>
    );
  }
);
