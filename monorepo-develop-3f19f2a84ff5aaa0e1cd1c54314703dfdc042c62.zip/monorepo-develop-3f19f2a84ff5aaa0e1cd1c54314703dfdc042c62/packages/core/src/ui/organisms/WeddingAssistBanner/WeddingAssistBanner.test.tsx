import { noop } from "@babel/types";
import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import {
  WeddingAssistBanner,
  WeddingAssistBannerProps
} from "./WeddingAssistBanner";

afterEach(cleanup);

const props: WeddingAssistBannerProps = {
  onAction: () => noop(),
  actionCaption: "See how it works"
};

describe("WeddingAssistBanner:", () => {
  it("renders correctly", () => {
    const { container } = render(<WeddingAssistBanner {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
