import { createGlobalStyle, DefaultTheme } from "styled-components";

export const GlobalStyle = createGlobalStyle`
@import url('https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700&display=swap');
html {
  font-size: 16px;
  ${props => props.theme.media.desktop} {
    font-size: 18px;
  } 
  body {
    margin: 0;
    overflow-x:hidden;
    background: #F3F3F3;
  } 
  body * {
    // user-select: none;
    font-family: ${props => props.theme.fontFamily};
    ${props => props.theme.media.desktop} {
      box-sizing: border-box;
      ::-webkit-scrollbar {
        height: 4px;              /* height of horizontal scrollbar ← You're missing this */
        width: 4px;               /* width of vertical scrollbar */
      }
      ::-webkit-scrollbar{
        self-alignment: inline;
        height: 8px;              /* height of horizontal scrollbar ← You're missing this */
        width: 8px;   
      }
      ::-webkit-scrollbar-track {
        box-shadow: inset 0 0 10px #ddd; 
        border-radius: 10px;
      }

      ::-webkit-scrollbar-thumb {
        background: #ddd; 
        border-radius: 10px;
      }

      ::-webkit-scrollbar-thumb:horizontal {
        background: #ddd;
        border-radius: 10px;
      }
    }
  } 
}
`;

export const theme: DefaultTheme = {
  borderRadius: "4px",
  fontFamily: "'Quicksand', sans-serif",
  fontWeight: {
    light: 300,
    regular: 400,
    medium: 500,
    semiBold: 600,
    bold: 700
  },
  fontSize: {
    xLarge: "1.2rem",
    large: "1rem",
    medium: "0.8rem",
    small: "0.6rem",
    xSmall: "0.4rem",
    900: "4.5rem",
    800: "3.75rem",
    700: "3rem",
    600: "2.5rem",
    500: "2rem",
    400: "1.5rem",
    300: "1.25rem",
    200: "1rem",
    150: ".875rem",
    100: "0.75rem",
    75: "0.62rem",
    50: "0.5625rem"
  },
  media: {
    mobile: `@media (max-width: 799px)`,
    desktop: `@media (min-width: 800px)`
  },
  colors: {
    primary: "#E94057",
    primaryFill: "#FFF2E9",
    accent1: "#00A651",
    accent2: "#F58220",
    accent3: "#E94057",

    black: "#231F20",
    white: "#FFFFFF",

    gray1: "#636466",
    gray2: "#939598",
    gray3: "#C7C8CA",
    gray4: "#E6E7E8",
    gray5: "#F4F4F4"
  },
  sizes: {
    mobile: `(max-width: 799px)`,
    desktop: `(min-width: 800px)`
  }
};
export const writerTheme: DefaultTheme = {
  ...theme,
  colors: {
    ...theme.colors,
    primary: "#00A651"
  }
};
