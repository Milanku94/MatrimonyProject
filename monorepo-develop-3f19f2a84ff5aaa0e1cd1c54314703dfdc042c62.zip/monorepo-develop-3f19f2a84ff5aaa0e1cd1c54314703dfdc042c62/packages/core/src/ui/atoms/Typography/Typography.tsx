import axios from "axios";
import React from "react";
import { Link, NavLink } from "react-router-dom";
import styled, { css } from "styled-components";
import * as content from "../../../content";
import { DomainContext } from "../../../contexts/DomainContext";
import { UserContext } from "../../../contexts/UserContext";
import { defaultStyles, DefaultStyles } from "../../../utils/ui.utils";
import { ThemeColors, ThemeFontSize, ThemeFontWeight } from "../../types/theme";

const TrackLink = (props: any) => {
  const { userId } = React.useContext(UserContext);
  const { domain, trackPageUrl } = React.useContext(DomainContext);
  if (domain === "writer") {
    return <Link {...props} />;
  }
  return (
    <Link
      {...props}
      onClick={async (e: any) => {
        await axios.post(trackPageUrl, {
          pageInfo: {
            id: userId,
            utmSource: "",
            utmContent: "",
            matchType: "",
            network: "",
            keyword: "",
            placement: "",
            campaign: "",
            adgroup: "",
            affiliation: "",
            assist: ""
          }
        });
        // await props.onClick(e);
      }}
    />
  );
};
export const TrackNavLink = (props: any) => {
  const { userId } = React.useContext(UserContext);
  const { domain, trackPageUrl } = React.useContext(DomainContext);
  if (domain === "writer") {
    return <NavLink {...props} />;
  }
  return (
    <NavLink
      {...props}
      onClick={async (e: any) => {
        await axios.post(trackPageUrl, {
          pageInfo: {
            id: userId,
            utmSource: "",
            utmContent: "",
            matchType: "",
            network: "",
            keyword: "",
            placement: "",
            campaign: "",
            adgroup: "",
            affiliation: "",
            assist: ""
          }
        });
        // await props.onClick(e);
      }}
    />
  );
};
export const StyledLink = styled(TrackLink)`
  color: initial;
  text-decoration: none;
  &:link {
    color: initial;
    text-decoration: none;
  }
  &:active {
    color: initial;
    text-decoration: none;
  }
  &:visited {
    color: initial;
    text-decoration: none;
  }
  &:hover {
    color: initial;
    text-decoration: none;
  }
`;
export interface TextProps extends DefaultStyles {
  fontSize?: keyof ThemeFontSize;
  fontWeight?: keyof ThemeFontWeight;
  color?: keyof ThemeColors;
}
interface BulletPointProps extends DefaultStyles {
  shape?: "round" | "square" | "no-bullet";
}
export const BulletPoint = styled("div")<BulletPointProps>`
  ${defaultStyles};
  min-width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.primary};
  //background-color: ${props =>
    props.shape ? "" : props.theme.colors.primary};
  color: ${props => props.theme.colors.white};
  display: flex;
  align-items: center;
  justify-content: center;
`;
export const Text = styled("div")<TextProps>`
  ${defaultStyles};
  font-family: ${props => props.theme.fontFamily};
  font-weight: ${props =>
    props.fontWeight && props.theme.fontWeight[props.fontWeight]};
  font-size: ${props => props.fontSize && props.theme.fontSize[props.fontSize]};
  color: ${props =>
    props.color ? props.theme.colors[props.color] : "inherit"};
`;

const headingReset = css`
  display: block;
  font-size: ${props => props.theme.fontSize[200]};
  margin-block-start: 0;
  margin-block-end: 0;
  margin-inline-start: 0;
  margin-inline-end: 0;
  font-weight: regular;
`;

export const H1 = styled(Text.withComponent("h1"))<TextProps>`
  ${headingReset}
  ${props => defaultStyles({ margin: "major-3", ...props })};
  font-weight: ${props => props.theme.fontWeight[props.fontWeight || "medium"]};
  font-size: ${props => props.theme.fontSize[props.fontSize || 500]};
`;

export const H2 = styled(Text.withComponent("h2"))<TextProps>`
  ${headingReset}
  ${props => defaultStyles({ margin: "major-2", ...props })};
  font-weight: ${props => props.theme.fontWeight[props.fontWeight || "medium"]};
  font-size: ${props => props.theme.fontSize[props.fontSize || 400]};
`;

export const H3 = styled(Text.withComponent("h3"))<TextProps>`
  ${headingReset}
  ${props => defaultStyles({ margin: "major-1", ...props })};
  font-weight: ${props => props.theme.fontWeight[props.fontWeight || "medium"]};
  font-size: ${props => props.theme.fontSize[props.fontSize || 300]};
`;
export const H4 = styled(Text.withComponent("h4"))<TextProps>`
  ${headingReset}
  ${props => defaultStyles({ margin: "major-1", ...props })};
  font-weight: ${props => props.theme.fontWeight[props.fontWeight || "medium"]};
  font-size: ${props => props.theme.fontSize[props.fontSize || 250]};
`;
export const Paragraph = styled(Text.withComponent("p"))<TextProps>`
  ${headingReset}
  ${props => defaultStyles({ margin: "0", marginBottom: "major-1", ...props })};
  font-weight: ${props =>
    props.theme.fontWeight[props.fontWeight || "regular"]};
  font-size: ${props => props.theme.fontSize[props.fontSize || 200]};
  line-height: 1.6rem;
`;
