import styled from "styled-components";
import { DefaultStyles, defaultStyles } from "../../../utils/ui.utils";
interface CardProps extends DefaultStyles {
  elevation?: "1" | "4" | "8";
  color?: string;
  radios?: string;
  border?: boolean;
}

/**
 * https://material-components.github.io/material-components-web-catalog/#/component/elevation
 */
const elevationRef = {
  "1": `0 2px 1px -1px rgba(0,0,0,.2),
    0 1px 1px 0 rgba(0,0,0,.14),
    0 1px 3px 0 rgba(0,0,0,.12)`,
  "4": `0 2px 4px -1px rgba(0,0,0,.2),
    0 4px 5px 0 rgba(0,0,0,.14),
    0 1px 10px 0 rgba(0,0,0,.12)`,
  "8": `0 5px 5px -3px rgba(0,0,0,.2),
    0 8px 10px 1px rgba(0,0,0,.14),
    0 3px 14px 2px rgba(0,0,0,.12)`
};

export const Pane = styled("div")<CardProps>`
  overflow: hidden;
  border-radius: ${props => props.radios};
  border: ${props => props.border && `1px solid ${props.theme.colors.gray1}`};
  background: ${props => props.theme.colors[props.color || "white"]};
  box-shadow: ${props => props.elevation && elevationRef[props.elevation]};
  ${defaultStyles}
`;
