import * as React from "react";
import styled from "styled-components";
import { Loader } from "../../components/Loader/Loader";
import { theme } from "../../theme";

export type ResponsiveImage = { mobile: string; desktop: string } | string;

interface PictureTagProps {
  transition?: "zoom";
  image: ResponsiveImage;
  alt?: string;
  width?: string;
  height?: string;
  onClick?: any;
  fullWidth?: boolean;
  onLoad?: any;
  imageRef?: React.RefObject<HTMLImageElement>;
  forceJPG?: boolean | null;
  rounded?: boolean;
}

export const getDesktopURL = (url: ResponsiveImage) =>
  typeof url === "string" ? url : url.desktop;
export const getMobileURL = (url: ResponsiveImage) =>
  typeof url === "string" ? url : url.mobile;

export const jpg2webp = (url: string) =>
  url && url.replace(/\.[j]*p[n]*[e]*g/, ".webp");

export const backgroundImage = (
  url: ResponsiveImage,
  backgroundSize: string = "cover",
  isGradientOverlay: boolean = false,
  backgroundColor: string = `#${Math.floor(Math.random() * 16777215).toString(
    16
  )}75`
) => `
.webp & {
  background-image: ${
    isGradientOverlay
      ? "linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),"
      : ""
  }
   url("${jpg2webp(getMobileURL(url))}");
  background-size: ${backgroundSize};
  background-color: ${backgroundColor};
}
.no-webp & {
  background-image:${
    isGradientOverlay
      ? "linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),"
      : ""
  }
   url("${getMobileURL(url)}");
  background-size: ${backgroundSize};
  background-color: ${backgroundColor};
}
${theme.media.desktop} {
  .webp & {
    background-image: ${
      isGradientOverlay
        ? "linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),"
        : ""
    }
     url("${jpg2webp(getDesktopURL(url))}");
    background-size: ${backgroundSize};
    background-color: ${backgroundColor};
  }
  .no-webp & {
    background-image: ${
      isGradientOverlay
        ? "linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),"
        : ""
    }
     url("${getDesktopURL(url)}");
    background-size: ${backgroundSize};
    background-color: ${backgroundColor};
  }  
}
`;

const StyledFragment = styled("div")<PictureTagProps>`
  img {
    transition: all 0.5s;
  }
  ${props =>
    props.transition &&
    `img:focus,
    img:hover {
      transform: scale(1.1);
    }`}
`;

export const PictureTag = (props: PictureTagProps) => {
  const imageRef = props.imageRef; // ? props.imageRef : React.useRef<HTMLImageElement>(null)
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (imageRef && imageRef.current && imageRef.current.complete) {
      setLoading(false);
    }
  }, [imageRef]);

  return (
    <StyledFragment {...props}>
      <picture
        onClick={props.onClick}
        style={{ lineHeight: 0, display: "block" }}
      >
        {!props.forceJPG && (
          <React.Fragment>
            <source
              media={theme.sizes.desktop}
              srcSet={jpg2webp(getDesktopURL(props.image))}
              type="image/webp"
            />
            <source
              media={theme.sizes.mobile}
              srcSet={jpg2webp(getMobileURL(props.image))}
              type="image/webp"
            />
          </React.Fragment>
        )}
        <source
          media={theme.sizes.desktop}
          srcSet={getDesktopURL(props.image)}
        />
        <source media={theme.sizes.mobile} srcSet={getMobileURL(props.image)} />
        <img
          loading="lazy"
          ref={imageRef}
          src={getDesktopURL(props.image)}
          alt={props.alt}
          width={props.width}
          height={props.height}
          style={{
            display: "block",
            width: props.fullWidth ? "100%" : props.width || "auto",
            objectFit: "cover",
            borderRadius: props.rounded ? "100%" : "none"
          }}
          onLoad={loadProps => {
            setLoading(false);
            const _ = !!props.onLoad && props.onLoad(loadProps);
          }}
          onError={errorProps => {
            setLoading(false);
          }}
        />
      </picture>
      {!!props.onLoad && loading ? <Loader /> : null}
    </StyledFragment>
  );
};

PictureTag.defaultProps = {
  alt: "image",
  fullWidth: true
};
