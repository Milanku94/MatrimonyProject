import React from "react";
import { theme } from "../../theme";
export interface IconProps {
  name: string;
  className?: string;
  style?: any;
  [key: string]: any;
}
export interface IconSheetProps extends IconProps {
  url: string;
  className?: string;
  style?: any;
}

export const Icon: React.FC<IconSheetProps> = (props: IconSheetProps) => {
  // There's an error here with importing external icon sheets -
  // Unsafe attempt to load URL <URL> from frame with URL <URL>. Domains, protocols and ports must match.
  // A fix I want to try is just deploying to the server to check if the files work.
  // Open to other ideas.
  // Also, code is not linted.
  // const url = `https://www.weddingbazaar.com/assets/icons/`;

  return (
    <svg viewBox="0 0 16 16" className={props.className || "icon"} {...props}>
      <use xlinkHref={`${props.url}#${props.name}`} />
    </svg>
  );
};

export const SiteIcon = React.memo((props: IconProps) => {
  const url = `/assets/icons/webicons.svg`;
  return (
    <Icon
      url={url}
      {...props}
      style={{
        width: "1rem",
        height: "1rem",
        fill: theme.colors.primary,
        verticalAlign: "middle",
        margin: "0.5rem",
        ...props.style
      }}
    />
  );
});
