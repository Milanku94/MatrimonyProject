import styled from "styled-components";
import { DefaultStyles, defaultStyles } from "../../../utils/ui.utils";
interface ButtonProps extends DefaultStyles {
  palette?: "primary" | "secondary" | "default";
}
const colorPaletteRef = {
  primary: { color: "white", background: "primary", border: "primary" },
  secondary: { color: "primary", background: "white", border: "white" },
  default: { color: "primary", background: "white", border: "primary" }
};

export const Button = styled("button")<ButtonProps>`
  border-radius: 3px;
  color: ${props =>
    props.palette && props.theme.colors[colorPaletteRef[props.palette].color]};
  background-color: ${props =>
    props.palette &&
    props.theme.colors[colorPaletteRef[props.palette].background]};
  font-size: ${props => props.theme.fontSize[150]};
  border: 1px solid
    ${props =>
      props.palette &&
      props.theme.colors[colorPaletteRef[props.palette].border]};
  cursor: pointer;
  ${props =>
    props.palette === "default" &&
    `:hover{
    background-color: ${props.theme.colors[colorPaletteRef.default.color]}
    color: ${props.theme.colors[colorPaletteRef.default.background]}
  }`}
  ${defaultStyles};
`;
Button.defaultProps = {
  padding: "major-1 major-2",
  palette: "default"
};
