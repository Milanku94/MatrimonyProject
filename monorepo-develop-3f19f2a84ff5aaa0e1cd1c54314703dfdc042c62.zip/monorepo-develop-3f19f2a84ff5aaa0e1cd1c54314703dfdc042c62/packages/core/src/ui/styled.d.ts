import "styled-components";
import {
  ThemeFontSize,
  ThemeFontWeight,
  ThemeColors,
  ThemeDevices
} from "./types/theme";
export declare module "styled-components" {
  export interface DefaultTheme {
    borderRadius: string;
    fontFamily: string;
    fontSize: ThemeFontSize;
    fontWeight: ThemeFontWeight;
    colors: ThemeColors;
    media: ThemeDevices;
    sizes: ThemeDevices;
  }
}
