import React from "react";

interface LocationContextProps {
  city: string;
  setCity: ({ city }: { city: string }) => void;
}

export const LocationContext = React.createContext<LocationContextProps>({
  city: "bangalore",
  setCity: ({ city }: { city: string }) => null
});
