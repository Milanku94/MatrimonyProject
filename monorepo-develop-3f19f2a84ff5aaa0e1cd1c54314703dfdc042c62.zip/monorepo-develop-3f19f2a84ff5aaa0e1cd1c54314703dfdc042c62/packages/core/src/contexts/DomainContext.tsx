import React from "react";
import { Domains } from "../content/types";
export interface DomainContextProps {
  domain: Domains;
  trackPageUrl: string;
  trackEventUrl: string;
}
export const DomainContext = React.createContext<DomainContextProps>({
  domain: Domains.mBazaar,
  trackPageUrl: "",
  trackEventUrl: ""
});
