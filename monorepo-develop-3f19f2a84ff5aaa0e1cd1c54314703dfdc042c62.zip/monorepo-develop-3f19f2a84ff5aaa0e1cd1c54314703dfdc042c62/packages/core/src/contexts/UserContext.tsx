import React from "react";

interface UserContextProps {
  userId?: string;
  userName?: string;
  role?: string;
}

export const UserContext = React.createContext<UserContextProps>({
  userId: undefined,
  userName: undefined,
  role: "GUEST"
});
