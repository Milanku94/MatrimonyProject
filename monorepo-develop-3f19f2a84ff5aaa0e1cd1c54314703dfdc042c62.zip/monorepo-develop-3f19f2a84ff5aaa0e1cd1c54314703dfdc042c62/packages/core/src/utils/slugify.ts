export const slugify = (name: string, options: any = {}) => {
  const defaultOptions = {
    lowercase: true,
    trim: true,
    spaces: true,
    nonWord: true,
    multipleHyphen: true,
    ampersand: true
  };
  const opt = { ...defaultOptions, ...options };
  let str = name;
  str = opt.lowercase ? str.toLowerCase() : str;
  str = opt.trim ? str.trim() : str;
  str = opt.spaces ? str.replace(/\s+/g, "-") : str; // Replace spaces with -
  str = opt.nonWord ? str.replace(/[^\w\-]+/g, "") : str; // Remove all non-word chars
  str = opt.multipleHyphen ? str.replace(/\-\-+/g, "-") : str; // Replace multiple - with single -
  str = opt.ampersand ? str.replace(/&/g, "-and-") : str; // Replace & with 'and'
  return str;
};
