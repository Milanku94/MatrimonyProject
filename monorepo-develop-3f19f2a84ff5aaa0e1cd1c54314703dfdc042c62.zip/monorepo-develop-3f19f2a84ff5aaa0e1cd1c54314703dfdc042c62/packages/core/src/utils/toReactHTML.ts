import insane from "insane";
import marked from "marked";

export const toReactHTML = (content: string) => {
  return {
    dangerouslySetInnerHTML: {
      __html: insane(marked(content, { sanitize: false, gfm: true }), {})
    }
  };
};
