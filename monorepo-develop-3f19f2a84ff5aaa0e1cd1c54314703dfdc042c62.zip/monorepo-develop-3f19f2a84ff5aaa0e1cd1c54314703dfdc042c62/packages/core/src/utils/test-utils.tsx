import { render } from "@testing-library/react";
import "jest-dom/extend-expect";
import * as React from "react";
import { ThemeProvider } from "styled-components";
import { GlobalStyle, theme } from "../ui/theme";

const AllTheProviders = ({ children }: any) => {
  return (
    <ThemeProvider theme={theme}>
      <React.Fragment>
        {children}
        <GlobalStyle />
      </React.Fragment>
    </ThemeProvider>
  );
};

const customRender = (ui: any, options?: any) =>
  render(ui, { wrapper: AllTheProviders, ...options });

// re-export everything
export * from "@testing-library/react";

// override render method
export { customRender as render };
