export const getKeys = (obj: { [key: string]: any }) => Object.keys(obj);

const spaceRef = {
  "!minor": -0.25,
  "!major": -0.5,
  minor: 0.25,
  major: 0.5
};

/**
 * Responsible to convert the measurement size into Nrem
 * @param measurement i.e, "minor-6" | "major-3" | "minor-1 major-2"
 */
export const space = (measurement: string): string | any => {
  const spacedArray = measurement.split(" ");
  if (spacedArray.length > 1) {
    return spacedArray.map(space).join(" ");
  }
  if (["0", "auto"].includes(measurement)) {
    return measurement;
  }
  const [type, n] = measurement.split("-");
  return +n * spaceRef[type] + "rem";
};

export interface DefaultStyles {
  textAlign?:
    | "start"
    | "end"
    | "left"
    | "right"
    | "center"
    | "justify"
    | "initial"
    | "inherit";
  padding?: string;
  paddingTop?: string;
  paddingBottom?: string;
  paddingLeft?: string;
  paddingRight?: string;
  margin?: string;
  marginTop?: string;
  marginBottom?: string;
  marginLeft?: string;
  marginRight?: string;
}
// export const customStyled:ThemedStyledInterface<DefaultStyles> = (
//   component: AnyStyledComponent,
// ) =>
//   styled(component)<DefaultStyles>`
//     ${props => defaultStyles(props)}
//   `;
export const defaultStyles = ({
  textAlign,
  padding,
  paddingBottom,
  paddingLeft,
  paddingRight,
  paddingTop,
  margin,
  marginTop,
  marginBottom,
  marginLeft,
  marginRight
}: DefaultStyles) => `
  ${textAlign ? `text-align:  ${textAlign}` : ""};

  ${padding ? `padding:  ${space(padding)}` : ""};
  ${paddingTop ? `padding-top: ${space(paddingTop)}` : ""};
  ${paddingBottom ? `padding-bottom:  ${space(paddingBottom)}` : ""};
  ${paddingLeft ? `padding-left:  ${space(paddingLeft)}` : ""};
  ${paddingRight ? `padding-right:  ${space(paddingRight)}` : ""};
  
  ${margin ? `margin: ${space(margin)}` : ""};
  ${marginTop ? `margin-top: ${space(marginTop)}` : ""};
  ${marginBottom ? `margin-bottom: ${space(marginBottom)}` : ""};
  ${marginLeft ? `margin-left: ${space(marginLeft)}` : ""};
  ${marginRight ? `margin-right: ${space(marginRight)}` : ""};
`;
