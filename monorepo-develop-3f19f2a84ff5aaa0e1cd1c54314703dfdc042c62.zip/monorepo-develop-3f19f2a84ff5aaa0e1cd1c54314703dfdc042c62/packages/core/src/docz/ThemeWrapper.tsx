import * as React from "react";
import { BrowserRouter } from "react-router-dom";
import { ThemeProvider } from "styled-components";
import { GlobalStyle, theme } from "../ui/theme";

const Wrapper: React.FC = ({ children }) => (
  <BrowserRouter>
    <ThemeProvider theme={theme}>
      <React.Fragment>
        <div className=" no-webp">{children}</div>
        <GlobalStyle />
      </React.Fragment>
    </ThemeProvider>
  </BrowserRouter>
);

export default Wrapper;
