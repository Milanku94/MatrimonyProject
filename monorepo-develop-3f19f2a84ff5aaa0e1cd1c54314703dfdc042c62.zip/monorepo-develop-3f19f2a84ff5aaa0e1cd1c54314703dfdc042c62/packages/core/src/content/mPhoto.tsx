import { MPhotoContent, SocialPlatform } from "./types";

export const mPhoto: MPhotoContent = {
  name: "Matrimony Photography",
  legalName: "Matrimony.com Ltd",
  url: "https://matrimonyphotography.com",
  logo: "https://www.matrimonyphotography.com/images/icons/icon-144x144.png",
  phoneNumber: "7448522222",
  vendorOnBoard: "",
  mail: "care@matrimonyphotography.com",
  partnerBanner: {
    title: `Become a MatrimonyPhotography partner`,
    content: `If you’d like an opportunity to be a part of our exclusive network of incredibly talented photographers and videographers, 
    then reach out to us today! With our broad base of customers, you’ll be able to scale your business to greater heights.
     Reach out to us on`
  },
  howTrustUs: {
    title: `MatrimonyPhotography is your one-stop-shop for all your wedding photography and videography needs.`,
    // title:`MatrimonyPhotography is an exclusive service that finds you the best photography solutions for your wedding.`,
    points: [
      {
        metric: `999+`,
        highlight: `Trusted photography solutions`,
        desc: `Verified, vetted, and over decades worth of experience in wedding photography, our photographers
          meet the highest standards of professionalism and quality. All our photographers meet the
          industry-leading benchmark set by CRISIL™`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "verified-shield"
      },
      {
        metric: `1430+`,
        highlight: `Memories captured`,
        desc: `Happy Marriages = Happy life = Happy Smiles = us. The MatrimonyPhotography family has covered over 20,000
          happy weddings all over India, leaving couples and family members smiling far and wide. Our goal is to make sure
          that you receive the best service, no matter the budget, location, and requirement`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "wedding-ring"
      },
      {
        metric: `17%`,
        highlight: `Quality first approach`,
        desc: `MatrimonyPhotography is built on a platform that has matchmaking and wedding planning in our DNA.
          The collective expertise acquired over the years has enabled us to deliver customer satisfaction at a
          deeper level.  The MatrimonyPhotography family goes above and beyond to ensure that you get the best
          photography solution for your wedding.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "exclusive-deals"
      }
    ]
  },
  whyUs: {
    title: `Why you should choose `,
    subtitle: "MatrimonyPhotography",
    steps: [
      {
        icon: "crisil_verified",
        strong: `CRISIL™`,
        followup: `verified photographers.`
      },
      { icon: "no-hidden-fees", strong: `No`, followup: `hidden fees` },
      {
        icon: "right-tick",
        strong: `Complete`,
        followup: `wedding photography solution`
      }
      // {
      //   strong: `A one-stop-shop`,
      //   followup: `for all your photography-related services.`
      // }
    ]
  },
  whyAssist: {
    title: `Why WeddingAssist? `,
    points: [
      {
        icon: "",
        strong: `Get connected to trusted,verified,and the top service provides in the industry`
      },
      {
        icon: "",
        strong: `A qualified marriage planner negotiation on your behalf with service providers`
      },
      {
        icon: "",
        strong: `Guaranteed hassle-free wedding planner experience including wedding day coordination`
      }
      // {
      //   strong: `A one-stop-shop`,
      //   followup: `for all your photography-related services.`
      // }
    ],
    icon: ""
  },

  howItWorks: {
    title: "Find and book trusted photographers without any stress",
    steps: [
      {
        short: "Share your requirements",
        long: `Share your requirements by calling us, chatting with us, or via our website`
      },
      {
        short: "Get expert help",
        long: `Talk to a wedding planning expert and understand the offers, discounts,
          and services you can avail via us`
      },
      {
        short: "Get Quotation",
        long: `Get quotes from a curated list of service providers`
      },
      {
        short: "Book service provider",
        long: `Finalize and book the service provider(s) based on your budget and requirements`
      }
    ]
  },
  links: [
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Chennai",
      to: "/chennai"
    },
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Bangalore",
      to: "/bangalore"
    },
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Hyderabad",
      to: "/hyderabad"
    },
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Kollam",
      to: "/kollam"
    },
    {
      label: "How it works",
      to: "/how-it-works"
    },
    {
      label: "Book a Shoot",
      to: "/book-a-shoot?city=chennai&category=wedding-photographers&ref=header"
    }
  ],
  socialLinks: [
    {
      platform: SocialPlatform.facebook,
      label: "nav to fb",
      id: "MatrimonyPhotography/"
    },
    {
      platform: SocialPlatform.youtube,
      label: "nav to youtube",
      id: "UCLGsyWTHgbX2iMDFeFVAT3w"
    }
  ],
  testimonials: [
    {
      bride: "Divya",
      groom: "Saravanan",
      location: "Chennai",
      story:
        "Wedding Assist by WeddingBazaar was a life saver. We were so worried about running around for all the wedding arrangements and applying for long leaves. Thank you, WeddingBazaar team for making our wedding planning easy.",
      categories: ["Photography"],
      image: "//www.weddingbazaar.com/assets/img/saravanan-divya.jpg"
    },
    {
      bride: "Sangeetha",
      groom: "Selvam",
      location: "Chennai",
      story:
        "We never thought planning a wedding would be this easy. Thank you WeddingBazaar for making life easy for us. We are so happy that we found your website and our guests were extremely happy with the food we served.",
      categories: ["Photography"],
      image: "//www.weddingbazaar.com/assets/img/selvam-sangeetha.jpg"
    },
    {
      bride: "Sunitha",
      groom: "Rajesh",
      location: "Chennai",
      story:
        "We were thrilled to find out that Bharat Matrimony could help us with wedding planning as well. Our wedding was praised by all our guests and we are extremely grateful to WeddingBazaar’s wedding assist team for helping us pull this off.",
      categories: ["Photography"],
      image: "//www.weddingbazaar.com/assets/img/sunitha.jpg"
    }
  ],
  covidSemData: {
    title: `Organise a wedding for under 50 guests by following all lockdown rules and regulations by the Government`,
    points: [
      {
        metric: `${Math.round(
          (new Date().getTime() - new Date("2020-01-01").getTime()) / 1000000
        )}+`,
        highlight: `COVID-safe`,
        desc: `All our service providers are on the AarogyaSetu App. COVID-safe measures like using alcohol-based sanitizers, face masks & shields, gloves & mandatory temperature checks for employees are done before every event.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "verified-shield"
      },
      {
        metric: `${Math.round(
          (new Date().getTime() - new Date("2019-01-01").getTime()) / 2000000
        )}+`,
        highlight: `Affordable`,
        desc: `COVID-19 has brought the entire world in an economic turmoil that was never heard of. That is why we are bringing this service to you at no cost! We are the bridge between you - the customer, and the service provider who is in need of your help.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "wedding-ring"
      },
      {
        metric: `17%`,
        highlight: `At Home`,
        desc: `We help you plan an intimate traditional wedding with a big heart! Stay at home and plan your entire cosy wedding on voice/video calls and WhatsApp. Stay home, stay safe, and plan a wedding.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "exclusive-deals"
      }
    ]
  },
  howItCovidSemWorks: {
    title: "How it works",
    subtitle:
      "Find COVID-safe Pandits, Caterers, Decorators, Makeup artists and Photographers, all in one place!",
    steps: [
      {
        strong: "Share your requirements",
        followup: `Let us know what you’re looking for by calling us, chatting with us, or via our website.`
      },
      {
        strong: "Get expert help",
        followup: `Our wedding planning expert will understand your requirements and will help you with a curated list of service providers who can arrange the wedding for you while adhering to the government regulations.`
      },
      {
        strong: "Get curated quotes",
        followup: `Get quotes from the best COVID-safe wedding service providers near you.`
      },
      {
        strong: "Book the service providers",
        followup: `Finalize and book the wedding service provider(s) based on your budget and requirements.`
      },
      {
        strong: "Have a serene and tension-free wedding ",
        followup: `Sit back and relax while our COVID-safe service providers arrive at your doorstep for a safe yet beautiful wedding.`
      }
    ]
  },
  covidSemBanner: {
    title: `Do you want to signup as a WeddingBazaar verified service partner?`,
    content: `Are you a service provider who can help our customers organise their wedding from home?`
  },
  howItCrisilSemWorks: {
    title: "How does this work",
    subtitle: "",
    steps: [
      {
        strong:
          "Any service provider listed on WeddingBazaar can opt for CRISIL verification",
        followup: ``
      },
      {
        strong:
          "Upon submitting the required documents, the verification process will start",
        followup: ``
      },
      {
        strong:
          "Post the completion of the verification process the service provider will receive a CRISIL-verified badge which will be displayed on their WeddingBazaar profile page",
        followup: ``
      },
      {
        strong:
          "Once the customer sees a CRISIL verified badge on the WeddingBazaar profile page, it will create reliability and trust on that particular service provider",
        followup: ``
      }
    ]
  }
};
