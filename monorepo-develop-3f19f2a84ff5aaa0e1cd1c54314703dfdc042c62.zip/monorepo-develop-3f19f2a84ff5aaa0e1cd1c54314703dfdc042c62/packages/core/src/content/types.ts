export interface LinkProps {
  to: string;
  label: string;
  type?: string;
  picture?: string;
  external?: boolean;
  desktop?: boolean;
  mobile?: boolean;
  header?: boolean;
  footer?: boolean;
}
export enum SocialPlatform {
  facebook = "facebook",
  twitter = "twitter",
  instagram = "instagram",
  pinterest = "pinterest",
  youtube = "youtube"
}
export enum Domains {
  mBazaar = "mbazaar",
  mPhoto = "mphoto",
  writer = "writer"
}

interface WhyUs {
  title: string;
  subtitle: string;
  steps: Array<{ icon?: string; strong: string; followup: string }>;
}
export interface DomainCommonContent {
  name: string;
  legalName: string;
  url: string;
  logo: string;
  mail: string;
  phoneNumber: string;
  vendorOnBoard: string;
  links: LinkProps[];
  partnerBanner: {
    title: string;
    content: string;
  };
  covidSemBanner: {
    title: string;
    content: string;
  };
  howTrustUs: {
    title: string;
    points: Array<{
      metric: string;
      icon: string;
      highlight: string;
      desc: string;
      showIn: {
        desktop: boolean;
        mobile: boolean;
      };
    }>;
  };
  howItWorks: { title: string; steps: Array<{ short: string; long: string }> };
  howItCovidSemWorks: WhyUs;
  howItCrisilSemWorks: WhyUs;
  whyUs: WhyUs;
  whyAssist: {
    title: string;
    points: Array<{ icon?: string; strong: string }>;
    icon: string;
  };
  socialLinks: Array<{
    platform: SocialPlatform;
    label: string;
    id: string;
  }>;
  testimonials: Array<{
    bride: string;
    groom: string;
    location: string;
    story: string;
    categories: string[];
    image: string;
  }>;
  covidSemData: {
    title: string;
    points: Array<{
      metric: string;
      icon: string;
      highlight: string;
      desc: string;
      showIn: {
        desktop: boolean;
        mobile: boolean;
      };
    }>;
  };
}

export interface MBazaarContent extends DomainCommonContent {
  partnerApp: {
    name: string;
    web: string;
    android: string;
    ios: string;
  };
  weddingStories: { title: string; content: string };
  weddingAssist: {
    title: JSX.Element;
    content: string;
  };
  whyWeddingAssist: {
    title: string;
    content: {
      header: { ours: string; typical: string };
      points: Array<{
        oursIcon?: string;
        ours: string;
        oursName?: string;
        typicalName?: string;
        typical: string;
        typicalIcon: string;
      }>;
    };
  };
  crisilAdvantages: {
    title: string;
    content: {
      header: { ours: string; typical: string };
      points: Array<{
        oursIcon?: string;
        ours: string;
        typical: string;
        typicalIcon: string;
      }>;
    };
  };
}
export interface MPhotoContent extends DomainCommonContent {}
