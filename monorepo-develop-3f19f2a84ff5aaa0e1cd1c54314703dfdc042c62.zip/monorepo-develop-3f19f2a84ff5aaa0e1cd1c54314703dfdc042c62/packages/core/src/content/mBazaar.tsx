import * as React from "react";
import { MBazaarContent, SocialPlatform } from "./types";

export const mBazaar: MBazaarContent = {
  name: "Wedding Bazaar",
  legalName: "Matrimony.com Ltd",
  url: "https://weddingbazaar.com",
  logo: "https://www.weddingbazaar.com/images/icons/icon-144x144.png",
  phoneNumber: "8124222266",
  vendorOnBoard: "/become-a-partner",
  mail: "care@weddingbazaar.com",
  partnerBanner: {
    title: `Do you want to signup as a WeddingBazaar verified service partner?`,
    content: `Join our team of professional service providers who help organise thousands of weddings every month. With benefits like enriched profile pages, exclusive access to thousands of matches made via BharatMatrimony, and much more. Check out our various packages now!`
  },
  partnerApp: {
    name: "WeddingBazaar Partner",
    web: "//www.weddingbazaar.com/onboard-vendor/",
    android:
      "//play.google.com/store/apps/details?id=com.matrimonybazaar.vendor&hl=en",
    ios: "//apps.apple.com/in/app/mb-partner/id1487910363"
  },
  howTrustUs: {
    title: `WeddingBazaar is a trusted platform which helps you plan your dream wedding in a hassle-free manner.`,
    points: [
      {
        metric: `${Math.round(
          (new Date().getTime() - new Date("2020-01-01").getTime()) / 1000000
        ) + 9000}+`,
        highlight: `Verified service providers`,
        desc: `WeddingBazaar is India’s most trusted platform for wedding services.
          Each and every service provider we connect you and your family with has
          gone through our stringent KYC process before being onboarded onto our platform.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "verified-shield"
      },
      {
        metric: `${Math.round(
          (new Date().getTime() - new Date("2019-01-01").getTime()) / 2000000
        )}+`,
        highlight: `Happy weddings planned`,
        desc: `WeddingBazaar is a one-stop destination for all things wedding
          related. Whether you’re looking to shortlist and book the best
          wedding service providers or read about the latest trends in the
          wedding planning industry, you’re at the right place.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "wedding-ring"
      },
      {
        metric: `17%`,
        highlight: `Average savings per wedding`,
        desc: `WeddingBazaar ensures that you get the most value for the money
          you spend on your wedding. Our exclusive partnerships, packages,
          and discounts ensure that you get benefits that are unheard of in
          the wedding planning industry.`,
        showIn: {
          desktop: true,
          mobile: true
        },
        icon: "exclusive-deals"
      }
    ]
  },
  whyUs: {
    title: `Why choose us`,
    subtitle: "We make wedding planning simple, hassle-free, and fun",
    steps: [
      {
        icon: "right-tick",
        strong: `Trusted and verified`,
        followup: `Service providers`
      },
      {
        icon: "no-hidden-fees",
        strong: `No hidden fees`,
        followup: `Absolutely none`
      },
      {
        icon: "one-stop-shop",
        strong: `One-stop shop`,
        followup: `From catering to honeymoon packages, plan it all here`
      }
    ]
  },
  whyAssist: {
    title: `Why WeddingAssist? `,
    points: [
      {
        icon: "asset",
        strong: `Get connected to trusted, verified, and top service providers in the industry`
      },
      {
        icon: "asset",
        strong: `A qualified wedding planner will negotiate on your behalf with service providers`
      },
      {
        icon: "asset",
        strong: `Guaranteed hassle-free wedding planning experience including wedding-day coordination`
      }
    ],
    icon: "wedding-assist"
  },
  howItWorks: {
    title: "Find trusted wedding service providers without any stress",
    steps: [
      {
        short: "Share your requirements",
        long: `Share your requirements by calling us, chatting with us, or via our website`
      },
      {
        short: "Get expert help",
        long: `Talk to a wedding planning experts and understand the offers, discounts,
          and services you can avail via us`
      },
      {
        short: "Get Quotation",
        long: `Get quotes from a curated list of service providers`
      },
      {
        short: "Book service provider",
        long: `Finalize and book the service provider(s) based on your budget and requirements`
      }
    ]
  },
  weddingStories: {
    title: "Wedding Stories",
    content: `At WeddingBazaar, we believe in the uniqueness and beauty of each
      couple and the stories behind their marriage and wedding. Our
      'Wedding Stories' section is an attempt to showcase some of our
      favourite stories to help inspire more couples and families.`
  },
  weddingAssist: {
    title: <>What is WeddingAssist</>,
    content: `WeddingAssist is a personalized wedding services platform brought to
      you by WeddingBazaar, that helps you plan your wedding with a
      qualified wedding planner.`
  },
  whyWeddingAssist: {
    title: "WeddingAssist Value",
    content: {
      header: {
        ours: "WeddingAssist",
        typical: "Typical Route"
      },
      points: [
        {
          oursIcon: "time-guy",
          typicalIcon: "notepad",
          oursName: `Expert Wedding Planner`,
          typicalName: `Too Many Hassles`,
          ours: `Dedicated wedding planning expert takes care of research and
            scheduling for you`,
          typical: `Do homework, research, and set up meetings by yourself or ask
            for favours`
        },
        {
          oursIcon: "percentage",
          typicalIcon: "hot-price",
          oursName: `Best Price`,
          typicalName: `Bargaining Skills Required`,
          ours: `Your dedicated wedding planning expert will bargain on your
            behalf`,
          typical: `Use your bargaining skills and limited knowledge of prevalent
            market prices`
        },
        {
          oursIcon: "coupon",
          typicalIcon: "fixprice",
          oursName: `No Hidden Costs`,
          typicalName: `Hidden Costs`,
          ours: `Exclusive packages and discounts. No hidden costs`,
          typical: `Fixed prices at the start followed by piling costs and high
            advance requirements`
        },
        {
          oursIcon: "verify",
          typicalIcon: "questionmark",
          oursName: `Verified`,
          typicalName: `Unverified`,
          ours: `Verified service providers and we remain your single point
            of contact`,
          typical: `Unverified service providers and multiple unsolicited calls
            disturbing your peace of mind`
        },
        {
          oursIcon: "money",
          typicalIcon: "headach",
          oursName: `Affordable`,
          typicalName: `Unaffordable`,
          ours: `One-time nominal fee`,
          typical: `Costs: headaches, sleepless nights, and hidden costs`
        },
        {
          oursIcon: "love",
          typicalIcon: "stress",
          oursName: `Wedding Day Coordination`,
          typicalName: `Wedding Day Coordination`,
          ours: `Guaranteed hassle-free wedding planning experience including
            wedding-day coordination`,
          typical: `Stress due to coordination on the day of the wedding and the
            days leading up to the wedding`
        }
        // {
        // oursIcon: "",
        // typicalIcon: "",
        //   ours: `The co-ordination makes life hectic and leaves you and your smiles
        //     out of the celebrations and family portraits`,
        //   typical: `We deliver a hassle-free experience so that you can celebrate the
        //   occasion while having peace of mind.`
        // }
      ]
    }
  },
  crisilAdvantages: {
    title: "",
    content: {
      header: {
        ours: "Advantages for customers",
        typical: "Advantages for service providers"
      },
      points: [
        {
          oursIcon: "pointer-icon",
          typicalIcon: "pointer-icon",
          ours: `Customers can now find the most reliable service providers verified by the best rating agency in India`,
          typical: `Instant recognition by the customers and a higher chance of conversions`
        },
        {
          oursIcon: "pointer-icon",
          typicalIcon: "pointer-icon",
          ours: `Guaranteed high-quality service by the verified service providers`,
          typical: `Creates trust and good impression on the brand once it is verified by CRISIL `
        },
        {
          oursIcon: "pointer-icon",
          typicalIcon: "pointer-icon",
          ours: `Additional information on the service providers will be displayed on the profile page`,
          typical: `A boost in online presence which in turn increases brand visibility`
        },
        {
          oursIcon: "pointer-icon",
          typicalIcon: "pointer-icon",
          ours: `Customers can now sit back relax because of the thorough verification process`,
          typical: `Opportunity to attract global customers thereby increasing the chances of business growth`
        }
      ]
    }
  },
  links: [
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Services",
      to: "/chennai",
      footer: false
    },
    {
      label: "How it works",
      to: "/how-it-works"
    },
    // {
    //   label: "HomeWeddings",
    //   to: "/home-weddings"
    // },
    {
      label: "Ideas & Inspirations",
      to: "/ideas"
    },
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Wedding Stories",
      to: "/wedding-stories"
    },
    // {
    //   picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
    //   label: "Partner Stories",
    //   to: "/partner-stories"
    // },
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-wedding-assist.svg",
      label: "WeddingAssist",
      to: "/wedding-assist"
    },
    {
      type: "separator",
      to: "string",
      label: "string"
    },
    {
      label: "Submit Wedding Story",
      to: "//goo.gl/forms/M4jfYYuFVL4FffGk1",
      external: true,
      header: false
    },
    {
      label: "Vendor Sign up",
      to: "/become-a-partner",
      external: true,
      footer: false
    },
    {
      label: "Media",
      to: "/media",
      header: false
    },
    {
      label: "CRISIL",
      to: "/crisil",
      header: false
    }
  ],
  socialLinks: [
    /**
     * platform: SocialPlatform.facebook,
     * label: "nav to fb/instagram/ so on",
     * id: "WeddingBazaar"  i.e, https://www.facebook.com/WeddingBazaar
     */
    {
      platform: SocialPlatform.facebook,
      label: "nav to fb",
      id: "WeddingBazaarOff/"
    },
    {
      platform: SocialPlatform.twitter,
      label: "nav to twitter",
      id: "Wedding_Bazaar"
    },
    {
      platform: SocialPlatform.instagram,
      label: "nav to instagram",
      id: "weddingbazaarofficial/?igshid=1at44juifia63"
    },
    {
      platform: SocialPlatform.pinterest,
      label: "nav to pinterest",
      id: "weddingbazaarofficial/"
    },
    {
      platform: SocialPlatform.youtube,
      label: "nav to youtube",
      id: "UCt1-NmgeaECOrKkmKDvkMjg"
    }
  ],
  testimonials: [
    {
      bride: "Divya",
      groom: "Saravanan",
      location: "Chennai",
      story:
        "Wedding Assist by WeddingBazaar was a life saver. We were so worried about running around for all the wedding arrangements and applying for long leaves. Thank you, WeddingBazaar team for making our wedding planning easy.",
      categories: ["Catering", "Photography"],
      image: "//www.weddingbazaar.com/assets/img/saravanan-divya.jpg"
    },
    {
      bride: "Sangeetha",
      groom: "Selvam",
      location: "Chennai",
      story:
        "We never thought planning a wedding would be this easy. Thank you WeddingBazaar for making life easy for us. We are so happy that we found your website and our guests were extremely happy with the food we served.",
      categories: ["Catering"],
      image: "//www.weddingbazaar.com/assets/img/selvam-sangeetha.jpg"
    },
    {
      bride: "Sunitha",
      groom: "Rajesh",
      location: "Chennai",
      story:
        "We were thrilled to find out that Bharat Matrimony could help us with wedding planning as well. Our wedding was praised by all our guests and we are extremely grateful to WeddingBazaar’s wedding assist team for helping us pull this off.",
      categories: ["Catering", "Decoration"],
      image: "//www.weddingbazaar.com/assets/img/sunitha.jpg"
    }
  ],
  covidSemData: {
    title: `Organise a wedding for under 50 guests by following all lockdown rules and regulations by the Government`,
    points: [
      {
        metric: `${Math.round(
          (new Date().getTime() - new Date("2020-01-01").getTime()) / 1000000
        )}+`,
        icon: "virus-icon",
        highlight: `COVID-safe`,
        desc: `All our service providers are on the AarogyaSetu App. COVID-safe measures like using alcohol-based sanitizers, face masks & shields, gloves & mandatory temperature checks for employees are done before every event.`,
        showIn: {
          desktop: true,
          mobile: true
        }
      },
      {
        metric: `${Math.round(
          (new Date().getTime() - new Date("2019-01-01").getTime()) / 2000000
        )}+`,
        icon: "hand-icon",
        highlight: `Affordable`,
        desc: `COVID-19 has brought the entire world in an economic turmoil that was never heard of. That is why we are bringing this service to you at no cost! We are the bridge between you - the customer, and the service provider who is in need of your help.`,
        showIn: {
          desktop: true,
          mobile: true
        }
      },
      {
        metric: `17%`,
        icon: "home-icon",
        highlight: `At Home`,
        desc: `We help you plan an intimate traditional wedding with a big heart! Stay at home and plan your entire cosy wedding on voice/video calls and WhatsApp. Stay home, stay safe, and plan a wedding.`,
        showIn: {
          desktop: true,
          mobile: true
        }
      }
    ]
  },
  howItCovidSemWorks: {
    title: "How it works",
    subtitle:
      "Find COVID-safe Pandits, Caterers, Decorators, Makeup artists and Photographers, all in one place!",
    steps: [
      {
        icon: "share-req",
        strong: "Share your requirements",
        followup: `Let us know what you’re looking for by calling us, chatting with us, or via our website.`
      },
      {
        icon: "expert-help",
        strong: "Get expert help",
        followup: `Our wedding planning expert will understand your requirements and will help you with a curated list of service providers who can arrange the wedding for you while adhering to the government regulations.`
      },
      {
        icon: "curated-quotes",
        strong: "Get curated quotes",
        followup: `Get quotes from the best COVID-safe wedding service providers near you.`
      },
      {
        icon: "book-service",
        strong: "Book the service providers",
        followup: `Finalize and book the wedding service provider(s) based on your budget and requirements.`
      },
      {
        icon: "tension-free",
        strong: "Have a serene and tension-free wedding ",
        followup: `Sit back and relax while our COVID-safe service providers arrive at your doorstep for a safe yet beautiful wedding.`
      }
    ]
  },
  covidSemBanner: {
    title: `Become a Verified WeddingBazaar service partner!`,
    content: `Are you a service provider who can help our customers organise their wedding from home?`
  },
  howItCrisilSemWorks: {
    title: "How does this work",
    subtitle: "",
    steps: [
      {
        strong:
          "Any service provider listed on WeddingBazaar can opt for CRISIL verification",
        followup: ``
      },
      {
        strong:
          "Upon submitting the required documents, the verification process will start",
        followup: ``
      },
      {
        strong:
          "Post the completion of the verification process the service provider will receive a CRISIL-verified badge which will be displayed on their WeddingBazaar profile page",
        followup: ``
      },
      {
        strong:
          "Once the customer sees a CRISIL verified badge on the WeddingBazaar profile page, it will create reliability and trust on that particular service provider",
        followup: ``
      }
    ]
  }
};
