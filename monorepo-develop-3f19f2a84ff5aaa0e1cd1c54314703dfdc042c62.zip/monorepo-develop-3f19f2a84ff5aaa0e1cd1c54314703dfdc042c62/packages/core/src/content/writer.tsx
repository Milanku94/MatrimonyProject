import { DomainCommonContent, SocialPlatform } from "./types";

export const writer: Pick<
  DomainCommonContent,
  "links" | "phoneNumber" | "socialLinks"
> = {
  phoneNumber: "7667777822",
  links: [
    {
      label: "Tags",
      to: "/tags"
    },
    {
      label: "Ideas & Inspirations",
      to: "/ideas"
    },
    {
      picture: "//www.weddingbazaar.com/assets/icons/m-stories.svg",
      label: "Wedding Stories",
      to: "/wedding-stories"
    },
    {
      label: "Partner Stories",
      to: "/partner-stories"
    },
    {
      type: "separator",
      to: "string",
      label: "string"
    },
    {
      label: "My Bio",
      to: "/my-bio"
    },
    {
      label: "Submit Wedding Story",
      to: "//goo.gl/forms/M4jfYYuFVL4FffGk1",
      external: true
    }
  ],
  socialLinks: [
    /**
     * platform: SocialPlatform.facebook,
     * label: "nav to fb/instagram/ so on",
     * id: "WeddingBazaar"  i.e, https://www.facebook.com/WeddingBazaar
     */
    {
      platform: SocialPlatform.facebook,
      label: "nav to fb",
      id: "WeddingBazaar/"
    },
    {
      platform: SocialPlatform.twitter,
      label: "nav to twitter",
      id: "Weddingbazaar"
    },
    {
      platform: SocialPlatform.instagram,
      label: "nav to instagram",
      id: "matrimonybazaarofficial"
    },
    {
      platform: SocialPlatform.pinterest,
      label: "nav to pinterest",
      id: "matrimonybazaar/"
    },
    {
      platform: SocialPlatform.youtube,
      label: "nav to youtube",
      id: "UCt1-NmgeaECOrKkmKDvkMjg"
    }
  ]
};
