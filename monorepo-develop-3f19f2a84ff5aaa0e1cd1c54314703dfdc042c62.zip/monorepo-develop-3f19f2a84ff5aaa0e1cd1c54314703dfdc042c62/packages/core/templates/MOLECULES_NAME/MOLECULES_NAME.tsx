import * as React from "react";
import styled from "styled-components";

export interface MOLECULES_NAMEProps {}

export const MOLECULES_NAME = styled("div")<MOLECULES_NAMEProps>``;
