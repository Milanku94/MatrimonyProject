import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { MOLECULES_NAME, MOLECULES_NAMEProps } from "./MOLECULES_NAME";

afterEach(cleanup);

const props: MOLECULES_NAMEProps = {};

describe("MOLECULES_NAME:", () => {
  it("renders correctly", () => {
    const { container } = render(<MOLECULES_NAME {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
