import * as React from "react";
import styled from "styled-components";

export interface ORGANISMS_NAMEProps {}

export const ORGANISMS_NAME = styled("div")<ORGANISMS_NAMEProps>``;
