import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { ORGANISMS_NAME, ORGANISMS_NAMEProps } from "./ORGANISMS_NAME";

afterEach(cleanup);

const props: ORGANISMS_NAMEProps = {};

describe("ORGANISMS_NAME:", () => {
  it("renders correctly", () => {
    const { container } = render(<ORGANISMS_NAME {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
