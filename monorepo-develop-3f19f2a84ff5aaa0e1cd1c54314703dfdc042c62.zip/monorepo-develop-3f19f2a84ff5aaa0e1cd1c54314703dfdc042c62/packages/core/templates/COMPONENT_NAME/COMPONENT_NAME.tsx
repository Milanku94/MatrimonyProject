import styled from "styled-components";

export interface COMPONENT_NAMEProps {}

export const COMPONENT_NAME = styled("div")<COMPONENT_NAMEProps>``;
