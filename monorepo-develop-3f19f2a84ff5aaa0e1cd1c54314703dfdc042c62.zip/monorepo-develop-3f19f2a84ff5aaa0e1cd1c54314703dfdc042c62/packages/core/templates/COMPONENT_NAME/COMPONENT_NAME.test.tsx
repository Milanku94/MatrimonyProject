import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { COMPONENT_NAME, COMPONENT_NAMEProps } from "./COMPONENT_NAME";

afterEach(cleanup);

const props: COMPONENT_NAMEProps = {};

describe("COMPONENT_NAME:", () => {
  it("renders correctly", () => {
    const { container } = render(<COMPONENT_NAME {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
