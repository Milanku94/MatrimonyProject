import * as React from "react";
import { cleanup, render } from "../../../utils/test-utils";
import { ATOM_NAME, ATOM_NAMEProps } from "./ATOM_NAME";

afterEach(cleanup);

const props: ATOM_NAMEProps = {};

describe("ATOM_NAME:", () => {
  it("renders correctly", () => {
    const { container } = render(<ATOM_NAME {...props} />);
    expect(container.firstChild).toMatchSnapshot();
  });
});
