import styled from "styled-components";

export interface ATOM_NAMEProps {}

export const ATOM_NAME = styled("div")<ATOM_NAMEProps>``;
