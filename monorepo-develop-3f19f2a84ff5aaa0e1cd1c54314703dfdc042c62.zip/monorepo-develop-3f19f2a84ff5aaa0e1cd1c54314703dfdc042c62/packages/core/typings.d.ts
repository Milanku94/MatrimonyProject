declare module "*.svg";
declare module "*.png";
