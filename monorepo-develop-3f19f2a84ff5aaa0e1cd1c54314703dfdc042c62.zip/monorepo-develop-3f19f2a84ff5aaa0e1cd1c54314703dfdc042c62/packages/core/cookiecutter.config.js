// in cookiecutter.config.js
module.exports = [
  {
    name: "Normal React Component",
    templatePath: "templates/COMPONENT_NAME",
    outputPath: "src/ui/components/",
    fields: [
      {
        templateVariable: "COMPONENT_NAME",
        question: "What is the component's name?",
        errorMessage:
          "A component must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
  {
    name: "Atoms",
    templatePath: "templates/ATOM_NAME",
    outputPath: "src/ui/atoms/",
    fields: [
      {
        templateVariable: "ATOM_NAME",
        question: "What is the component's name?",
        errorMessage:
          "A component must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
  {
    name: "Molecules",
    templatePath: "templates/MOLECULES_NAME",
    outputPath: "src/ui/molecules/",
    fields: [
      {
        templateVariable: "MOLECULES_NAME",
        question: "What is the component's name?",
        errorMessage:
          "A component must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
  {
    name: "Organisms",
    templatePath: "templates/MOLECULES_NAME",
    outputPath: "src/ui/organisms/",
    fields: [
      {
        templateVariable: "MOLECULES_NAME",
        question: "What is the component's name?",
        errorMessage:
          "A component must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  }
];
