module.exports = {
  title: "MBazaar Core",
  typescript: true,
  wrapper: "src/docz/ThemeWrapper",
  codeSandbox: false,
  public: "/public",
  src: "./src/"
};
