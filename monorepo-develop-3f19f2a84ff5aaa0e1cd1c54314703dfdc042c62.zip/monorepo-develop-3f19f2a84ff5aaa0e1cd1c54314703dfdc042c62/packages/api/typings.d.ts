declare module "cryptian";
