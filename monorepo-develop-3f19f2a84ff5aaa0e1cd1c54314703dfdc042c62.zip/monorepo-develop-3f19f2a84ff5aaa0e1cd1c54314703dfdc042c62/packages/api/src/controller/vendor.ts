import { waterfall } from "async";
import * as fs from "fs-extra";
import { checkPointList } from "../config/config.enum";
import config from "../config/config.env";
import { provider as ProfileGalleryProvider } from "../servers/vendor/ProfileGallery";
import { decryptVendorDocumentSlug } from "../servers/vendor/VendorDocuments";
import { directivePermissionRequest } from "../services/crmApis.utils";
import { portableVendorContext } from "../services/vendorContext.utils";
import {
  addDocument,
  getFileName,
  isKycCheckpointRequire,
  isKycDocumentExist,
  updateCheckPoint
} from "./vendor.utils";

enum uploadingFileType {
  DOCUMENT = "doc",
  GALLERY = "img"
}

export const uploadDocController = async (req: any, res: any) => {
  const { type, uuid, index } = req.body;
  const [fileType, slugId]: any = type.split("-");
  if (
    !Object.values(uploadingFileType).includes(fileType) ||
    !(fileType && slugId)
  ) {
    return res.status(422).json({
      status: "failure",
      message: "bad input"
    });
  }
  if (index && req.files.length !== 1) {
    return res.status(422).json({
      status: "failure",
      message: "index applicable for single image only"
    });
  }
  const { docType, docSubType } = decryptVendorDocumentSlug(slugId);
  const availFiles: any = req.files;
  const {
    addFile: addGallery,
    getDescVendorId,
    getVendorId,
    isPublished
  } = new ProfileGalleryProvider(
    portableVendorContext({
      accessToken: req.headers[config.JWT.AUTH_TOKEN_NAME],
      deviceToken: req.headers[config.DEVICE_TOKEN_NAME]
    })
  );
  return Promise.all(
    availFiles.map(
      async ({ path, size, filename: orgFileName }: any, idx: any) => {
        const fileName =
          fileType === uploadingFileType.DOCUMENT
            ? getFileName({
                docType,
                vendorId: getVendorId(),
                index: index || idx + 1,
                fileExtension: orgFileName.split(".").slice(-1)
              })
            : `${uuid ? uuid : getDescVendorId()}-${Date.now()}${
                idx ? idx : ""
              }.${orgFileName.split(".").slice(-1)}`; // Todo: actual id need to handle the fileName
        const destination = `${config.IMAGE_DOC_PATH}${
          fileType === uploadingFileType.DOCUMENT ? "vendordoc" : "vendor"
        }/${isPublished() ? getVendorId() : getDescVendorId()}`;
        const isDirectiveExist = await fs.pathExists(destination);
        if (fileType === uploadingFileType.GALLERY && isDirectiveExist) {
          await directivePermissionRequest({
            vendorId: destination.split("/").slice(-1)[0]
          });
        }
        return await fs
          .move(path, `${destination}/${fileName}`)
          .then(async () => {
            if (fileType === uploadingFileType.GALLERY && !isDirectiveExist) {
              await fs.chmod(destination, 0o775);
            }
            const fileInfo: any =
              fileType === uploadingFileType.DOCUMENT
                ? await addDocument({
                    fileName,
                    vendorId: getVendorId(),
                    size,
                    docType,
                    docSubType
                  })
                : await addGallery({
                    fileName,
                    uuid,
                    profileSlug: slugId
                  });
            return {
              ...(typeof fileInfo === "object"
                ? { ...fileInfo }
                : { id: fileInfo }),
              fileName
            };
          })
          .catch((err: any) => {
            // console.error("UPLOAD MV ERR", err);
            return res.status(500).json({
              status: "failure",
              message: "internal server error",
              err
            });
          });
      }
    )
  ).then(docInfo => {
    return waterfall(
      [
        (done: any) =>
          done(fileType === uploadingFileType.DOCUMENT ? null : "its not KYC"),
        async (done: any) => {
          const isKycReq = await isKycCheckpointRequire(getVendorId());
          done(isKycReq ? null : "KYC already verified");
        },
        async (done: any) => {
          const isExist = await isKycDocumentExist(getVendorId());
          done(isExist ? null : "basic docs require");
        },
        async (done: any) => {
          await updateCheckPoint(getVendorId(), checkPointList.KYC);
          done(null, "done");
        }
      ],
      (err, result) => {
        // console.error("UPLOAD SUCC ERR", result, err);

        return res.status(200).json({
          status: "success",
          message: "successfully uploaded",
          docInfo
        });
      }
    );
  });
};
