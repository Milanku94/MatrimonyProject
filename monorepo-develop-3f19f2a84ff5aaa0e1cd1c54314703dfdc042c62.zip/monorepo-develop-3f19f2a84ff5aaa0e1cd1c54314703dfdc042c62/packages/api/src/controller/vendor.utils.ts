import {
  checkPointList,
  vendorDocCategory,
  vendorDocStatus
} from "../config/config.enum";
import DB from "../config/db";
import { mBazaarProspect } from "../knex";

/**
 * Note: Document name by Document category
 * @key as Document name
 * @value as value of Document Category
 */
enum kycFileNames {
  Agreement_doc = 1,
  KYC_doc = 2,
  Business_doc = 3,
  Payment_doc = 4,
  PO_doc = 5
}

export const getFileName = ({
  vendorId,
  docType,
  fileExtension,
  index
}: {
  vendorId: number;
  docType: any;
  fileExtension: string;
  index: number;
}): string =>
  [
    [`PVD${vendorId}`, kycFileNames[docType], index, Date.now()]
      .filter(Boolean)
      .join("_"),
    fileExtension
  ].join(".");
export const addDocument = async ({
  fileName,
  vendorId,
  size,
  docType,
  docSubType
}: {
  fileName: string;
  vendorId: number;
  size: number;
  docType: number;
  docSubType: number;
}): Promise<number> => {
  const { table, fields } = DB.mBazaarProspect.vendorDocument;
  const actualDocument = {
    [fields.name]: fileName,
    [fields.vendorId]: vendorId,
    // [fields.comments]: comments,
    [fields.size]: size,
    /* FIX: FSE tool doesn't read from 3,3. Use 2,5 for GST */
    [fields.docType]: docType === 3 && docSubType === 3 ? 2 : docType,
    [fields.docSubType]: docSubType === 3 && docType === 3 ? 5 : docSubType,
    [fields.status]: vendorDocStatus.ACTIVE // vendorDocStatus.PENDING
  };
  // let insDocuments: any[] = [actualDocument];
  // if (
  //   (docType === vendorDocCategory.KYC_DOC && docSubType === 5) ||
  //   (docType === vendorDocCategory.BUSINESS_DOC && docSubType === 3)
  // ) {
  //   insDocuments = [
  //     { docType: 2, docSubType: 5 },
  //     { docType: 3, docSubType: 3 }
  //   ].map((dup: any) => ({
  //     ...actualDocument,
  //     [fields.docType]: dup.docType,
  //     [fields.docSubType]: dup.docSubType
  //   }));
  // }
  return await mBazaarProspect(table)
    //    .insert(insDocuments)
    .insert(actualDocument)
    .then(async ([documentId]: number[]) => {
      const _ =
        vendorDocCategory.BUSINESS_DOC === docType &&
        (await mBazaarProspect(DB.mBazaarProspect.vendorDetails.table)
          .update({
            [DB.mBazaarProspect.vendorDetails.fields["billingInfo.gstNo"]]:
              docSubType === kycFileNames.Business_doc ? `PVD${vendorId}` : ``
          })
          .where({
            [DB.mBazaarProspect.vendorDetails.fields.prospectId]: vendorId
          }));
      return documentId;
    });
};

export const getDocumentsByVendor = async ({
  vendorId
}: {
  vendorId: number;
}) => {
  const { table, fields } = DB.mBazaarProspect.vendorDocument;

  return await mBazaarProspect(table)
    .columns(fields)
    .where(function() {
      this.whereIn(
        [fields.docType, fields.status],
        [
          [vendorDocCategory.BUSINESS_DOC, vendorDocStatus.ACTIVE],
          [vendorDocCategory.BUSINESS_DOC, vendorDocStatus.PENDING],
          [vendorDocCategory.KYC_DOC, vendorDocStatus.ACTIVE],
          [vendorDocCategory.KYC_DOC, vendorDocStatus.PENDING]
        ]
      )
        .andWhere({
          [fields.vendorId]: vendorId
        })
        .andWhere(fields.docSubType, ">", 0);
    })
    .groupBy(fields.docType);
};
export const isKycDocumentExist = async (vendorId: number) => {
  const allDocuments = await getDocumentsByVendor({ vendorId });

  return allDocuments.length === 1;
};
export const isKycCheckpointRequire = async (vendorId: string | number) => {
  const { table, fields } = DB.mBazaarProspect.vendorDetails;
  return !!(
    await mBazaarProspect(table)
      .columns(fields)
      .where({
        [fields.prospectId]: vendorId // Note: this operation should be happen in prospect
      })
      .andWhereBetween(fields["onBoardStatus.progressLevel"], [
        checkPointList.PROFILE,
        checkPointList.KYC
      ])
  )[0];
};
export const updateCheckPoint = async (
  vendorId: string | number,
  checkPointDone: checkPointList
) => {
  const { table, fields } = DB.mBazaarProspect.vendorDetails;
  return await mBazaarProspect(table)
    .update({
      [fields["onBoardStatus.progressLevel"]]: checkPointDone
    })
    .where({
      [fields.prospectId]: vendorId
    });
};
