import { AuthenticationError } from "apollo-server-express";
import { defaultFieldResolver } from "graphql";
import { SchemaDirectiveVisitor } from "graphql-tools";
import { isArray as _isArray } from "lodash";

export class VendorAuthDirective extends SchemaDirectiveVisitor {
  public visitObject(type: any) {
    this.ensureFieldsWrapped(type);
    type._requiredAuthRole = this.args.requires;
  }
  public visitFieldDefinition(field: any, details: any) {
    this.ensureFieldsWrapped(details.objectType);
    field._requiredAuthRole = this.args.requires;
  }

  public ensureFieldsWrapped(objectType: any) {
    if (objectType._authFieldsWrapped) {
      return;
    }
    objectType._authFieldsWrapped = true;

    const fields = objectType.getFields();

    Object.keys(fields).forEach(fieldName => {
      const field = fields[fieldName];
      const { resolve = defaultFieldResolver } = field;
      field.resolve = async function(...args: any) {
        const requiredRole =
          field._requiredAuthRole || objectType._requiredAuthRole;

        if (!requiredRole) {
          return resolve.apply(this, args);
        }

        const requiredRoles = _isArray(requiredRole)
          ? requiredRole
          : [requiredRole];
        const user = args[2].user;
        if (!user) {
          throw new AuthenticationError("you must be logged in");
        }
        const { role: operationRole }: any = user;
        if (!requiredRole || !requiredRoles.includes(operationRole)) {
          throw new AuthenticationError("you are not authenticated user");
        }
        return resolve.apply(this, args);
      };
    });
  }
}
