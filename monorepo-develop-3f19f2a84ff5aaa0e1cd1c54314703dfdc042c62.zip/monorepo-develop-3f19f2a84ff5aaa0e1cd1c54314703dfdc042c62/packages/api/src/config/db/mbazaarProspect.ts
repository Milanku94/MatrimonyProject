import { ReferenceDatabase } from "../../types";

export const mBazaarProspect: ReferenceDatabase = {
  vendorDetails: {
    table: "vendor_details",
    fields: {
      prospectId: "prospect_id",
      vendorId: "vendor_id",

      businessName: "company_name",
      description: "description",

      // info: Primary Contact
      "primary.name": "primary_contact_name",
      "primary.role": "primary_contactperson_role",
      "primary.email": "email",
      "primary.isWhatsappConsent": "is_whatsapp_consent",
      "primary.whatsappConsentUpdatedAt": "whatsapp_consent_date",

      // "primary.phone1.isd": "primary_contact_1_isd",
      "primary.phone1.phone": "primary_contact_1",
      "primary.phone1.verifyStatus": "primary_contact1_verify_status",
      "primary.phone1.verifySource": "primary_contact1_verify_source",
      "primary.phone1.verifyOn": "primary_contact1_verifyon",

      // "primary.phone2.isd": "primary_contact_2_isd",
      "primary.phone2.phone": "primary_contact_2",
      "primary.phone2.verifyStatus": "primary_contact2_verify_status",
      "primary.phone2.verifySource": "primary_contact2_verify_source",
      "primary.phone2.verifyOn": "primary_contact2_verifyon",

      // info: Secondary Contact
      "secondary.name": "secondary_contact_name",
      "secondary.role": "secondary_contactperson_role",
      "secondary.email": "secondary_email",

      // "secondary.phone1.isd": "secondary_contact_1_isd",
      "secondary.phone1.phone": "secondary_contact_1",
      "secondary.phone1.verify.status": "secondary_contact1_verify_status",
      "secondary.phone1.verify.source": "secondary_contact1_verify_source",
      "secondary.phone1.verifyon": "secondary_contact1_verifyon",

      // "secondary.phone2.isd": "secondary_contact_2_isd",
      "secondary.phone2.phone": "secondary_contact_2",
      "secondary.phone2.verifyStatus": "secondary_contact2_verify_status",
      "secondary.phone2.verifySource": "secondary_contact2_verify_source",
      "secondary.phone2.verifyOn": "secondary_contact2_verifyon",

      // info: Address of Business Reg.
      "address.address": "address",
      // "address.location": "location",
      "address.localityId": "location",
      "address.cityId": "city",
      "address.stateId": "state",
      "address.pincode": "pincode",
      "address.latitude": "latitude",
      "address.longitude": "longitude",

      // info: Billing and GST info
      "billingInfo.gstNo": "gst_no",
      "billingInfo.gstBusinessName": "gst_business_name",
      "billingInfo.gstState": "gst_state",
      "billingInfo.billingName": "billing_name",
      "billingInfo.billingAddress": "billing_address",
      "billingInfo.salesCityId": "sales_city_id",
      "billingInfo.salesStateId": "sales_state_id",

      // info: Social network
      "socialLinks.webUrl": "web_url",
      "socialLinks.fbUrl": "fb_url",
      "socialLinks.instagramUrl": "instagram_url",
      "socialLinks.pinterestUrl": "pinterest_url",
      "socialLinks.twitterUrl": "twittter_url",

      // info: KYC number and src files
      "document.panNo": "pan_no",
      "document.aadharNo": "aadhar_no",
      "document.fathersNameKyc": "fathers_name_kyc",
      "document.dobKyc": "dob_kyc",

      // info:
      "onBoardStatus.status": "status",
      "onBoardStatus.onboardState": "onboard_state",
      // "onBoardStatus.progressStatus": "progress_status",
      "onBoardStatus.activatedOn": "activated_on",
      "onBoardStatus.progressLevel": "app_progress_level",

      // info: Payment
      "payment.paidStatus": "paid_status",
      "payment.paidType": "paid_type",
      "payment.noOfPayments": "no_of_payments",
      "payment.isFeatured": "is_featured",
      "payment.featuredStartDate": "featured_start_date",
      "payment.featuredEndDate": "featured_end_date",

      // info: Features
      "misc.listingWithCompetition": "listing_with_competition",
      "misc.operatingOutOf": "operating_out_of",
      "misc.numberOfEmployees": "number_of_employees",
      "misc.eventsConductedSoFar": "events_conducted_so_far",

      createdOn: "created_on",
      updatedOn: "updated_on"
    },
    prospect: {},
    actual: {
      totalValuePaid: "total_value_paid",
      valueDelivered: "value_delivered",
      pendingValue: "pending_value"
    }
  },
  category: {
    table: "categories",
    fields: {
      id: "categoryId",
      name: "categoryName",
      displayName: "displaycategoryname",
      status: "status",
      displayOrder: "DisplayOrder",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  subCategory: {
    table: "category",
    fields: {
      id: "categoryId",
      name: "categoryName",
      displayName: "displaycategoryname",
      seoCategoryName: "seo_category_name",
      state: "stateId",
      domain: "domain",
      commissionStatus: "commissionStatus",
      status: "status",
      displayOrder: "DisplayOrder",
      layeredFormTitle: "layered_form_title",
      createdOn: "createdOn"
    }
  },
  profiles: {
    table: "vendor_category_settings",
    fields: {
      id: "vendor_category_setting_id",
      vendorId: "vendor_id",
      categoryId: "parent_category_id",
      subCategoryId: "category_id",
      cityId: "city_id",
      stateId: "state_id",

      status: "status",
      // isActive: "is_active",
      serviceable: "is_osc",
      currentPackage: "current_package",

      "leadManagement.status": "lms_user_status",
      "leadManagement.count": "vendor_custom_lead_count",
      "leadManagement.maxCount": "lms_custom_lead_count",

      // "pricing.approved": "is_commission_approved",
      // "pricing.disposition": "commission_disposition",
      "pricing.commissionPercentage": "approved_commission_percentage",
      "pricing.discount": "approved_customer_discount",
      "pricing.leadFee": "lead_price",
      "pricing.listingFee": "listing_fee",

      createdOn: "created_on",
      updatedOn: "updated_at"
    },
    prospect: {},
    actual: {
      baseRating: "baseRating",
      rating: "rating",
      totalRaters: "totalRaters"
    }
  },
  profileAttributes: {
    table: "vendor_category_details",
    fields: {
      id: "vendor_category_detail_id",
      vendorId: "vendor_id",
      cityId: "city_id",
      categoryId: "category_id",
      header: "category_header_id",
      subHeaderId: "category_subheader_id",
      fields: "category_fieldoption_id",
      values: "category_field_value",
      // parentCatId: "parent_cat_id",
      startDate: "start_date",
      endDate: "end_date",
      txtVal: "txt_val",
      fieldType: "field_type",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  profileGallery: {
    table: "vendor_images",
    fields: {
      id: "PhotoId",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      filePath: "PhotoPath",
      fileName: "PhotoName",
      title: "PhotoTitle",
      subTitle: "PhotoSubTitle",
      isHero: "PhotoBaseImage",
      displayOrder: "displayorder",
      description: "PhotoDescription",
      uuid: "uuid",
      createdDate: "CreatedDate",
      updatedDate: "UpdatedDate"
    },
    prospect: { status: "PhotoStatus" },
    actual: {
      approvedRejectedOn: "approved_rejected_on",
      deletedSource: "deleted_source",
      source: "source",
      photoStatus: "PhotoStatus",
      status: "status",
      ticketId: "ticket_id",
      vendorImageId: "vendor_image_id"
    }
  },
  vendorDocument: {
    table: "vendor_documents",
    fields: {
      id: "vendor_document_id",
      vendorId: "vendor_id",
      docType: "doc_type",
      docSubType: "sub_doc_type",
      // fileType: "file_type",
      // categoryId: "category_id",
      paymentId: "payment_id",
      name: "name",
      size: "size",
      comments: "comments",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on",
      updatedAt: "updated_at"
    }
  },
  userOtp: {
    table: "customer_vendor_otp",
    fields: {
      id: "otpid",
      vendorId: "vendor_id",
      mobileNumber: "mobile_number",
      otp: "otp",
      otpGeneratedTime: "otp_generated_time",
      otpVerifiedTime: "otp_verified_time",
      otpExpiryTime: "otp_expiry_time",
      source: "source",
      status: "status",
      otpAttempt: "otp_attempt",
      createdOn: "created_on",
      updatedAt: "updated_at"
    }
  }
};
