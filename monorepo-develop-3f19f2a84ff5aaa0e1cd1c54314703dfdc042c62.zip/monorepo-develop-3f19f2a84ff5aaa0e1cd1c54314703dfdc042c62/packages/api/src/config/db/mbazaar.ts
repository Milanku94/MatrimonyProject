import { ReferenceDatabase } from "../../types";

export const mBazaar: ReferenceDatabase = {
  /**
   * VirtualTable: contains the common field from Actual/Prospect
   */
  appLogs: {
    table: "vendor_apploginlog",
    fields: {
      id: "logid",
      userId: "userid",
      vcdId: "vcd_id",
      loggedOn: "loggedinat",
      clientIp: "clientip",
      appType: "apptype",
      appVersionCode: "appversioncode",
      appVersion: "appversion",
      registerId: "registerid",
      deviceDetails: "devicedetails",
      UpdatedOn: "dateupdated"
    }
  },
  vendorContactDetails: {
    table: "vendor_contact_details",
    fields: {
      id: "id",
      vendorId: "vendor_id",
      name: "name",
      contactNumberType: "contact_number_type",
      isdNumber: "isd_number",
      contactEncNumber: "contact_enc_number",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  vendorContactMapping: {
    table: "vendor_contact_mapping",
    fields: {
      id: "id",
      vcdId: "vcd_id",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      stateId: "state_id",
      designation: "designation",
      taggedPurpose: "tagged_purpose",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  vendorValidate: {
    table: "vendor_details",
    fields: {
      userId: "primary_contact_1",
      primaryContact_1: "primary_contact_1",
      primaryContact_2: "primary_contact_2",
      secondaryContact_1: "secondary_contact_1",
      secondaryContact_2: "secondary_contact_2",
      vendorId: "vendor_id",
      prospectId: "prospect_id",
      businessName: "company_name",
      status: "status"
    }
  },
  states: {
    table: "states",
    fields: {
      id: "state_id",
      name: "state_name",
      countryId: "country_id",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  cities: {
    table: "cities",
    fields: {
      id: "city_id",
      name: "city_name",
      crmDistrictId: "crm_district_id",
      seoCityName: "seo_city_name",
      countryId: "country_id",
      stateId: "state_id",
      districtId: "district_id",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  categories: {
    table: "category",
    fields: {
      id: "categoryId",
      name: "categoryName",
      displayName: "displaycategoryname",
      seoName: "seo_category_name",
      parentId: "parentId",
      stateId: "stateId",
      domain: "domain",
      commissionStatus: "commissionStatus",
      status: "status",
      displayOrder: "DisplayOrder",
      layeredFormTitle: "layered_form_title"
    }
  },
  attributeHeader: {
    table: "categoryHeaderFields",
    fields: {
      id: "CatHdrFieldId",
      value: "HdrFieldValue",
      categoryId: "CategoryId",
      displayOrder: "displayorder",
      visibleField: "visibilefield",
      // portalLabel: "portal_label",
      // layeredFieldLabel: "layered_field_label",
      // 1, 3 enable for bazaar
      crmFlag: "crm_flag",
      status: "ActiveStatus",
      createdOn: "CreatedOn",
      updatedOn: "UpdatedOn"
    }
  },
  attributeSubHeader: {
    table: "categorySubHeaderfields",
    fields: {
      id: "CatSubHdrFieldId",
      name: "SubHdrFieldValue",
      displayOrder: "displayorder",
      categoryId: "CategoryId",
      headerFieldId: "CatHdrFieldId",
      fieldType: "fieldtype",
      fieldValidation: "customer_form_rules",
      crmFlag: "crm_flag",
      vendorMandatory: "vendor_mandatory",

      fieldtypeCustomer: "fieldtype_customer",
      mandatory: "mandatory",
      visibilefield: "visibilefield",
      distributeFlag: "distribute_flag",
      filterFlag: "filter_flag",
      customerForm: "customer_form",
      layeredFormDisplayOrder: "layered_form_display_order",
      searchFlag: "search_flag",
      solrFlag: "solr_flag",
      listFlag: "list_flag",
      informationFlag: "information_flag",
      fieldrules: "fieldrules",
      portalLabel: "portal_label",
      question: "vendor_field_label",
      layeredFieldLabel: "layered_field_label",
      status: "ActiveStatus",
      createdOn: "CreatedOn",
      updatedOn: "UpdatedOn"
    }
  },
  fieldOptions: {
    table: "fieldOptions",
    fields: {
      id: "id",
      subHeaderId: "subhdrid",
      displayOrder: "displayorder",
      value: "value",
      isDefault: "is_default",
      createdOn: "createdon",
      updatedOn: "updatedon"
    }
  },
  textMessage: {
    table: "smslogs",
    fields: {
      id: "LogId",
      senderId: "SenderId",
      serviceProvider: "ServiceProvider",
      accountUser: "AccountUsed",
      mobileNumber: "MobileNumber",
      message: "Message",
      referenceNumber: "ReferenceNumber",
      messageSplitCount: "MessageSpltiCount",
      deliveryStatus: "DeliveryStatus",
      failureReason: "FailureReason",
      enqSource: "EnqSource",
      dateSentOn: "DateSentOn",
      dateUpdatedOn: "DateUpdatedOn"
    }
  },
  crmLeads: {
    table: "vendor_user_leads",
    fields: {
      vendorUserLeadId: "vendor_user_lead_id",
      createdOn: "created_on",
      updatedAt: "updated_at",
      cityId: "city_id",
      isOsc: "is_osc",
      vendorId: "vendor_id",
      categoryId: "category_id",
      leadId: "lead_id",
      followupDate: "followup_date",
      status: "status",

      userLeadId: "user_lead_id",
      parentCategoryId: "parent_category_id",
      vendorDisposition: "vendor_disposition",
      isImported: "is_imported",
      updatedOn: "updated_on",

      // Note: resolver sorting purpose
      createdAt: "created_on"
      // updatedAt: "updated_at",
    }
  },
  customer: {
    table: "lead_basic_info",
    fields: {
      leadId: "lead_id",
      crmReferenceId: "crmreference_id",
      name: "name",
      countryId: "country_id",
      isdCode: "isd_code",
      mobileNo: "mobile_no",
      emailId: "email_id",
      stateId: "state_id",
      enqSource: "enq_source",
      priorityLead: "priority_lead",
      leadDisposition: "lead_disposition",
      leadSentCount: "lead_sent_count",
      categoryOptedCount: "category_opted_count",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on",
      updatedAt: "updated_at"
    }
  },
  vendorWallet: {
    table: "vendor_wallets",
    fields: {
      vendorWalletId: "vendor_wallet_id",
      vendorId: "vendor_id",
      packageId: "package_id",
      type: "type",
      amount: "amount",
      bonusAmount: "bonus_amount",
      bannerBalance: "banner_balance",
      brandingBalance: "branding_balance",
      activeWalletPaymentId: "active_wallet_payment_id",
      activeWalletPaymentBalance: "active_wallet_payment_balance",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on",
      updatedAt: "updated_at",
      activeWalletBonusBalance: "active_wallet_bonus_balance"
    }
  },
  vendorPayments: {
    table: "vendor_banner_brand_settings",
    fields: {
      id: "id",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      stateId: "state_id",
      parentCategoryId: "parent_category_id",
      activeWalletPaymentId: "active_wallet_payment_id",
      landingCategoryId: "landing_category_id",
      landingCityId: "landing_city_id",
      startDate: "start_date",
      endDate: "end_date",
      status: "status",
      campaignStatus: "campaign_status",
      balanceAmount: "balance_amount",
      valueDelivered: "value_delivered",
      totalValue: "total_value",
      targetRunRate: "target_run_rate",
      actualRunRate: "actual_run_rate",
      requiredRunRate: "required_run_rate",
      listingFeePerDay: "listing_fee_per_day",
      type: "type",
      campaignPauseDate: "campaign_pause_date",
      createdOn: "created_on",
      updatedOn: "updated_on",
      updatedAt: "updated_at"
    }
  },
  vendorBannerCredit: {
    table: "banner_payment_details",
    fields: {
      id: "id",
      walletPaymentId: "wallet_payment_id",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      landingCategoryId: "landing_category_id",
      landingCityId: "landing_city_id",
      packageCategorySettingsId: "package_category_settings_id",
      packageId: "package_id",
      amount: "amount",
      status: "status",
      bannerApproveStatus: "banner_approve_status",
      publishedDate: "published_date",
      createdOn: "created_on",
      updatedOn: "updated_on",

      // Note: resolver sorting purpose
      updatedAt: "updated_on",
      createdAt: "created_on"
    }
  },
  vendorBrandListingCredit: {
    table: "category_payment_details",
    fields: {
      id: "id",
      walletPaymentId: "wallet_payment_id",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      packageCategorySettingsId: "package_category_settings_id",
      packageId: "package_id",
      amount: "amount",
      setupCost: "setup_cost",
      type: "type",
      tenure: "tenure",
      status: "status",
      publishedDate: "published_date",
      createdOn: "created_on",
      updatedOn: "updated_on",

      // Note: resolver sorting purpose
      updatedAt: "updated_on",
      createdAt: "created_on"
    }
  },
  vendorBannerAndBrandDebit: {
    table: "banner_brand_deduction",
    fields: {
      id: "id",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      vendorBannerBrandSettingsId: "vendor_banner_brand_settings_id",
      walletPaymentId: "wallet_payment_id",
      startDate: "start_date",
      endDate: "end_date",
      amount: "amount",
      standardAmount: "standard_amount",
      bonusAmount: "bonus_amount",
      sourceType: "source_type",
      deductionType: "deduction_type",
      createdOn: "created_on",
      updatedOn: "updated_on",

      // Note: resolver sorting purpose
      updatedAt: "updated_at",
      createdAt: "created_on"
    }
  },
  vendorListingDebit: {
    table: "listing_activation_deduction",
    fields: {
      id: "id",
      vendorId: "vendor_id",
      userId: "user_id",
      categoryId: "category_id",
      cityId: "city_id",
      packageCategorySettingId: "package_category_setting_id",
      vendorCategorySettingId: "vendor_category_setting_id",
      startDate: "start_date",
      endDate: "end_date",
      amountPayable: "amount_payable",
      amountPaid: "amount_paid",
      standardWalletAmount: "standard_wallet_amount",
      bonusWalletAmount: "bonus_wallet_amount",
      sourceType: "source_type",
      amountPaidSgst: "amount_paid_sgst",
      amountPaidCgst: "amount_paid_cgst",
      amountPaidIgst: "amount_paid_igst",
      percentageSgst: "percentage_sgst",
      percentageCgst: "percentage_cgst",
      percentageIgst: "percentage_igst",
      deductionType: "deduction_type",
      createdOn: "created_on",
      updatedOn: "updated_on",

      // Note: resolver sorting purpose
      updatedAt: "updated_at",
      createdAt: "created_on"
    }
  },
  vendorLeadDebit: {
    table: "lead_payment_history",
    fields: {
      paymentHistoryId: "payment_history_id",
      vendorId: "vendor_id",
      leadId: "lead_id",
      categoryId: "category_id",
      walletPaymentId: "wallet_payment_id",
      transactionId: "transaction_id",
      orderId: "order_id",
      orderDate: "order_date",
      discountId: "discount_id",
      discount: "discount",
      packageCategorySettingId: "package_category_setting_id",
      price: "price",
      amountPayable: "amount_payable",
      amountPaid: "amount_paid",
      standardWalletAmount: "standard_wallet_amount",
      bonusWalletAmount: "bonus_wallet_amount",
      salesStateId: "sales_state_id",
      gstSalesStateId: "gst_sales_state_id",
      sourceType: "source_type",
      paymentType: "payment_type",
      type: "type",
      refundFlag: "refund_flag",
      refundComments: "refund_comments",
      comments: "comments",
      userId: "user_id",
      amountPaidSgst: "amount_paid_sgst",
      amountPaidCgst: "amount_paid_cgst",
      amountPaidIgst: "amount_paid_igst",
      percentageSgst: "percentage_sgst",
      percentageCgst: "percentage_cgst",
      percentageIgst: "percentage_igst",
      isImported: "is_imported",
      cityId: "city_id",
      isOsc: "is_osc",
      createdOn: "created_on",
      updatedOn: "updated_on",

      // Note: resolver sorting purpose
      updatedAt: "updated_at",
      createdAt: "created_on"
    }
  },
  vendorWalletPayments: {
    table: "wallet_payments",
    fields: {
      id: "id",
      vendorId: "vendor_id",
      packageId: "package_id",
      amount: "amount",
      leadWalletAmount: "lead_wallet_amount",
      paymentReferenceNumber: "payment_reference_number",
      paymentType: "payment_type",
      disposition: "disposition",
      status: "status",
      type: "type"
    }
  },
  vendorCommission: {
    table: "commission_payment_history",
    fields: {
      commissionPaymentHistoryId: "commission_payment_history_id",
      vendorId: "vendor_id",
      memberId: "member_id",
      userLeadClosureId: "user_lead_closure_id",
      orderId: "order_id",
      orderDate: "order_date",
      parentCategoryId: "parent_category_id",
      categoryId: "category_id",
      cityId: "city_id",
      stateId: "state_id",
      price: "price",
      amountPayable: "amount_payable",
      amountPaid: "amount_paid",
      standardWalletAmount: "standard_wallet_amount",
      bonusWalletAmount: "bonus_wallet_amount",
      salesStateId: "sales_state_id",
      gstSalesStateId: "gst_sales_state_id",
      sourceType: "source_type",
      paymentType: "payment_type",
      type: "type",
      refundFlag: "refund_flag",
      comments: "comments",
      userId: "user_id",
      amountPaidSgst: "amount_paid_sgst",
      amountPaidCgst: "amount_paid_cgst",
      amountPaidIgst: "amount_paid_igst",
      percentageSgst: "percentage_sgst",
      percentageCgst: "percentage_cgst",
      percentageIgst: "percentage_igst",
      isImported: "is_imported",
      createdOn: "created_on",
      updatedOn: "updated_on",
      requestId: "request_id",

      createdAt: "created_on",
      updatedAt: "updated_at"
    }
  },
  purchaseOrder: {
    table: "purchase_order",
    fields: {
      id: "id",
      vendorId: "vendor_id",
      vendorType: "vendor_type",
      walletPaymentId: "wallet_payment_id",
      poNumber: "po_number",
      poDate: "po_date",
      poSentData: "po_sent_data",
      userId: "user_id",
      roleId: "role_id",
      branchId: "branch_id",
      downloadUrlKey: "download_url_key",
      downloadUrl: "download_url",
      expiryDate: "expiry_date",
      isRegenerate: "is_regenerate",
      fileVersion: "file_version",
      createdOn: "created_on",

      createdAt: "created_on",
      updatedAt: "updated_at"
    }
  }
};
