import { ReferenceDatabase } from "../../types";

export const mBazaarService: ReferenceDatabase = {
  callLead: {
    table: "mbazaar_vminbound_track",
    fields: {
      id: "id",
      empId: "Empid",
      status: "Status",

      encMemberContactNum: "EncMemberContactNum",
      vmNumber: "VMNumber",
      memberId: "MemberId",
      connectedAgent: "ConnectedAgent",

      vendorId: "VendorId",
      vendorCategoryId: "VendorCategoryId",
      vendorCityId: "VendorCityId",

      vmCallTag: "VmCallTag",
      dateCalled: "DateCalled",
      callStatus: "CallStatus",
      voiceLogPath: "VoiceLogPath",
      callDuration: "CallDuration",

      apiParameter: "APIParameter",
      vmCallStatus: "VMCallStatus",
      vmSubCallStatus: "VMSubCallStatus",

      comments: "Comments",
      visitingDate: "VisitingDate",

      fromEventDate: "FromEventDate",
      toEventDate: "ToEventDate",
      fromEventDateSession: "FromEventDateSession",
      toEventDateSession: "ToEventDateSession",

      dateUpdated: "DateUpdated",
      dateAdded: "DateAdded",

      // Note: resolver sorting purpose
      updatedAt: "DateUpdated",
      createdAt: "DateAdded"
    }
  },

  customerDetails: {
    table: "mb_member_info",
    fields: {
      memberId: "MemberId",
      matriId: "MatriId",
      partnerId: "PartnerId",
      name: "Name",
      age: "Age",
      gender: "Gender",
      byWhom: "ByWhom",

      brideName: "BrideName",
      groomName: "GroomName",

      marriageDate: "MarriageDate",
      engagementDate: "EngagementDate",
      eventStartDate: "EventStartDate",
      eventEndDate: "EventEndDate",
      eventInDays: "EventInDays",
      eventStateId: "EventStateId",
      eventCityId: "EventCityId",

      residingState: "ResidingState",
      residingArea: "ResidingArea",
      residingDistrict: "ResidingDistrict",
      residingCity: "ResidingCity",
      residingCityId: "ResidingCityId",

      registrationDate: "RegistrationDate",
      profileTimeCreated: "ProfileTimeCreated",
      profilePublishedOn: "ProfilePublishedOn",
      profileDelReasonId: "ProfileDelReasonId",
      profileStatus: "ProfileStatus",

      assignedDate: "AssignedDate",
      assignedBy: "AssignedBy",
      branchId: "BranchId",
      leadType: "LeadType",
      leadSource: "LeadSource",
      addedBy: "AddedBy",
      addedOn: "AddedOn",
      modifiedOn: "ModifiedOn",
      dateUpdated: "DateUpdated",
      status: "Status",

      requestedService: "RequestedService",
      servedService: "ServedService",
      pendingService: "PendingService",
      expectedDiscount: "ExpectedDiscount",
      proposedDiscount: "ProposedDiscount",
      noOfPayments: "NoOfPayments",
      couponCode: "CouponCode",
      paymentDate: "PaymentDate",

      bcId: "BCId",
      midType: "MidType",
      paidStatus: "PaidStatus",
      bmcbsPaidStatus: "BMCBSPaidStatus",
      productId: "ProductId",
      domainId: "DomainId",
      motherTongue: "MotherTongue",
      religion: "Religion",
      caste: "Caste",
      educationSelected: "EducationSelected",
      educationId: "EducationId",
      occupationCategory: "OccupationCategory",
      occupationSelected: "OccupationSelected",
      incomeCurrency: "IncomeCurrency",
      annualIncomeSrc: "AnnualIncomeSrc",
      annualIncome: "AnnualIncome",
      countrySelected: "CountrySelected",
      professionId: "ProfessionId",
      professionOthers: "ProfessionOthers",
      industryId: "IndustryId",
      industryOthers: "IndustryOthers",
      marriageFixedSource: "MarriageFixedSource",
      categoryAlreadyFinalized: "CategoryAlreadyFinalized",
      categoryFinalizedSrc: "CategoryFinalizedSrc",
      overAllBudget: "OverAllBudget",
      categoryFinalizedInMbazaar: "CategoryFinalizedInMbazaar",
      cifImgStatus: "CIFImgStatus",
      cifImgName: "CIFImgName",
      cifImgName2: "CIFImgName2",
      rmEmpId: "RMEmpId",
      vendorType: "VendorType",
      totalVisitedCnt: "TotalVisitedCnt",
      overAllLeadSource: "OverAllLeadSource"
    }
  },
  customerRequirement: {
    table: "mb_member_expectation_info",
    fields: {
      memberId: "MemberId",
      categoryId: "CategoryId",
      header: "FieldId",
      subHeaderId: "SubFieldId",
      fieldType: "ValueType",
      fields: "FieldValue_Selected",
      values: "FieldValue_Text",

      fieldValueMinValue: "FieldValue_MinValue",
      fieldValueMaxValue: "FieldValue_MaxValue",
      fieldValueSdatetime: "FieldValue_Sdatetime",
      fieldValueEdatetime: "FieldValue_Edatetime",
      fieldValueDate: "FieldValue_Date",
      cifType: "CifType",
      dateCreated: "DateCreated",
      dateModified: "DateModified",
      modifiedBy: "ModifiedBy",
      status: "Status",
      enquiryFrom: "EnquiryFrom",
      dateUpdated: "DateUpdated"
    }
  },
  leadMeta: {
    table: "mb_leaddet",
    fields: {
      memberId: "MemberId",
      leadSource: "LeadSource",
      status: "Status"

      // leadCategory: "LeadCategory",
      // bcId: "BCId",
      // assignedBcId: "AssignedBCId",
      // vendorPurposeId: "VendorPurposeId",
      // leadStatus: "LeadStatus",
      // orgLeadSource: "orgLeadSource",
      // leadType: "LeadType",
      // leadLevel: "LeadLevel",
      // empId: "EmpId",
      // prevEmpId: "PrevEmpId",
      // branchId: "BranchId",
      // userLevel: "UserLevel",
      // leadLockTime: "LeadLockTime",
      // motherTongue: "MotherTongue",
      // domainId: "DomainId",
      // campaignId: "CampaignId",
      // alertFlag: "AlertFlag",
      // noOfRnrCount: "NoOfRNRCount",
      // noOfFollowUpCount: "NoOfFollowUpCount",
      // leadRotationCount: "LeadRotationCount",
      // serviceCategory: "ServiceCategory",
      // vendorType: "VendorType",
      // leadPriority: "LeadPriority",
      // followUpDate: "FollowUpDate",
      // appointmentDate: "AppointmentDate",
      // followupStatus: "FollowupStatus",
      // subFollowupStatus1: "SubFollowupStatus1",
      // subFollowupStatus2: "SubFollowupStatus2",
      // dateCalled: "DateCalled",
      // uniqueId: "UniqueId",
      // leadsUpdatedOn: "LeadsUpdatedOn",
      // dateAddedOn: "DateAddedOn",
      // leadReAssigned: "LeadReAssigned",
      // reAssignedStatus: "RE_AssignedStatus",
      // reAssignedSrc: "RE_AssignedSrc",
      // reAssignedBy: "RE_AssignedBy",
      // reLeadStatus: "RE_LeadStatus",
      // reEmpId: "RE_EmpId",
      // reDateCalled: "RE_DateCalled",
      // reFollowupStatus: "RE_FollowupStatus",
      // reNoOfRnrCount: "RE_NoOfRNRCount",
      // reFollowUpDate: "RE_FollowUpDate",
      // reNoOfFollowUpCount: "RE_NoOfFollowUpCount",
      // reLeadsUpdatedOn: "RE_LeadsUpdatedOn",
      // reAssignedDate: "RE_AssignedDate",
      // lastLeadStatus: "LastLeadStatus",
      // lastDateCalled: "LastDateCalled"
    }
  },
  serviceableCities: {
    table: "mb_serviceable_city",
    fields: {
      districtId: "DistrictId",
      stateId: "StateId",
      eprDistrictId: "EPRDistrictId",
      bmDistrictId: "BMDistrictId",
      cbsDistrictId: "CBSDistrictId",
      districtName: "DistrictName",
      vendorEnableMBZ: "VendorEnable_MBZ",
      vendorEnableMM: "VendorEnable_MM",
      vendorEnablePG: "VendorEnable_PG",
      vendorEnableMMA: "VendorEnable_MMA",
      isOSC: "IsOsc",
      portalVisibility: "PortalVisibility",
      status: "Status",
      createdOn: "CreatedOn"
    }
  },
  locality: {
    table: "mb_localitydet",
    fields: {
      id: "LocalityId",
      name: "LocalityName",
      pincode: "Pincode",
      cityId: "CityId",
      districtId: "DistrictId",
      stateId: "StateId",
      status: "Status"
    }
  },
  salesState: {
    table: "mb_statedet",
    fields: {
      id: "StateId",
      name: "StateName",
      address: "StateAddress",
      enable: "VendorEnable_MBZ",
      status: "Status"
    }
  },
  salesCities: {
    table: "mb_citydet",
    fields: {
      id: "CityId",
      name: "CityName",
      districtId: "DistrictId",
      stateId: "StateId",
      status: "Status"
    }
  },
  whatsappConsentLog: {
    table: "whatsapp_consent_log",
    fields: {
      id: "id",
      matriId: "matri_id",
      source: "source",
      type: "type",
      isWhatsappConsent: "is_whatsapp_consent",
      addedOn: "added_on"
    }
  }
};
