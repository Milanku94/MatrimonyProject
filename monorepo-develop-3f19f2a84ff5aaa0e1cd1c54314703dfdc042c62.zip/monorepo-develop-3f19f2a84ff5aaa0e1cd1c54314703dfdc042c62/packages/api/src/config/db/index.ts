import { mBazaar } from "./mbazaar";
import { mBazaarProspect } from "./mbazaarProspect";
import { mBazaarService } from "./mbazaarService";

export default {
  mBazaar,
  mBazaarService,
  mBazaarProspect
};
