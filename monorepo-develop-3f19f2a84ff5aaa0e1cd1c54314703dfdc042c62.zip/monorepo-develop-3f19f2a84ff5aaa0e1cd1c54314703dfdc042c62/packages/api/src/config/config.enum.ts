/**
 * Vendor onBoard
 */
export enum verifiedSource {
  CUSTOMER = 1,
  VENDOR = 2,
  PROSPECT = 3,
  VENDOR_APP = 4
}

export enum textMessageEnqSrc {
  VENDOR_ONBOARD_OTP = 1
}

export enum checkPointList {
  BUSINESS = 15,
  PROFILE = 20,
  KYC = 30,
  PROFILE_DETAILS = 40,
  DASHBOARD = 50
}
export enum userRole {
  VENDOR = "VENDOR",
  ADMIN = "ADMIN"
}
export enum vendorRole {
  NO_ROLE = 0,
  DIRECTOR = 1,
  MANAGER = 2,
  TRUSTEE = 3,
  PARTNER = 4,
  PROPRIETOR = 5,
  AGENT = 6
}
export enum paidStatus {
  FREE = 0,
  PAID = 1
}
export enum vendorDocStatus {
  REMOVED = 0,
  ACTIVE = 1,
  PENDING = 2,
  REJECTED = 3,
  DELETION_QUEUE = 4
}
export enum vendorDocCategory {
  AGREEMENT_DOC = 1,
  KYC_DOC = 2,
  BUSINESS_DOC = 3,
  PAYMENT_DOC = 4,
  PO_DOC = 5
}
export enum onBoardProgressStatus {
  VENDOR_DETAILS = 1,
  CATEGORY_DETAILS = 2,
  CATEGORY_SETTINGS_DETAILS = 3,
  CITY_DETAILS = 4,
  WALLET_DETAILS = 5,
  WALLET_LOG_DETAILS = 6,
  IMAGES_DETAILS = 7,
  DOCUMENTS_DETAILS = 8,
  BANNER_PAYMENT_DETAILS = 9,
  BANNER_IMAGES = 10,
  BANNER_TAG_IMAGES = 11,
  CATEGORY_PAYMENT_DETAILS = 12
}
export enum miscListCompetition {
  JUST_DIAL = 1,
  SULEKHA = 2,
  WED_ME_GOOD = 3,
  OTHERS = 4
}
export enum miscOperatingOutOf {
  NOT_AVAILABLE = 0,
  HOME = 1,
  OFFICE = 2,
  OTHERS = 3
}
export enum miscEventConducted {
  NOT_AVAILABLE = 0,
  LESS_THEN_10 = 1,
  LESS_THEN_50 = 2,
  LESS_THEN_100 = 3,
  LESS_THEN_500 = 4,
  LESS_THEN_1000 = 5,
  MORE_THEN_1000 = 6
}
export enum miscMiscNosEmployees {
  NOT_AVAILABLE = 0,
  LESS_THEN_10 = 1,
  LESS_THEN_25 = 2,
  LESS_THEN_50 = 3,
  LESS_THEN_100 = 4,
  MORE_THEN_101 = 5
}

export enum profileStatus {
  INACTIVE = 0,
  ACTIVE = 1,
  DELETE = 2
}
export enum profileLeadManagementStatus {
  DISABLE = 0,
  ON = 1,
  OFF = 3,
  DELETE = 4
}
export enum profileCommissionApproved {
  NO = 0,
  YES = 1
}
export enum profilePackage {
  OLD = 0,
  NEW = 1
}
export enum profileServiceable {
  SERVICEABLE_CITY = 0,
  OTHER_SERVICEABLE_CITY = 1
}
export enum profileAttributeFieldType {
  TEXT_BOX = 0,
  TEXT_AREA = 1,
  RADIO_BUTTON = 2,
  CHECKBOX = 3,
  SELECT_BOX = 4,
  MULTIPLE_SELECT_BOX = 5,
  PASSWORD = 6,
  RANGE = 7,
  SPLIT_TEXT = 8,
  SPLIT_OPTION = 9,
  SPLIT_FIELD_OPTION = 14,
  DATE = 15,
  MULTIPLE_DATE = 16
}
export enum leadTag {
  Direct = "Direct",
  Lead = "Lead",
  Order = "Order",
  Call = "Call"
}

export enum leadFeedbackCreatedByType {
  SELF = "SELF",
  CALL = "CALL"
}
export enum ticketSrc {
  PARTNER_APP = "PARTNER_APP",
  CRM = "CRM"
}
export enum ticketStatus {
  OPEN = "OPEN",
  CLOSED = "CLOSED"
}
export enum leadFeedbackType {
  SUCCESS = "SUCCESS",
  FAILURE = "FAILURE",
  ARCHIVE = "ARCHIVE"
}
export enum leadFeedbackDispositionTypes {
  SUCCESS_INTERESTED = "SUCCESS_INTERESTED",
  FAILURE_RINGING_NO_RESPONSE = "FAILURE_RINGING_NO_RESPONSE",
  FAILURE_NOT_INTERESTED = "FAILURE_NOT_INTERESTED",
  FAILURE_SERVICE_UNAVAILABLE = "FAILURE_SERVICE_UNAVAILABLE",
  FAILURE_CITY_UNAVAILABLE = "FAILURE_CITY_UNAVAILABLE",
  FAILURE_ALREADY_BOOKED = "FAILURE_ALREADY_BOOKED",
  COMMUNICATION_CALL = "COMMUNICATION_CALL",
  UPDATE_ADD_NOTE = "UPDATE_ADD_NOTE",
  ARCHIVE_EVENT_DONE = "ARCHIVE_EVENT_DONE",
  ARCHIVE_EVENT_CANCELLED = "ARCHIVE_EVENT_CANCELLED"
}
export enum notificationTypes {
  PROFILE_ACTIVATION = "PROFILE_ACTIVATION",
  LEAD = "LEAD",
  TRANSACTION = "TRANSACTION",
  FOLLOWUP = "FOLLOWUP",
  APP_LANDING = "APP_LANDING"
}
export enum vendorPaymentStatus {
  EXPIRED = "EXPIRED",
  PENDING = "PENDING",
  ACTIVATED = "ACTIVATED",
  RENEW_ACTIVATED = "RENEW_ACTIVATED"
}
export enum bazaarTransaction {
  PAYMENT = "Payment",
  LEAD = "Lead",
  ORDER = "Order",
  DIRECT = "Direct",
  CALL = "Call",
  REFUND = "Refund",
  ACTIVATION_FEE = "Activation fee",
  BANNER_PACKAGE = "Banner Package",
  BRAND_PACKAGE = "Brand Package",
  LEAD_LISTING_PACKAGE = "Lead Listing Package",
  MONTHLY_FEE = "Monthly fee",
  LISTING_FEE = "Listing fee",
  REVERSAL = "Reversal"
}
export enum paymentMode {
  WALLET = 16,
  TRIAL_PACKAGE = 17,
  CHEQUE = 1,
  DD = 2,
  NEFT = 3,
  DEBIT_CARD = 4,
  CREDIT_CARD = 5,
  OFFLINE = 6,
  RO = 7,
  ONLINE = 8,
  RAZZLE_PAY = 15
}
export enum callStatus {
  MISSED_CALL = 0,
  CONNECTED = 1
}
export enum leadSource {
  BM_DELETED_MBZ = 1,
  CBS_DELETED = 15,
  MANUAL_CREATE = 3,
  WEB_SITE = 4,
  CHAT = 5,
  VENUE_BANNER = 6,
  M_PHOTOGRAPHY = 7,
  M_PHOTOGRAPHY_CONVERTED = 8,
  M_PHOTOGRAPHY_TOUCHED = 9,
  MISSEDCALL_API = 10,
  HELP_LINE = 11,
  MATRIMONY_DIRECTORY_WEB = 12,
  MATRIMONY_DIRECTORY_WAP = 13,
  BM_DELETED_MARRIED = 14,
  MANDAPAM_WEB = 16,
  MBAZAAR_HELPLINE_INBOUND = 17,
  MBAZAAR_TVC_INBOUND = 18,
  BM_WEB_MM = 19,
  KEY_VENDOR_LEADS = 20,
  MM_CHAT = 21,
  MM_INBOUND_CALL = 22,
  MM_REFERRAL = 23,
  M_MANDAP_SEM = 24,
  BM_WEB_MBZ = 25,
  BM_DELETED_INTERESTED_MBZ = 26,
  BM_BANNER_MBZ = 27,
  BM_DELETED_INTERESTED_MM = 28,
  BM_BANNER_MM = 29,
  BANNER_CAMPAIGN_MM = 30,
  MISSEDCALL_MM = 31,
  BM_DELETED_MM = 32,
  INTERESTED_IN_MBZ = 33,
  WEB_SR_H_PAGE_MBZ = 34,
  WEB_LIST_VIEW_MBZ = 35,
  WEB_SR_STRIP_MBZ = 36,
  WEB_SAVC_MBZ = 37,
  WEB_DEAL_LIST_MBZ = 38,
  MBZ_INBOUND_CALL = 39,
  MISSED_CALL_MBZ = 40,
  MBZ_SEM = 41,
  BM_DELETED_CCP = 42,
  BM_DELETED_INTERESTED_CCP = 43,
  BM_SUCCESS_STORY_CCP = 44,
  CBS_DELETED_CCP = 45,
  CBS_DELETED_INTERESTED_CCP = 46,
  CBS_SUCCESS_STORY_CCP = 47,
  INTERESTED_IN_MM = 48,
  SPL_BK_WEB_MM = 49,
  SPL_LP_WEB_MM = 50,
  INTERESTED_IN_PG = 51,
  INTERESTED_IN_MBZ_CCP = 52,
  WALK_IN_MMA = 53,
  PHONE_ENQUIRY_MMA = 54,
  BANNER_CAMPAIGN_MMA = 55,
  CLASSIFIEDS_MMA = 56,
  INBOUND_MMA = 57,
  INTERESTED_IN_MBZ_MMA = 58,
  INTERESTED_IN_PG_MMA = 59,
  OTHERS = 126,
  INTERESTED_IN_MM_MMA = 60,
  INTERESTED_IN_MMA = 62,
  M_FIXED_THRU_BM_PORTAL = 63,
  M_FIXED_THRU_BM_OTHER_SRC = 64,
  MM_INBOUND_WEB = 65,
  MM_INBOUND_BTL = 66,
  MM_INBOUND_ATL = 67,
  M_FIXED_THRU_CBS_PORTAL = 68,
  M_FIXED_THRU_CBS_OTHER_SRC = 69,
  BM_ACTIVE_INTERESTED_MM = 70,
  MMA_INTEREST = 71,
  VM_INBOUND_ANSWERED = 72,
  WPS_HOME = 73,
  WPS_SEM = 74,
  VM_INBOUND_MISSED = 75,
  M_PHOTOGRAPHY_NOT_CONVERTED = 76,
  BM_M_FIXED_THRU_COMMENTS = 77,
  CBS_M_FIXED_THRU_COMMENTS = 78,
  VENDOR_THRU_API = 79,
  VENDOR_THRU_MANUAL = 80,
  INTERESTED_M_FIXED_VIA_BM = 81,
  INTERESTED_M_FIXED_VIA_CBS = 82,
  BM_WEDDING_ASSIST = 83,
  FB_WEDDING_ASSIST_SEM = 84,
  GOOGLE_WEDDING_ASSIST_SEM = 85,
  DIRECT_WEDDING_ASSIST = 86,
  OTHER_WEDDING_ASSIST = 87,
  BM_PORTAL = 88,
  PORTAL_SELF_SIGN_UP = 89,
  RETAIL = 90,
  TOLL_FREE = 91,
  E_MAIL = 92,
  REFERENCE = 93,
  SUCCESS_STORY = 94,
  FB = 95,
  TWITTER = 96,
  INSTAGRAM = 97,
  PINTEREST = 98,
  YOUTUBE = 99,
  MANDAP_CONVERTED = 100,
  VENDOR_THRU_APP = 101
}
export enum vendorWalletType {
  LEAD = 1,
  COMMISSION = 2
}
export enum transactionType {
  CREDIT = 1,
  DEBIT = 2
}
export enum vendorPaymentType {
  BANNER = 0,
  BRAND = 1,
  LEAD_LIST = 2
}
export enum vendorNotifyPaymentType {
  BANNER = 1,
  BRAND = 2,
  LEAD = 3,
  LISTING = 4
}
export enum eventType {
  ENGAGEMENT,
  MARRIAGE,
  NOT_AVAILABLE
}

/**
 * RM Toolkit
 */
export enum profession {
  SALARIED = "Salaried",
  SELF_EMPLOYED = "Selfemployed",
  RETIRED = "Retired",
  PROFESSIONAL = "Professional",
  BUSINESS = "Business"
}
export enum industry {
  BANKING = "Banking",
  HOSPITALITY = "Hospitality",
  GOVT = "Govt",
  IT_ITES = "IT/ ITES",
  MEDICAL_PHARMA = "Medical/ Pharma",
  MANUFACTURING = "Manufacturing",
  OTHERS = "Others"
}
export enum relationship {
  MY_SELF = "My Self",
  RELATIVE = "Relative",
  FRIEND = "Friend",
  SON = "Son",
  DAUGHTER = "Daughter",
  BROTHER = "Brother",
  SISTER = "Sister"
}
export enum hindu {
  BRAHMIN_BHATT = "Brahmin - Bhatt",
  BRAHMIN_DESHASTHA = "Brahmin - Deshastha",
  BRAHMIN_DRAVIDA = "Brahmin - Dravida",
  BRAHMIN_HAVYAKA = "Brahmin - Havyaka",
  BRAHMIN_HOYSALA = "Brahmin - Hoysala",
  BRAHMIN_IYENGAR = "Brahmin - Iyengar",
  BRAHMIN_IYER = "Brahmin - Iyer",
  BRAHMIN_MADHWA = "Brahmin - Madhwa",
  BRAHMIN_RIGVEDI = "Brahmin - Rigvedi",
  BRAHMIN_SANKETI = "Brahmin - Sanketi",
  BRAHMIN_SARASWAT = "Brahmin - Saraswat",
  BRAHMIN_SHIVHALLI = "Brahmin - Shivhalli",
  BRAHMIN_SMARTHA = "Brahmin - Smartha",
  BRAHMIN_VYAS = "Brahmin - Vyas",
  AGARWAL = "Agarwal",
  ARYA_VYSYA = "Arya Vysya",
  BUNT_SHETTY = "Bunt (Shetty)",
  CHETTIAR = "Chettiar",
  COORGI = "Coorgi",
  DEVANGA = "Devanga",
  GOAN = "Goan",
  GOWDA = "Gowda",
  GUPTA = "Gupta",
  KASHYAP = "Kashyap",
  KAYASTHA = "Kayastha",
  KHANDELWAL = "Khandelwal",
  KONKANI = "Konkani",
  KSHATRIYA = "Kshatriya",
  LINGAYATH = "Lingayath",
  MANGALOREAN = "Mangalorean",
  NAICKER = "Naicker",
  NAIDU = "Naidu",
  NAIK = "Naik",
  NAIR = "Nair",
  PATEL = "Patel",
  RAJASTANI = "Rajastani",
  RAJPUT = "Rajput",
  REDDY = "Reddy",
  SC = "SC",
  SOURASHTRA = "Sourashtra",
  ST = "ST",
  SUNDHI = "Sundhi",
  URS = "Urs",
  VAISH = "Vaish",
  VAISHNAV = "Vaishnav",
  VAISHNAVA = "Vaishnava",
  VAISHYA = "Vaishya",
  VISWABRAHMIN = "Viswabrahmin",
  VISWAKARMA = "Viswakarma",
  VOKKALIGA = "Vokkaliga",
  VYSYA = "Vysya",
  YADAV = "Yadav"
}
