import { notificationTypes } from "./config.enum";
export default {
  appLog: {
    initSuccess: `Initiation completed successfully`,
    initFailed: `Initiation failed`
  },
  smsProvider: {
    // updated SMS content need to whitelist on SMS service provider
    otpMessage: `<otp> is your One time password (OTP). Please use this to verify your mobile number - WeddingBazaar`,
    errorMessage: `Something broke. Please try again in sometime.`
  },
  imageUrl: {
    categoryIcon: `https://www.weddingbazaar.com/assets/icons/<categoryName>.png`
  },
  multer: {
    unSupportImage: "Unsupported image type. Please upload JPEG or PNG image."
  },
  attributesGroup: {
    basic: `Basic Details`,
    organization: `Organization Details`,
    service: `Service Details`,
    others: `Others`
  },
  profile: {
    duplicateProfileERR: `This profile already exists`
  },
  vendorLogin: {
    otpMisMatch: `Please enter the correct OTP`,
    otpRequest: `OTP will expire in <otpInterval> secs`,
    otpRequestFailed: `OTP request failed`,
    otpMaxRequestAVD: `You have reached the maximum possible attempts. Please try after <time> or contact our customer care on 8124222266`,
    otpMaxRequestPVD: `You have reached the maximum possible attempts. Please try after <time>`
  },
  vendorDetails: {
    mobileNumberAlreadyTaken: `This number is already registered`
  },
  vendorLeadFeedback: {
    mandatoryLeadId: "leadId is mandatory"
  },
  vendorValidate: {
    actual: `Active user`,
    prospect: `Prospect user`,
    new: `New user`
  },
  vendorKyc: {
    verified: `Verified`,
    rejected: `Rejected`,
    reviewing: `Reviewing`
  },
  notification: {
    [notificationTypes.LEAD]: {
      title: `Here's a new lead for you!`,
      body: `Call now to talk to the customer right away`
    },
    [notificationTypes.FOLLOWUP]: {
      title: `You have a pending follow-up`,
      body: `Call now to talk to the customer right away`
    },
    [notificationTypes.TRANSACTION]: {
      title: `Wallet updating`,
      body: `Tap to know more`
    },
    [notificationTypes.PROFILE_ACTIVATION]: {
      title: `Your profile is now Active`,
      body: `Tap here to view your profile `
    },
    [notificationTypes.APP_LANDING]: {
      title: `Haven't logged in in a while?`,
      body: `Add more details and photos on your profile to get more customers!`
    }
  }
};
