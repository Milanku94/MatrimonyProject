/**
 * Vendor onBoard
 */
export enum blogType {
  BLOGS_IDEAS = "BLOGS_IDEAS",
  WEDDING_STORIES = "WEDDING_STORIES",
  PARTNER_STORIES = "PARTNER_STORIES"
}
export enum userRole {
  AUTHOR = "AUTHOR",
  EDITOR = "EDITOR",
  ADMIN = "ADMIN"
}
export enum blogPostView {
  AUTHOR = "AUTHOR",
  EDITOR = "EDITOR",
  PUBLIC = "PUBLIC"
}
export enum blogStatus {
  DRAFT = "DRAFT",
  PUBLISHED = "PUBLISHED",
  REVIEW = "REVIEW",
  INACTIVE = "INACTIVE"
}
export enum userReviewStatus {
  ACTIVE = "ACTIVE",
  PENDING = "PENDING",
  REJECTED = "REJECTED"
}
export enum offersType {
  FLAT = "Flat Discount",
  PERCENTAGE = "Percentage Discount",
  FLAT_PERCENTAGE = "Flat & Percentage Discount",
  SPECIAL_OFFER_PRICE = "Special Offer Price",
  COMPLIMENTARY_SERVICE = "Complimentary Service"
}
export enum offersImagetype {
  OFFER_IMAGE = "1",
  TC_IMAGE = "2"
}
export enum searchLogType {
  SEARCH = "SEARCH",
  AUTO_SUGGEST = "AUTO_SUGGEST"
}
export enum whatsappConsentLogType {
  CUSTOMER = "1",
  VENDOR = "2",
  PROSPECT = "3"
}
export enum whatsappConsentLogSource {
  UNKNOWN = "0",
  PORTAL_ONBOARD = "1",
  PORTAL_LCF_DESKTOP = "2",
  PORTAL_LCF_MOBILE = "3",
  CRM = "4",
  APP_ANDRIOD = "5",
  APP_IOS = "6",
  PORTAL_SMS_URL_DESKTOP = "7",
  PORTAL_SMS_URL_MOBILE = "8"
}
