import { config } from "dotenv";
import fs from "fs";
import path from "path";

[
  ...(process.env.NODE_ENV === "development"
    ? [`../../.env.development.local`, `../../.env.development`]
    : [`../../.env.production.local`, `../../.env.production`]),
  "../../.env.local",
  "../../.env"
].forEach(
  name =>
    fs.existsSync(path.resolve(__dirname, name)) &&
    config({ path: path.resolve(__dirname, name) })
);

const MONGO_COLLECTION = {
  eventType: "event_type",
  vendorLead: "vendor_lead",
  person: "people",
  participant: "participant",
  address: "address",
  event: "event",
  profile: "profile"
};
export default {
  PORT: process.env.SERVER_PORT || 4000,

  PROFILE_COMPL_LEVEL_SCHEDULE:
    process.env.PROFILE_COMPL_LEVEL_SCHEDULE || "0 0 2 * * *",
  MONGO_URI: process.env.MONGO_URI || "mongodb://localhost:27017/test",

  REDIS: {
    MASTER_URL: process.env.REDIS_MASTER_URL || "127.0.0.1:6379",
    SLAVE_URL: process.env.REDIS_SLAVE_URL || "127.0.0.1:6379",
    PWD: process.env.REDIS_PWD || ""
  },
  MONGO_COLLECTION,
  VENDOR_PARTNER_MOCK: process.env.VENDOR_PARTNER_MOCK || false,
  HIDE_APOLLO_PLAYGROUND: process.env.HIDE_APOLLO_PLAYGROUND || false,

  GQL_QUERY_LOG: process.env.GQL_QUERY_LOG === "enable" || false,

  SUPPORT_MAIL_TO: process.env.SUPPORT_MAIL_TO || "",

  JWT: {
    SECRET: process.env.JWT_SECRET || "",
    AUTH_TOKEN_NAME: process.env.JWT_AUTH_TOKEN_NAME || "x-access-token",
    EXPIRES_IN: process.env.JWT_EXPIRES_IN || "1d"
  },

  SERVICES_CRM: {
    IS_MOCK: process.env.SERVICE_CRM_MOCK || false,
    BASE_URL: process.env.SERVICES_CRM_BASE_URL || "",
    BASIC_AUTH: process.env.SERVICES_CRM_BASIC_AUTH || ""
  },

  FCM_DB_URI: process.env.FCM_DB_URI || "",
  DEVICE_TOKEN_NAME: process.env.DEVICE_TOKEN_NAME || "x-device-token",
  HASH_SALT_KEY: process.env.HASH_SALT_KEY || "",
  MOB_ENCRYPT_KEY: process.env.MOB_ENCRYPT_KEY || "",

  IMAGE_DOC_PATH: process.env.IMAGE_DOC_PATH || "uploads/",
  VENDOR_ASSET_BASE_URL: process.env.VENDOR_ASSET_BASE_URL || "",

  SMS_PROVIDER: {
    URL: process.env.SMS_PROVIDER_URL || "",
    USERNAME: process.env.SMS_PROVIDER_USERNAME || "",
    PASSWORD: process.env.SMS_PROVIDER_PASSWORD || ""
  },
  LDAP_CONFIG: {
    URL: process.env.LDAP_URL || "",
    BIND_DN: process.env.LDAP_BIND_DN || "",
    BIND_CRED: process.env.LDAP_BIND_CRED || "",
    SEARCH_BASE: process.env.LDAP_SEARCH_BASE || "",
    SEARCH_FILTER: process.env.LDAP_SEARCH_FILTER || ""
  },
  DB_MBAZAAR: {
    HOST: process.env.DB_MBAZAAR_HOST || "",
    DB: process.env.DB_MBAZAAR_DB || "",
    USER_NAME: process.env.DB_MBAZAAR_USER_NAME || "",
    PWD: process.env.DB_MBAZAAR_PWD || ""
  },
  DB_MBAZAAR_SERVICES: {
    HOST: process.env.DB_MBAZAAR_SERVICES_HOST || "",
    DB: process.env.DB_MBAZAAR_SERVICES_DB || "",
    USER_NAME: process.env.DB_MBAZAAR_SERVICES_USER_NAME || "",
    PWD: process.env.DB_MBAZAAR_SERVICES_PWD || ""
  },
  DB_MBAZAAR_PROSPECT: {
    HOST: process.env.DB_MBAZAAR_PROSPECT_HOST || "",
    DB: process.env.DB_MBAZAAR_PROSPECT_DB || "",
    USER_NAME: process.env.DB_MBAZAAR_PROSPECT_USER_NAME || "",
    PWD: process.env.DB_MBAZAAR_PROSPECT_PWD || ""
  }
};
