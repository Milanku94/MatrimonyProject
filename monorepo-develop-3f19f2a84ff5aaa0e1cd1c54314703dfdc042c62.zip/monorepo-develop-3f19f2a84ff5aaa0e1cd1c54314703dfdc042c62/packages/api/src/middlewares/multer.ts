import multer from "multer";
import path from "path";
import config from "../config/config.env";
import TEMPLATE from "../config/config.message";

const storage = multer.diskStorage({
  destination: (req: any, file: any, cb: any) => {
    cb(null, config.IMAGE_DOC_PATH + "/temp");
  },
  filename: (req: any, file: any, cb: any) => {
    cb(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  }
});
const imageUpload = multer({
  storage,
  fileFilter: (req: any, file: any, callback: any) => {
    const ext = path.extname(file.originalname);
    if (ext !== ".png" && ext !== ".jpg" && ext !== ".gif" && ext !== ".jpeg") {
      return callback(TEMPLATE.multer.unSupportImage, null);
    }
    callback(null, true);
  }
});
export { storage, imageUpload };
