export const logMetrics = (
  req: Express.Request,
  res: Express.Response,
  next: any
) => {
  // console.log("++++++++++");
  next();
};
