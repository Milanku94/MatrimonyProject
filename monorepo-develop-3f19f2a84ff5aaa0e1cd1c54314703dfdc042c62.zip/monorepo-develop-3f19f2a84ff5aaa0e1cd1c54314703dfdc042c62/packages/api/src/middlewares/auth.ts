import jwt from "jsonwebtoken";
import passport from "passport";
import {
  ExtractJwt as jwtExtract,
  Strategy as jwtStrategy
} from "passport-jwt";
import LdapStrategy from "passport-ldapauth";
import config from "../config/config.env";

const jwtOptions = {
  jwtFromRequest: jwtExtract.fromAuthHeaderWithScheme("JWT"),
  secretOrKey: config.JWT.SECRET
};
const {
  URL,
  BIND_DN,
  BIND_CRED,
  SEARCH_BASE,
  SEARCH_FILTER
} = config.LDAP_CONFIG;
const ldapOptions = {
  server: {
    url: URL,
    bindDN: BIND_DN,
    bindCredentials: BIND_CRED,
    searchBase: SEARCH_BASE,
    searchFilter: SEARCH_FILTER
  }
};

passport.use(
  new LdapStrategy(ldapOptions, (user: any, done: any) => {
    done(null, user);
  })
);
passport.use(
  "jwt",
  new jwtStrategy(jwtOptions, (payload: any, done: any) => {
    console.log("##payload##", payload);
    done(null, payload);
  })
);

const LoginController = (req: any, res: any) => {
  const token = jwt.sign({ id: req.user.uid }, config.JWT.SECRET);
  console.log(req.user);
  res.json({
    success: true,
    message: "Authentication successful!",
    token
  });
};

export { LoginController };
export default passport;
