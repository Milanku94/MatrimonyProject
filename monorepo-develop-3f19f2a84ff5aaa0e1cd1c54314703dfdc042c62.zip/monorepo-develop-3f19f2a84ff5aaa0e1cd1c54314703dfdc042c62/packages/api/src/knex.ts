import Knex from "knex";
import config from "./config/config.env";

export const getKnexInstance = ({
  HOST,
  USER_NAME,
  PWD,
  DB
}: {
  HOST: string;
  USER_NAME: string;
  PWD: string;
  DB: string;
}): Knex => {
  return Knex({
    client: "mysql",
    connection: {
      host: HOST,
      user: USER_NAME,
      password: PWD,
      database: DB
    },
    pool: {
      afterCreate: (conn: any, done: any) => {
        // Note: https://stackoverflow.com/a/44305593
        conn.query(
          "SET @@sql_mode = 'NO_ENGINE_SUBSTITUTION';",
          (err: any, res: any) => {
            if (err) {
              console.log("KNEX connection ERR:", err);
              done(err, conn);
            } else {
              // console.log("KNEX connected SUCCESSFULLY:", res);
              done(err, conn);
            }
          }
        );
      }
    }
  } as Knex.Config);
};

export const mBazaar: Knex = getKnexInstance(config.DB_MBAZAAR);
export const mBazaarServices: Knex = getKnexInstance(
  config.DB_MBAZAAR_SERVICES
);
export const mBazaarProspect: Knex = getKnexInstance(
  config.DB_MBAZAAR_PROSPECT
);
