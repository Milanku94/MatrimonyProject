import { vendorDocStatus } from "../config/config.enum";
import DB from "../config/db";
import { mBazaar, mBazaarProspect } from "../knex";

export const getProfileImages = async ({
  KnexInstance,
  vendorId,
  categoryId,
  cityId
}: {
  KnexInstance: typeof mBazaar | typeof mBazaarProspect;
  vendorId: any;
  categoryId: any;
  cityId: any;
}): Promise<{ total: number }> =>
  (
    await KnexInstance(DB.mBazaarProspect.profileGallery.table)
      .select(mBazaarProspect.raw(`PhotoStatus`).wrap(`count(`, `) as total`))
      .where({
        vendor_id: vendorId,
        category_id: categoryId
      })
      .whereIn(
        [`city_id`, `PhotoStatus`],
        [
          [cityId, vendorDocStatus.ACTIVE],
          [0, vendorDocStatus.ACTIVE]
        ]
      )
  )[0];

export const getAllProfileAttributes = async ({
  vendorId,
  categoryId,
  cityId
}: {
  vendorId: any;
  categoryId: any;
  cityId: any;
}): Promise<Array<{
  vendorId: any;
  cityId: any;
  categoryId: any;
  subHeaderId: any;
  headerId: any;
  headerValue: any;
  isDistribute: any;
  fieldType: any;
  fieldIds: any;
  fieldValues: any;
  textValues: any;
}>> =>
  await mBazaar({
    csh: "categorySubHeaderfields"
  })
    .select(
      mBazaar.raw(`vendor_id`).wrap("vcd.", " as vendorId"),
      mBazaar.raw(`city_id`).wrap("vcd.", " as cityId"),
      `csh.CategoryId as categoryId`,
      `csh.CatSubHdrFieldId as subHeaderId`,
      `csh.CatHdrFieldId as headerId`,
      mBazaar
        .raw(
          `SELECT ch.HdrFieldValue 
            FROM mbazaar.categoryHeaderFields ch 
            WHERE ch.CatHdrFieldId = csh.CatHdrFieldId`
        )
        .wrap(`(`, `) headerValue`),
      `csh.distribute_flag as isDistribute`,
      `csh.fieldtype as fieldType`,
      mBazaar.raw("category_fieldoption_id").wrap("vcd.", " as fieldIds"),
      mBazaar.raw("category_field_value").wrap("vcd.", " as fieldValues"),
      mBazaar.raw("txt_val").wrap("vcd.", " as textValues")
    )
    .leftJoin("mbazaarprospect.vendor_category_details as vcd", function() {
      this.on("vcd.category_subheader_id", "=", "csh.CatSubHdrFieldId")
        .andOn("vcd.vendor_id", "=", vendorId)
        .andOn("vcd.city_id", "=", cityId);
    })
    .where("csh.CategoryId", "=", categoryId);

export const getTotalProfiles = async ({
  KnexInstance,
  DBConfig
}: {
  KnexInstance: typeof mBazaar | typeof mBazaarProspect;
  DBConfig: typeof DB.mBazaarProspect | typeof DB.mBazaar;
}): Promise<{ totalRecords: any }> =>
  (
    await KnexInstance(DBConfig.profiles.table).select(
      KnexInstance.raw(DBConfig.profiles.fields.id).wrap(
        `count(`,
        `) as totalRecords`
      )
    )
  )[0];

export const getProfiles = async ({
  KnexInstance,
  DBConfig,
  page
}: {
  page: number;
  KnexInstance: typeof mBazaar | typeof mBazaarProspect;
  DBConfig: typeof DB.mBazaarProspect | typeof DB.mBazaar;
}) =>
  await KnexInstance(DBConfig.profiles.table)
    .select(DBConfig.profiles.fields)
    .orderBy(DBConfig.profiles.fields.id, "desc")
    .limit(10)
    .offset(page * 10);
export const getAttributesMeta = async ({
  attribute
}: {
  attribute: "progressLevel" | "nonDistribute";
}) =>
  await mBazaar(DB.mBazaar.attributeSubHeader.table)
    .column(DB.mBazaar.attributeSubHeader.fields)
    .where({
      [attribute === "progressLevel"
        ? DB.mBazaar.attributeSubHeader.fields.crmFlag
        : DB.mBazaar.attributeSubHeader.fields.distributeFlag]:
        attribute === "progressLevel" ? 4 : 0
    })
    .andWhere(DB.mBazaar.attributeSubHeader.fields.categoryId, ">=", 84);
export const getLifeTimeValue = async ({
  vendorId
}: {
  vendorId: any;
}): Promise<{ totalValueSpend: any }> =>
  (
    await mBazaar(DB.mBazaarProspect.vendorDetails.table)
      .select(mBazaar.raw("total_value_paid").wrap("", " as totalValueSpend"))
      .where({
        [DB.mBazaarProspect.vendorDetails.fields.vendorId]: vendorId
      })
  )[0] || { totalValueSpend: 0 };

export enum Rating {
  five = 4.5,
  four = 4,
  three = 3,
  two = 2,
  one = 1.5
}
export enum RatingWeightage {
  image = 0.25,
  lifeTimeValue = 0.3,
  kyc = 0.3,
  attributes = 0.15
}
export const ratingMetaLogic = {
  image: [
    {
      condition: ({ imagesCount }: { imagesCount: number }): boolean =>
        imagesCount > 50,
      rating: Rating.five
    },
    {
      condition: ({ imagesCount }: { imagesCount: number }): boolean =>
        imagesCount <= 50 && imagesCount >= 21,
      rating: Rating.four
    },
    {
      condition: ({ imagesCount }: { imagesCount: number }): boolean =>
        imagesCount <= 20 && imagesCount >= 11,
      rating: Rating.three
    },
    {
      condition: ({ imagesCount }: { imagesCount: number }): boolean =>
        imagesCount <= 10 && imagesCount >= 5,
      rating: Rating.two
    },
    {
      condition: ({ imagesCount }: { imagesCount: number }): boolean =>
        imagesCount < 5,
      rating: Rating.one
    }
  ],
  lifeTimeValue: [
    {
      condition: ({ totalValueSpend }: { totalValueSpend: number }): boolean =>
        totalValueSpend > 100000,
      rating: Rating.five
    },
    {
      condition: ({ totalValueSpend }: { totalValueSpend: number }): boolean =>
        totalValueSpend <= 100000 && totalValueSpend > 50000,
      rating: Rating.four
    },
    {
      condition: ({ totalValueSpend }: { totalValueSpend: number }): boolean =>
        totalValueSpend <= 50000 && totalValueSpend > 25000,
      rating: Rating.three
    },
    {
      condition: ({ totalValueSpend }: { totalValueSpend: number }): boolean =>
        totalValueSpend <= 25000 && totalValueSpend > 10000,
      rating: Rating.two
    },
    {
      condition: ({ totalValueSpend }: { totalValueSpend: number }): boolean =>
        totalValueSpend <= 10000 || !totalValueSpend,
      rating: Rating.one
    }
  ],
  kyc: [
    {
      condition: ({ documents }: { documents: any[] }): boolean =>
        documents.length >= 2,
      rating: Rating.five
    },
    {
      condition: ({ documents }: { documents: any[] }): boolean =>
        documents.length < 2 || !documents,
      rating: Rating.one
    }
  ]
};
export const profileScore = {
  basic: {
    score: 15,
    comments: "Basic Service mapping includes city/category"
  },
  contactInfo: { score: 20, comments: "Name, Address and Phone number" },
  kyc: {
    score: 20,
    comments: "Basic KYC (Aadhar, Passport, DL, GSTIN, Voter ID)"
  },
  imgBetter: { score: 10, comments: "At least 5 images per Profile" },
  imgGood: { score: 10, comments: "At least 15 images per Profile" },
  attributesDetails: {
    score: 10,
    comments: "Detailed informational attributes"
  }
};
