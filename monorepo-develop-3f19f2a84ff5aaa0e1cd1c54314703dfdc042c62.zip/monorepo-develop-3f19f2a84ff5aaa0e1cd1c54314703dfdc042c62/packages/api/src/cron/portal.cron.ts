import { forEach as _forEach } from "lodash";
import cron from "node-cron";
import { userReviewStatus } from "../config/config.portal.enum";
import DB from "../config/db";
import { mBazaar } from "../knex";
import { batchGenerateInquiry } from "../servers/portal/LatestInquries/GenerateInquries";
import { ReviewModel } from "../servers/portal/Review";
import { decryptProfileSlug } from "../servers/vendor/Profile";

export const scheduledGenerateInquiry = cron.schedule(
  "0 3 * * *",
  () => batchGenerateInquiry({ mode: "future" }),
  {
    scheduled: true,
    timezone: "Asia/Kolkata"
  }
);
export const profileUserRating = async () => {
  const { actual, fields, table } = DB.mBazaarProspect.profiles;
  const actualFields = { ...fields, ...actual };
  await ReviewModel.aggregate([
    {
      $match: {
        status: userReviewStatus.ACTIVE
      }
    },
    {
      $group: {
        _id: "$profileID",
        totalRaters: { $sum: 1 },
        rating: { $avg: "$overall" }
      }
    }
  ]).then((profiles: any) => {
    _forEach(
      profiles,
      async ({ _id: profileSlug, totalRaters, rating }: any) => {
        const { categoryId, cityId, vendorId } = decryptProfileSlug(
          profileSlug
        );
        await mBazaar(table)
          .update({
            [actualFields.rating]: rating,
            [actualFields.totalRaters]: totalRaters
          })
          .where({
            [actualFields.subCategoryId]: categoryId,
            [actualFields.cityId]: cityId,
            [actualFields.vendorId]: vendorId
          });
      }
    );
  });
};
export const profileUserRatingCron = cron.schedule(
  "0 0 3 * * *",
  profileUserRating
);
