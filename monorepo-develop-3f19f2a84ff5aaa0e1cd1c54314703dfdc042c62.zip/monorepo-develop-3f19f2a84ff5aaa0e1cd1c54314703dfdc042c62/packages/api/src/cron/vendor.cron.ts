import {
  every as _every,
  filter as _filter,
  find as _find,
  forEach as _forEach,
  range as _range
} from "lodash";
import cron from "node-cron";
import ENV from "../config/config.env";
import DB from "../config/db";
import { NotificationTypes } from "../generated/vendor.models";
import { mBazaarProspect } from "../knex";
import { provider as AppNotificationProvider } from "../servers/vendor/AppNotification";
import { getLatestVendorDocuments } from "../servers/vendor/VendorDocuments/VendorDocuments.provider";
import { VendorLeadFeedbackModel } from "../servers/vendor/VendorLeadFeedback";
import { objectDeepMap } from "../services/utils";
import { portableVendorContext } from "../services/vendorContext.utils";
import {
  getAllProfileAttributes,
  getAttributesMeta,
  getProfileImages,
  getProfiles,
  getTotalProfiles,
  profileScore
} from "./vendor.cron.utils";

// Todo: Actual DB
export const evaluateProfileCompletionLevel = async () => {
  console.log(":::: CRON_STARTED ::::");
  const { totalRecords } = await getTotalProfiles({
    KnexInstance: mBazaarProspect,
    DBConfig: DB.mBazaarProspect
  });
  console.log(":::: CRON Total profiles ::::", totalRecords, new Date());
  const progressAttributes = await getAttributesMeta({
    attribute: "progressLevel"
  });

  _forEach(_range(totalRecords / 10), (page: number) =>
    getProfiles({
      KnexInstance: mBazaarProspect,
      DBConfig: DB.mBazaarProspect,
      page
    }).then((totalProfile: any) => {
      // console.log("_page__", page, totalProfile.length);
      totalProfile.map(
        async ({ vendorId, subCategoryId: categoryId, cityId }: any) => {
          let profileCompletionScore: number = profileScore.basic.score;
          const { primary, address }: any = await objectDeepMap(
            (
              await mBazaarProspect(DB.mBazaarProspect.vendorDetails.table)
                .select(DB.mBazaarProspect.vendorDetails.fields)
                // Note: if its Actual Profile, need to check vendorId instead of id
                .where({
                  [DB.mBazaarProspect.vendorDetails.fields.prospectId]: vendorId
                })
            )[0]
          );
          const availableDocuments = await getLatestVendorDocuments({
            knexInstance: mBazaarProspect,
            vendorId
          });
          const profileImages = await getProfileImages({
            KnexInstance: mBazaarProspect,
            vendorId,
            categoryId,
            cityId
          });
          const profileAttributes = await getAllProfileAttributes({
            vendorId,
            categoryId,
            cityId
          });
          const profileAttributeDetails = _filter(profileAttributes, {
            headerValue: "Details"
          });
          if (
            primary &&
            primary.name &&
            address.cityId &&
            address.stateId &&
            address.pincode &&
            address.address &&
            primary.phone1.phone
          ) {
            profileCompletionScore += profileScore.contactInfo.score;
          }
          if (availableDocuments.length === 2) {
            profileCompletionScore += profileScore.kyc.score;
          }
          if (profileImages.total >= 5) {
            profileCompletionScore += profileScore.imgBetter.score;
          }
          if (profileImages.total >= 15) {
            profileCompletionScore += profileScore.imgGood.score;
          }
          if (
            profileAttributeDetails.length &&
            !_find(profileAttributeDetails, { vendorId: null })
          ) {
            if (
              !_every(profileAttributeDetails, {
                fieldIds: "",
                fieldValues: "",
                textValues: ""
              })
            ) {
              profileCompletionScore += profileScore.attributesDetails.score;
            }
          }
          const progressMeta = _find(progressAttributes, {
            categoryId
          });
          if (!progressMeta) {
            // Note: this profiles are contains deprecated/unRuled categories
            return;
          }
          const progressAttribute = {
            [DB.mBazaarProspect.profileAttributes.fields.vendorId]: vendorId,
            [DB.mBazaarProspect.profileAttributes.fields
              .categoryId]: categoryId,
            [DB.mBazaarProspect.profileAttributes.fields.cityId]: cityId,
            [DB.mBazaarProspect.profileAttributes.fields.header]:
              progressMeta.headerFieldId,
            [DB.mBazaarProspect.profileAttributes.fields.subHeaderId]:
              progressMeta.id,
            [DB.mBazaarProspect.profileAttributes.fields
              .txtVal]: profileCompletionScore
          };

          await mBazaarProspect(DB.mBazaarProspect.profileAttributes.table)
            .update(progressAttribute)
            .where({
              [DB.mBazaarProspect.profileAttributes.fields.vendorId]: vendorId,
              [DB.mBazaarProspect.profileAttributes.fields
                .categoryId]: categoryId,
              [DB.mBazaarProspect.profileAttributes.fields.cityId]: cityId,
              [DB.mBazaarProspect.profileAttributes.fields.subHeaderId]:
                progressMeta.id
            })
            .then(
              async (isUpdated: any) =>
                !isUpdated &&
                (await mBazaarProspect(
                  DB.mBazaarProspect.profileAttributes.table
                ).insert(progressAttribute))
            );
          // console.log("__PROF_SCORE__", cityId, categoryId, vendorId, profileCompletionScore);
        }
      );
    })
  );
};

const appNotificationProvider = new AppNotificationProvider(
  portableVendorContext()
);

const fcmFollowUp = async () => {
  const time = new Date();
  const followups = await VendorLeadFeedbackModel.find({
    followupDate: {
      $lt: new Date(+time.getTime() + 15 * 60 * 1000),
      $gt: time
    }
  });
  followups.map(({ vendorId, _id, leadSlug }: any) => {
    appNotificationProvider.notifyRec({
      userId: vendorId,
      type: NotificationTypes.Followup,
      leadFeedbackId: _id.toString(),
      leadSlug
    });
  });
};

export const fcmFollowUpCron = cron.schedule("0 */15 * * * *", () => {
  if (
    process.env.FOLLOWUP_CRON_ENABLE &&
    process.env.FOLLOWUP_CRON_ENABLE === "true"
  ) {
    fcmFollowUp();
  }
});
export const profileCompletionLevelCron = cron.schedule(
  ENV.PROFILE_COMPL_LEVEL_SCHEDULE,
  evaluateProfileCompletionLevel
);
