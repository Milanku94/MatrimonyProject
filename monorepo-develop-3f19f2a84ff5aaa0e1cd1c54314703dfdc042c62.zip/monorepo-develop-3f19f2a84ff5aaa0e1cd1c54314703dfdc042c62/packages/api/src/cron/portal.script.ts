import { each as forEach } from "async";
import cliProgress from "cli-progress";
import mongoose from "mongoose";
import config from "../config/config.env";
import { userReviewStatus } from "../config/config.portal.enum";
import { ReviewModel } from "../servers/portal/Review";
export const disableDuplicatedReview = async () => {
  mongoose
    .connect(config.MONGO_URI, {
      useNewUrlParser: true,
      useCreateIndex: true,
      useFindAndModify: false
    })
    .then(
      (success: any) => console.log("Successfully Connected with MongoDB"),
      (error: any) => console.log("Connection failed MongoDB..!!!!!!")
    );

  console.log(":::: REVIEW DUPLICATE CHECKING INIT ::::");
  const totalReview = await ReviewModel.countDocuments({});
  const totalProfile = await ReviewModel.distinct("profileID");
  const totalUser = await ReviewModel.distinct("user");
  const unKnownReview = await ReviewModel.countDocuments({
    user: { $exists: false }
  });
  const hiddenReview = await ReviewModel.countDocuments({
    status: userReviewStatus.REJECTED
  });
  console.log("Total Review  :", totalReview);
  console.log("Total Profile :", totalProfile.length);
  console.log("Total User    :", totalUser.length);
  console.log("Unknown Review:", unKnownReview);
  console.log("Hidden Review :", hiddenReview);
  await ReviewModel.updateMany(
    { user: { $exists: false } },
    { status: userReviewStatus.REJECTED }
  );
  const progressBar = new cliProgress.SingleBar({
    format:
      "Profile review duplicate fix | {bar} | {percentage}% || {value}/{total} profiles updated",
    barCompleteChar: "#",
    barIncompleteChar: "-",
    hideCursor: true
  });
  let progressedProfile = 1;
  progressBar.start(totalProfile.length, progressedProfile);
  await forEach(totalProfile, async (profile: string) => {
    const reviewedUsers = await ReviewModel.find({
      profileID: profile
    }).distinct("user");

    await ReviewModel.updateMany(
      { profileID: profile },
      { status: userReviewStatus.REJECTED }
    );
    await forEach(reviewedUsers, async (reviewedUser: string, clback: any) => {
      await ReviewModel.findOneAndUpdate(
        { profileID: profile, user: reviewedUser },
        { status: userReviewStatus.ACTIVE },
        {
          sort: { created: -1 }
        }
      ).then(() => clback());
    }).then(() => {
      if (totalProfile.length === progressedProfile) {
        progressBar.stop();
      } else {
        progressBar.update(++progressedProfile);
      }
    });
  });
};
