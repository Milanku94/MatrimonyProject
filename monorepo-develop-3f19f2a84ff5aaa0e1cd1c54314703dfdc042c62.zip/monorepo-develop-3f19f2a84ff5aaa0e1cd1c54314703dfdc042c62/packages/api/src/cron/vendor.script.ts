import cliProgress from "cli-progress";
import * as fs from "fs-extra";
import {
  difference as _difference,
  filter as _filter,
  find as _find,
  forEach as _forEach,
  map as _map,
  range as _range
} from "lodash";
import path from "path";
import DB from "../config/db";
import { mBazaar } from "../knex";
import { getLatestVendorDocuments } from "../servers/vendor/VendorDocuments/VendorDocuments.provider";
import {
  getAllProfileAttributes,
  getAttributesMeta,
  getLifeTimeValue,
  getProfileImages,
  getProfiles,
  getTotalProfiles,
  Rating,
  ratingMetaLogic,
  RatingWeightage
} from "./vendor.cron.utils";

const writeToCSVFile = async (records: any) => {
  const now = new Date();
  const exportPath = path.join(__dirname, "../../export");
  const isDirExist = await fs.pathExists(exportPath);
  if (!isDirExist) {
    await fs.mkdir(exportPath);
  }
  const filename = `${exportPath}/${[
    "profileBaseRatings",
    now.getDate(),
    now.getMonth() + 1,
    now.getFullYear(),
    [now.getHours(), now.getMinutes()].join(":")
  ].join("_")}.csv`;

  fs.writeFile(filename, extractAsCSV(records), (err: any) => {
    if (err) {
      console.log("Error writing to csv file", err);
    } else {
      console.log(`saved as ${filename}`);
    }
  });
};

const extractAsCSV = (records: any) =>
  [
    [
      "vendorId",
      "categoryId",
      "cityId",
      "imagesCount",
      "imgRating",
      "totalValueSpend",
      "lifeTimeValueRating",
      "documentsCount",
      "kycRating",
      "missedAttributes",
      "attributesRating",
      "normaliseValue",
      "baseRating"
    ].join(",")
  ]
    .concat(records)
    .join("\n");

export const profileBaseRating = async (args?: { normalisedValue: number }) => {
  console.log(":::: PROFILE BASE RATING INIT ::::");
  const { totalRecords } = await getTotalProfiles({
    KnexInstance: mBazaar,
    DBConfig: DB.mBazaarProspect
  });
  const nonDistributeAttributesMeta = await getAttributesMeta({
    attribute: "nonDistribute"
  });
  const profileProgressBar = new cliProgress.SingleBar({
    format:
      "Profile's Base Rating updating | {bar} | {percentage}% || {value}/{total} profiles updated",
    barCompleteChar: "#",
    barIncompleteChar: "-",
    hideCursor: true
  });
  profileProgressBar.start(totalRecords, 1);
  let progressedProfile = 1;
  const records: any[] = [];

  const maxBaseRating = args ? 5 - args.normalisedValue : 5;
  _forEach(_range(totalRecords / 10), (page: number) => {
    getProfiles({
      KnexInstance: mBazaar,
      DBConfig: DB.mBazaarProspect,
      page
    }).then((profiles: any[]) => {
      _forEach(
        profiles,
        async ({ vendorId, subCategoryId: categoryId, cityId }: any) => {
          const documents = await getLatestVendorDocuments({
            knexInstance: mBazaar,
            vendorId
          });
          const { total: imagesCount } = await getProfileImages({
            KnexInstance: mBazaar,
            vendorId,
            categoryId,
            cityId
          });
          const profileAttributes = await getAllProfileAttributes({
            vendorId,
            categoryId,
            cityId
          });
          const attributesMeta = _map(
            _filter(nonDistributeAttributesMeta, { categoryId }),
            "id"
          );
          const { totalValueSpend } = await getLifeTimeValue({ vendorId });

          const { rating: imgRating }: any = _find(
            ratingMetaLogic.image,
            ({ condition }: any) => condition({ imagesCount })
          );
          const { rating: kycRating }: any = _find(
            ratingMetaLogic.kyc,
            ({ condition }: any) => condition({ documents })
          );
          const {
            rating: lifeTimeValueRating
          }: any = _find(ratingMetaLogic.lifeTimeValue, ({ condition }: any) =>
            condition({ totalValueSpend })
          );
          const missedAttributes = _difference(
            attributesMeta,
            _map(_filter(profileAttributes, { isDistribute: 0 }), "subHeaderId")
          ).length;
          const attributesRating = missedAttributes ? Rating.one : Rating.five;

          const baseRating =
            imgRating * RatingWeightage.image +
            kycRating * RatingWeightage.kyc +
            lifeTimeValueRating * RatingWeightage.lifeTimeValue +
            attributesRating * RatingWeightage.attributes;
          const normalisedBaseRating =
            maxBaseRating < baseRating
              ? 5
              : baseRating + (args ? args.normalisedValue : 0);
          records.push(
            [
              vendorId,
              categoryId,
              cityId,
              imagesCount,
              imgRating,
              totalValueSpend,
              lifeTimeValueRating,
              documents.length,
              kycRating,
              missedAttributes,
              attributesRating,
              args ? args.normalisedValue : "",
              normalisedBaseRating
            ].join(",")
          );
          await mBazaar(DB.mBazaarProspect.profiles.table)
            .update({
              baseRating: normalisedBaseRating
            })
            .where({
              [DB.mBazaarProspect.profiles.fields.vendorId]: vendorId,
              [DB.mBazaarProspect.profiles.fields.subCategoryId]: categoryId,
              [DB.mBazaarProspect.profiles.fields.cityId]: cityId
            })
            .then(async () => {
              if (progressedProfile === totalRecords) {
                profileProgressBar.stop();
                await writeToCSVFile(records);
              } else {
                profileProgressBar.update(++progressedProfile);
              }
            });
        }
      );
    });
  });
};
