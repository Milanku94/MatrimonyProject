import Axios, { AxiosInstance } from "axios";
import ENV from "../config/config.env";

export default class VendorApi {
  private axios: AxiosInstance;
  constructor({ accessToken }: { accessToken: string }) {
    this.axios = Axios.create({
      baseURL: `http://localhost:${ENV.PORT}/vendor`,
      headers: {
        [ENV.JWT.AUTH_TOKEN_NAME]: accessToken
      }
    });
  }

  public getVendorWalletTransactionById = async ({
    transactionId
  }: {
    transactionId: string;
  }) =>
    (
      await this.axios.post("", {
        query: vendorWalletTransactionQuery({ transactionId })
      })
    ).data.data;
}

const vwTransactionCredit = `
  id
  type
  paymentType
  transactionAt
  paymentMode
  referenceNumber
  actualAmount
  transaction
  city
  category
`;
const vwTransactionDebit = `
  id
  type
  paymentType
  transactionAt
  paymentMode
  transaction
  actualAmount
  standardAmount
  bonusAmount
  city
  category
`;

const vendorWalletTransactionQuery = ({
  transactionId
}: {
  transactionId: string;
}): string => `{
  vendorWalletTransactionById(transactionId: "${transactionId}") {
    __typename
    ... on VendorBannerBrandDebitTransaction {
      ${vwTransactionDebit}
    }
    ... on VendorLeadDebitTransaction {
      ${vwTransactionDebit}
    }
    ... on VendorListingDebitTransaction {
      ${vwTransactionDebit}
    }
    ... on VendorBannerCredit {
      ${vwTransactionCredit}
    }
    ... on VendorBrandListingCredit {
      ${vwTransactionCredit}
    }
  }
}
`;
