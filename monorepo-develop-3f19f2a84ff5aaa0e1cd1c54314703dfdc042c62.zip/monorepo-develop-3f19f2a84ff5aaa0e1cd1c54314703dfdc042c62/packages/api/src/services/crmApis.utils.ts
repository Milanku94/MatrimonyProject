import axios from "axios";
import ENV from "../config/config.env";

const crmApi = axios.create({
  baseURL: ENV.SERVICES_CRM.BASE_URL,
  headers: {
    Authorization: ENV.SERVICES_CRM.BASIC_AUTH
  }
});
enum VendorType {
  ACTIVE_VENDOR = 1,
  PROSPECT_VENDOR = 2
}
enum ApiHit {
  API_HIT = 1
}
enum Type {
  LEAD_CREATION = 1,
  EMPLOYEE_ASSIGNMENT = 2
}
export enum SolrSource {
  UNKNOWN = 0,
  CRM = 1,
  ANDROID_APP = 2,
  IOS_APP = 3,
  PORTAL = 4
}

export enum SolrAction {
  ATTRIBUTE_UPDATE = "attribute_update",
  RATING_UPDATE = "rating_update"
  // OFFER_UPDATE = "offer_update",
  // IMAGE_UPDATE = "image_update",
}

export const createProspectTicket = async ({ vendorId }: { vendorId: any }) =>
  await crmApi.get("/prospect_vendor_api.php", {
    params: {
      vendor_id: vendorId,
      apihit: ApiHit.API_HIT,
      type: Type.LEAD_CREATION,
      skipauth: "mbazaarauthskip",
      vendor_type: VendorType.PROSPECT_VENDOR
    }
  });
export const updateVendorAcDetails = async (args: {
  vendorId: any;
  companyName?: any;
  primarycontactName?: any;
  primaryEmailId?: any;
  address?: any;
  cityId?: any;
  localityId?: any;
  stateId?: any;
  pincode?: any;
  latitude?: any;
  longitude?: any;
}) =>
  ENV.SERVICES_CRM.IS_MOCK
    ? {
        data: {
          code: "200",
          msg: "Dummy Ticket created successfully",
          ticket_id: 10000
        }
      }
    : await crmApi.post("/vendor_update_api.php", args);

export const getTicketsByVendor = async ({ vendorId }: { vendorId: any }) =>
  ENV.SERVICES_CRM.IS_MOCK
    ? { data: { code: "200", msg: "Success", tickets: [] } }
    : await crmApi.post("/vendor_tickets.php", { vendorId });
export const updateGalleryTicket = async ({
  vendorId,
  photoIds,
  action
}: {
  vendorId: any;
  photoIds: any[];
  action: "add" | "delete";
}): Promise<{
  photoId: number;
  status: string;
  response: string;
  ticket_id: number;
}> =>
  ENV.SERVICES_CRM.IS_MOCK
    ? { data: { code: "200", msg: [] } }
    : (
        await crmApi.post("/api/vendor_images.php", {
          vendorId,
          photoIds,
          action
        })
      ).data;

export const directivePermissionRequest = async ({
  vendorId
}: {
  vendorId: any;
}) =>
  ENV.SERVICES_CRM.IS_MOCK
    ? { data: { code: "200", msg: "Success" } }
    : await crmApi.post("/api/set_dir_permission.php", { dir_name: vendorId });

export const addSolrQueue = async ({
  vendorId,
  categoryId,
  cityId,
  action,
  source,
  diff
}: {
  vendorId: number;
  categoryId: number;
  cityId: number;
  action: SolrAction;
  source: SolrSource;
  diff: { old: JSON | {}; current: JSON };
}): Promise<{
  code: string;
  msg: string;
  ticket_id: number;
  solr_queue_ids: [number];
}> =>
  (
    await crmApi.post("api/vendor_update.php", {
      vendor_id: vendorId,
      category_id: categoryId,
      city_id: cityId,
      action,
      source,
      diff_data: diff
    })
  ).data;
