import nodemailer, { SendMailOptions } from "nodemailer";
import ENV from "../config/config.env";
const transporter = nodemailer.createTransport({
  sendmail: true,
  newline: "unix",
  path: "/usr/sbin/sendmail"
});

export const sendMail = ({
  subject,
  text,
  html
}: {
  subject: string;
  text?: string;
  html?: string;
}) =>
  new Promise((res, rej) =>
    transporter.sendMail(
      {
        from: {
          name: "WB Partner App",
          address: "no-reply@weddingbazaar.com"
        },
        to: ENV.SUPPORT_MAIL_TO.split(","),
        subject,
        text,
        html
      },
      (err: any, info: any) => {
        // console.log("____", info);
        if (err) {
          console.log(":::::  Error: Send mailer :::::", err);
        }

        res(info);
        rej(err);
      }
    )
  );
