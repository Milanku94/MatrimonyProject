// @ts-ignore
import { algorithm, mode, padding } from "cryptian";
import md5 from "md5";
import ENV from "../config/config.env";

export const crmEncrypt = (plaintext: string) => {
  const algo = new algorithm.Rijndael256();
  algo.setKey(md5(ENV.MOB_ENCRYPT_KEY));
  const cipher = new mode.cbc.Cipher(algo, md5(ENV.MOB_ENCRYPT_KEY));
  const padder = new padding.Null(cipher.getBlockSize());
  return Buffer.from(
    cipher.transform(padder.pad(Buffer.from(plaintext)))
  ).toString("base64");
};
export const crmDecrypt = (plaintext: string) => {
  const algo = new algorithm.Rijndael256();
  algo.setKey(md5(ENV.MOB_ENCRYPT_KEY));
  const cipher = new mode.cbc.Decipher(algo, md5(ENV.MOB_ENCRYPT_KEY));
  const padder = new padding.Null(cipher.getBlockSize());
  return Buffer.from(
    padder.unpad(cipher.transform(Buffer.from(plaintext, "base64")))
  ).toString();
};
