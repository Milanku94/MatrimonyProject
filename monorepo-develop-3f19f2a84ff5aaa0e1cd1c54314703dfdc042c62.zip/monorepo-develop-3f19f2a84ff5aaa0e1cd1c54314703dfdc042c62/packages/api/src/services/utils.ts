import {
  filter as _filter,
  mapKeys as _mapKeys,
  pickBy as _pickBy,
  set as _set
} from "lodash";

export const objectDeepMap = (actualData: any) => {
  const expectedObject: any = {};
  _mapKeys(actualData, (value: any, key: any) =>
    _set(expectedObject, key, value)
  );

  return expectedObject;
};
export const getValueByKey = (obj: any, key: any) => obj && obj[key];

export const enumToKeys = (enumObject: any) =>
  _filter(Object.values(enumObject), (val: any) => !isNaN(val));

export const enumToSchema = (enumObject: any) =>
  _filter(Object.keys(enumObject), isNaN);

export const enumToResolver = (enumObject: any) =>
  _pickBy(enumObject, (key: any) => !isNaN(key));

export const generateOTP = (): string => {
  const otpLength = 6;
  const otp = Math.round(Math.random() * Math.pow(10, otpLength)).toString();
  // Some OTPs aren't 6 digits. Regenerate if this is the case.
  return otp.length !== otpLength ? generateOTP() : otp;
};
export const templateToMessage = (src: string, obj: object) => {
  let message = src;
  Object.entries(obj).forEach(
    ([key, value]: any) =>
      (message = message.replace(new RegExp(`<${key}>`, "g"), value))
  );
  return message;
};

export const compareJSON = (
  old: { [key: string]: any },
  current: { [key: string]: any }
): { [key: string]: any } => {
  const diff: { [key: string]: any } = {};
  for (const i in current) {
    if (!old.hasOwnProperty(i) || current[i] !== old[i]) {
      diff[i] = current[i];
    }
  }
  return diff;
};
export const getCookieByName = (name: string, src: any) => {
  const value = "; " + src;
  const parts: any = value.split("; " + name + "=");
  if (parts.length === 2) {
    return parts[1].split(";")[0];
  }
  return "";
};
