import Path from "path";
import {
  createLogger,
  format,
  Logger,
  LoggerOptions,
  transports
} from "winston";
import DailyRotateFile from "winston-daily-rotate-file";

const myFormat = format.printf(
  ({ level, message, timestamp, label, ...metadata }: any) => {
    let msg = `${timestamp} ${label} ${level}: ${message} `;
    if (metadata) {
      msg += JSON.stringify(metadata);
    }
    return msg;
  }
);

const createRotateFile = ({ fileName }: { fileName: string }) =>
  createLogger({
    level: "debug",
    format: format.combine(
      format.label({ label: fileName }),
      format.timestamp(),
      myFormat
    ),
    transports: [
      new transports.Console({ level: "info" }),
      new DailyRotateFile({
        json: true,
        dirname: Path.join(__dirname, "../../log/"),
        filename: `${fileName}-%DATE%`,
        datePattern: "YYYY-MM-DD",
        extension: ".log",
        maxSize: 50 * 1000 * 1000
      })
    ]
  } as LoggerOptions);

export const logger = Object.fromEntries(
  [{ fileName: "vendorGQL" }, { fileName: "portalGQL" }].map(
    ({ fileName }: any) => {
      return [fileName, createRotateFile({ fileName }) as Logger];
    }
  )
) as { vendorGQL: Logger; portalGQL: Logger };
