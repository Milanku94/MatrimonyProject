/**
 * TODO: move into vendorServer.ts
 */
import { userRole } from "../config/config.enum";
import { vendorEnum } from "../dataSource/vendor";
import { mBazaar, mBazaarProspect, mBazaarServices } from "../knex";
import { hashIds } from "../services/hashIds.utils";
import { decodeVendorJWT } from "../services/jwt.utils";
import { objectDeepMap, templateToMessage } from "../services/utils";
import { VendorContext } from "../types";

export const portableVendorContext = (args?: {
  accessToken: string;
  deviceToken: string;
}): VendorContext => ({
  mBazaarProspect,
  mBazaar,
  mBazaarServices,
  user: args
    ? (decodeVendorJWT(args.accessToken) as any)
    : {
        id: "SUPER_ADMIN",
        vendorId: 0,
        prospectId: 0,
        businessName: "",
        role: userRole.ADMIN
      },
  deviceToken: args ? args.deviceToken : "",
  accessToken: args ? args.accessToken : "",
  dataSources: {
    vendorEnum,
    hashIds,
    objectDeepMap,
    templateToMessage
  }
});
