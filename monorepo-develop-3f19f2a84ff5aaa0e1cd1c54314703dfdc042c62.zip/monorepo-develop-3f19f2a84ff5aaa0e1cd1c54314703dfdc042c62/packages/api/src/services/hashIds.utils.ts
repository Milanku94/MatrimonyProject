import ENV from "../config/config.env";

/**
 * Original:
 * hashedIds
 * https://github.com/goldfashhosting/hashed-ids
 * (c) 2014 GoldFash Hosting
 */
class HashIds {
  public version = "0.1.3";

  private alphabet: string = "abcdefghijklmnopqrstuvwxyz";
  private primes: number[] = [
    2,
    3,
    5,
    7,
    11,
    13,
    17,
    19,
    23,
    29,
    31,
    37,
    41,
    43
  ];
  private minHashLength: number = 8;
  private salt: string = "";
  private guards: string[] = [];
  private seps: string[] = [];
  private guardIndexes: number[] = [0, 4, 8, 12];

  constructor(salt = "", minHashLength = 0, alphabet = "") {
    this.salt = salt;
    if (minHashLength > 0) {
      this.minHashLength = minHashLength;
    }
    if (alphabet) {
      this.alphabet = alphabet;
    }
    this.alphabet = [...new Set(this.alphabet.split(""))].join("");
    if (this.alphabet.length < 4) {
      throw new Error("Alphabet must contain at least 4 unique characters");
    }
    this.primes.forEach(prime => {
      if (this.alphabet.length >= prime) {
        const char = this.alphabet[prime - 1];
        this.seps.push(char);
        this.alphabet = this.alphabet.replace(char, " ");
      }
    });
    this.guardIndexes.forEach(guard => {
      if (this.seps[guard]) {
        this.guards.push(this.seps[guard]);
        this.seps.splice(guard, 1);
      }
    });
    this.alphabet = this.alphabet.replace(/ /g, "");
    this.alphabet = this.consistentShuffle(this.alphabet, this.salt);
  }

  public encrypt = (...ids: number[]): string =>
    this.encode(ids, this.alphabet, this.salt, this.minHashLength);

  public decrypt = (hash: string) => this.decode(hash);
  public encryptString = (ids: Array<number | string>): string =>
    this.encrypt(...Buffer.from(ids.join("|")));
  public decryptString = (hashString: string): string[] =>
    Buffer.from(this.decrypt(hashString))
      .toString()
      .split("|");
  private encode = (
    ids: number[],
    alphabet: string,
    salt: string,
    minHashLength = 0
  ) => {
    let ret = "";
    const seps = this.consistentShuffle(this.seps, ids).split("");
    let lotteryChar = "";
    ids.forEach((id, idx) => {
      if (!idx) {
        let lotterySalt = ids.join("-");
        ids.forEach(subNumber => (lotterySalt += "-" + (subNumber + 1) * 2));
        const lottery = this.consistentShuffle(alphabet, lotterySalt);
        lotteryChar = lottery[0];
        ret += lotteryChar;
        alphabet = lotteryChar + alphabet.replace(lotteryChar, "");
      }
      alphabet = this.consistentShuffle(
        alphabet,
        (lotteryChar.charCodeAt(0) & 12345) + salt
      );
      ret += this.hash(id, alphabet);
      if (idx + 1 < ids.length) {
        const sepsIndex = (id + idx) % seps.length;
        ret += seps[sepsIndex];
      }
    });
    if (ret.length < minHashLength) {
      let firstIndex = 0;
      ids.forEach((id, idx) => {
        firstIndex += (idx + 1) * id;
      });
      let guardIndex = firstIndex % this.guards.length;
      let guard = this.guards[guardIndex];
      ret = guard + ret;
      if (ret.length < minHashLength) {
        guardIndex = (guardIndex + ret.length) % this.guards.length;
        guard = this.guards[guardIndex];
        ret += guard;
      }
    }
    while (ret.length < minHashLength) {
      const padArray = [alphabet.charCodeAt(1), alphabet.charCodeAt(0)];
      const padLeft = this.encode(padArray, alphabet, salt);
      const padRight = this.encode(padArray, alphabet, padArray.join(""));

      ret = padLeft + ret + padRight;
      const excess = ret.length - minHashLength;
      if (excess > 0) {
        ret = ret.substring(excess / 2, excess / 2 + minHashLength);
      }
      alphabet = this.consistentShuffle(alphabet, salt + ret);
    }
    return ret;
  };

  private decode = (hash: string) => {
    const ret: number[] = [];
    if (hash) {
      if (!hash.match(new RegExp(`[${this.alphabet}]`))) {
        throw new Error("Invalid characters in hash");
      }

      let copyHash = hash;
      this.guards.forEach(guard => {
        copyHash = copyHash.replace(new RegExp(guard, "g"), " ");
      });
      const hashExplode = copyHash.split(" ");
      let i = 0;
      if (hashExplode.length === 3 || hashExplode.length === 2) {
        i = 1;
      }
      copyHash = hashExplode[i];
      this.seps.forEach(sep => {
        copyHash = copyHash.replace(new RegExp(sep, "g"), " ");
      });
      const hashArray = copyHash.split(" ");
      let alphabet = "";
      let lotteryChar = "";
      hashArray.forEach((subHash, idx) => {
        if (subHash.length > 0) {
          if (!idx) {
            lotteryChar = copyHash[0];
            subHash = subHash.substring(1);
            alphabet = lotteryChar + this.alphabet.replace(lotteryChar, "");
          }
          if (alphabet && lotteryChar) {
            alphabet = this.consistentShuffle(
              alphabet,
              (lotteryChar.charCodeAt(0) & 12345) + this.salt
            );
            ret.push(this.unHash(subHash, alphabet));
          }
        }
      });
      if (this.encrypt(...ret) !== hash) {
        throw new Error("Invalid hash");
      }
    }
    return ret;
  };

  private consistentShuffle = (alphabet: any, salt: any) => {
    let ret = "";
    if (Array.isArray(alphabet)) {
      alphabet = alphabet.join("");
    }
    if (Array.isArray(salt)) {
      salt = salt.join("");
    }
    const alphabetArray = alphabet.split("");
    const saltArray = salt.split("");
    const sortingArray = saltArray.map((char: string) => char.charCodeAt(0));
    sortingArray.forEach((_: any, idx: number) => {
      for (
        let add = true, k = idx, j = sortingArray.length + idx - 1;
        k !== j;
        k++, add = !add
      ) {
        const nextIndex = (k + 1) % sortingArray.length;
        if (add) {
          sortingArray[idx] += sortingArray[nextIndex] + k * idx;
        } else {
          sortingArray[idx] -= sortingArray[nextIndex];
        }
      }
      sortingArray[idx] = Math.abs(sortingArray[idx]);
    });
    let i = 0;
    while (alphabetArray.length > 0) {
      const alphabetSize = alphabetArray.length;
      let pos = sortingArray[i];
      if (pos >= alphabetSize) {
        pos %= alphabetSize;
      }
      ret += alphabetArray[pos];
      alphabetArray.splice(pos, 1);
      i = ++i % sortingArray.length;
    }
    return ret;
  };

  private hash = (input: number, alphabet: string) => {
    let hash = "";
    const alphabetLength = alphabet.length;
    do {
      hash = alphabet[input % alphabetLength] + hash;
      input = Math.floor(input / alphabetLength);
    } while (input);
    return hash;
  };

  private unHash = (input: string, alphabet: string) => {
    let id = 0;
    if (input && alphabet) {
      const alphabetLength = alphabet.length;
      const inputChars = input.split("");
      inputChars.forEach((char, idx) => {
        const pos = alphabet.indexOf(char);
        id += pos * Math.pow(alphabetLength, input.length - idx - 1);
      });
    }
    return id;
  };
}

export const hashIds: HashIds = new HashIds(ENV.HASH_SALT_KEY);
