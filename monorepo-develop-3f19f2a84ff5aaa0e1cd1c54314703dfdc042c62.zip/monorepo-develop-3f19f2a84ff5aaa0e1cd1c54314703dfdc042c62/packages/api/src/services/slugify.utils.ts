export const slugify = (name: string, options: any = {}) => {
  const defaultOptions = {
    lowercase: true,
    trim: true,
    spaces: true,
    nonWord: true,
    multipleHyphen: true,
    ampersand: true
  };
  const opt = { ...defaultOptions, ...options };
  let str = name;
  str = opt.lowercase ? str.toLowerCase() : str;
  str = opt.trim ? str.trim() : str;
  str = opt.spaces ? str.replace(/\s+/g, "-") : str; // Replace spaces with -
  str = opt.nonWord ? str.replace(/[^\w\-]+/g, "") : str; // Remove all non-word chars
  str = opt.multipleHyphen ? str.replace(/\-\-+/g, "-") : str; // Replace multiple - with single -
  str = opt.ampersand ? str.replace(/&/g, "-and-") : str; // Replace & with 'and'
  return str;
};
export const getSlug = (obj: any) => {
  const { id, name, slug } = obj;
  if (!!slug) {
    return slugify(slug);
  }
  return slugify(!!name ? name : id);
};
export const getSlugId = (obj: any) => {
  const { id, name, slug } = obj;
  if (!!slug) {
    return slugify(`${slug}-${id}`);
  }
  return slugify(!!name ? `${name}-${id}` : id);
};
export const addSlug = (obj: any): any => {
  if (!obj) {
    return;
  }
  if (obj instanceof Array) {
    return obj.map(o => addSlug(o));
  }
  if ("categories" in obj) {
    obj.categories = addSlug(obj.categories);
  }
  if ("attributes" in obj) {
    obj.attributes = addSlug(obj.attributes);
  }
  if ("options" in obj) {
    obj.options = addSlug(obj.options);
  }
  if ("profiles" in obj) {
    obj.profiles = addSlug(obj.profiles);
  }
  if ("badges" in obj) {
    obj.badges = Array.isArray(obj.badges) ? obj.badges : [obj.badges];
  }
  if ("categoryProfiles" in obj) {
    obj.categoryProfiles = addSlug(obj.categoryProfiles);
  }
  const { name, slug, slug_id } = obj;
  if (!name) {
    obj.slug = obj.id || null;
  } else if (!slug) {
    const newSlug = slugify(name);
    obj.slug = newSlug;
    obj.slug_id = `${newSlug}-${obj.id}`;
  } else if (!slug_id) {
    obj.slug_id = `${obj.slug}-${obj.id}`;
  }
  return obj;
};
