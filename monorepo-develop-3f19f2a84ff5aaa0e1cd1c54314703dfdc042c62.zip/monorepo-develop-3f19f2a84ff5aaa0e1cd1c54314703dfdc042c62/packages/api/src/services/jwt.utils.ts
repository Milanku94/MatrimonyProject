import jwt from "jsonwebtoken";
import config from "../config/config.env";
import { hashIds } from "../services/hashIds.utils";
import { PortalUserContext, UserContext, VendorProfiles } from "../types";

export const decodeVendorJWT = (token: string = "") => {
  if (token.startsWith("Bearer ")) {
    token = token.slice(7, token.length);
  }
  return jwt.verify(token, config.JWT.SECRET, (err: any, decoded: any) => {
    if (decoded) {
      const { vendorId, prospectId } = decryptVendorSlug(decoded.slug);
      return {
        vendorId,
        ...decoded,
        profiles:
          decoded.profiles && decoded.profiles.length
            ? decoded.profiles.map((profileSlug: any) =>
                decryptProfileSlug({ profileSlug })
              )
            : [],
        prospectId
      };
    }
  });
};

export const encodeVendorJWT = ({
  id,
  businessName,
  role,
  prospectId,
  vendorId,
  profiles
}: UserContext) =>
  jwt.sign(
    {
      id,
      businessName,
      slug: getVendorSlug({ prospectId, vendorId }),
      role,
      profiles: profiles.map(
        ({ categoryId, cityId, stateId, designation }: VendorProfiles) =>
          encryptProfileSlug({ categoryId, cityId, stateId, designation })
      )
    },
    config.JWT.SECRET,
    {
      expiresIn: config.JWT.EXPIRES_IN
    }
  );
export const getPortalJwtToken = ({ id, role, mailId }: PortalUserContext) =>
  jwt.sign({ id, role, mailId }, config.JWT.SECRET, { expiresIn: "1d" });

export const decodePortalJWT = (token: string = "") => {
  if (token.startsWith("Bearer ")) {
    token = token.slice(7, token.length);
  }
  return jwt.verify(token, config.JWT.SECRET, (err: any, decoded: any) => {
    if (decoded) {
      return decoded;
    }
  });
};

const getVendorSlug = ({
  vendorId,
  prospectId
}: {
  vendorId: number;
  prospectId: number;
}) => hashIds.encrypt(vendorId, prospectId);

const decryptVendorSlug = (
  slug: string
): { vendorId: number; prospectId: number } => {
  const [vendorId, prospectId] = hashIds.decrypt(slug);
  return { vendorId, prospectId };
};

const encryptProfileSlug = ({
  categoryId,
  cityId,
  designation = 0,
  stateId = 0
}: VendorProfiles) => {
  return hashIds.encrypt(categoryId, cityId, designation, stateId);
};
const decryptProfileSlug = ({ profileSlug }: { profileSlug: any }) => {
  const [categoryId, cityId, designation = 0, stateId = 0] = hashIds.decrypt(
    profileSlug
  );
  return { categoryId, cityId, designation, stateId };
};
