import * as admin from "firebase-admin";
import ENV from "../config/config.env";

admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: ENV.FCM_DB_URI
});
const fcmOptions: admin.messaging.MessagingOptions = {
  timeToLive: 60 * 60 * 24,
  // dryRun: process.env.NODE_ENV === "development",
  priority: "high" || "medium",
  // collapseKey?: string;
  mutableContent: true, // For ios - modify before display
  contentAvailable: true // For ios - iActive client App will awoken
  // restrictedPackageName?: string; // The package name of the application
};

export const sendAll = async (
  messages: admin.messaging.Message[]
): Promise<admin.messaging.BatchResponse> => {
  return await admin
    .messaging()
    .sendAll(
      messages
      //  process.env.NODE_ENV === "development"
    )
    .then(response => {
      // console.log("Successfully sent message:", JSON.stringify(response));
      return response;
    })
    .catch(error => {
      // console.log("Error FCM sending message:", error);
      return error;
    });
};
export const send = async (
  message: admin.messaging.Message
): Promise<string> => {
  return await admin
    .messaging()
    .send(message)
    .then(response => {
      // console.log("Successfully sent message:", JSON.stringify(response));
      return response;
    })
    .catch(error => {
      console.log("Error FCM sending message:", error);
      return error;
    });
};
export const sendToDevice = async ({
  token,
  payload,
  option = fcmOptions
}: {
  token: string | string[];
  payload: admin.messaging.MessagingPayload;
  option?: admin.messaging.MessagingOptions;
}) => {
  return await admin
    .messaging()
    .sendToDevice(token, payload, option)
    .then(response => {
      // console.log("Successfully sent message:", JSON.stringify(response));
      return response;
    })
    .catch(error => {
      // console.log("Error FCM sending message:", error);
      return error;
    });
};

interface GetAndroidNotification {
  priority: "high" | "min" | "low" | "default" | "max";
  clickAction: string;
  title: string;
  body: string;
  icon?: string;
  eventTimestamp?: Date;
}
const getAndroidNotification = ({
  priority = "high",
  title,
  body,
  icon,
  clickAction,
  eventTimestamp
}: GetAndroidNotification): admin.messaging.AndroidNotification => {
  return {
    priority,
    title,
    body,
    icon,
    clickAction,
    defaultVibrateTimings: true,
    defaultSound: true,
    eventTimestamp,
    sticky: true,
    defaultLightSettings: true
    // color?: string,
    // sound?: string,
    // tag?: string,
    // imageUrl?: string,
    // bodyLocKey?: string,
    // bodyLocArgs?: string[],
    // titleLocKey?: string,
    // titleLocArgs?: string[],
    // channelId?: string,
    // ticker?: string,
    // localOnly?: boolean,
    // vibrateTimingsMillis?: number[],
    // lightSettings?: LightSettings,
    // visibility?: ('private' | 'public' | 'secret'),
    // notificationCount?: number,
  };
};
const getAndroidConfig = ({
  data,
  notification
}: {
  data: { [key: string]: string };
  notification: GetAndroidNotification;
}): admin.messaging.AndroidConfig => {
  return {
    // collapseKey:
    priority: "high",
    ttl: 24 * 60 * 60,
    // restrictedPackageName
    // notification: getAndroidNotification(notification),
    // fcmOptions: null,
    data
  };
};
const getApnsConfig = ({
  headers,
  category,
  imageUrl,
  badge
}: {
  headers?: { [key: string]: string };
  imageUrl?: string;
  category: string;
  badge?: number;
}): admin.messaging.ApnsConfig => {
  return {
    headers,
    payload: {
      aps: {
        category,
        badge,
        contentAvailable: true,
        mutableContent: true,
        // alert: {
        //   title: "string",
        //   subtitle: "string",
        //   body: "string",
        //   locKey: "string",
        //   locArgs: ["string"],
        //   titleLocKey: "string",
        //   titleLocArgs: ["string"],
        //   subtitleLocKey: "string",
        //   subtitleLocArgs: ["string"],
        //   actionLocKey: "string",
        //   launchImage: "string"
        // },
        sound: "default"
        // threadId: "string",
        // other: "other"
      }
      // other: { other: other }
    },
    fcmOptions: {
      // analyticsLabel: "string",
      imageUrl
    }
  };
};
export const buildFcmMessage = ({
  clickAction,
  notification,
  data,
  eventTimestamp,
  badge,
  registerId,
  imageUrl
}: {
  clickAction: any;
  notification: { title: string; body: string; imageUrl?: string };
  data: { [key: string]: string };
  eventTimestamp?: Date;
  registerId: string;
  imageUrl?: string;
  badge: number;
}): admin.messaging.Message => ({
  token: registerId,

  notification,
  apns: getApnsConfig({
    badge,
    category: clickAction,
    imageUrl
  }),
  android: getAndroidConfig({
    data,
    notification: {
      priority: "high",
      clickAction,
      eventTimestamp,
      ...notification
    }
  }),
  data
});
