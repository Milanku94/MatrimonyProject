import axios from "axios";
import { xml2js, xml2json } from "xml-js";
import config from "../config/config.env";

const SENDER_ID = "WEDBZR";
const smsProvInfo = {
  accountUser: config.SMS_PROVIDER.USERNAME,
  senderId: SENDER_ID,
  smsProvider: "myValueFirst"
};
const smsProviderOption = {
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
};
export const sendMessage = async ({
  to,
  text
}: {
  to: number;
  text: string;
}) => {
  return await axios
    .post(
      config.SMS_PROVIDER.URL,
      transformRequest({
        data: getXmlData({
          text,
          to
        }),
        action: "send"
      }),
      smsProviderOption
    )
    .then(({ data }: any) => {
      const response: any = xml2js(data, { compact: true });
      if (response.MESSAGEACK.Err) {
        throw {
          info: smsProvInfo,
          ...response.MESSAGEACK.Err._attributes
        };
      }
      return {
        info: smsProvInfo,
        acknowledge: response.MESSAGEACK.GUID._attributes,
        error:
          response.MESSAGEACK.GUID.ERROR &&
          response.MESSAGEACK.GUID.ERROR._attributes
      };
    });
};

const transformRequest = (jsonData = {}) =>
  Object.entries(jsonData)
    .map((x: any) => `${encodeURIComponent(x[0])}=${encodeURIComponent(x[1])}`)
    .join("&");

// Todo: json2Xml
const getXmlData = ({
  text,
  to
}: any) => `<?xml version="1.0" encoding="ISO-8859-1"?>
    <!DOCTYPE MESSAGE SYSTEM "http://127.0.0.1/psms/dtd/message.dtd" >
    <MESSAGE>
    <USER 
      USERNAME="${config.SMS_PROVIDER.USERNAME}"
      PASSWORD="${config.SMS_PROVIDER.PASSWORD}"/>
      <SMS
        UDH="0"
        CODING="1"
        TEXT="${text}"
        PROPERTY="0"
        ID="1">
        <ADDRESS
          FROM="${SENDER_ID}"
          TO="${to}"
          SEQ="1"
          TAG="WeddingBazaar"/>
      </SMS>
    </MESSAGE>`;
