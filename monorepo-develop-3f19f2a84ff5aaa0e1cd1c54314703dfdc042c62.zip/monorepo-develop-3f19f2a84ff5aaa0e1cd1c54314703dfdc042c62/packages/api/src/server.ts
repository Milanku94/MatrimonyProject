// tslint:disable-next-line:no-var-requires
require("newrelic");
import bodyParser from "body-parser";
import { exec } from "child_process";
import express, { Express } from "express";
import useragent from "express-useragent";
import mongoose from "mongoose";
import config from "./config/config.env";
import { uploadDocController } from "./controller/vendor";
import {
  profileUserRatingCron,
  scheduledGenerateInquiry
} from "./cron/portal.cron";
import {
  fcmFollowUpCron,
  profileCompletionLevelCron
} from "./cron/vendor.cron";
import { mBazaar, mBazaarProspect, mBazaarServices } from "./knex";
import passport, { LoginController } from "./middlewares/auth";
import { checkToken } from "./middlewares/auth.helper";
import { logMetrics } from "./middlewares/logMetrics";
import { imageUpload } from "./middlewares/multer";
import { mbPortalServer, rmtoolServer, vendorServer } from "./servers";

profileCompletionLevelCron.start();
fcmFollowUpCron.start();
scheduledGenerateInquiry.start();
profileUserRatingCron.start();
const app: Express = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(passport.initialize());
app.use(useragent.express());

mongoose
  .connect(config.MONGO_URI, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false
  })
  .then(
    (success: any) => console.log("Successfully Connected with MongoDB"),
    (error: any) => console.log("Connection failed MongoDB..!!!!!!")
  );

app.use("/", logMetrics);
rmtoolServer({ mBazaar, mBazaarServices }).applyMiddleware({
  app,
  path: "/rmtool"
});

app.use(
  "/vendor/uploads",
  checkToken,
  imageUpload.array("docs"),
  uploadDocController
);
vendorServer({ mBazaar, mBazaarProspect, mBazaarServices }).applyMiddleware({
  app,
  path: "/vendor"
});
mbPortalServer({ mBazaar, mBazaarServices }).applyMiddleware({
  app,
  path: "/portal"
});

app.post(
  "/login",
  passport.authenticate("ldapauth", { session: false }),
  LoginController
);

app.listen({ port: config.PORT }, () => {
  console.log(`🚀  Server ready at ${config.PORT}`);
  exec("yarn generate:all", (err, stdout, stderr) => {
    if (err) {
      console.warn("types generating error:", err);
    }
    console.info("types generated \n", stdout);
  });
});
