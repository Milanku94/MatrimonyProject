import {
  GraphQLResolveInfo,
  GraphQLScalarType,
  GraphQLScalarTypeConfig
} from "graphql";
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K];
};
export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
export type RequireFields<T, K extends keyof T> = {
  [X in Exclude<keyof T, K>]?: T[X];
} &
  { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export interface Scalars {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  /** The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSON: any;
  /** DateTime custom scalar type */
  DateTime: any;
}

export interface AddLogResponse {
  status: Scalars["String"];
  message: Scalars["String"];
  deviceToken: Scalars["String"];
}

export interface Address {
  address?: Maybe<Scalars["String"]>;
  localityId?: Maybe<Scalars["ID"]>;
  cityId?: Maybe<Scalars["ID"]>;
  stateId?: Maybe<Scalars["ID"]>;
  locality?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  pincode?: Maybe<Scalars["String"]>;
  latitude?: Maybe<Scalars["String"]>;
  longitude?: Maybe<Scalars["String"]>;
}

export interface AddressInfo {
  addressLine1?: Maybe<Scalars["String"]>;
  addressLine2?: Maybe<Scalars["String"]>;
  locality?: Maybe<Locality>;
  city?: Maybe<City>;
}

export interface AddressInput {
  address: Scalars["String"];
  localityId: Scalars["ID"];
  cityId: Scalars["ID"];
  stateId: Scalars["ID"];
  pincode: Scalars["String"];
  latitude?: Maybe<Scalars["String"]>;
  longitude?: Maybe<Scalars["String"]>;
}

export interface AttributeHeader {
  id?: Maybe<Scalars["String"]>;
  name?: Maybe<Scalars["String"]>;
  categoryId?: Maybe<Scalars["String"]>;
  /**
   * displayOrder: String
   * visibleField: String
   * crmFlag: String
   */
  status?: Maybe<Scalars["String"]>;
}

/** Todo: need to remove */
export interface AttributesByGroup {
  groupName?: Maybe<Scalars["String"]>;
  attributes?: Maybe<Array<Maybe<AttributeSubHeader>>>;
}

/** Attributes */
export interface AttributeSubHeader {
  id: Scalars["ID"];
  label?: Maybe<Scalars["String"]>;
  question?: Maybe<Scalars["String"]>;
  groupName?: Maybe<Scalars["String"]>;
  groupOrder?: Maybe<Scalars["Int"]>;
  displayOrder?: Maybe<Scalars["Int"]>;
  /**
   * "we can categories the field"
   * header: String
   * "get the values alone for the information purpose"
   */
  values?: Maybe<Scalars["String"]>;
  /** headerId: ID! */
  fieldType?: Maybe<ProfileAttributeFieldType>;
  /** field is require or Not */
  isMandatory?: Maybe<Scalars["Boolean"]>;
  /** get the field related info for the form */
  fieldValues?: Maybe<Array<Maybe<FieldOptions>>>;
  fieldValidation?: Maybe<Scalars["JSON"]>;
  isEditable?: Maybe<Scalars["Boolean"]>;
}

export enum BazaarTransaction {
  Payment = "PAYMENT",
  Lead = "LEAD",
  Order = "ORDER",
  Direct = "DIRECT",
  Call = "CALL",
  Refund = "REFUND",
  ActivationFee = "ACTIVATION_FEE",
  BannerPackage = "BANNER_PACKAGE",
  BrandPackage = "BRAND_PACKAGE",
  LeadListingPackage = "LEAD_LISTING_PACKAGE",
  MonthlyFee = "MONTHLY_FEE",
  ListingFee = "LISTING_FEE",
  Reversal = "REVERSAL"
}

export interface BillingInfo {
  gstNo?: Maybe<Scalars["String"]>;
  gstBusinessName?: Maybe<Scalars["String"]>;
  gstState?: Maybe<Scalars["String"]>;
  billingName?: Maybe<Scalars["String"]>;
  billingAddress?: Maybe<Scalars["String"]>;
  salesCityId?: Maybe<Scalars["String"]>;
  salesStateId?: Maybe<Scalars["String"]>;
}

export interface BillingInfoInput {
  gstNumber?: Maybe<Scalars["String"]>;
  gstBusinessName?: Maybe<Scalars["String"]>;
}

export enum CacheControlScope {
  Public = "PUBLIC",
  Private = "PRIVATE"
}

export interface CallCustomer {
  tag?: Maybe<LeadTag>;
  mobileNo: Scalars["String"];
  virtualNo?: Maybe<Scalars["String"]>;
  /** ADMIN only can read this info */
  agentNo?: Maybe<Scalars["String"]>;
}

export interface CallInfo {
  status?: Maybe<CallStatus>;
  duration?: Maybe<Scalars["Int"]>;
}

export interface CallLeads {
  id: Scalars["ID"];
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  createdAt: Scalars["DateTime"];
  updatedAt?: Maybe<Scalars["DateTime"]>;
  followupDate?: Maybe<Scalars["DateTime"]>;
  customer: CallCustomer;
  call: CallInfo;
}

export enum CallStatus {
  MissedCall = "MISSED_CALL",
  Connected = "CONNECTED"
}

export interface Category {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  iconUrl?: Maybe<Scalars["String"]>;
  displayName?: Maybe<Scalars["String"]>;
  status?: Maybe<Scalars["Boolean"]>;
  displayOrder?: Maybe<Scalars["Int"]>;
}

export interface CheckPoint {
  step: CheckPointList;
  accessToken: Scalars["String"];
  deviceToken: Scalars["String"];
}

export interface CheckPointDeviceTokenArgs {
  newToken: Scalars["String"];
}

export enum CheckPointList {
  Business = "BUSINESS",
  Profile = "PROFILE",
  Kyc = "KYC",
  ProfileDetails = "PROFILE_DETAILS",
  Dashboard = "DASHBOARD"
}

export interface City {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  stateId: Scalars["ID"];
  isOSC?: Maybe<Scalars["Boolean"]>;
}

export interface ContactPerson {
  name: Scalars["String"];
  role?: Maybe<VendorRole>;
  email?: Maybe<Scalars["String"]>;
  phone1: ContactPhone;
  phone2: ContactPhone;
  isWhatsappConsent?: Maybe<Scalars["Boolean"]>;
}

export interface ContactPersonInput {
  name?: Maybe<Scalars["String"]>;
  phone: Scalars["ID"];
  role?: Maybe<VendorRole>;
  email?: Maybe<Scalars["String"]>;
  isWhatsappConsent?: Maybe<Scalars["Boolean"]>;
}

export interface ContactPersonReview {
  name?: Maybe<Scalars["String"]>;
  role?: Maybe<VendorRole>;
  email?: Maybe<Scalars["String"]>;
  phone1?: Maybe<ContactPhone>;
  phone2?: Maybe<ContactPhone>;
}

export interface ContactPhone {
  /** isd: String */
  phone: Scalars["String"];
  verifyStatus?: Maybe<Scalars["Boolean"]>;
  verifySource?: Maybe<VerifiedSource>;
  verifyOn?: Maybe<Scalars["String"]>;
}

export interface CrmCustomer {
  id?: Maybe<Scalars["ID"]>;
  tag?: Maybe<LeadTag>;
  name?: Maybe<Scalars["String"]>;
  mobileNo: Scalars["String"];
  emailId?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  status?: Maybe<Scalars["String"]>;
  createdAt: Scalars["DateTime"];
  updatedAt?: Maybe<Scalars["DateTime"]>;
}

export interface CrmCustomerDetails {
  relationship?: Maybe<Scalars["String"]>;
  age?: Maybe<Scalars["Int"]>;
  gender?: Maybe<Scalars["String"]>;
  brideName?: Maybe<Scalars["String"]>;
  groomName?: Maybe<Scalars["String"]>;
  event: LeadEvent;
}

export interface CrmLeads {
  id: Scalars["ID"];
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  status?: Maybe<Scalars["Boolean"]>;
  createdAt: Scalars["DateTime"];
  updatedAt?: Maybe<Scalars["DateTime"]>;
  followupDate?: Maybe<Scalars["DateTime"]>;
  customer: CrmCustomer;
  customerDetails?: Maybe<CrmCustomerDetails>;
  customerReq?: Maybe<ProfileAttributes[]>;
}

export interface CrmLeadsCustomerReqArgs {
  groupName?: Maybe<Scalars["String"]>;
}

export interface Customer {
  id?: Maybe<Scalars["ID"]>;
  tag?: Maybe<LeadTag>;
  name?: Maybe<Scalars["String"]>;
  mobileNo: Scalars["String"];
  emailId?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  status?: Maybe<Scalars["String"]>;
  createdAt?: Maybe<Scalars["String"]>;
  updatedAt?: Maybe<Scalars["String"]>;
}

export interface DeviceDetailsInput {
  simOperatorName?: Maybe<Scalars["String"]>;
  product?: Maybe<Scalars["String"]>;
  deviceId?: Maybe<Scalars["String"]>;
  appVersionName?: Maybe<Scalars["String"]>;
  device: Scalars["String"];
  model: Scalars["String"];
  operatorName?: Maybe<Scalars["String"]>;
  os?: Maybe<Scalars["String"]>;
  release?: Maybe<Scalars["String"]>;
  appVersion: Scalars["String"];
  serial?: Maybe<Scalars["String"]>;
  lineNumber?: Maybe<Scalars["String"]>;
  manufacturer?: Maybe<Scalars["String"]>;
  brand: Scalars["String"];
  deviceFingerprint?: Maybe<Scalars["String"]>;
}

export enum EventType {
  Engagement = "ENGAGEMENT",
  Marriage = "MARRIAGE",
  NotAvailable = "NOT_AVAILABLE"
}

export enum FeedbackType {
  AppFeedback = "APP_FEEDBACK",
  NotifyRecharge = "NOTIFY_RECHARGE",
  ConcernTransaction = "CONCERN_TRANSACTION"
}

export interface FieldOptions {
  id: Scalars["ID"];
  displayOrder?: Maybe<Scalars["Int"]>;
  value?: Maybe<Scalars["String"]>;
  checked?: Maybe<Scalars["Boolean"]>;
  isDefault?: Maybe<Scalars["Boolean"]>;
}

export interface FieldValidation {
  rule?: Maybe<Scalars["String"]>;
  err?: Maybe<Scalars["String"]>;
}

export interface GstAmount {
  cGst?: Maybe<Scalars["Float"]>;
  sGst?: Maybe<Scalars["Float"]>;
  iGst?: Maybe<Scalars["Float"]>;
}

export interface GstPercentage {
  cGst?: Maybe<Scalars["Float"]>;
  sGst?: Maybe<Scalars["Float"]>;
  iGst?: Maybe<Scalars["Float"]>;
}

export interface ImageTag {
  id: Scalars["ID"];
  name: Scalars["String"];
}

export interface LeadEvent {
  date?: Maybe<Scalars["DateTime"]>;
  type?: Maybe<Scalars["String"]>;
  startDate?: Maybe<Scalars["DateTime"]>;
  endDate?: Maybe<Scalars["DateTime"]>;
  durationDays?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
}

export enum LeadFeedbackCreatedByType {
  Self = "SELF",
  Call = "CALL"
}

export interface LeadFeedbackDispositionList {
  label: Scalars["String"];
  dispositionType: LeadFeedbackDispositionTypes;
}

export enum LeadFeedbackDispositionTypes {
  SuccessInterested = "SUCCESS_INTERESTED",
  FailureRingingNoResponse = "FAILURE_RINGING_NO_RESPONSE",
  FailureNotInterested = "FAILURE_NOT_INTERESTED",
  FailureServiceUnavailable = "FAILURE_SERVICE_UNAVAILABLE",
  FailureCityUnavailable = "FAILURE_CITY_UNAVAILABLE",
  FailureAlreadyBooked = "FAILURE_ALREADY_BOOKED",
  CommunicationCall = "COMMUNICATION_CALL",
  UpdateAddNote = "UPDATE_ADD_NOTE",
  ArchiveEventDone = "ARCHIVE_EVENT_DONE",
  ArchiveEventCancelled = "ARCHIVE_EVENT_CANCELLED"
}

export enum LeadFeedbackType {
  Success = "SUCCESS",
  Failure = "FAILURE",
  Archive = "ARCHIVE"
}

export interface LeadFilterInput {
  type?: Maybe<LeadsFilterType>;
  tags?: Maybe<LeadTag[]>;
}

export interface LeadManagement {
  status?: Maybe<ProfileLeadManagementStatus>;
  count?: Maybe<Scalars["Int"]>;
  maxCount?: Maybe<Scalars["Int"]>;
}

export interface LeadMeta {
  id: Scalars["ID"];
  leadSource?: Maybe<LeadSource>;
  status?: Maybe<Scalars["Boolean"]>;
}

export type Leads = CallLeads | CrmLeads;

export enum LeadsFilterType {
  New = "NEW",
  Followup = "FOLLOWUP"
}

export enum LeadSource {
  BmDeletedMbz = "BM_DELETED_MBZ",
  CbsDeleted = "CBS_DELETED",
  ManualCreate = "MANUAL_CREATE",
  WebSite = "WEB_SITE",
  Chat = "CHAT",
  VenueBanner = "VENUE_BANNER",
  MPhotography = "M_PHOTOGRAPHY",
  MPhotographyConverted = "M_PHOTOGRAPHY_CONVERTED",
  MPhotographyTouched = "M_PHOTOGRAPHY_TOUCHED",
  MissedcallApi = "MISSEDCALL_API",
  HelpLine = "HELP_LINE",
  MatrimonyDirectoryWeb = "MATRIMONY_DIRECTORY_WEB",
  MatrimonyDirectoryWap = "MATRIMONY_DIRECTORY_WAP",
  BmDeletedMarried = "BM_DELETED_MARRIED",
  MandapamWeb = "MANDAPAM_WEB",
  MbazaarHelplineInbound = "MBAZAAR_HELPLINE_INBOUND",
  MbazaarTvcInbound = "MBAZAAR_TVC_INBOUND",
  BmWebMm = "BM_WEB_MM",
  KeyVendorLeads = "KEY_VENDOR_LEADS",
  MmChat = "MM_CHAT",
  MmInboundCall = "MM_INBOUND_CALL",
  MmReferral = "MM_REFERRAL",
  MMandapSem = "M_MANDAP_SEM",
  BmWebMbz = "BM_WEB_MBZ",
  BmDeletedInterestedMbz = "BM_DELETED_INTERESTED_MBZ",
  BmBannerMbz = "BM_BANNER_MBZ",
  BmDeletedInterestedMm = "BM_DELETED_INTERESTED_MM",
  BmBannerMm = "BM_BANNER_MM",
  BannerCampaignMm = "BANNER_CAMPAIGN_MM",
  MissedcallMm = "MISSEDCALL_MM",
  BmDeletedMm = "BM_DELETED_MM",
  InterestedInMbz = "INTERESTED_IN_MBZ",
  WebSrHPageMbz = "WEB_SR_H_PAGE_MBZ",
  WebListViewMbz = "WEB_LIST_VIEW_MBZ",
  WebSrStripMbz = "WEB_SR_STRIP_MBZ",
  WebSavcMbz = "WEB_SAVC_MBZ",
  WebDealListMbz = "WEB_DEAL_LIST_MBZ",
  MbzInboundCall = "MBZ_INBOUND_CALL",
  MissedCallMbz = "MISSED_CALL_MBZ",
  MbzSem = "MBZ_SEM",
  BmDeletedCcp = "BM_DELETED_CCP",
  BmDeletedInterestedCcp = "BM_DELETED_INTERESTED_CCP",
  BmSuccessStoryCcp = "BM_SUCCESS_STORY_CCP",
  CbsDeletedCcp = "CBS_DELETED_CCP",
  CbsDeletedInterestedCcp = "CBS_DELETED_INTERESTED_CCP",
  CbsSuccessStoryCcp = "CBS_SUCCESS_STORY_CCP",
  InterestedInMm = "INTERESTED_IN_MM",
  SplBkWebMm = "SPL_BK_WEB_MM",
  SplLpWebMm = "SPL_LP_WEB_MM",
  InterestedInPg = "INTERESTED_IN_PG",
  InterestedInMbzCcp = "INTERESTED_IN_MBZ_CCP",
  WalkInMma = "WALK_IN_MMA",
  PhoneEnquiryMma = "PHONE_ENQUIRY_MMA",
  BannerCampaignMma = "BANNER_CAMPAIGN_MMA",
  ClassifiedsMma = "CLASSIFIEDS_MMA",
  InboundMma = "INBOUND_MMA",
  InterestedInMbzMma = "INTERESTED_IN_MBZ_MMA",
  InterestedInPgMma = "INTERESTED_IN_PG_MMA",
  Others = "OTHERS",
  InterestedInMmMma = "INTERESTED_IN_MM_MMA",
  InterestedInMma = "INTERESTED_IN_MMA",
  MFixedThruBmPortal = "M_FIXED_THRU_BM_PORTAL",
  MFixedThruBmOtherSrc = "M_FIXED_THRU_BM_OTHER_SRC",
  MmInboundWeb = "MM_INBOUND_WEB",
  MmInboundBtl = "MM_INBOUND_BTL",
  MmInboundAtl = "MM_INBOUND_ATL",
  MFixedThruCbsPortal = "M_FIXED_THRU_CBS_PORTAL",
  MFixedThruCbsOtherSrc = "M_FIXED_THRU_CBS_OTHER_SRC",
  BmActiveInterestedMm = "BM_ACTIVE_INTERESTED_MM",
  MmaInterest = "MMA_INTEREST",
  VmInboundAnswered = "VM_INBOUND_ANSWERED",
  WpsHome = "WPS_HOME",
  WpsSem = "WPS_SEM",
  VmInboundMissed = "VM_INBOUND_MISSED",
  MPhotographyNotConverted = "M_PHOTOGRAPHY_NOT_CONVERTED",
  BmMFixedThruComments = "BM_M_FIXED_THRU_COMMENTS",
  CbsMFixedThruComments = "CBS_M_FIXED_THRU_COMMENTS",
  VendorThruApi = "VENDOR_THRU_API",
  VendorThruManual = "VENDOR_THRU_MANUAL",
  InterestedMFixedViaBm = "INTERESTED_M_FIXED_VIA_BM",
  InterestedMFixedViaCbs = "INTERESTED_M_FIXED_VIA_CBS",
  BmWeddingAssist = "BM_WEDDING_ASSIST",
  FbWeddingAssistSem = "FB_WEDDING_ASSIST_SEM",
  GoogleWeddingAssistSem = "GOOGLE_WEDDING_ASSIST_SEM",
  DirectWeddingAssist = "DIRECT_WEDDING_ASSIST",
  OtherWeddingAssist = "OTHER_WEDDING_ASSIST",
  BmPortal = "BM_PORTAL",
  PortalSelfSignUp = "PORTAL_SELF_SIGN_UP",
  Retail = "RETAIL",
  TollFree = "TOLL_FREE",
  EMail = "E_MAIL",
  Reference = "REFERENCE",
  SuccessStory = "SUCCESS_STORY",
  Fb = "FB",
  Twitter = "TWITTER",
  Instagram = "INSTAGRAM",
  Pinterest = "PINTEREST",
  Youtube = "YOUTUBE",
  MandapConverted = "MANDAP_CONVERTED",
  VendorThruApp = "VENDOR_THRU_APP"
}

export enum LeadTag {
  Direct = "Direct",
  Lead = "Lead",
  Order = "Order",
  Call = "Call"
}

export interface Locality {
  id?: Maybe<Scalars["String"]>;
  name?: Maybe<Scalars["String"]>;
  pincode?: Maybe<Scalars["String"]>;
}

export enum MiscEventConducted {
  NotAvailable = "NOT_AVAILABLE",
  LessThen_10 = "LESS_THEN_10",
  LessThen_50 = "LESS_THEN_50",
  LessThen_100 = "LESS_THEN_100",
  LessThen_500 = "LESS_THEN_500",
  LessThen_1000 = "LESS_THEN_1000",
  MoreThen_1000 = "MORE_THEN_1000"
}

export enum MiscListCompetition {
  JustDial = "JUST_DIAL",
  Sulekha = "SULEKHA",
  WedMeGood = "WED_ME_GOOD",
  Others = "OTHERS"
}

export enum MiscNosEmployees {
  NotAvailable = "NOT_AVAILABLE",
  LessThen_10 = "LESS_THEN_10",
  LessThen_25 = "LESS_THEN_25",
  LessThen_50 = "LESS_THEN_50",
  LessThen_100 = "LESS_THEN_100",
  MoreThen_101 = "MORE_THEN_101"
}

export enum MiscOperatingOutOf {
  NotAvailable = "NOT_AVAILABLE",
  Home = "HOME",
  Office = "OFFICE",
  Others = "OTHERS"
}

export interface MiscVendorDetails {
  listingWithCompetition?: Maybe<Array<Maybe<MiscListCompetition>>>;
  operatingOutOf?: Maybe<MiscOperatingOutOf>;
  numberOfEmployees?: Maybe<MiscNosEmployees>;
  eventsConductedSoFar?: Maybe<MiscEventConducted>;
}

export interface MiscVendorDetailsInput {
  listingWithCompetition?: Maybe<Array<Maybe<MiscListCompetition>>>;
  operatingOutOf?: Maybe<MiscOperatingOutOf>;
  numberOfEmployees?: Maybe<MiscNosEmployees>;
  eventsConductedSoFar?: Maybe<MiscEventConducted>;
}

export interface Mutation {
  addLog: AddLogResponse;
  updateNotificationLog: NotificationLogs;
  addFeedback?: Maybe<Scalars["String"]>;
  addProfile: Profile;
  addProfileAttributes?: Maybe<Array<Maybe<ProfileAttributes>>>;
  updateGallery?: Maybe<Array<Maybe<ProfileGallery>>>;
  createVendor: NewVendorDetailsMonetary;
  updateVendor: VendorDetails;
  createVendorLeadFeedback?: Maybe<VendorLeadFeedback>;
  updateVendorLeadFeedback?: Maybe<VendorLeadFeedback>;
}

export interface MutationAddLogArgs {
  buildVersion: Scalars["String"];
  imeiNo: Scalars["String"];
  deviceToken: Scalars["String"];
  ip: Scalars["String"];
  deviceDetails: DeviceDetailsInput;
}

export interface MutationUpdateNotificationLogArgs {
  id: Scalars["ID"];
}

export interface MutationAddFeedbackArgs {
  message: Scalars["String"];
  type?: Maybe<FeedbackType>;
  referenceId?: Maybe<Scalars["String"]>;
}

export interface MutationAddProfileArgs {
  profile: ProfileInput;
}

export interface MutationAddProfileAttributesArgs {
  profileId: Scalars["ID"];
  attributes: ProfileAttributesInput[];
}

export interface MutationUpdateGalleryArgs {
  images?: Maybe<ProfileGalleryInput[]>;
}

export interface MutationCreateVendorArgs {
  businessName: Scalars["String"];
  primary: ContactPersonInput;
}

export interface MutationUpdateVendorArgs {
  description?: Maybe<Scalars["String"]>;
  businessName?: Maybe<Scalars["String"]>;
  primary?: Maybe<UpdatePersonInput>;
  address?: Maybe<UpdateAddressInput>;
  document?: Maybe<VendorKycInput>;
}

export interface MutationCreateVendorLeadFeedbackArgs {
  leadId: Scalars["ID"];
  notes?: Maybe<Scalars["String"]>;
  disposition?: Maybe<LeadFeedbackDispositionTypes>;
  callDuration?: Maybe<Scalars["Int"]>;
  createdBy?: Maybe<LeadFeedbackCreatedByType>;
  followupDate?: Maybe<Scalars["DateTime"]>;
}

export interface MutationUpdateVendorLeadFeedbackArgs {
  leadFeedbackId: Scalars["ID"];
  notes?: Maybe<Scalars["String"]>;
  followupDate?: Maybe<Scalars["DateTime"]>;
}

export interface NewVendorDetailsMonetary {
  id: Scalars["ID"];
  accessToken: Scalars["String"];
  businessName?: Maybe<Scalars["String"]>;
}

export interface NotificationCount {
  total?: Maybe<Scalars["Int"]>;
  byType?: Maybe<Array<Maybe<NotificationCountByTypes>>>;
}

export interface NotificationCountByTypes {
  type?: Maybe<NotificationTypes>;
  count?: Maybe<Scalars["Int"]>;
}

export interface NotificationFilterinput {
  types?: Maybe<NotificationTypes[]>;
}

export interface NotificationFollowupLogsResponse {
  read?: Maybe<Scalars["Int"]>;
  unRead?: Maybe<Scalars["Int"]>;
  notifications?: Maybe<NotificationLogs[]>;
}

export interface NotificationLogs {
  id: Scalars["ID"];
  leadId?: Maybe<Scalars["ID"]>;
  type?: Maybe<NotificationTypes>;
  title?: Maybe<Scalars["String"]>;
  leadInfo?: Maybe<Leads>;
  transactionId?: Maybe<Scalars["ID"]>;
  transactionInfo?: Maybe<VendorWalletTransaction>;
  leadFeedbackId?: Maybe<Scalars["ID"]>;
  notes?: Maybe<Scalars["String"]>;
  isRead?: Maybe<Scalars["Boolean"]>;
  createdAt?: Maybe<Scalars["DateTime"]>;
}

export enum NotificationTypes {
  ProfileActivation = "PROFILE_ACTIVATION",
  Lead = "LEAD",
  Transaction = "TRANSACTION",
  Followup = "FOLLOWUP",
  AppLanding = "APP_LANDING"
}

export enum OnBoardProgressStatus {
  VendorDetails = "VENDOR_DETAILS",
  CategoryDetails = "CATEGORY_DETAILS",
  CategorySettingsDetails = "CATEGORY_SETTINGS_DETAILS",
  CityDetails = "CITY_DETAILS",
  WalletDetails = "WALLET_DETAILS",
  WalletLogDetails = "WALLET_LOG_DETAILS",
  ImagesDetails = "IMAGES_DETAILS",
  DocumentsDetails = "DOCUMENTS_DETAILS",
  BannerPaymentDetails = "BANNER_PAYMENT_DETAILS",
  BannerImages = "BANNER_IMAGES",
  BannerTagImages = "BANNER_TAG_IMAGES",
  CategoryPaymentDetails = "CATEGORY_PAYMENT_DETAILS"
}

export interface OnBoardStatus {
  status?: Maybe<Scalars["String"]>;
  onboardState: Scalars["String"];
  /** progressStatus: OnBoardProgressStatus! */
  activatedOn?: Maybe<Scalars["String"]>;
}

export interface OtpRequestAcknowledge {
  message?: Maybe<Scalars["String"]>;
  isExisting?: Maybe<Scalars["Boolean"]>;
  /** number of retry has left */
  retryLeft?: Maybe<Scalars["Int"]>;
  /** next resent allowing time span (milli seconds) */
  retryAgain?: Maybe<Scalars["Int"]>;
  /** resent allowing time delay (seconds) */
  otpInterval?: Maybe<Scalars["Int"]>;
}

export enum PaidStatus {
  Free = "FREE",
  Paid = "PAID"
}

export enum PaymentMode {
  Wallet = "WALLET",
  TrialPackage = "TRIAL_PACKAGE",
  Cheque = "CHEQUE",
  Dd = "DD",
  Neft = "NEFT",
  DebitCard = "DEBIT_CARD",
  CreditCard = "CREDIT_CARD",
  Offline = "OFFLINE",
  Ro = "RO",
  Online = "ONLINE",
  RazzlePay = "RAZZLE_PAY"
}

export interface PaymentStatus {
  paidStatus?: Maybe<PaidStatus>;
  noOfPayments?: Maybe<Scalars["String"]>;
  isFeatured?: Maybe<Scalars["Boolean"]>;
  featuredStartDate?: Maybe<Scalars["String"]>;
  featuredEndDate?: Maybe<Scalars["String"]>;
}

export enum Platform {
  Android = "android",
  Ios = "ios"
}

export interface PntRnotification {
  referenceId: Scalars["ID"];
  devices?: Maybe<Scalars["Int"]>;
  devicesInfo?: Maybe<Scalars["JSON"]>;
}

export interface Pricing {
  /**
   * approved: ProfileCommissionApproved
   * disposition: String
   */
  commissionPercentage?: Maybe<Scalars["Int"]>;
  discount?: Maybe<Scalars["Int"]>;
  leadFee?: Maybe<Scalars["Float"]>;
  listingFee?: Maybe<Scalars["Float"]>;
}

export interface Profile {
  id: Scalars["ID"];
  vendorId: Scalars["ID"];
  url?: Maybe<Scalars["String"]>;
  ratings?: Maybe<Scalars["Float"]>;
  reviewLink?: Maybe<Scalars["String"]>;
  listingName: Scalars["String"];
  category?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  currentPackage?: Maybe<Scalars["String"]>;
  serviceable?: Maybe<ProfileServiceable>;
  completionLevel?: Maybe<Scalars["Int"]>;
  status?: Maybe<ProfileStatus>;
  leadManagement?: Maybe<LeadManagement>;
  pricing?: Maybe<Pricing>;
  gallery?: Maybe<ProfileGallery[]>;
  attributes?: Maybe<ProfileAttributes[]>;
}

export interface ProfileIdArgs {
  profileId?: Maybe<Scalars["String"]>;
}

export interface ProfileAttributesArgs {
  groupName?: Maybe<Scalars["String"]>;
}

export interface ProfileAttributeChangeLogs {
  id: Scalars["ID"];
  crmTicketId?: Maybe<Scalars["ID"]>;
  vendorId: Scalars["ID"];
  diff: ProfileAttributesDiff;
  employeeId?: Maybe<Scalars["ID"]>;
  source?: Maybe<Scalars["String"]>;
  status?: Maybe<Scalars["Boolean"]>;
  createdAt: Scalars["DateTime"];
}

export enum ProfileAttributeFieldType {
  TextBox = "TEXT_BOX",
  TextArea = "TEXT_AREA",
  RadioButton = "RADIO_BUTTON",
  Checkbox = "CHECKBOX",
  SelectBox = "SELECT_BOX",
  MultipleSelectBox = "MULTIPLE_SELECT_BOX",
  Password = "PASSWORD",
  Range = "RANGE",
  SplitText = "SPLIT_TEXT",
  SplitOption = "SPLIT_OPTION",
  SplitFieldOption = "SPLIT_FIELD_OPTION",
  Date = "DATE",
  MultipleDate = "MULTIPLE_DATE"
}

export interface ProfileAttributes {
  id: Scalars["ID"];
  groupName?: Maybe<Scalars["String"]>;
  label?: Maybe<Scalars["String"]>;
  displayOrder?: Maybe<Scalars["String"]>;
  question?: Maybe<Scalars["String"]>;
  values?: Maybe<Array<Maybe<Scalars["String"]>>>;
  fieldType?: Maybe<ProfileAttributeFieldType>;
  isEditable?: Maybe<Scalars["Boolean"]>;
}

export interface ProfileAttributesDiff {
  old?: Maybe<ProfileAttributes[]>;
  new?: Maybe<ProfileAttributes[]>;
}

export interface ProfileAttributesInput {
  id: Scalars["ID"];
  values?: Maybe<Array<Maybe<Scalars["String"]>>>;
}

export enum ProfileCommissionApproved {
  No = "NO",
  Yes = "YES"
}

export interface ProfileGallery {
  id: Scalars["ID"];
  uuid: Scalars["ID"];
  url: Scalars["String"];
  status: VendorDocStatus;
  rejectionReason?: Maybe<Scalars["String"]>;
  title: Scalars["String"];
  subTitle?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
  isHero?: Maybe<Scalars["Boolean"]>;
  canBeHero?: Maybe<Scalars["Boolean"]>;
  displayOrder: Scalars["String"];
  tags?: Maybe<ImageTag[]>;
}

export interface ProfileGalleryInput {
  id: Scalars["ID"];
  title?: Maybe<Scalars["String"]>;
  subTitle?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
  isHero?: Maybe<Scalars["Boolean"]>;
  isDelete?: Maybe<Scalars["Boolean"]>;
  displayOrder?: Maybe<Scalars["Int"]>;
}

export interface ProfileInput {
  categoryId: Scalars["ID"];
  cityId: Scalars["ID"];
}

export enum ProfileLeadManagementStatus {
  Disable = "DISABLE",
  On = "ON",
  Off = "OFF",
  Delete = "DELETE"
}

export enum ProfileServiceable {
  ServiceableCity = "SERVICEABLE_CITY",
  OtherServiceableCity = "OTHER_SERVICEABLE_CITY"
}

export enum ProfileStatus {
  Inactive = "INACTIVE",
  Active = "ACTIVE",
  Delete = "DELETE"
}

export interface PurchaseOrder {
  id: Scalars["ID"];
  poNumber?: Maybe<Scalars["String"]>;
  poDate?: Maybe<Scalars["String"]>;
  poSentData?: Maybe<Scalars["String"]>;
  userId?: Maybe<Scalars["String"]>;
  roleId?: Maybe<Scalars["String"]>;
  branchId?: Maybe<Scalars["String"]>;
  downloadUrlKey?: Maybe<Scalars["String"]>;
  downloadUrl?: Maybe<Scalars["String"]>;
  expiryDate?: Maybe<Scalars["String"]>;
  isRegenerate?: Maybe<Scalars["Boolean"]>;
  fileVersion?: Maybe<Scalars["String"]>;
  createdAt?: Maybe<Scalars["String"]>;
}

export interface PushNotificationLead {
  vendorId: Scalars["ID"];
  devices?: Maybe<Scalars["Int"]>;
  devicesInfo?: Maybe<Scalars["JSON"]>;
}

export interface PushNotificationProfileInput {
  vendorId: Scalars["ID"];
  cityId: Scalars["ID"];
  categoryId: Scalars["ID"];
}

export interface PushNotificationProfileResult {
  vendorId: Scalars["ID"];
  cityId: Scalars["ID"];
  categoryId: Scalars["ID"];
  profileSlug: Scalars["ID"];
  devices?: Maybe<Scalars["Int"]>;
  devicesInfo?: Maybe<Scalars["JSON"]>;
}

export interface PushNotificationTransactionInput {
  vendorId: Scalars["ID"];
  transactionType: TransactionType;
  paymentType: VendorNotifyPaymentType;
  referenceIds?: Maybe<Array<Scalars["ID"]>>;
}

export interface PushNotificationTransactionResult {
  vendorId: Scalars["ID"];
  transactionType: TransactionType;
  paymentType: VendorNotifyPaymentType;
  notification?: Maybe<PntRnotification[]>;
}

export interface Query {
  tokenGen?: Maybe<Scalars["String"]>;
  getAddressInfo: AddressInfo;
  crmMobEncrypt?: Maybe<Scalars["String"]>;
  crmMobDecrypt?: Maybe<Scalars["String"]>;
  decrypt?: Maybe<Array<Scalars["Int"]>>;
  decryptString?: Maybe<Array<Scalars["String"]>>;
  encrypt: Scalars["ID"];
  encryptString: Scalars["ID"];
  pushNotificationLead?: Maybe<Array<Maybe<PushNotificationLead>>>;
  pushNotificationProfile?: Maybe<Array<Maybe<PushNotificationProfileResult>>>;
  pushNotificationTransaction?: Maybe<PushNotificationTransactionResult[]>;
  notifyRec?: Maybe<Scalars["JSON"]>;
  notificationLogs?: Maybe<NotificationLogs[]>;
  notificationFollowupLogs?: Maybe<NotificationFollowupLogsResponse>;
  notificationCount: NotificationCount;
  category?: Maybe<Array<Maybe<Category>>>;
  checkPoint: CheckPoint;
  version: Version;
  cities?: Maybe<Array<Maybe<City>>>;
  cityByState?: Maybe<Array<Maybe<City>>>;
  cityServiceableOther?: Maybe<Array<Maybe<City>>>;
  cityServiceable?: Maybe<Array<Maybe<City>>>;
  leads?: Maybe<Leads[]>;
  leadById?: Maybe<Leads>;
  totalLeads: TotalLeads;
  localityByCity?: Maybe<Array<Maybe<Locality>>>;
  profileById?: Maybe<Profile>;
  attributesByProfile?: Maybe<Array<Maybe<AttributeSubHeader>>>;
  profileGalleryImgByUUID?: Maybe<ProfileGallery>;
  salesCityByState?: Maybe<Array<Maybe<SalesCity>>>;
  salesState?: Maybe<Array<Maybe<SalesState>>>;
  states?: Maybe<Array<Maybe<State>>>;
  subCategory?: Maybe<Array<Maybe<SubCategory>>>;
  vendorDetails?: Maybe<VendorDetails>;
  allVendorDetails?: Maybe<VendorDetails[]>;
  /** vendorDocumentsById(vendorId: ID!): [VendorDocuments] @auth(requires: VENDOR) */
  vendorDocumentTypes?: Maybe<VendorDocumentTypes[]>;
  vendorLeadFeedbacks?: Maybe<Array<Maybe<VendorLeadFeedback>>>;
  leadFeedbackDisposition?: Maybe<LeadFeedbackDispositionList[]>;
  vendorLogin?: Maybe<VendorLogin>;
  vendorLogout: Scalars["String"];
  otpRequest?: Maybe<OtpRequestAcknowledge>;
  vendorValidate?: Maybe<VendorValidate>;
  vendorWallet?: Maybe<VendorWallet>;
  vendorWalletTransaction?: Maybe<Array<Maybe<VendorWalletTransaction>>>;
  vendorWalletTransactionById?: Maybe<VendorWalletTransaction>;
}

export interface QueryTokenGenArgs {
  role: Role;
}

export interface QueryGetAddressInfoArgs {
  addressInfo: Scalars["JSON"];
}

export interface QueryCrmMobEncryptArgs {
  val: Scalars["String"];
}

export interface QueryCrmMobDecryptArgs {
  val: Scalars["String"];
}

export interface QueryDecryptArgs {
  slug: Scalars["ID"];
}

export interface QueryDecryptStringArgs {
  slug: Scalars["ID"];
}

export interface QueryEncryptArgs {
  listOfIds: Array<Scalars["Int"]>;
}

export interface QueryEncryptStringArgs {
  listOfIds: Array<Scalars["String"]>;
}

export interface QueryPushNotificationLeadArgs {
  vendorUserLeadIds: Array<Scalars["ID"]>;
}

export interface QueryPushNotificationProfileArgs {
  profiles: PushNotificationProfileInput[];
}

export interface QueryPushNotificationTransactionArgs {
  transactions: PushNotificationTransactionInput[];
}

export interface QueryNotifyRecArgs {
  userId?: Maybe<Scalars["String"]>;
  type?: Maybe<NotificationTypes>;
  leadFeedbackId?: Maybe<Scalars["ID"]>;
  leadSlug?: Maybe<Scalars["ID"]>;
  transactionSlug?: Maybe<Scalars["ID"]>;
}

export interface QueryNotificationLogsArgs {
  duration?: Maybe<TimePeriodInput>;
  filter?: Maybe<NotificationFilterinput>;
}

export interface QueryNotificationCountArgs {
  isRead?: Maybe<Scalars["Boolean"]>;
}

export interface QueryVersionArgs {
  platform: Platform;
}

export interface QueryCitiesArgs {
  search?: Maybe<Scalars["String"]>;
}

export interface QueryCityByStateArgs {
  stateId: Scalars["String"];
}

export interface QueryLeadsArgs {
  duration: TimePeriodInput;
  filter?: Maybe<LeadFilterInput>;
}

export interface QueryLeadByIdArgs {
  leadId: Scalars["ID"];
}

export interface QueryTotalLeadsArgs {
  type: LeadsFilterType;
}

export interface QueryLocalityByCityArgs {
  cityId: Scalars["String"];
}

export interface QueryProfileByIdArgs {
  id: Scalars["ID"];
}

export interface QueryAttributesByProfileArgs {
  profileId: Scalars["ID"];
}

export interface QueryProfileGalleryImgByUuidArgs {
  imgUUID: Scalars["ID"];
}

export interface QuerySalesCityByStateArgs {
  stateId: Scalars["String"];
}

export interface QuerySubCategoryArgs {
  page?: Maybe<Scalars["Int"]>;
}

export interface QueryAllVendorDetailsArgs {
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
}

export interface QueryVendorDocumentTypesArgs {
  category: VendorDocCategory;
}

export interface QueryVendorLeadFeedbacksArgs {
  leadId: Scalars["ID"];
}

export interface QueryLeadFeedbackDispositionArgs {
  type: LeadFeedbackType;
}

export interface QueryVendorLoginArgs {
  userId: Scalars["ID"];
  otp: Scalars["String"];
}

export interface QueryOtpRequestArgs {
  userId: Scalars["ID"];
}

export interface QueryVendorValidateArgs {
  userId: Scalars["ID"];
}

export interface QueryVendorWalletTransactionArgs {
  paymentType?: Maybe<WalletPaymentType>;
  profileId?: Maybe<Scalars["ID"]>;
}

export interface QueryVendorWalletTransactionByIdArgs {
  transactionId: Scalars["ID"];
}

export enum Role {
  Vendor = "VENDOR",
  Admin = "ADMIN"
}

export interface SalesCity {
  name?: Maybe<Scalars["String"]>;
  id?: Maybe<Scalars["String"]>;
  address?: Maybe<Scalars["String"]>;
}

export interface SalesState {
  name?: Maybe<Scalars["String"]>;
  id?: Maybe<Scalars["String"]>;
  address?: Maybe<Scalars["String"]>;
}

export interface SocialLinks {
  webUrl?: Maybe<Scalars["String"]>;
  fbUrl?: Maybe<Scalars["String"]>;
  instagramUrl?: Maybe<Scalars["String"]>;
  pinterestUrl?: Maybe<Scalars["String"]>;
  twitterUrl?: Maybe<Scalars["String"]>;
}

export interface SocialLinksInput {
  webUrl?: Maybe<Scalars["String"]>;
  fbUrl?: Maybe<Scalars["String"]>;
  instagramUrl?: Maybe<Scalars["String"]>;
  pinterestUrl?: Maybe<Scalars["String"]>;
  twitterUrl?: Maybe<Scalars["String"]>;
}

export interface State {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
}

export interface SubCategory {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  displayName?: Maybe<Scalars["String"]>;
  seoCategoryName?: Maybe<Scalars["String"]>;
  categoryImage?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  domain?: Maybe<Scalars["Int"]>;
  commissionStatus?: Maybe<Scalars["String"]>;
  status?: Maybe<Scalars["String"]>;
  displayOrder?: Maybe<Scalars["Int"]>;
  layeredFormTitle?: Maybe<Scalars["String"]>;
}

export interface TenurePeriod {
  start?: Maybe<Scalars["DateTime"]>;
  end?: Maybe<Scalars["DateTime"]>;
}

export interface TextMessage {
  name?: Maybe<Scalars["String"]>;
}

export interface TimePeriodInput {
  since: Scalars["DateTime"];
  until: Scalars["DateTime"];
}

export interface TotalLeads {
  direct?: Maybe<Scalars["Int"]>;
  lead?: Maybe<Scalars["Int"]>;
  order?: Maybe<Scalars["Int"]>;
  call?: Maybe<Scalars["Int"]>;
  total?: Maybe<Scalars["Int"]>;
}

export interface TransactionCreditInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  referenceNumber?: Maybe<Scalars["String"]>;
  actualAmount?: Maybe<Scalars["Float"]>;
  transaction: Scalars["String"];
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
}

export interface TransactionDebitInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  transaction: Scalars["String"];
  actualAmount?: Maybe<Scalars["Float"]>;
  standardAmount?: Maybe<Scalars["Float"]>;
  bonusAmount?: Maybe<Scalars["Float"]>;
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
}

export enum TransactionType {
  Credit = "CREDIT",
  Debit = "DEBIT"
}

export interface UpdateAddressInput {
  address?: Maybe<Scalars["String"]>;
  localityId?: Maybe<Scalars["ID"]>;
  cityId?: Maybe<Scalars["ID"]>;
  stateId?: Maybe<Scalars["ID"]>;
  pincode?: Maybe<Scalars["String"]>;
  latitude?: Maybe<Scalars["String"]>;
  longitude?: Maybe<Scalars["String"]>;
}

export interface UpdatePersonInput {
  name?: Maybe<Scalars["String"]>;
  email?: Maybe<Scalars["String"]>;
  isWhatsappConsent?: Maybe<Scalars["Boolean"]>;
}

export interface VendorBannerBrandDebitTransaction extends TransactionDebitInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  transaction: Scalars["String"];
  actualAmount?: Maybe<Scalars["Float"]>;
  standardAmount?: Maybe<Scalars["Float"]>;
  bonusAmount?: Maybe<Scalars["Float"]>;
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  profileSlug: Scalars["ID"];
  profileUrl: Scalars["String"];
  /** payementAndMore: ID! */
  tenurePeriod?: Maybe<TenurePeriod>;
}

export interface VendorBannerBrandPayment {
  id: Scalars["ID"];
  category?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  landingCategory?: Maybe<Scalars["String"]>;
  landingCity?: Maybe<Scalars["String"]>;
  status?: Maybe<VendorPaymentStatus>;
  tenurePeriod?: Maybe<TenurePeriod>;
  balanceAmount?: Maybe<Scalars["Float"]>;
  deliveredAmount?: Maybe<Scalars["Float"]>;
  totalPaidAmount?: Maybe<Scalars["Float"]>;
  type: VendorPaymentType;
}

export interface VendorBannerCredit extends TransactionCreditInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  referenceNumber?: Maybe<Scalars["String"]>;
  transaction: Scalars["String"];
  actualAmount?: Maybe<Scalars["Float"]>;
  profileSlug: Scalars["ID"];
  profileUrl: Scalars["String"];
  category?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
}

export interface VendorBrandListingCredit extends TransactionCreditInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  referenceNumber?: Maybe<Scalars["String"]>;
  transaction: Scalars["String"];
  actualAmount?: Maybe<Scalars["Float"]>;
  setupCost?: Maybe<Scalars["Float"]>;
  tenure?: Maybe<Scalars["Int"]>;
  leadId?: Maybe<Scalars["ID"]>;
  profileSlug: Scalars["ID"];
  profileUrl: Scalars["String"];
  category?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
}

export interface VendorDetails {
  id: Scalars["ID"];
  vendorId?: Maybe<Scalars["String"]>;
  businessName?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
  document?: Maybe<VendorKyc>;
  primary?: Maybe<ContactPerson>;
  secondary?: Maybe<ContactPerson>;
  address?: Maybe<Address>;
  profiles?: Maybe<Profile[]>;
  billingInfo?: Maybe<BillingInfo>;
  payment?: Maybe<PaymentStatus>;
  onBoardStatus?: Maybe<OnBoardStatus>;
  socialLinks?: Maybe<SocialLinks>;
  misc?: Maybe<MiscVendorDetails>;
  verified?: Maybe<Scalars["Boolean"]>;
  poDocumentUrl?: Maybe<Scalars["String"]>;
  isEditable?: Maybe<Scalars["Boolean"]>;
  underReview?: Maybe<VendorDetailsReview>;
}

export interface VendorDetailsReview {
  businessName?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
  document?: Maybe<VendorKyc>;
  primary?: Maybe<ContactPersonReview>;
  secondary?: Maybe<ContactPersonReview>;
  address?: Maybe<Address>;
  profiles?: Maybe<Profile[]>;
  billingInfo?: Maybe<BillingInfo>;
  payment?: Maybe<PaymentStatus>;
  onBoardStatus?: Maybe<OnBoardStatus>;
  socialLinks?: Maybe<SocialLinks>;
  misc?: Maybe<MiscVendorDetails>;
  verified?: Maybe<Scalars["Boolean"]>;
  poDocumentUrl?: Maybe<Scalars["String"]>;
}

export enum VendorDocCategory {
  AgreementDoc = "AGREEMENT_DOC",
  KycDoc = "KYC_DOC",
  BusinessDoc = "BUSINESS_DOC",
  PaymentDoc = "PAYMENT_DOC",
  PoDoc = "PO_DOC"
}

export enum VendorDocStatus {
  Removed = "REMOVED",
  Active = "ACTIVE",
  Pending = "PENDING",
  Rejected = "REJECTED",
  DeletionQueue = "DELETION_QUEUE"
}

export interface VendorDocuments {
  id: Scalars["ID"];
  /**
   * vendorId: ID!,
   * name: String,
   */
  url?: Maybe<Scalars["String"]>;
  comments?: Maybe<Scalars["String"]>;
  size?: Maybe<Scalars["Int"]>;
  docType?: Maybe<Scalars["String"]>;
}

export interface VendorDocumentTypes {
  id: Scalars["ID"];
  label: Scalars["String"];
  numberOfImages?: Maybe<Scalars["Int"]>;
}

export interface VendorKyc {
  status: VendorDocStatus;
  message?: Maybe<Scalars["String"]>;
}

export interface VendorKycInput {
  panNo?: Maybe<Scalars["String"]>;
  aadharNo?: Maybe<Scalars["String"]>;
}

export interface VendorLeadDebitTransaction extends TransactionDebitInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  transaction: Scalars["String"];
  actualAmount?: Maybe<Scalars["Float"]>;
  standardAmount?: Maybe<Scalars["Float"]>;
  bonusAmount?: Maybe<Scalars["Float"]>;
  gstAmount?: Maybe<GstAmount>;
  gstPercentage?: Maybe<GstPercentage>;
  leadId?: Maybe<Scalars["ID"]>;
  orderId: Scalars["ID"];
  orderDate?: Maybe<Scalars["DateTime"]>;
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  isOSC?: Maybe<Scalars["Boolean"]>;
}

export interface VendorLeadFeedback {
  id: Scalars["ID"];
  vendorId: Scalars["ID"];
  leadId: Scalars["ID"];
  notes?: Maybe<Scalars["String"]>;
  disposition: LeadFeedbackDispositionTypes;
  createdBy: LeadFeedbackCreatedByType;
  createdAt: Scalars["DateTime"];
  updatedAt?: Maybe<Scalars["DateTime"]>;
  followupDate?: Maybe<Scalars["DateTime"]>;
}

export interface VendorLeadListPayment {
  id: Scalars["ID"];
  status?: Maybe<VendorPaymentStatus>;
  tenurePeriod?: Maybe<TenurePeriod>;
  balanceAmount?: Maybe<Scalars["Float"]>;
  deliveredAmount?: Maybe<Scalars["Float"]>;
  totalPaidAmount?: Maybe<Scalars["Float"]>;
  type: VendorPaymentType;
}

export interface VendorListingDebitTransaction extends TransactionDebitInt {
  id: Scalars["ID"];
  type: TransactionType;
  paymentType: VendorPaymentType;
  transactionAt: Scalars["DateTime"];
  paymentMode?: Maybe<PaymentMode>;
  transaction: Scalars["String"];
  actualAmount?: Maybe<Scalars["Float"]>;
  standardAmount?: Maybe<Scalars["Float"]>;
  bonusAmount?: Maybe<Scalars["Float"]>;
  gstAmount?: Maybe<GstAmount>;
  gstPercentage?: Maybe<GstPercentage>;
  leadId?: Maybe<Scalars["ID"]>;
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  profileSlug: Scalars["ID"];
  profileUrl: Scalars["String"];
  tenurePeriod?: Maybe<TenurePeriod>;
}

export interface VendorLogin {
  deviceToken: Scalars["String"];
  accessToken: Scalars["String"];
  step: CheckPointList;
}

export interface VendorLoginDeviceTokenArgs {
  newToken: Scalars["String"];
}

export enum VendorNotifyPaymentType {
  Banner = "BANNER",
  Brand = "BRAND",
  Lead = "LEAD",
  Listing = "LISTING"
}

export type VendorPayments = VendorBannerBrandPayment | VendorLeadListPayment;

export enum VendorPaymentStatus {
  Expired = "EXPIRED",
  Pending = "PENDING",
  Activated = "ACTIVATED",
  RenewActivated = "RENEW_ACTIVATED"
}

export enum VendorPaymentType {
  Banner = "BANNER",
  Brand = "BRAND",
  LeadList = "LEAD_LIST"
}

export interface VendorProfileRole {
  category?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  state?: Maybe<Scalars["String"]>;
  designation?: Maybe<VendorRole>;
}

export enum VendorRole {
  NoRole = "NO_ROLE",
  Director = "DIRECTOR",
  Manager = "MANAGER",
  Trustee = "TRUSTEE",
  Partner = "PARTNER",
  Proprietor = "PROPRIETOR",
  Agent = "AGENT"
}

export interface VendorValidate {
  id?: Maybe<Scalars["ID"]>;
  message?: Maybe<Scalars["String"]>;
  businessName?: Maybe<Scalars["String"]>;
  profiles?: Maybe<VendorProfileRole[]>;
  validatedSrc?: Maybe<Scalars["String"]>;
}

export interface VendorWallet {
  overview?: Maybe<WalletOverview>;
  payments?: Maybe<Array<Maybe<VendorPayments>>>;
}

export interface VendorWalletPaymentsArgs {
  type?: Maybe<WalletPaymentType>;
}

export type VendorWalletTransaction =
  | VendorBannerBrandDebitTransaction
  | VendorListingDebitTransaction
  | VendorLeadDebitTransaction
  | VendorBannerCredit
  | VendorBrandListingCredit;

export enum VendorWalletType {
  Lead = "LEAD",
  Commission = "COMMISSION"
}

export enum VerifiedSource {
  Customer = "CUSTOMER",
  Vendor = "VENDOR",
  Prospect = "PROSPECT",
  VendorApp = "VENDOR_APP"
}

export interface Version {
  latest: Scalars["String"];
  deprecated?: Maybe<Array<Scalars["String"]>>;
  appstoreUrl?: Maybe<Scalars["String"]>;
  playstoreUrl?: Maybe<Scalars["String"]>;
}

export interface WalletOverview {
  id: Scalars["ID"];
  type: VendorWalletType;
  amount?: Maybe<Scalars["Float"]>;
  bonusAmount?: Maybe<Scalars["Float"]>;
  bannerBalance?: Maybe<Scalars["Float"]>;
  brandingBalance?: Maybe<Scalars["Float"]>;
  lastTransactionAt: Scalars["DateTime"];
}

export enum WalletPaymentType {
  Brand = "BRAND",
  Banner = "BANNER",
  LeadList = "LEAD_LIST"
}

export type ResolverTypeWrapper<T> = Promise<T> | T;

export interface LegacyStitchingResolver<TResult, TParent, TContext, TArgs> {
  fragment: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}

export interface NewStitchingResolver<TResult, TParent, TContext, TArgs> {
  selectionSet: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}
export type StitchingResolver<TResult, TParent, TContext, TArgs> =
  | LegacyStitchingResolver<TResult, TParent, TContext, TArgs>
  | NewStitchingResolver<TResult, TParent, TContext, TArgs>;
export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> =
  | ResolverFn<TResult, TParent, TContext, TArgs>
  | StitchingResolver<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterator<TResult> | Promise<AsyncIterator<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> {
  subscribe: SubscriptionSubscribeFn<
    { [key in TKey]: TResult },
    TParent,
    TContext,
    TArgs
  >;
  resolve?: SubscriptionResolveFn<
    TResult,
    { [key in TKey]: TResult },
    TContext,
    TArgs
  >;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<
  TResult,
  TKey extends string,
  TParent = {},
  TContext = {},
  TArgs = {}
> =
  | ((
      ...args: any[]
    ) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}> = (
  obj: T,
  info: GraphQLResolveInfo
) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<
  TResult = {},
  TParent = {},
  TContext = {},
  TArgs = {}
> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping between all available schema types and the resolvers types */
export interface ResolversTypes {
  Query: ResolverTypeWrapper<{}>;
  Role: Role;
  String: ResolverTypeWrapper<Scalars["String"]>;
  JSON: ResolverTypeWrapper<Scalars["JSON"]>;
  AddressInfo: ResolverTypeWrapper<AddressInfo>;
  Locality: ResolverTypeWrapper<Locality>;
  City: ResolverTypeWrapper<City>;
  ID: ResolverTypeWrapper<Scalars["ID"]>;
  Boolean: ResolverTypeWrapper<Scalars["Boolean"]>;
  Int: ResolverTypeWrapper<Scalars["Int"]>;
  PushNotificationLead: ResolverTypeWrapper<PushNotificationLead>;
  PushNotificationProfileInput: PushNotificationProfileInput;
  PushNotificationProfileResult: ResolverTypeWrapper<
    PushNotificationProfileResult
  >;
  PushNotificationTransactionInput: PushNotificationTransactionInput;
  TransactionType: TransactionType;
  VendorNotifyPaymentType: VendorNotifyPaymentType;
  PushNotificationTransactionResult: ResolverTypeWrapper<
    PushNotificationTransactionResult
  >;
  PNTRnotification: ResolverTypeWrapper<PntRnotification>;
  NotificationTypes: NotificationTypes;
  TimePeriodInput: TimePeriodInput;
  DateTime: ResolverTypeWrapper<Scalars["DateTime"]>;
  NotificationFilterinput: NotificationFilterinput;
  NotificationLogs: ResolverTypeWrapper<
    Omit<NotificationLogs, "leadInfo" | "transactionInfo"> & {
      leadInfo?: Maybe<ResolversTypes["Leads"]>;
      transactionInfo?: Maybe<ResolversTypes["VendorWalletTransaction"]>;
    }
  >;
  Leads: ResolversTypes["CallLeads"] | ResolversTypes["CRMLeads"];
  CallLeads: ResolverTypeWrapper<CallLeads>;
  CallCustomer: ResolverTypeWrapper<CallCustomer>;
  LeadTag: LeadTag;
  CallInfo: ResolverTypeWrapper<CallInfo>;
  CallStatus: CallStatus;
  CRMLeads: ResolverTypeWrapper<CrmLeads>;
  CrmCustomer: ResolverTypeWrapper<CrmCustomer>;
  CrmCustomerDetails: ResolverTypeWrapper<CrmCustomerDetails>;
  LeadEvent: ResolverTypeWrapper<LeadEvent>;
  ProfileAttributes: ResolverTypeWrapper<ProfileAttributes>;
  ProfileAttributeFieldType: ProfileAttributeFieldType;
  VendorWalletTransaction:
    | ResolversTypes["VendorBannerBrandDebitTransaction"]
    | ResolversTypes["VendorListingDebitTransaction"]
    | ResolversTypes["VendorLeadDebitTransaction"]
    | ResolversTypes["VendorBannerCredit"]
    | ResolversTypes["VendorBrandListingCredit"];
  VendorBannerBrandDebitTransaction: ResolverTypeWrapper<
    VendorBannerBrandDebitTransaction
  >;
  TransactionDebitInt:
    | ResolversTypes["VendorBannerBrandDebitTransaction"]
    | ResolversTypes["VendorListingDebitTransaction"]
    | ResolversTypes["VendorLeadDebitTransaction"];
  VendorPaymentType: VendorPaymentType;
  PaymentMode: PaymentMode;
  Float: ResolverTypeWrapper<Scalars["Float"]>;
  TenurePeriod: ResolverTypeWrapper<TenurePeriod>;
  VendorListingDebitTransaction: ResolverTypeWrapper<
    VendorListingDebitTransaction
  >;
  GstAmount: ResolverTypeWrapper<GstAmount>;
  GstPercentage: ResolverTypeWrapper<GstPercentage>;
  VendorLeadDebitTransaction: ResolverTypeWrapper<VendorLeadDebitTransaction>;
  VendorBannerCredit: ResolverTypeWrapper<VendorBannerCredit>;
  TransactionCreditInt:
    | ResolversTypes["VendorBannerCredit"]
    | ResolversTypes["VendorBrandListingCredit"];
  VendorBrandListingCredit: ResolverTypeWrapper<VendorBrandListingCredit>;
  NotificationFollowupLogsResponse: ResolverTypeWrapper<
    NotificationFollowupLogsResponse
  >;
  NotificationCount: ResolverTypeWrapper<NotificationCount>;
  NotificationCountByTypes: ResolverTypeWrapper<NotificationCountByTypes>;
  Category: ResolverTypeWrapper<Category>;
  CheckPoint: ResolverTypeWrapper<CheckPoint>;
  CheckPointList: CheckPointList;
  Platform: Platform;
  Version: ResolverTypeWrapper<Version>;
  LeadFilterInput: LeadFilterInput;
  LeadsFilterType: LeadsFilterType;
  TotalLeads: ResolverTypeWrapper<TotalLeads>;
  Profile: ResolverTypeWrapper<Profile>;
  ProfileServiceable: ProfileServiceable;
  ProfileStatus: ProfileStatus;
  LeadManagement: ResolverTypeWrapper<LeadManagement>;
  ProfileLeadManagementStatus: ProfileLeadManagementStatus;
  Pricing: ResolverTypeWrapper<Pricing>;
  ProfileGallery: ResolverTypeWrapper<ProfileGallery>;
  VendorDocStatus: VendorDocStatus;
  ImageTag: ResolverTypeWrapper<ImageTag>;
  AttributeSubHeader: ResolverTypeWrapper<AttributeSubHeader>;
  FieldOptions: ResolverTypeWrapper<FieldOptions>;
  SalesCity: ResolverTypeWrapper<SalesCity>;
  SalesState: ResolverTypeWrapper<SalesState>;
  State: ResolverTypeWrapper<State>;
  SubCategory: ResolverTypeWrapper<SubCategory>;
  VendorDetails: ResolverTypeWrapper<VendorDetails>;
  VendorKYC: ResolverTypeWrapper<VendorKyc>;
  ContactPerson: ResolverTypeWrapper<ContactPerson>;
  VendorRole: VendorRole;
  ContactPhone: ResolverTypeWrapper<ContactPhone>;
  VerifiedSource: VerifiedSource;
  Address: ResolverTypeWrapper<Address>;
  BillingInfo: ResolverTypeWrapper<BillingInfo>;
  PaymentStatus: ResolverTypeWrapper<PaymentStatus>;
  PaidStatus: PaidStatus;
  OnBoardStatus: ResolverTypeWrapper<OnBoardStatus>;
  SocialLinks: ResolverTypeWrapper<SocialLinks>;
  MiscVendorDetails: ResolverTypeWrapper<MiscVendorDetails>;
  MiscListCompetition: MiscListCompetition;
  MiscOperatingOutOf: MiscOperatingOutOf;
  MiscNosEmployees: MiscNosEmployees;
  MiscEventConducted: MiscEventConducted;
  VendorDetailsReview: ResolverTypeWrapper<VendorDetailsReview>;
  ContactPersonReview: ResolverTypeWrapper<ContactPersonReview>;
  VendorDocCategory: VendorDocCategory;
  VendorDocumentTypes: ResolverTypeWrapper<VendorDocumentTypes>;
  VendorLeadFeedback: ResolverTypeWrapper<VendorLeadFeedback>;
  LeadFeedbackDispositionTypes: LeadFeedbackDispositionTypes;
  LeadFeedbackCreatedByType: LeadFeedbackCreatedByType;
  LeadFeedbackType: LeadFeedbackType;
  LeadFeedbackDispositionList: ResolverTypeWrapper<LeadFeedbackDispositionList>;
  VendorLogin: ResolverTypeWrapper<VendorLogin>;
  OTPRequestAcknowledge: ResolverTypeWrapper<OtpRequestAcknowledge>;
  VendorValidate: ResolverTypeWrapper<VendorValidate>;
  VendorProfileRole: ResolverTypeWrapper<VendorProfileRole>;
  VendorWallet: ResolverTypeWrapper<
    Omit<VendorWallet, "payments"> & {
      payments?: Maybe<Array<Maybe<ResolversTypes["VendorPayments"]>>>;
    }
  >;
  WalletOverview: ResolverTypeWrapper<WalletOverview>;
  VendorWalletType: VendorWalletType;
  WalletPaymentType: WalletPaymentType;
  VendorPayments:
    | ResolversTypes["VendorBannerBrandPayment"]
    | ResolversTypes["VendorLeadListPayment"];
  VendorBannerBrandPayment: ResolverTypeWrapper<VendorBannerBrandPayment>;
  VendorPaymentStatus: VendorPaymentStatus;
  VendorLeadListPayment: ResolverTypeWrapper<VendorLeadListPayment>;
  Mutation: ResolverTypeWrapper<{}>;
  DeviceDetailsInput: DeviceDetailsInput;
  AddLogResponse: ResolverTypeWrapper<AddLogResponse>;
  FeedbackType: FeedbackType;
  ProfileInput: ProfileInput;
  ProfileAttributesInput: ProfileAttributesInput;
  ProfileGalleryInput: ProfileGalleryInput;
  ContactPersonInput: ContactPersonInput;
  NewVendorDetailsMonetary: ResolverTypeWrapper<NewVendorDetailsMonetary>;
  UpdatePersonInput: UpdatePersonInput;
  UpdateAddressInput: UpdateAddressInput;
  VendorKYCInput: VendorKycInput;
  CacheControlScope: CacheControlScope;
  OnBoardProgressStatus: OnBoardProgressStatus;
  ProfileCommissionApproved: ProfileCommissionApproved;
  LeadSource: LeadSource;
  EventType: EventType;
  BazaarTransaction: BazaarTransaction;
  AddressInput: AddressInput;
  AttributeHeader: ResolverTypeWrapper<AttributeHeader>;
  AttributesByGroup: ResolverTypeWrapper<AttributesByGroup>;
  FieldValidation: ResolverTypeWrapper<FieldValidation>;
  Customer: ResolverTypeWrapper<Customer>;
  LeadMeta: ResolverTypeWrapper<LeadMeta>;
  MiscVendorDetailsInput: MiscVendorDetailsInput;
  ProfileAttributesDiff: ResolverTypeWrapper<ProfileAttributesDiff>;
  ProfileAttributeChangeLogs: ResolverTypeWrapper<ProfileAttributeChangeLogs>;
  PurchaseOrder: ResolverTypeWrapper<PurchaseOrder>;
  TextMessage: ResolverTypeWrapper<TextMessage>;
  BillingInfoInput: BillingInfoInput;
  SocialLinksInput: SocialLinksInput;
  VendorDocuments: ResolverTypeWrapper<VendorDocuments>;
}

/** Mapping between all available schema types and the resolvers parents */
export interface ResolversParentTypes {
  Query: {};
  String: Scalars["String"];
  JSON: Scalars["JSON"];
  AddressInfo: AddressInfo;
  Locality: Locality;
  City: City;
  ID: Scalars["ID"];
  Boolean: Scalars["Boolean"];
  Int: Scalars["Int"];
  PushNotificationLead: PushNotificationLead;
  PushNotificationProfileInput: PushNotificationProfileInput;
  PushNotificationProfileResult: PushNotificationProfileResult;
  PushNotificationTransactionInput: PushNotificationTransactionInput;
  PushNotificationTransactionResult: PushNotificationTransactionResult;
  PNTRnotification: PntRnotification;
  TimePeriodInput: TimePeriodInput;
  DateTime: Scalars["DateTime"];
  NotificationFilterinput: NotificationFilterinput;
  NotificationLogs: Omit<NotificationLogs, "leadInfo" | "transactionInfo"> & {
    leadInfo?: Maybe<ResolversParentTypes["Leads"]>;
    transactionInfo?: Maybe<ResolversParentTypes["VendorWalletTransaction"]>;
  };
  Leads: ResolversParentTypes["CallLeads"] | ResolversParentTypes["CRMLeads"];
  CallLeads: CallLeads;
  CallCustomer: CallCustomer;
  CallInfo: CallInfo;
  CRMLeads: CrmLeads;
  CrmCustomer: CrmCustomer;
  CrmCustomerDetails: CrmCustomerDetails;
  LeadEvent: LeadEvent;
  ProfileAttributes: ProfileAttributes;
  VendorWalletTransaction:
    | ResolversParentTypes["VendorBannerBrandDebitTransaction"]
    | ResolversParentTypes["VendorListingDebitTransaction"]
    | ResolversParentTypes["VendorLeadDebitTransaction"]
    | ResolversParentTypes["VendorBannerCredit"]
    | ResolversParentTypes["VendorBrandListingCredit"];
  VendorBannerBrandDebitTransaction: VendorBannerBrandDebitTransaction;
  TransactionDebitInt:
    | ResolversParentTypes["VendorBannerBrandDebitTransaction"]
    | ResolversParentTypes["VendorListingDebitTransaction"]
    | ResolversParentTypes["VendorLeadDebitTransaction"];
  Float: Scalars["Float"];
  TenurePeriod: TenurePeriod;
  VendorListingDebitTransaction: VendorListingDebitTransaction;
  GstAmount: GstAmount;
  GstPercentage: GstPercentage;
  VendorLeadDebitTransaction: VendorLeadDebitTransaction;
  VendorBannerCredit: VendorBannerCredit;
  TransactionCreditInt:
    | ResolversParentTypes["VendorBannerCredit"]
    | ResolversParentTypes["VendorBrandListingCredit"];
  VendorBrandListingCredit: VendorBrandListingCredit;
  NotificationFollowupLogsResponse: NotificationFollowupLogsResponse;
  NotificationCount: NotificationCount;
  NotificationCountByTypes: NotificationCountByTypes;
  Category: Category;
  CheckPoint: CheckPoint;
  Version: Version;
  LeadFilterInput: LeadFilterInput;
  TotalLeads: TotalLeads;
  Profile: Profile;
  LeadManagement: LeadManagement;
  Pricing: Pricing;
  ProfileGallery: ProfileGallery;
  ImageTag: ImageTag;
  AttributeSubHeader: AttributeSubHeader;
  FieldOptions: FieldOptions;
  SalesCity: SalesCity;
  SalesState: SalesState;
  State: State;
  SubCategory: SubCategory;
  VendorDetails: VendorDetails;
  VendorKYC: VendorKyc;
  ContactPerson: ContactPerson;
  ContactPhone: ContactPhone;
  Address: Address;
  BillingInfo: BillingInfo;
  PaymentStatus: PaymentStatus;
  OnBoardStatus: OnBoardStatus;
  SocialLinks: SocialLinks;
  MiscVendorDetails: MiscVendorDetails;
  VendorDetailsReview: VendorDetailsReview;
  ContactPersonReview: ContactPersonReview;
  VendorDocumentTypes: VendorDocumentTypes;
  VendorLeadFeedback: VendorLeadFeedback;
  LeadFeedbackDispositionList: LeadFeedbackDispositionList;
  VendorLogin: VendorLogin;
  OTPRequestAcknowledge: OtpRequestAcknowledge;
  VendorValidate: VendorValidate;
  VendorProfileRole: VendorProfileRole;
  VendorWallet: Omit<VendorWallet, "payments"> & {
    payments?: Maybe<Array<Maybe<ResolversParentTypes["VendorPayments"]>>>;
  };
  WalletOverview: WalletOverview;
  VendorPayments:
    | ResolversParentTypes["VendorBannerBrandPayment"]
    | ResolversParentTypes["VendorLeadListPayment"];
  VendorBannerBrandPayment: VendorBannerBrandPayment;
  VendorLeadListPayment: VendorLeadListPayment;
  Mutation: {};
  DeviceDetailsInput: DeviceDetailsInput;
  AddLogResponse: AddLogResponse;
  ProfileInput: ProfileInput;
  ProfileAttributesInput: ProfileAttributesInput;
  ProfileGalleryInput: ProfileGalleryInput;
  ContactPersonInput: ContactPersonInput;
  NewVendorDetailsMonetary: NewVendorDetailsMonetary;
  UpdatePersonInput: UpdatePersonInput;
  UpdateAddressInput: UpdateAddressInput;
  VendorKYCInput: VendorKycInput;
  AddressInput: AddressInput;
  AttributeHeader: AttributeHeader;
  AttributesByGroup: AttributesByGroup;
  FieldValidation: FieldValidation;
  Customer: Customer;
  LeadMeta: LeadMeta;
  MiscVendorDetailsInput: MiscVendorDetailsInput;
  ProfileAttributesDiff: ProfileAttributesDiff;
  ProfileAttributeChangeLogs: ProfileAttributeChangeLogs;
  PurchaseOrder: PurchaseOrder;
  TextMessage: TextMessage;
  BillingInfoInput: BillingInfoInput;
  SocialLinksInput: SocialLinksInput;
  VendorDocuments: VendorDocuments;
}

export interface AddLogResponseResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AddLogResponse"] = ResolversParentTypes["AddLogResponse"]
> {
  status?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  message?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  deviceToken?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AddressResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Address"] = ResolversParentTypes["Address"]
> {
  address?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  localityId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  cityId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  stateId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  locality?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  pincode?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  latitude?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  longitude?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AddressInfoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AddressInfo"] = ResolversParentTypes["AddressInfo"]
> {
  addressLine1?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  addressLine2?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  locality?: Resolver<
    Maybe<ResolversTypes["Locality"]>,
    ParentType,
    ContextType
  >;
  city?: Resolver<Maybe<ResolversTypes["City"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AttributeHeaderResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AttributeHeader"] = ResolversParentTypes["AttributeHeader"]
> {
  id?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  categoryId?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AttributesByGroupResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AttributesByGroup"] = ResolversParentTypes["AttributesByGroup"]
> {
  groupName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["AttributeSubHeader"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AttributeSubHeaderResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AttributeSubHeader"] = ResolversParentTypes["AttributeSubHeader"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  label?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  question?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  groupName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  groupOrder?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  displayOrder?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  values?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  fieldType?: Resolver<
    Maybe<ResolversTypes["ProfileAttributeFieldType"]>,
    ParentType,
    ContextType
  >;
  isMandatory?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  fieldValues?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["FieldOptions"]>>>,
    ParentType,
    ContextType
  >;
  fieldValidation?: Resolver<
    Maybe<ResolversTypes["JSON"]>,
    ParentType,
    ContextType
  >;
  isEditable?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BillingInfoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BillingInfo"] = ResolversParentTypes["BillingInfo"]
> {
  gstNo?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  gstBusinessName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  gstState?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  billingName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  billingAddress?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  salesCityId?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  salesStateId?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CallCustomerResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CallCustomer"] = ResolversParentTypes["CallCustomer"]
> {
  tag?: Resolver<Maybe<ResolversTypes["LeadTag"]>, ParentType, ContextType>;
  mobileNo?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  virtualNo?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  agentNo?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CallInfoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CallInfo"] = ResolversParentTypes["CallInfo"]
> {
  status?: Resolver<
    Maybe<ResolversTypes["CallStatus"]>,
    ParentType,
    ContextType
  >;
  duration?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CallLeadsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CallLeads"] = ResolversParentTypes["CallLeads"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  followupDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  customer?: Resolver<ResolversTypes["CallCustomer"], ParentType, ContextType>;
  call?: Resolver<ResolversTypes["CallInfo"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Category"] = ResolversParentTypes["Category"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  iconUrl?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  displayName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  displayOrder?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CheckPointResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CheckPoint"] = ResolversParentTypes["CheckPoint"]
> {
  step?: Resolver<ResolversTypes["CheckPointList"], ParentType, ContextType>;
  accessToken?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  deviceToken?: Resolver<
    ResolversTypes["String"],
    ParentType,
    ContextType,
    RequireFields<CheckPointDeviceTokenArgs, "newToken">
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["City"] = ResolversParentTypes["City"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  stateId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  isOSC?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ContactPersonResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ContactPerson"] = ResolversParentTypes["ContactPerson"]
> {
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  role?: Resolver<Maybe<ResolversTypes["VendorRole"]>, ParentType, ContextType>;
  email?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  phone1?: Resolver<ResolversTypes["ContactPhone"], ParentType, ContextType>;
  phone2?: Resolver<ResolversTypes["ContactPhone"], ParentType, ContextType>;
  isWhatsappConsent?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ContactPersonReviewResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ContactPersonReview"] = ResolversParentTypes["ContactPersonReview"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  role?: Resolver<Maybe<ResolversTypes["VendorRole"]>, ParentType, ContextType>;
  email?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  phone1?: Resolver<
    Maybe<ResolversTypes["ContactPhone"]>,
    ParentType,
    ContextType
  >;
  phone2?: Resolver<
    Maybe<ResolversTypes["ContactPhone"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ContactPhoneResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ContactPhone"] = ResolversParentTypes["ContactPhone"]
> {
  phone?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  verifyStatus?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  verifySource?: Resolver<
    Maybe<ResolversTypes["VerifiedSource"]>,
    ParentType,
    ContextType
  >;
  verifyOn?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CrmCustomerResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CrmCustomer"] = ResolversParentTypes["CrmCustomer"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes["LeadTag"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  mobileNo?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  emailId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CrmCustomerDetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CrmCustomerDetails"] = ResolversParentTypes["CrmCustomerDetails"]
> {
  relationship?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  age?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  gender?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  brideName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  groomName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  event?: Resolver<ResolversTypes["LeadEvent"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CrmLeadsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CRMLeads"] = ResolversParentTypes["CRMLeads"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  followupDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  customer?: Resolver<ResolversTypes["CrmCustomer"], ParentType, ContextType>;
  customerDetails?: Resolver<
    Maybe<ResolversTypes["CrmCustomerDetails"]>,
    ParentType,
    ContextType
  >;
  customerReq?: Resolver<
    Maybe<Array<ResolversTypes["ProfileAttributes"]>>,
    ParentType,
    ContextType,
    RequireFields<CrmLeadsCustomerReqArgs, never>
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CustomerResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Customer"] = ResolversParentTypes["Customer"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes["LeadTag"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  mobileNo?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  emailId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  createdAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface DateTimeScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["DateTime"], any> {
  name: "DateTime";
}

export interface FieldOptionsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["FieldOptions"] = ResolversParentTypes["FieldOptions"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  displayOrder?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  value?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  checked?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  isDefault?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface FieldValidationResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["FieldValidation"] = ResolversParentTypes["FieldValidation"]
> {
  rule?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  err?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface GstAmountResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["GstAmount"] = ResolversParentTypes["GstAmount"]
> {
  cGst?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  sGst?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  iGst?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface GstPercentageResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["GstPercentage"] = ResolversParentTypes["GstPercentage"]
> {
  cGst?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  sGst?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  iGst?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ImageTagResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ImageTag"] = ResolversParentTypes["ImageTag"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface JsonScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["JSON"], any> {
  name: "JSON";
}

export interface LeadEventResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["LeadEvent"] = ResolversParentTypes["LeadEvent"]
> {
  date?: Resolver<Maybe<ResolversTypes["DateTime"]>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  startDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  endDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  durationDays?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface LeadFeedbackDispositionListResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["LeadFeedbackDispositionList"] = ResolversParentTypes["LeadFeedbackDispositionList"]
> {
  label?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  dispositionType?: Resolver<
    ResolversTypes["LeadFeedbackDispositionTypes"],
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface LeadManagementResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["LeadManagement"] = ResolversParentTypes["LeadManagement"]
> {
  status?: Resolver<
    Maybe<ResolversTypes["ProfileLeadManagementStatus"]>,
    ParentType,
    ContextType
  >;
  count?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  maxCount?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface LeadMetaResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["LeadMeta"] = ResolversParentTypes["LeadMeta"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  leadSource?: Resolver<
    Maybe<ResolversTypes["LeadSource"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface LeadsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Leads"] = ResolversParentTypes["Leads"]
> {
  __resolveType: TypeResolveFn<
    "CallLeads" | "CRMLeads",
    ParentType,
    ContextType
  >;
}

export interface LocalityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Locality"] = ResolversParentTypes["Locality"]
> {
  id?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  pincode?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MiscVendorDetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["MiscVendorDetails"] = ResolversParentTypes["MiscVendorDetails"]
> {
  listingWithCompetition?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["MiscListCompetition"]>>>,
    ParentType,
    ContextType
  >;
  operatingOutOf?: Resolver<
    Maybe<ResolversTypes["MiscOperatingOutOf"]>,
    ParentType,
    ContextType
  >;
  numberOfEmployees?: Resolver<
    Maybe<ResolversTypes["MiscNosEmployees"]>,
    ParentType,
    ContextType
  >;
  eventsConductedSoFar?: Resolver<
    Maybe<ResolversTypes["MiscEventConducted"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MutationResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Mutation"] = ResolversParentTypes["Mutation"]
> {
  addLog?: Resolver<
    ResolversTypes["AddLogResponse"],
    ParentType,
    ContextType,
    RequireFields<
      MutationAddLogArgs,
      "buildVersion" | "imeiNo" | "deviceToken" | "ip" | "deviceDetails"
    >
  >;
  updateNotificationLog?: Resolver<
    ResolversTypes["NotificationLogs"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateNotificationLogArgs, "id">
  >;
  addFeedback?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType,
    RequireFields<MutationAddFeedbackArgs, "message">
  >;
  addProfile?: Resolver<
    ResolversTypes["Profile"],
    ParentType,
    ContextType,
    RequireFields<MutationAddProfileArgs, "profile">
  >;
  addProfileAttributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileAttributes"]>>>,
    ParentType,
    ContextType,
    RequireFields<MutationAddProfileAttributesArgs, "profileId" | "attributes">
  >;
  updateGallery?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileGallery"]>>>,
    ParentType,
    ContextType,
    RequireFields<MutationUpdateGalleryArgs, never>
  >;
  createVendor?: Resolver<
    ResolversTypes["NewVendorDetailsMonetary"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateVendorArgs, "businessName" | "primary">
  >;
  updateVendor?: Resolver<
    ResolversTypes["VendorDetails"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateVendorArgs, never>
  >;
  createVendorLeadFeedback?: Resolver<
    Maybe<ResolversTypes["VendorLeadFeedback"]>,
    ParentType,
    ContextType,
    RequireFields<MutationCreateVendorLeadFeedbackArgs, "leadId">
  >;
  updateVendorLeadFeedback?: Resolver<
    Maybe<ResolversTypes["VendorLeadFeedback"]>,
    ParentType,
    ContextType,
    RequireFields<MutationUpdateVendorLeadFeedbackArgs, "leadFeedbackId">
  >;
}

export interface NewVendorDetailsMonetaryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["NewVendorDetailsMonetary"] = ResolversParentTypes["NewVendorDetailsMonetary"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  accessToken?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  businessName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface NotificationCountResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["NotificationCount"] = ResolversParentTypes["NotificationCount"]
> {
  total?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  byType?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["NotificationCountByTypes"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface NotificationCountByTypesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["NotificationCountByTypes"] = ResolversParentTypes["NotificationCountByTypes"]
> {
  type?: Resolver<
    Maybe<ResolversTypes["NotificationTypes"]>,
    ParentType,
    ContextType
  >;
  count?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface NotificationFollowupLogsResponseResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["NotificationFollowupLogsResponse"] = ResolversParentTypes["NotificationFollowupLogsResponse"]
> {
  read?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  unRead?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  notifications?: Resolver<
    Maybe<Array<ResolversTypes["NotificationLogs"]>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface NotificationLogsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["NotificationLogs"] = ResolversParentTypes["NotificationLogs"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  leadId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  type?: Resolver<
    Maybe<ResolversTypes["NotificationTypes"]>,
    ParentType,
    ContextType
  >;
  title?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  leadInfo?: Resolver<Maybe<ResolversTypes["Leads"]>, ParentType, ContextType>;
  transactionId?: Resolver<
    Maybe<ResolversTypes["ID"]>,
    ParentType,
    ContextType
  >;
  transactionInfo?: Resolver<
    Maybe<ResolversTypes["VendorWalletTransaction"]>,
    ParentType,
    ContextType
  >;
  leadFeedbackId?: Resolver<
    Maybe<ResolversTypes["ID"]>,
    ParentType,
    ContextType
  >;
  notes?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isRead?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  createdAt?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface OnBoardStatusResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["OnBoardStatus"] = ResolversParentTypes["OnBoardStatus"]
> {
  status?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  onboardState?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  activatedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface OtpRequestAcknowledgeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["OTPRequestAcknowledge"] = ResolversParentTypes["OTPRequestAcknowledge"]
> {
  message?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isExisting?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  retryLeft?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  retryAgain?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  otpInterval?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PaymentStatusResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["PaymentStatus"] = ResolversParentTypes["PaymentStatus"]
> {
  paidStatus?: Resolver<
    Maybe<ResolversTypes["PaidStatus"]>,
    ParentType,
    ContextType
  >;
  noOfPayments?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  isFeatured?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  featuredStartDate?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  featuredEndDate?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PntRnotificationResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["PNTRnotification"] = ResolversParentTypes["PNTRnotification"]
> {
  referenceId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  devices?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  devicesInfo?: Resolver<
    Maybe<ResolversTypes["JSON"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PricingResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Pricing"] = ResolversParentTypes["Pricing"]
> {
  commissionPercentage?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  discount?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  leadFee?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  listingFee?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Profile"] = ResolversParentTypes["Profile"]
> {
  id?: Resolver<
    ResolversTypes["ID"],
    ParentType,
    ContextType,
    RequireFields<ProfileIdArgs, never>
  >;
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  ratings?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  reviewLink?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  listingName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  currentPackage?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  serviceable?: Resolver<
    Maybe<ResolversTypes["ProfileServiceable"]>,
    ParentType,
    ContextType
  >;
  completionLevel?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<
    Maybe<ResolversTypes["ProfileStatus"]>,
    ParentType,
    ContextType
  >;
  leadManagement?: Resolver<
    Maybe<ResolversTypes["LeadManagement"]>,
    ParentType,
    ContextType
  >;
  pricing?: Resolver<Maybe<ResolversTypes["Pricing"]>, ParentType, ContextType>;
  gallery?: Resolver<
    Maybe<Array<ResolversTypes["ProfileGallery"]>>,
    ParentType,
    ContextType
  >;
  attributes?: Resolver<
    Maybe<Array<ResolversTypes["ProfileAttributes"]>>,
    ParentType,
    ContextType,
    RequireFields<ProfileAttributesArgs, never>
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileAttributeChangeLogsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileAttributeChangeLogs"] = ResolversParentTypes["ProfileAttributeChangeLogs"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  crmTicketId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  diff?: Resolver<
    ResolversTypes["ProfileAttributesDiff"],
    ParentType,
    ContextType
  >;
  employeeId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  source?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  status?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileAttributesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileAttributes"] = ResolversParentTypes["ProfileAttributes"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  groupName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  label?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  displayOrder?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  question?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  values?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  fieldType?: Resolver<
    Maybe<ResolversTypes["ProfileAttributeFieldType"]>,
    ParentType,
    ContextType
  >;
  isEditable?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileAttributesDiffResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileAttributesDiff"] = ResolversParentTypes["ProfileAttributesDiff"]
> {
  old?: Resolver<
    Maybe<Array<ResolversTypes["ProfileAttributes"]>>,
    ParentType,
    ContextType
  >;
  new?: Resolver<
    Maybe<Array<ResolversTypes["ProfileAttributes"]>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileGalleryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileGallery"] = ResolversParentTypes["ProfileGallery"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  uuid?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  url?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  status?: Resolver<ResolversTypes["VendorDocStatus"], ParentType, ContextType>;
  rejectionReason?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  title?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  subTitle?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  isHero?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  canBeHero?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  displayOrder?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<ResolversTypes["ImageTag"]>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PurchaseOrderResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["PurchaseOrder"] = ResolversParentTypes["PurchaseOrder"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  poNumber?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  poDate?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  poSentData?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  userId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  roleId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  branchId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  downloadUrlKey?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  downloadUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  expiryDate?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  isRegenerate?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  fileVersion?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  createdAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PushNotificationLeadResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["PushNotificationLead"] = ResolversParentTypes["PushNotificationLead"]
> {
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  devices?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  devicesInfo?: Resolver<
    Maybe<ResolversTypes["JSON"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PushNotificationProfileResultResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["PushNotificationProfileResult"] = ResolversParentTypes["PushNotificationProfileResult"]
> {
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  cityId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  categoryId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  profileSlug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  devices?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  devicesInfo?: Resolver<
    Maybe<ResolversTypes["JSON"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PushNotificationTransactionResultResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["PushNotificationTransactionResult"] = ResolversParentTypes["PushNotificationTransactionResult"]
> {
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  transactionType?: Resolver<
    ResolversTypes["TransactionType"],
    ParentType,
    ContextType
  >;
  paymentType?: Resolver<
    ResolversTypes["VendorNotifyPaymentType"],
    ParentType,
    ContextType
  >;
  notification?: Resolver<
    Maybe<Array<ResolversTypes["PNTRnotification"]>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface QueryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Query"] = ResolversParentTypes["Query"]
> {
  tokenGen?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType,
    RequireFields<QueryTokenGenArgs, "role">
  >;
  getAddressInfo?: Resolver<
    ResolversTypes["AddressInfo"],
    ParentType,
    ContextType,
    RequireFields<QueryGetAddressInfoArgs, "addressInfo">
  >;
  crmMobEncrypt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType,
    RequireFields<QueryCrmMobEncryptArgs, "val">
  >;
  crmMobDecrypt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType,
    RequireFields<QueryCrmMobDecryptArgs, "val">
  >;
  decrypt?: Resolver<
    Maybe<Array<ResolversTypes["Int"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryDecryptArgs, "slug">
  >;
  decryptString?: Resolver<
    Maybe<Array<ResolversTypes["String"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryDecryptStringArgs, "slug">
  >;
  encrypt?: Resolver<
    ResolversTypes["ID"],
    ParentType,
    ContextType,
    RequireFields<QueryEncryptArgs, "listOfIds">
  >;
  encryptString?: Resolver<
    ResolversTypes["ID"],
    ParentType,
    ContextType,
    RequireFields<QueryEncryptStringArgs, "listOfIds">
  >;
  pushNotificationLead?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["PushNotificationLead"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryPushNotificationLeadArgs, "vendorUserLeadIds">
  >;
  pushNotificationProfile?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["PushNotificationProfileResult"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryPushNotificationProfileArgs, "profiles">
  >;
  pushNotificationTransaction?: Resolver<
    Maybe<Array<ResolversTypes["PushNotificationTransactionResult"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryPushNotificationTransactionArgs, "transactions">
  >;
  notifyRec?: Resolver<
    Maybe<ResolversTypes["JSON"]>,
    ParentType,
    ContextType,
    RequireFields<QueryNotifyRecArgs, never>
  >;
  notificationLogs?: Resolver<
    Maybe<Array<ResolversTypes["NotificationLogs"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryNotificationLogsArgs, never>
  >;
  notificationFollowupLogs?: Resolver<
    Maybe<ResolversTypes["NotificationFollowupLogsResponse"]>,
    ParentType,
    ContextType
  >;
  notificationCount?: Resolver<
    ResolversTypes["NotificationCount"],
    ParentType,
    ContextType,
    RequireFields<QueryNotificationCountArgs, never>
  >;
  category?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  checkPoint?: Resolver<ResolversTypes["CheckPoint"], ParentType, ContextType>;
  version?: Resolver<
    ResolversTypes["Version"],
    ParentType,
    ContextType,
    RequireFields<QueryVersionArgs, "platform">
  >;
  cities?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["City"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryCitiesArgs, never>
  >;
  cityByState?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["City"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryCityByStateArgs, "stateId">
  >;
  cityServiceableOther?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["City"]>>>,
    ParentType,
    ContextType
  >;
  cityServiceable?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["City"]>>>,
    ParentType,
    ContextType
  >;
  leads?: Resolver<
    Maybe<Array<ResolversTypes["Leads"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryLeadsArgs, "duration">
  >;
  leadById?: Resolver<
    Maybe<ResolversTypes["Leads"]>,
    ParentType,
    ContextType,
    RequireFields<QueryLeadByIdArgs, "leadId">
  >;
  totalLeads?: Resolver<
    ResolversTypes["TotalLeads"],
    ParentType,
    ContextType,
    RequireFields<QueryTotalLeadsArgs, "type">
  >;
  localityByCity?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Locality"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryLocalityByCityArgs, "cityId">
  >;
  profileById?: Resolver<
    Maybe<ResolversTypes["Profile"]>,
    ParentType,
    ContextType,
    RequireFields<QueryProfileByIdArgs, "id">
  >;
  attributesByProfile?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["AttributeSubHeader"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryAttributesByProfileArgs, "profileId">
  >;
  profileGalleryImgByUUID?: Resolver<
    Maybe<ResolversTypes["ProfileGallery"]>,
    ParentType,
    ContextType,
    RequireFields<QueryProfileGalleryImgByUuidArgs, "imgUUID">
  >;
  salesCityByState?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["SalesCity"]>>>,
    ParentType,
    ContextType,
    RequireFields<QuerySalesCityByStateArgs, "stateId">
  >;
  salesState?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["SalesState"]>>>,
    ParentType,
    ContextType
  >;
  states?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["State"]>>>,
    ParentType,
    ContextType
  >;
  subCategory?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["SubCategory"]>>>,
    ParentType,
    ContextType,
    RequireFields<QuerySubCategoryArgs, never>
  >;
  vendorDetails?: Resolver<
    Maybe<ResolversTypes["VendorDetails"]>,
    ParentType,
    ContextType
  >;
  allVendorDetails?: Resolver<
    Maybe<Array<ResolversTypes["VendorDetails"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryAllVendorDetailsArgs, never>
  >;
  vendorDocumentTypes?: Resolver<
    Maybe<Array<ResolversTypes["VendorDocumentTypes"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryVendorDocumentTypesArgs, "category">
  >;
  vendorLeadFeedbacks?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["VendorLeadFeedback"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryVendorLeadFeedbacksArgs, "leadId">
  >;
  leadFeedbackDisposition?: Resolver<
    Maybe<Array<ResolversTypes["LeadFeedbackDispositionList"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryLeadFeedbackDispositionArgs, "type">
  >;
  vendorLogin?: Resolver<
    Maybe<ResolversTypes["VendorLogin"]>,
    ParentType,
    ContextType,
    RequireFields<QueryVendorLoginArgs, "userId" | "otp">
  >;
  vendorLogout?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  otpRequest?: Resolver<
    Maybe<ResolversTypes["OTPRequestAcknowledge"]>,
    ParentType,
    ContextType,
    RequireFields<QueryOtpRequestArgs, "userId">
  >;
  vendorValidate?: Resolver<
    Maybe<ResolversTypes["VendorValidate"]>,
    ParentType,
    ContextType,
    RequireFields<QueryVendorValidateArgs, "userId">
  >;
  vendorWallet?: Resolver<
    Maybe<ResolversTypes["VendorWallet"]>,
    ParentType,
    ContextType
  >;
  vendorWalletTransaction?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["VendorWalletTransaction"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryVendorWalletTransactionArgs, never>
  >;
  vendorWalletTransactionById?: Resolver<
    Maybe<ResolversTypes["VendorWalletTransaction"]>,
    ParentType,
    ContextType,
    RequireFields<QueryVendorWalletTransactionByIdArgs, "transactionId">
  >;
}

export interface SalesCityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["SalesCity"] = ResolversParentTypes["SalesCity"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  address?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SalesStateResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["SalesState"] = ResolversParentTypes["SalesState"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  address?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SocialLinksResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["SocialLinks"] = ResolversParentTypes["SocialLinks"]
> {
  webUrl?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  fbUrl?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  instagramUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  pinterestUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  twitterUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface StateResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["State"] = ResolversParentTypes["State"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SubCategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["SubCategory"] = ResolversParentTypes["SubCategory"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  displayName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  seoCategoryName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  categoryImage?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  domain?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  commissionStatus?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  displayOrder?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  layeredFormTitle?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface TenurePeriodResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["TenurePeriod"] = ResolversParentTypes["TenurePeriod"]
> {
  start?: Resolver<Maybe<ResolversTypes["DateTime"]>, ParentType, ContextType>;
  end?: Resolver<Maybe<ResolversTypes["DateTime"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface TextMessageResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["TextMessage"] = ResolversParentTypes["TextMessage"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface TotalLeadsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["TotalLeads"] = ResolversParentTypes["TotalLeads"]
> {
  direct?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  lead?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  order?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  call?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  total?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface TransactionCreditIntResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["TransactionCreditInt"] = ResolversParentTypes["TransactionCreditInt"]
> {
  __resolveType: TypeResolveFn<
    "VendorBannerCredit" | "VendorBrandListingCredit",
    ParentType,
    ContextType
  >;
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  referenceNumber?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
}

export interface TransactionDebitIntResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["TransactionDebitInt"] = ResolversParentTypes["TransactionDebitInt"]
> {
  __resolveType: TypeResolveFn<
    | "VendorBannerBrandDebitTransaction"
    | "VendorListingDebitTransaction"
    | "VendorLeadDebitTransaction",
    ParentType,
    ContextType
  >;
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  standardAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  bonusAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
}

export interface VendorBannerBrandDebitTransactionResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorBannerBrandDebitTransaction"] = ResolversParentTypes["VendorBannerBrandDebitTransaction"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  standardAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  bonusAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  profileSlug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  profileUrl?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tenurePeriod?: Resolver<
    Maybe<ResolversTypes["TenurePeriod"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorBannerBrandPaymentResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorBannerBrandPayment"] = ResolversParentTypes["VendorBannerBrandPayment"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  landingCategory?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  landingCity?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<
    Maybe<ResolversTypes["VendorPaymentStatus"]>,
    ParentType,
    ContextType
  >;
  tenurePeriod?: Resolver<
    Maybe<ResolversTypes["TenurePeriod"]>,
    ParentType,
    ContextType
  >;
  balanceAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  deliveredAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  totalPaidAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  type?: Resolver<ResolversTypes["VendorPaymentType"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorBannerCreditResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorBannerCredit"] = ResolversParentTypes["VendorBannerCredit"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  referenceNumber?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  profileSlug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  profileUrl?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorBrandListingCreditResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorBrandListingCredit"] = ResolversParentTypes["VendorBrandListingCredit"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  referenceNumber?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  setupCost?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  tenure?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  leadId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  profileSlug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  profileUrl?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorDetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorDetails"] = ResolversParentTypes["VendorDetails"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  vendorId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  businessName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  document?: Resolver<
    Maybe<ResolversTypes["VendorKYC"]>,
    ParentType,
    ContextType
  >;
  primary?: Resolver<
    Maybe<ResolversTypes["ContactPerson"]>,
    ParentType,
    ContextType
  >;
  secondary?: Resolver<
    Maybe<ResolversTypes["ContactPerson"]>,
    ParentType,
    ContextType
  >;
  address?: Resolver<Maybe<ResolversTypes["Address"]>, ParentType, ContextType>;
  profiles?: Resolver<
    Maybe<Array<ResolversTypes["Profile"]>>,
    ParentType,
    ContextType
  >;
  billingInfo?: Resolver<
    Maybe<ResolversTypes["BillingInfo"]>,
    ParentType,
    ContextType
  >;
  payment?: Resolver<
    Maybe<ResolversTypes["PaymentStatus"]>,
    ParentType,
    ContextType
  >;
  onBoardStatus?: Resolver<
    Maybe<ResolversTypes["OnBoardStatus"]>,
    ParentType,
    ContextType
  >;
  socialLinks?: Resolver<
    Maybe<ResolversTypes["SocialLinks"]>,
    ParentType,
    ContextType
  >;
  misc?: Resolver<
    Maybe<ResolversTypes["MiscVendorDetails"]>,
    ParentType,
    ContextType
  >;
  verified?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  poDocumentUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  isEditable?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  underReview?: Resolver<
    Maybe<ResolversTypes["VendorDetailsReview"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorDetailsReviewResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorDetailsReview"] = ResolversParentTypes["VendorDetailsReview"]
> {
  businessName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  document?: Resolver<
    Maybe<ResolversTypes["VendorKYC"]>,
    ParentType,
    ContextType
  >;
  primary?: Resolver<
    Maybe<ResolversTypes["ContactPersonReview"]>,
    ParentType,
    ContextType
  >;
  secondary?: Resolver<
    Maybe<ResolversTypes["ContactPersonReview"]>,
    ParentType,
    ContextType
  >;
  address?: Resolver<Maybe<ResolversTypes["Address"]>, ParentType, ContextType>;
  profiles?: Resolver<
    Maybe<Array<ResolversTypes["Profile"]>>,
    ParentType,
    ContextType
  >;
  billingInfo?: Resolver<
    Maybe<ResolversTypes["BillingInfo"]>,
    ParentType,
    ContextType
  >;
  payment?: Resolver<
    Maybe<ResolversTypes["PaymentStatus"]>,
    ParentType,
    ContextType
  >;
  onBoardStatus?: Resolver<
    Maybe<ResolversTypes["OnBoardStatus"]>,
    ParentType,
    ContextType
  >;
  socialLinks?: Resolver<
    Maybe<ResolversTypes["SocialLinks"]>,
    ParentType,
    ContextType
  >;
  misc?: Resolver<
    Maybe<ResolversTypes["MiscVendorDetails"]>,
    ParentType,
    ContextType
  >;
  verified?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  poDocumentUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorDocumentsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorDocuments"] = ResolversParentTypes["VendorDocuments"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  url?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  comments?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  size?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  docType?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorDocumentTypesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorDocumentTypes"] = ResolversParentTypes["VendorDocumentTypes"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  label?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  numberOfImages?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorKycResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorKYC"] = ResolversParentTypes["VendorKYC"]
> {
  status?: Resolver<ResolversTypes["VendorDocStatus"], ParentType, ContextType>;
  message?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorLeadDebitTransactionResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorLeadDebitTransaction"] = ResolversParentTypes["VendorLeadDebitTransaction"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  standardAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  bonusAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  gstAmount?: Resolver<
    Maybe<ResolversTypes["GstAmount"]>,
    ParentType,
    ContextType
  >;
  gstPercentage?: Resolver<
    Maybe<ResolversTypes["GstPercentage"]>,
    ParentType,
    ContextType
  >;
  leadId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  orderId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  orderDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isOSC?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorLeadFeedbackResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorLeadFeedback"] = ResolversParentTypes["VendorLeadFeedback"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  leadId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  notes?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  disposition?: Resolver<
    ResolversTypes["LeadFeedbackDispositionTypes"],
    ParentType,
    ContextType
  >;
  createdBy?: Resolver<
    ResolversTypes["LeadFeedbackCreatedByType"],
    ParentType,
    ContextType
  >;
  createdAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  followupDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorLeadListPaymentResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorLeadListPayment"] = ResolversParentTypes["VendorLeadListPayment"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  status?: Resolver<
    Maybe<ResolversTypes["VendorPaymentStatus"]>,
    ParentType,
    ContextType
  >;
  tenurePeriod?: Resolver<
    Maybe<ResolversTypes["TenurePeriod"]>,
    ParentType,
    ContextType
  >;
  balanceAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  deliveredAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  totalPaidAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  type?: Resolver<ResolversTypes["VendorPaymentType"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorListingDebitTransactionResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorListingDebitTransaction"] = ResolversParentTypes["VendorListingDebitTransaction"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["TransactionType"], ParentType, ContextType>;
  paymentType?: Resolver<
    ResolversTypes["VendorPaymentType"],
    ParentType,
    ContextType
  >;
  transactionAt?: Resolver<ResolversTypes["DateTime"], ParentType, ContextType>;
  paymentMode?: Resolver<
    Maybe<ResolversTypes["PaymentMode"]>,
    ParentType,
    ContextType
  >;
  transaction?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  actualAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  standardAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  bonusAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  gstAmount?: Resolver<
    Maybe<ResolversTypes["GstAmount"]>,
    ParentType,
    ContextType
  >;
  gstPercentage?: Resolver<
    Maybe<ResolversTypes["GstPercentage"]>,
    ParentType,
    ContextType
  >;
  leadId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  profileSlug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  profileUrl?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tenurePeriod?: Resolver<
    Maybe<ResolversTypes["TenurePeriod"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorLoginResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorLogin"] = ResolversParentTypes["VendorLogin"]
> {
  deviceToken?: Resolver<
    ResolversTypes["String"],
    ParentType,
    ContextType,
    RequireFields<VendorLoginDeviceTokenArgs, "newToken">
  >;
  accessToken?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  step?: Resolver<ResolversTypes["CheckPointList"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorPaymentsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorPayments"] = ResolversParentTypes["VendorPayments"]
> {
  __resolveType: TypeResolveFn<
    "VendorBannerBrandPayment" | "VendorLeadListPayment",
    ParentType,
    ContextType
  >;
}

export interface VendorProfileRoleResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorProfileRole"] = ResolversParentTypes["VendorProfileRole"]
> {
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  state?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  designation?: Resolver<
    Maybe<ResolversTypes["VendorRole"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorValidateResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorValidate"] = ResolversParentTypes["VendorValidate"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  message?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  businessName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  profiles?: Resolver<
    Maybe<Array<ResolversTypes["VendorProfileRole"]>>,
    ParentType,
    ContextType
  >;
  validatedSrc?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorWalletResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorWallet"] = ResolversParentTypes["VendorWallet"]
> {
  overview?: Resolver<
    Maybe<ResolversTypes["WalletOverview"]>,
    ParentType,
    ContextType
  >;
  payments?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["VendorPayments"]>>>,
    ParentType,
    ContextType,
    RequireFields<VendorWalletPaymentsArgs, never>
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorWalletTransactionResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorWalletTransaction"] = ResolversParentTypes["VendorWalletTransaction"]
> {
  __resolveType: TypeResolveFn<
    | "VendorBannerBrandDebitTransaction"
    | "VendorListingDebitTransaction"
    | "VendorLeadDebitTransaction"
    | "VendorBannerCredit"
    | "VendorBrandListingCredit",
    ParentType,
    ContextType
  >;
}

export interface VersionResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Version"] = ResolversParentTypes["Version"]
> {
  latest?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  deprecated?: Resolver<
    Maybe<Array<ResolversTypes["String"]>>,
    ParentType,
    ContextType
  >;
  appstoreUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  playstoreUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface WalletOverviewResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["WalletOverview"] = ResolversParentTypes["WalletOverview"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["VendorWalletType"], ParentType, ContextType>;
  amount?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  bonusAmount?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  bannerBalance?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  brandingBalance?: Resolver<
    Maybe<ResolversTypes["Float"]>,
    ParentType,
    ContextType
  >;
  lastTransactionAt?: Resolver<
    ResolversTypes["DateTime"],
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface Resolvers<ContextType = any> {
  AddLogResponse?: AddLogResponseResolvers<ContextType>;
  Address?: AddressResolvers<ContextType>;
  AddressInfo?: AddressInfoResolvers<ContextType>;
  AttributeHeader?: AttributeHeaderResolvers<ContextType>;
  AttributesByGroup?: AttributesByGroupResolvers<ContextType>;
  AttributeSubHeader?: AttributeSubHeaderResolvers<ContextType>;
  BillingInfo?: BillingInfoResolvers<ContextType>;
  CallCustomer?: CallCustomerResolvers<ContextType>;
  CallInfo?: CallInfoResolvers<ContextType>;
  CallLeads?: CallLeadsResolvers<ContextType>;
  Category?: CategoryResolvers<ContextType>;
  CheckPoint?: CheckPointResolvers<ContextType>;
  City?: CityResolvers<ContextType>;
  ContactPerson?: ContactPersonResolvers<ContextType>;
  ContactPersonReview?: ContactPersonReviewResolvers<ContextType>;
  ContactPhone?: ContactPhoneResolvers<ContextType>;
  CrmCustomer?: CrmCustomerResolvers<ContextType>;
  CrmCustomerDetails?: CrmCustomerDetailsResolvers<ContextType>;
  CRMLeads?: CrmLeadsResolvers<ContextType>;
  Customer?: CustomerResolvers<ContextType>;
  DateTime?: GraphQLScalarType;
  FieldOptions?: FieldOptionsResolvers<ContextType>;
  FieldValidation?: FieldValidationResolvers<ContextType>;
  GstAmount?: GstAmountResolvers<ContextType>;
  GstPercentage?: GstPercentageResolvers<ContextType>;
  ImageTag?: ImageTagResolvers<ContextType>;
  JSON?: GraphQLScalarType;
  LeadEvent?: LeadEventResolvers<ContextType>;
  LeadFeedbackDispositionList?: LeadFeedbackDispositionListResolvers<
    ContextType
  >;
  LeadManagement?: LeadManagementResolvers<ContextType>;
  LeadMeta?: LeadMetaResolvers<ContextType>;
  Leads?: LeadsResolvers<ContextType>;
  Locality?: LocalityResolvers<ContextType>;
  MiscVendorDetails?: MiscVendorDetailsResolvers<ContextType>;
  Mutation?: MutationResolvers<ContextType>;
  NewVendorDetailsMonetary?: NewVendorDetailsMonetaryResolvers<ContextType>;
  NotificationCount?: NotificationCountResolvers<ContextType>;
  NotificationCountByTypes?: NotificationCountByTypesResolvers<ContextType>;
  NotificationFollowupLogsResponse?: NotificationFollowupLogsResponseResolvers<
    ContextType
  >;
  NotificationLogs?: NotificationLogsResolvers<ContextType>;
  OnBoardStatus?: OnBoardStatusResolvers<ContextType>;
  OTPRequestAcknowledge?: OtpRequestAcknowledgeResolvers<ContextType>;
  PaymentStatus?: PaymentStatusResolvers<ContextType>;
  PNTRnotification?: PntRnotificationResolvers<ContextType>;
  Pricing?: PricingResolvers<ContextType>;
  Profile?: ProfileResolvers<ContextType>;
  ProfileAttributeChangeLogs?: ProfileAttributeChangeLogsResolvers<ContextType>;
  ProfileAttributes?: ProfileAttributesResolvers<ContextType>;
  ProfileAttributesDiff?: ProfileAttributesDiffResolvers<ContextType>;
  ProfileGallery?: ProfileGalleryResolvers<ContextType>;
  PurchaseOrder?: PurchaseOrderResolvers<ContextType>;
  PushNotificationLead?: PushNotificationLeadResolvers<ContextType>;
  PushNotificationProfileResult?: PushNotificationProfileResultResolvers<
    ContextType
  >;
  PushNotificationTransactionResult?: PushNotificationTransactionResultResolvers<
    ContextType
  >;
  Query?: QueryResolvers<ContextType>;
  SalesCity?: SalesCityResolvers<ContextType>;
  SalesState?: SalesStateResolvers<ContextType>;
  SocialLinks?: SocialLinksResolvers<ContextType>;
  State?: StateResolvers<ContextType>;
  SubCategory?: SubCategoryResolvers<ContextType>;
  TenurePeriod?: TenurePeriodResolvers<ContextType>;
  TextMessage?: TextMessageResolvers<ContextType>;
  TotalLeads?: TotalLeadsResolvers<ContextType>;
  TransactionCreditInt?: TransactionCreditIntResolvers<ContextType>;
  TransactionDebitInt?: TransactionDebitIntResolvers<ContextType>;
  VendorBannerBrandDebitTransaction?: VendorBannerBrandDebitTransactionResolvers<
    ContextType
  >;
  VendorBannerBrandPayment?: VendorBannerBrandPaymentResolvers<ContextType>;
  VendorBannerCredit?: VendorBannerCreditResolvers<ContextType>;
  VendorBrandListingCredit?: VendorBrandListingCreditResolvers<ContextType>;
  VendorDetails?: VendorDetailsResolvers<ContextType>;
  VendorDetailsReview?: VendorDetailsReviewResolvers<ContextType>;
  VendorDocuments?: VendorDocumentsResolvers<ContextType>;
  VendorDocumentTypes?: VendorDocumentTypesResolvers<ContextType>;
  VendorKYC?: VendorKycResolvers<ContextType>;
  VendorLeadDebitTransaction?: VendorLeadDebitTransactionResolvers<ContextType>;
  VendorLeadFeedback?: VendorLeadFeedbackResolvers<ContextType>;
  VendorLeadListPayment?: VendorLeadListPaymentResolvers<ContextType>;
  VendorListingDebitTransaction?: VendorListingDebitTransactionResolvers<
    ContextType
  >;
  VendorLogin?: VendorLoginResolvers<ContextType>;
  VendorPayments?: VendorPaymentsResolvers<ContextType>;
  VendorProfileRole?: VendorProfileRoleResolvers<ContextType>;
  VendorValidate?: VendorValidateResolvers<ContextType>;
  VendorWallet?: VendorWalletResolvers<ContextType>;
  VendorWalletTransaction?: VendorWalletTransactionResolvers<ContextType>;
  Version?: VersionResolvers<ContextType>;
  WalletOverview?: WalletOverviewResolvers<ContextType>;
}

/**
 * @deprecated
 * Use "Resolvers" root object instead. If you wish to get "IResolvers", add "typesPrefix: I" to your config.
 */
export type IResolvers<ContextType = any> = Resolvers<ContextType>;
