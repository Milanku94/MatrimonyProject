import { GraphQLResolveInfo } from "graphql";
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K];
};
export type RequireFields<T, K extends keyof T> = {
  [X in Exclude<keyof T, K>]?: T[X];
} &
  { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export interface Scalars {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
}

export interface Address {
  id: Scalars["ID"];
  tag?: Maybe<Scalars["String"]>;
  line1?: Maybe<Scalars["String"]>;
  line2?: Maybe<Scalars["String"]>;
  locality?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  pincode?: Maybe<Scalars["String"]>;
  landmark?: Maybe<Scalars["String"]>;
}

export interface AddressInput {
  tag: Scalars["String"];
  line1: Scalars["String"];
  line2: Scalars["String"];
  locality: Scalars["String"];
  city: Scalars["String"];
  pincode: Scalars["String"];
  landmark: Scalars["String"];
}

export interface Basic {
  self?: Maybe<Person>;
  pointOfContact?: Maybe<Person>;
  decisionMaker?: Maybe<Person>;
}

export interface Category {
  /** Todo: rest of category related info come here instead of id */
  categoryId?: Maybe<Scalars["String"]>;
  events?: Maybe<Array<Maybe<Event>>>;
  profiles?: Maybe<Array<Maybe<Profile>>>;
}

export interface CategoryInfo {
  id: Scalars["ID"];
  name: Scalars["String"];
  displayName: Scalars["String"];
}

export interface CityInfo {
  id: Scalars["ID"];
  name: Scalars["String"];
}

export interface Event {
  id: Scalars["ID"];
  categories?: Maybe<Category[]>;
  date?: Maybe<Scalars["String"]>;
  /** Todo: */
  formFields?: Maybe<Scalars["String"]>;
  eventType?: Maybe<Scalars["String"]>;
  address?: Maybe<Address>;
  notes?: Maybe<Scalars["String"]>;
}

export interface EventInfoInput {
  date: Scalars["String"];
  categories?: Maybe<Array<Scalars["String"]>>;
  /** Todo: */
  formFields?: Maybe<Scalars["String"]>;
  eventType: Scalars["String"];
  address: Scalars["String"];
  notes?: Maybe<Scalars["String"]>;
}

export interface EventType {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
}

export interface EventTypeInput {
  name?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
}

export interface Mutation {
  createAddress: Address;
  updateAddress: Address;
  createEvent: Event;
  updateEvent: Event;
  updateServiceByEvent: Event;
  createEventType: EventType;
  updateEventType: EventType;
  createParticipant: Participant;
  createPerson: Person;
  updatePerson: Person;
  createVendorLead: VendorLead;
  updateVendorLead: VendorLead;
}

export interface MutationCreateAddressArgs {
  participantId: Scalars["String"];
  address: AddressInput;
}

export interface MutationUpdateAddressArgs {
  addressId: Scalars["String"];
  address: UpdateAddressInput;
}

export interface MutationCreateEventArgs {
  participantId?: Maybe<Scalars["String"]>;
  eventInfo?: Maybe<EventInfoInput>;
}

export interface MutationUpdateEventArgs {
  eventId: Scalars["String"];
  eventInfo: EventInfoInput;
}

export interface MutationUpdateServiceByEventArgs {
  categories?: Maybe<Array<Scalars["String"]>>;
  eventId?: Maybe<Scalars["String"]>;
}

export interface MutationCreateEventTypeArgs {
  name: Scalars["String"];
  description?: Maybe<Scalars["String"]>;
}

export interface MutationUpdateEventTypeArgs {
  eventTypeId: Scalars["String"];
  eventType: EventTypeInput;
}

export interface MutationCreateParticipantArgs {
  leadId: Scalars["String"];
  participantType: ParticipantType;
  person: PersonInput;
}

export interface MutationCreatePersonArgs {
  participantId: Scalars["String"];
  personInfo: PersonInput;
}

export interface MutationUpdatePersonArgs {
  personId: Scalars["String"];
  personInfo: PersonUpdateInput;
}

export interface MutationCreateVendorLeadArgs {
  rmId?: Maybe<Scalars["String"]>;
  crmId?: Maybe<Scalars["String"]>;
  person: PersonInput;
  participantType: ParticipantType;
}

export interface MutationUpdateVendorLeadArgs {
  id: Scalars["String"];
  managerId?: Maybe<Scalars["String"]>;
  rmId?: Maybe<Scalars["String"]>;
}

export interface Participant {
  id: Scalars["ID"];
  participantType?: Maybe<ParticipantType>;
  basic?: Maybe<Basic>;
  categories?: Maybe<Array<Maybe<Category>>>;
  events?: Maybe<Array<Maybe<Event>>>;
  interactions?: Maybe<Scalars["String"]>;
  addresses?: Maybe<Array<Maybe<Address>>>;
}

export enum ParticipantType {
  Bride = "BRIDE",
  Groom = "GROOM"
}

export interface Person {
  name?: Maybe<Scalars["String"]>;
  mobile?: Maybe<Scalars["Int"]>;
  email?: Maybe<Scalars["String"]>;
  professional?: Maybe<Scalars["String"]>;
  community?: Maybe<Scalars["String"]>;
  relationship?: Maybe<Scalars["String"]>;
}

export interface PersonInput {
  name: Scalars["String"];
  mobile: Scalars["Int"];
  email?: Maybe<Scalars["String"]>;
  relationship: Scalars["String"];
  professional?: Maybe<Scalars["String"]>;
  community?: Maybe<Scalars["String"]>;
  personType: PersonType;
}

export enum PersonType {
  Self = "SELF",
  PointOfContact = "POINT_OF_CONTACT",
  DecisionMaker = "DECISION_MAKER"
}

export interface PersonUpdateInput {
  name?: Maybe<Scalars["String"]>;
  mobile?: Maybe<Scalars["Int"]>;
  email?: Maybe<Scalars["String"]>;
  relationship?: Maybe<Scalars["String"]>;
  professional?: Maybe<Scalars["String"]>;
  community?: Maybe<Scalars["String"]>;
  personType?: Maybe<PersonType>;
}

export interface Profile {
  profileID?: Maybe<Scalars["String"]>;
  vendorName?: Maybe<Scalars["String"]>;
  businessName?: Maybe<Scalars["String"]>;
  profileURL?: Maybe<Scalars["String"]>;
  phoneString?: Maybe<Scalars["String"]>;
  /** Todo */
  leadStatus?: Maybe<Array<Maybe<Scalars["String"]>>>;
  /** Todo */
  quote?: Maybe<Array<Maybe<Scalars["String"]>>>;
  /** note: virtual data */
  shortlisted?: Maybe<Scalars["Boolean"]>;
  finalised?: Maybe<Scalars["Boolean"]>;
  rejected?: Maybe<Scalars["Boolean"]>;
  /** ------------- */
  interactions?: Maybe<Scalars["String"]>;
  notes?: Maybe<Scalars["String"]>;
}

export interface Query {
  hello?: Maybe<Scalars["String"]>;
  addresses?: Maybe<Array<Maybe<Address>>>;
  getAddress?: Maybe<Array<Maybe<Address>>>;
  getCategories?: Maybe<CategoryInfo[]>;
  getCategoryById?: Maybe<CategoryInfo[]>;
  getCities?: Maybe<CityInfo[]>;
  getCityById?: Maybe<CityInfo[]>;
  eventsByCategory?: Maybe<Array<Maybe<Event>>>;
  events?: Maybe<Array<Maybe<Event>>>;
  eventTypes?: Maybe<Array<Maybe<EventType>>>;
  profiles?: Maybe<Array<Maybe<Profile>>>;
  Users?: Maybe<Array<Maybe<User>>>;
  vendorLeads?: Maybe<VendorLead[]>;
}

export interface QueryAddressesArgs {
  participantId: Scalars["String"];
}

export interface QueryGetAddressArgs {
  addressId: Scalars["String"];
}

export interface QueryGetCategoryByIdArgs {
  categoryId: Scalars["ID"];
}

export interface QueryGetCityByIdArgs {
  cityId: Scalars["ID"];
}

export interface QueryEventsByCategoryArgs {
  participantId: Scalars["String"];
  categoryId: Scalars["String"];
}

export interface QueryEventsArgs {
  participantId: Scalars["String"];
}

export interface QueryProfilesArgs {
  id: Scalars["String"];
}

export enum Role {
  Admin = "ADMIN",
  Reviewer = "REVIEWER",
  User = "USER",
  Unknown = "UNKNOWN"
}

export interface UpdateAddressInput {
  tag?: Maybe<Scalars["String"]>;
  line1?: Maybe<Scalars["String"]>;
  line2?: Maybe<Scalars["String"]>;
  locality?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  pincode?: Maybe<Scalars["String"]>;
  landmark?: Maybe<Scalars["String"]>;
}

export interface User {
  name?: Maybe<Scalars["String"]>;
}

export interface VendorLead {
  id: Scalars["ID"];
  managerId?: Maybe<Scalars["String"]>;
  rmId?: Maybe<Scalars["String"]>;
  crmId?: Maybe<Scalars["String"]>;
  districtId?: Maybe<Scalars["String"]>;
  participants?: Maybe<Array<Maybe<Participant>>>;
}

export type ResolverTypeWrapper<T> = Promise<T> | T;

export interface LegacyStitchingResolver<TResult, TParent, TContext, TArgs> {
  fragment: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}

export interface NewStitchingResolver<TResult, TParent, TContext, TArgs> {
  selectionSet: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}
export type StitchingResolver<TResult, TParent, TContext, TArgs> =
  | LegacyStitchingResolver<TResult, TParent, TContext, TArgs>
  | NewStitchingResolver<TResult, TParent, TContext, TArgs>;
export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> =
  | ResolverFn<TResult, TParent, TContext, TArgs>
  | StitchingResolver<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterator<TResult> | Promise<AsyncIterator<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> {
  subscribe: SubscriptionSubscribeFn<
    { [key in TKey]: TResult },
    TParent,
    TContext,
    TArgs
  >;
  resolve?: SubscriptionResolveFn<
    TResult,
    { [key in TKey]: TResult },
    TContext,
    TArgs
  >;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<
  TResult,
  TKey extends string,
  TParent = {},
  TContext = {},
  TArgs = {}
> =
  | ((
      ...args: any[]
    ) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}> = (
  obj: T,
  info: GraphQLResolveInfo
) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<
  TResult = {},
  TParent = {},
  TContext = {},
  TArgs = {}
> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping between all available schema types and the resolvers types */
export interface ResolversTypes {
  Query: ResolverTypeWrapper<{}>;
  String: ResolverTypeWrapper<Scalars["String"]>;
  Address: ResolverTypeWrapper<Address>;
  ID: ResolverTypeWrapper<Scalars["ID"]>;
  CategoryInfo: ResolverTypeWrapper<CategoryInfo>;
  CityInfo: ResolverTypeWrapper<CityInfo>;
  Event: ResolverTypeWrapper<Event>;
  Category: ResolverTypeWrapper<Category>;
  Profile: ResolverTypeWrapper<Profile>;
  Boolean: ResolverTypeWrapper<Scalars["Boolean"]>;
  EventType: ResolverTypeWrapper<EventType>;
  User: ResolverTypeWrapper<User>;
  VendorLead: ResolverTypeWrapper<VendorLead>;
  Participant: ResolverTypeWrapper<Participant>;
  ParticipantType: ParticipantType;
  Basic: ResolverTypeWrapper<Basic>;
  Person: ResolverTypeWrapper<Person>;
  Int: ResolverTypeWrapper<Scalars["Int"]>;
  Mutation: ResolverTypeWrapper<{}>;
  AddressInput: AddressInput;
  UpdateAddressInput: UpdateAddressInput;
  EventInfoInput: EventInfoInput;
  EventTypeInput: EventTypeInput;
  PersonInput: PersonInput;
  PersonType: PersonType;
  PersonUpdateInput: PersonUpdateInput;
  Role: Role;
}

/** Mapping between all available schema types and the resolvers parents */
export interface ResolversParentTypes {
  Query: {};
  String: Scalars["String"];
  Address: Address;
  ID: Scalars["ID"];
  CategoryInfo: CategoryInfo;
  CityInfo: CityInfo;
  Event: Event;
  Category: Category;
  Profile: Profile;
  Boolean: Scalars["Boolean"];
  EventType: EventType;
  User: User;
  VendorLead: VendorLead;
  Participant: Participant;
  Basic: Basic;
  Person: Person;
  Int: Scalars["Int"];
  Mutation: {};
  AddressInput: AddressInput;
  UpdateAddressInput: UpdateAddressInput;
  EventInfoInput: EventInfoInput;
  EventTypeInput: EventTypeInput;
  PersonInput: PersonInput;
  PersonUpdateInput: PersonUpdateInput;
}

export interface AddressResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Address"] = ResolversParentTypes["Address"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  tag?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  line1?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  line2?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  locality?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  pincode?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  landmark?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BasicResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Basic"] = ResolversParentTypes["Basic"]
> {
  self?: Resolver<Maybe<ResolversTypes["Person"]>, ParentType, ContextType>;
  pointOfContact?: Resolver<
    Maybe<ResolversTypes["Person"]>,
    ParentType,
    ContextType
  >;
  decisionMaker?: Resolver<
    Maybe<ResolversTypes["Person"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Category"] = ResolversParentTypes["Category"]
> {
  categoryId?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  events?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Event"]>>>,
    ParentType,
    ContextType
  >;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Profile"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CategoryInfoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CategoryInfo"] = ResolversParentTypes["CategoryInfo"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  displayName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CityInfoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CityInfo"] = ResolversParentTypes["CityInfo"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface EventResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Event"] = ResolversParentTypes["Event"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  categories?: Resolver<
    Maybe<Array<ResolversTypes["Category"]>>,
    ParentType,
    ContextType
  >;
  date?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  formFields?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  eventType?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  address?: Resolver<Maybe<ResolversTypes["Address"]>, ParentType, ContextType>;
  notes?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface EventTypeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["EventType"] = ResolversParentTypes["EventType"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MutationResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Mutation"] = ResolversParentTypes["Mutation"]
> {
  createAddress?: Resolver<
    ResolversTypes["Address"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateAddressArgs, "participantId" | "address">
  >;
  updateAddress?: Resolver<
    ResolversTypes["Address"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateAddressArgs, "addressId" | "address">
  >;
  createEvent?: Resolver<
    ResolversTypes["Event"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateEventArgs, never>
  >;
  updateEvent?: Resolver<
    ResolversTypes["Event"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateEventArgs, "eventId" | "eventInfo">
  >;
  updateServiceByEvent?: Resolver<
    ResolversTypes["Event"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateServiceByEventArgs, never>
  >;
  createEventType?: Resolver<
    ResolversTypes["EventType"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateEventTypeArgs, "name">
  >;
  updateEventType?: Resolver<
    ResolversTypes["EventType"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateEventTypeArgs, "eventTypeId" | "eventType">
  >;
  createParticipant?: Resolver<
    ResolversTypes["Participant"],
    ParentType,
    ContextType,
    RequireFields<
      MutationCreateParticipantArgs,
      "leadId" | "participantType" | "person"
    >
  >;
  createPerson?: Resolver<
    ResolversTypes["Person"],
    ParentType,
    ContextType,
    RequireFields<MutationCreatePersonArgs, "participantId" | "personInfo">
  >;
  updatePerson?: Resolver<
    ResolversTypes["Person"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdatePersonArgs, "personId" | "personInfo">
  >;
  createVendorLead?: Resolver<
    ResolversTypes["VendorLead"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateVendorLeadArgs, "person" | "participantType">
  >;
  updateVendorLead?: Resolver<
    ResolversTypes["VendorLead"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateVendorLeadArgs, "id">
  >;
}

export interface ParticipantResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Participant"] = ResolversParentTypes["Participant"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  participantType?: Resolver<
    Maybe<ResolversTypes["ParticipantType"]>,
    ParentType,
    ContextType
  >;
  basic?: Resolver<Maybe<ResolversTypes["Basic"]>, ParentType, ContextType>;
  categories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  events?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Event"]>>>,
    ParentType,
    ContextType
  >;
  interactions?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  addresses?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Address"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface PersonResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Person"] = ResolversParentTypes["Person"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  mobile?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  email?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  professional?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  community?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  relationship?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Profile"] = ResolversParentTypes["Profile"]
> {
  profileID?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  vendorName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  businessName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  profileURL?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  phoneString?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  leadStatus?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  quote?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  shortlisted?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  finalised?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  rejected?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  interactions?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  notes?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface QueryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Query"] = ResolversParentTypes["Query"]
> {
  hello?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  addresses?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Address"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryAddressesArgs, "participantId">
  >;
  getAddress?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Address"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetAddressArgs, "addressId">
  >;
  getCategories?: Resolver<
    Maybe<Array<ResolversTypes["CategoryInfo"]>>,
    ParentType,
    ContextType
  >;
  getCategoryById?: Resolver<
    Maybe<Array<ResolversTypes["CategoryInfo"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCategoryByIdArgs, "categoryId">
  >;
  getCities?: Resolver<
    Maybe<Array<ResolversTypes["CityInfo"]>>,
    ParentType,
    ContextType
  >;
  getCityById?: Resolver<
    Maybe<Array<ResolversTypes["CityInfo"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCityByIdArgs, "cityId">
  >;
  eventsByCategory?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Event"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryEventsByCategoryArgs, "participantId" | "categoryId">
  >;
  events?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Event"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryEventsArgs, "participantId">
  >;
  eventTypes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["EventType"]>>>,
    ParentType,
    ContextType
  >;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Profile"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryProfilesArgs, "id">
  >;
  Users?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["User"]>>>,
    ParentType,
    ContextType
  >;
  vendorLeads?: Resolver<
    Maybe<Array<ResolversTypes["VendorLead"]>>,
    ParentType,
    ContextType
  >;
}

export interface UserResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["User"] = ResolversParentTypes["User"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface VendorLeadResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["VendorLead"] = ResolversParentTypes["VendorLead"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  managerId?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  rmId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  crmId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  districtId?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  participants?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Participant"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface Resolvers<ContextType = any> {
  Address?: AddressResolvers<ContextType>;
  Basic?: BasicResolvers<ContextType>;
  Category?: CategoryResolvers<ContextType>;
  CategoryInfo?: CategoryInfoResolvers<ContextType>;
  CityInfo?: CityInfoResolvers<ContextType>;
  Event?: EventResolvers<ContextType>;
  EventType?: EventTypeResolvers<ContextType>;
  Mutation?: MutationResolvers<ContextType>;
  Participant?: ParticipantResolvers<ContextType>;
  Person?: PersonResolvers<ContextType>;
  Profile?: ProfileResolvers<ContextType>;
  Query?: QueryResolvers<ContextType>;
  User?: UserResolvers<ContextType>;
  VendorLead?: VendorLeadResolvers<ContextType>;
}

/**
 * @deprecated
 * Use "Resolvers" root object instead. If you wish to get "IResolvers", add "typesPrefix: I" to your config.
 */
export type IResolvers<ContextType = any> = Resolvers<ContextType>;
