import {
  GraphQLResolveInfo,
  GraphQLScalarType,
  GraphQLScalarTypeConfig
} from "graphql";
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = {
  [K in keyof T]: T[K];
};
export type RequireFields<T, K extends keyof T> = {
  [X in Exclude<keyof T, K>]?: T[X];
} &
  { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export interface Scalars {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  /** The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSON: any;
  /** DateTime custom scalar type */
  DateTime: any;
  /** Boolean or enum(radio|checkbox|textbox) */
  DisplayOptionType: any;
}

export interface AttributesInput {
  attributeId?: Maybe<Scalars["String"]>;
  optionIds?: Maybe<Array<Maybe<Scalars["String"]>>>;
  value?: Maybe<Scalars["String"]>;
}

export interface AutoCategoryProfiles {
  id: Scalars["ID"];
  slug: Scalars["ID"];
  needName: Scalars["String"];
  name: Scalars["String"];
  seoCategoryName: Scalars["String"];
  profilesCount: Scalars["Int"];
  profiles?: Maybe<Array<Maybe<AutoSuggestProfile>>>;
}

export interface AutoSuggest {
  categories?: Maybe<Array<Maybe<AutoSuggestCategory>>>;
  categoryProfiles?: Maybe<Array<Maybe<AutoCategoryProfiles>>>;
  attributes?: Maybe<Array<Maybe<AutoSuggestAttribute>>>;
}

export interface AutoSuggestAttribute {
  id: Scalars["ID"];
  attributeId: Scalars["String"];
  categorySlug: Scalars["ID"];
  name: Scalars["String"];
  optionValue: Scalars["String"];
  optionId: Scalars["String"];
  categoryId: Scalars["String"];
  categoryName: Scalars["String"];
  categoryNeedName: Scalars["String"];
  seoCategoryName: Scalars["String"];
}

export interface AutoSuggestCategory {
  id: Scalars["ID"];
  slug: Scalars["ID"];
  needName: Scalars["String"];
  name: Scalars["String"];
  seoCategoryName: Scalars["String"];
}

/** need to revamp */
export interface AutoSuggestProfile {
  id: Scalars["ID"];
  slug: Scalars["String"];
  name: Scalars["String"];
  type: Scalars["String"];
  categoryId: Scalars["String"];
  categoryName: Scalars["String"];
  categoryNeedName: Scalars["String"];
}

export interface Badges {
  id?: Maybe<Scalars["ID"]>;
  name?: Maybe<Scalars["String"]>;
}

export interface Banner {
  city?: Maybe<Scalars["ID"]>;
  category?: Maybe<Scalars["ID"]>;
  image?: Maybe<Media>;
  redirect?: Maybe<Scalars["String"]>;
}

export interface BannerImg {
  mobile?: Maybe<Scalars["String"]>;
  desktop?: Maybe<Scalars["String"]>;
}

export interface BestSeries {
  header?: Maybe<Scalars["String"]>;
  profiles?: Maybe<Array<Maybe<Profile>>>;
}

export interface BlogAccessibility {
  canReview?: Maybe<Scalars["Boolean"]>;
  canEdit?: Maybe<Scalars["Boolean"]>;
  canDelete?: Maybe<Scalars["Boolean"]>;
}

export interface BlogPost extends BlogAccessibility {
  id: Scalars["ID"];
  slug?: Maybe<Scalars["String"]>;
  title?: Maybe<Scalars["String"]>;
  excerpt?: Maybe<Scalars["String"]>;
  heroImage?: Maybe<Scalars["String"]>;
  content?: Maybe<Scalars["JSON"]>;
  metaTitle?: Maybe<Scalars["String"]>;
  metaDescription?: Maybe<Scalars["String"]>;
  metaKeywords?: Maybe<Scalars["String"]>;
  type: BlogType;
  tags?: Maybe<Array<Maybe<BlogTagAdmin>>>;
  editor?: Maybe<Scalars["String"]>;
  author?: Maybe<Scalars["String"]>;
  status?: Maybe<BlogStatus>;
  publishedOn?: Maybe<Scalars["DateTime"]>;
  canReview?: Maybe<Scalars["Boolean"]>;
  canEdit?: Maybe<Scalars["Boolean"]>;
  canDelete?: Maybe<Scalars["Boolean"]>;
}

export interface BlogPostFilterInput {
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
  viewAs?: Maybe<BlogPostView>;
  status?: Maybe<BlogStatus>;
}

export interface BlogPostInput {
  content?: Maybe<Scalars["JSON"]>;
  title?: Maybe<Scalars["String"]>;
  excerpt?: Maybe<Scalars["String"]>;
  metaTitle?: Maybe<Scalars["String"]>;
  metaDescription?: Maybe<Scalars["String"]>;
  metaKeywords?: Maybe<Scalars["String"]>;
  tags?: Maybe<Array<Scalars["String"]>>;
  heroImage?: Maybe<Scalars["String"]>;
}

export enum BlogPostView {
  Author = "AUTHOR",
  Editor = "EDITOR",
  Public = "PUBLIC"
}

export interface Blogs {
  content?: Maybe<Scalars["String"]>;
  similar?: Maybe<Array<Maybe<Blogs>>>;
  meta?: Maybe<MetaDetails>;
  excerpt?: Maybe<Scalars["String"]>;
  image?: Maybe<Media>;
  id: Scalars["ID"];
  name: Scalars["String"];
  publishedOn?: Maybe<Scalars["String"]>;
  slug: Scalars["String"];
  slugId: Scalars["String"];
  tags?: Maybe<Array<Maybe<BlogTag>>>;
  category?: Maybe<Array<Maybe<Category>>>;
}

export interface BlogsCategory {
  id: Scalars["ID"];
  name: Scalars["String"];
  publishedOn?: Maybe<Scalars["String"]>;
  excerpt?: Maybe<Scalars["String"]>;
  slug: Scalars["String"];
  tags?: Maybe<Array<Maybe<BlogTag>>>;
  heroPhoto?: Maybe<HeroPhoto>;
  category?: Maybe<Array<Maybe<Category>>>;
}

export enum BlogStatus {
  Draft = "DRAFT",
  Published = "PUBLISHED",
  Review = "REVIEW",
  Inactive = "INACTIVE"
}

export interface BlogTag {
  id: Scalars["ID"];
  name: Scalars["String"];
  slug?: Maybe<Scalars["String"]>;
  image: Media;
  posts?: Maybe<Array<Maybe<Blogs>>>;
  excerpt: Scalars["String"];
  meta?: Maybe<MetaDetails>;
}

export interface BlogTagAdmin extends BlogAccessibility {
  id: Scalars["ID"];
  slug?: Maybe<Scalars["String"]>;
  name?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
  metaTitle?: Maybe<Scalars["String"]>;
  metaDescription?: Maybe<Scalars["String"]>;
  metaKeywords?: Maybe<Scalars["String"]>;
  status: BlogStatus;
  createdBy: Scalars["String"];
  publishedBy?: Maybe<Scalars["String"]>;
  canReview?: Maybe<Scalars["Boolean"]>;
  canEdit?: Maybe<Scalars["Boolean"]>;
  canDelete?: Maybe<Scalars["Boolean"]>;
}

export interface BlogTagAdminInput {
  name: Scalars["String"];
  description: Scalars["String"];
  metaTitle: Scalars["String"];
  metaDescription: Scalars["String"];
  metaKeywords: Scalars["String"];
}

export interface BlogTagAdminUpdateInput {
  name: Scalars["String"];
  description: Scalars["String"];
  metaTitle: Scalars["String"];
  metaDescription: Scalars["String"];
  metaKeywords: Scalars["String"];
}

export enum BlogType {
  BlogsIdeas = "BLOGS_IDEAS",
  WeddingStories = "WEDDING_STORIES",
  PartnerStories = "PARTNER_STORIES"
}

export interface BlogUser {
  email: Scalars["String"];
  role: UserRole;
  name: Scalars["String"];
  active?: Maybe<Scalars["Boolean"]>;
}

export interface BlogUserLogin {
  token: Scalars["String"];
  user: BlogUser;
}

export interface BranchDetails {
  buildingName?: Maybe<Scalars["String"]>;
  flat?: Maybe<Scalars["String"]>;
  floor?: Maybe<Scalars["String"]>;
  address?: Maybe<Scalars["String"]>;
  streetName?: Maybe<Scalars["String"]>;
  locality?: Maybe<Scalars["String"]>;
  pincode?: Maybe<Scalars["String"]>;
  landmark?: Maybe<Scalars["String"]>;
  latitude?: Maybe<Scalars["String"]>;
  longitude?: Maybe<Scalars["String"]>;
  timings?: Maybe<Scalars["String"]>;
}

export enum CacheControlScope {
  Public = "PUBLIC",
  Private = "PRIVATE"
}

export interface Category {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  displaycategoryname?: Maybe<Scalars["String"]>;
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  needName?: Maybe<Scalars["String"]>;
  attributes?: Maybe<Array<Maybe<FilterAttribute>>>;
  ratingQuestions?: Maybe<Array<Maybe<CategoryQuestion>>>;
  meta: MetaDetails;
  content?: Maybe<Array<Maybe<Content>>>;
}

export interface CategoryQuestion {
  name?: Maybe<Scalars["String"]>;
  label?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
}

export interface City {
  id?: Maybe<Scalars["ID"]>;
  slug: Scalars["String"];
  slugId: Scalars["String"];
  name: Scalars["String"];
  categories?: Maybe<Array<Maybe<Category>>>;
  stateName?: Maybe<Scalars["String"]>;
  stateId?: Maybe<Scalars["ID"]>;
}

export interface Content {
  section?: Maybe<Scalars["String"]>;
  question?: Maybe<Scalars["String"]>;
  answer?: Maybe<Scalars["String"]>;
}

export interface Couple {
  bride?: Maybe<Scalars["String"]>;
  groom?: Maybe<Scalars["String"]>;
}

export interface CustomerFields {
  categoryId: Scalars["ID"];
  cityId: Scalars["ID"];
  email: Scalars["String"];
  enquirySource: Scalars["String"];
  name: Scalars["String"];
  phone: Scalars["String"];
  sourceUrl: Scalars["String"];
  userUniqueId?: Maybe<Scalars["String"]>;
  weddingAssist: Scalars["String"];
  vendorId: Scalars["String"];
}

export interface CustomerId {
  customerId: Scalars["ID"];
}

export interface DisplayAttribute {
  id: Scalars["ID"];
  name: Scalars["String"];
  slug: Scalars["String"];
  values?: Maybe<Array<Maybe<Scalars["String"]>>>;
  forDistribution?: Maybe<Scalars["Boolean"]>;
  forInformation?: Maybe<Scalars["Boolean"]>;
  subtext?: Maybe<Scalars["String"]>;
  header: Scalars["String"];
}

export interface DisplayOptions {
  question?: Maybe<Scalars["String"]>;
  search?: Maybe<Scalars["DisplayOptionType"]>;
  filter?: Maybe<Scalars["DisplayOptionType"]>;
  form?: Maybe<Scalars["DisplayOptionType"]>;
}

export interface FilterAttribute {
  id: Scalars["ID"];
  name: Scalars["String"];
  display?: Maybe<DisplayOptions>;
  options?: Maybe<Array<Maybe<FilterAttributeOptions>>>;
}

export interface FilterAttributeOptions {
  id?: Maybe<Scalars["ID"]>;
  name?: Maybe<Scalars["String"]>;
  isDefault?: Maybe<Scalars["Boolean"]>;
}

export interface HeroPhoto {
  url?: Maybe<Scalars["String"]>;
  isHero?: Maybe<Scalars["Boolean"]>;
  caption?: Maybe<Scalars["String"]>;
  altText?: Maybe<Scalars["String"]>;
}

export interface InquriesAttribute {
  name?: Maybe<Scalars["String"]>;
  selected?: Maybe<Scalars["String"]>;
}

export interface LatestInquries {
  id?: Maybe<Scalars["ID"]>;
  name?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  date?: Maybe<Scalars["DateTime"]>;
  attributes?: Maybe<Array<Maybe<InquriesAttribute>>>;
}

export interface Media {
  altText?: Maybe<Scalars["String"]>;
  caption?: Maybe<Scalars["String"]>;
  isHero?: Maybe<Scalars["Boolean"]>;
  slug: Scalars["String"];
  url: Scalars["String"];
  tags?: Maybe<Array<Maybe<MediaTag>>>;
  thumbnail?: Maybe<Scalars["String"]>;
  meta?: Maybe<MetaDetails>;
  type?: Maybe<Scalars["String"]>;
}

export interface MediaTag {
  id: Scalars["ID"];
  name: Scalars["String"];
}

export interface MetaDetails {
  title: Scalars["String"];
  description?: Maybe<Scalars["String"]>;
  keywords?: Maybe<Scalars["String"]>;
  image?: Maybe<Scalars["String"]>;
}

export interface Mutation {
  createBlogPost: BlogPost;
  updateBlogPost: BlogPost;
  publishBlogPost: BlogPost;
  deleteBlogPost: BlogPost;
  createBlogTag: BlogTagAdmin;
  updateBlogTag: BlogTagAdmin;
  publishBlogTag: BlogTagAdmin;
  deleteBlogTag: BlogTagAdmin;
  blogUserLogin: BlogUserLogin;
  otpVerify?: Maybe<CustomerId>;
  otpRegen?: Maybe<CustomerId>;
  postContact: CustomerId;
  postNeed?: Maybe<CustomerId>;
  createReview: Review;
  addSearchLog: SearchLog;
  createUser: UserAuth;
}

export interface MutationCreateBlogPostArgs {
  type: BlogType;
  post: BlogPostInput;
}

export interface MutationUpdateBlogPostArgs {
  id: Scalars["ID"];
  post: BlogPostInput;
}

export interface MutationPublishBlogPostArgs {
  id: Scalars["ID"];
}

export interface MutationDeleteBlogPostArgs {
  id: Scalars["ID"];
}

export interface MutationCreateBlogTagArgs {
  tag: BlogTagAdminInput;
}

export interface MutationUpdateBlogTagArgs {
  tagId: Scalars["ID"];
  tag?: Maybe<BlogTagAdminUpdateInput>;
}

export interface MutationPublishBlogTagArgs {
  tagId: Scalars["ID"];
}

export interface MutationDeleteBlogTagArgs {
  tagId: Scalars["ID"];
}

export interface MutationBlogUserLoginArgs {
  userId: Scalars["ID"];
  password: Scalars["String"];
}

export interface MutationOtpVerifyArgs {
  customerId: Scalars["String"];
  otp: Scalars["String"];
}

export interface MutationOtpRegenArgs {
  customerId: Scalars["String"];
}

export interface MutationPostContactArgs {
  postData: CustomerFields;
}

export interface MutationPostNeedArgs {
  postData: Needs;
}

export interface MutationCreateReviewArgs {
  userID: Scalars["ID"];
  review: ReviewDetail;
}

export interface MutationAddSearchLogArgs {
  user: SearchLogUserInput;
  search: SearchLogMoreInput;
}

export interface MutationCreateUserArgs {
  name: Scalars["String"];
  email: Scalars["String"];
  profilePicture: Scalars["String"];
  provider: Scalars["String"];
  idByProvider: Scalars["String"];
}

export interface Needs {
  categoryId: Scalars["ID"];
  attributes?: Maybe<Array<Maybe<PostAttribute>>>;
  isDateConfirmed?: Maybe<Scalars["String"]>;
  notes?: Maybe<Scalars["String"]>;
  posted?: Maybe<Scalars["Boolean"]>;
  sourceUrl?: Maybe<Scalars["String"]>;
  cityId: Scalars["ID"];
  customerId: Scalars["String"];
  timeslot: Scalars["String"];
  vendorId: Scalars["String"];
}

export interface OfferImage {
  tile?: Maybe<Scalars["String"]>;
  tc?: Maybe<Scalars["String"]>;
  cover?: Maybe<Scalars["String"]>;
  coverDefault: Scalars["String"];
  tileDefault: Scalars["String"];
}

export interface Offers {
  type: Scalars["String"];
  typeName: Scalars["String"];
  title: Scalars["String"];
  description: Scalars["String"];
  complementaryDesc?: Maybe<Scalars["String"]>;
  flatValue?: Maybe<Scalars["Int"]>;
  percentageValue?: Maybe<Scalars["Int"]>;
  originalPrice?: Maybe<Scalars["Int"]>;
  code?: Maybe<Scalars["String"]>;
  startDate?: Maybe<Scalars["DateTime"]>;
  endDate?: Maybe<Scalars["DateTime"]>;
  url?: Maybe<Scalars["String"]>;
  image?: Maybe<OfferImage>;
}

export enum OffersType {
  Flat = "FLAT",
  Percentage = "PERCENTAGE",
  FlatPercentage = "FLAT_PERCENTAGE",
  SpecialOfferPrice = "SPECIAL_OFFER_PRICE",
  ComplimentaryService = "COMPLIMENTARY_SERVICE"
}

export interface OverAllRating {
  id?: Maybe<Scalars["ID"]>;
  answer?: Maybe<Scalars["Float"]>;
}

export interface PostAttribute {
  attributeId: Scalars["ID"];
  optionId: Array<Scalars["ID"]>;
}

export interface Profile {
  attributes?: Maybe<Array<Maybe<DisplayAttribute>>>;
  badges?: Maybe<Array<Maybe<Badges>>>;
  category?: Maybe<Category>;
  city?: Maybe<Scalars["String"]>;
  heroPhoto?: Maybe<Media>;
  id: Scalars["ID"];
  name: Scalars["String"];
  rating?: Maybe<Scalars["Float"]>;
  ratingCount?: Maybe<Scalars["String"]>;
  reviewCount?: Maybe<Scalars["String"]>;
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  type?: Maybe<Scalars["String"]>;
  gallery?: Maybe<Array<Maybe<Media>>>;
  averageRating?: Maybe<Array<Maybe<ProfileRating>>>;
  specialities?: Maybe<Array<Maybe<Scalars["String"]>>>;
  localities?: Maybe<Array<Maybe<Scalars["String"]>>>;
  aboutUs?: Maybe<Scalars["String"]>;
  virtualNumber?: Maybe<Scalars["String"]>;
  branch?: Maybe<Array<Maybe<BranchDetails>>>;
  canonicalUrl?: Maybe<Scalars["String"]>;
  review?: Maybe<Array<Maybe<Review>>>;
  offers?: Maybe<Offers[]>;
  overallRatings?: Maybe<Array<Maybe<OverAllRating>>>;
  view360?: Maybe<Array<Maybe<View360Details>>>;
}

export interface ProfileInput {
  attributes: Array<Maybe<AttributesInput>>;
  categoryId: Scalars["ID"];
  cityId: Scalars["ID"];
  freeText?: Maybe<Scalars["String"]>;
  isAutoSearch?: Maybe<Scalars["Boolean"]>;
}

export interface ProfileRating {
  id: Scalars["ID"];
  name: Scalars["String"];
  rating?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
}

export interface ProfileReview {
  id: Scalars["ID"];
  name: Scalars["String"];
  reviewer?: Maybe<ProfileReviewer>;
  rating?: Maybe<Array<Maybe<ProfileRating>>>;
  review?: Maybe<Scalars["String"]>;
  event?: Maybe<Scalars["String"]>;
  date?: Maybe<Scalars["String"]>;
  createdOn?: Maybe<Scalars["String"]>;
  publishedOn?: Maybe<Scalars["String"]>;
}

export interface ProfileReviewer {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  profilePhoto?: Maybe<Media>;
}

export interface Query {
  getBannersByCityCategory: Array<Maybe<Banner>>;
  blogPosts?: Maybe<Array<Maybe<BlogPost>>>;
  blogPostCount?: Maybe<Scalars["Int"]>;
  blogPostById?: Maybe<BlogPost>;
  blogPostDraft?: Maybe<BlogPost[]>;
  blogTag?: Maybe<BlogTagAdmin[]>;
  blogTagById: BlogTagAdmin;
  blogUser?: Maybe<Array<Maybe<BlogUser>>>;
  userInfo: BlogUser;
  getBlogs?: Maybe<Blogs[]>;
  getTotalBlogsCount?: Maybe<Scalars["Int"]>;
  getBlogsByID: Blogs;
  getHomeBlogs?: Maybe<Array<Maybe<Blogs>>>;
  getBlogsByCategoryID?: Maybe<Array<Maybe<BlogsCategory>>>;
  getCategories?: Maybe<Array<Maybe<Category>>>;
  getCategoriesByID?: Maybe<Category>;
  getCategoriesBySlug?: Maybe<Category>;
  getCities?: Maybe<City[]>;
  getPopularCities?: Maybe<City[]>;
  getCitiesByID?: Maybe<City>;
  getCitiesBySlug?: Maybe<City>;
  getLatestInquries?: Maybe<LatestInquries[]>;
  generateInquiries?: Maybe<Scalars["Boolean"]>;
  Media?: Maybe<Array<Maybe<Media>>>;
  MetaDetails?: Maybe<Array<Maybe<MetaDetails>>>;
  decryptWhatsappUrl: WhatsappUrlInfo;
  getProfiles?: Maybe<Profile[]>;
  getTotalProfilesCount?: Maybe<Scalars["Int"]>;
  getProfilesByID?: Maybe<Profile>;
  topProfilesByCity?: Maybe<Array<Maybe<TopProfilesByCity>>>;
  getProfilesByCity?: Maybe<Array<Maybe<TopProfilesByCity>>>;
  profileBestSeries?: Maybe<BestSeries>;
  similarProfiles?: Maybe<Profile[]>;
  ProfileRating?: Maybe<Array<Maybe<ProfileRating>>>;
  getRatingQuestionsForCategory: Array<Maybe<RatingQuestions>>;
  reviewByProfile?: Maybe<Review[]>;
  search?: Maybe<Search>;
  autoSuggest?: Maybe<AutoSuggest>;
  getSEM?: Maybe<Sem[]>;
  getSEMByCityCategory: Sem;
  seoMeta: SeoMeta;
  getWeddingStories?: Maybe<Array<Maybe<WeddingStory>>>;
  getTotalWeddingCount?: Maybe<Scalars["Int"]>;
  getWeddingStoriesByID?: Maybe<WeddingStory>;
}

export interface QueryGetBannersByCityCategoryArgs {
  category: Scalars["String"];
  city: Scalars["String"];
}

export interface QueryBlogPostsArgs {
  type: BlogType;
  filter?: Maybe<BlogPostFilterInput>;
}

export interface QueryBlogPostCountArgs {
  type: BlogType;
  viewAs?: Maybe<BlogPostView>;
  status?: Maybe<BlogStatus>;
}

export interface QueryBlogPostByIdArgs {
  blogPostId: Scalars["ID"];
}

export interface QueryBlogPostDraftArgs {
  type: BlogType;
}

export interface QueryBlogTagArgs {
  status?: Maybe<BlogStatus>;
  viewAs?: Maybe<BlogPostView>;
}

export interface QueryBlogTagByIdArgs {
  blogTagId: Scalars["ID"];
}

export interface QueryGetBlogsArgs {
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
}

export interface QueryGetBlogsByIdArgs {
  blogID?: Maybe<Scalars["Int"]>;
}

export interface QueryGetHomeBlogsArgs {
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
}

export interface QueryGetBlogsByCategoryIdArgs {
  categoryId?: Maybe<Scalars["Int"]>;
}

export interface QueryGetCategoriesByIdArgs {
  categoryID: Scalars["ID"];
}

export interface QueryGetCategoriesBySlugArgs {
  slug: Scalars["String"];
}

export interface QueryGetCitiesByIdArgs {
  cityId: Scalars["ID"];
}

export interface QueryGetCitiesBySlugArgs {
  slug: Scalars["String"];
}

export interface QueryGetLatestInquriesArgs {
  category: Scalars["String"];
  city: Scalars["String"];
}

export interface QueryDecryptWhatsappUrlArgs {
  urlId: Scalars["ID"];
}

export interface QueryGetProfilesArgs {
  postData: ProfileInput;
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
}

export interface QueryGetTotalProfilesCountArgs {
  postData: ProfileInput;
}

export interface QueryGetProfilesByIdArgs {
  profileID: Scalars["String"];
}

export interface QueryTopProfilesByCityArgs {
  cityId: Scalars["ID"];
}

export interface QueryGetProfilesByCityArgs {
  cityId: Scalars["ID"];
}

export interface QueryProfileBestSeriesArgs {
  url: Scalars["String"];
}

export interface QuerySimilarProfilesArgs {
  postData: SimilarProfileInput;
}

export interface QueryGetRatingQuestionsForCategoryArgs {
  slug: Scalars["String"];
}

export interface QueryReviewByProfileArgs {
  profileId: Scalars["ID"];
}

export interface QuerySearchArgs {
  postData: SearchInput;
}

export interface QueryAutoSuggestArgs {
  postData: SearchInput;
}

export interface QueryGetSemByCityCategoryArgs {
  city: Scalars["String"];
  category: Scalars["String"];
}

export interface QuerySeoMetaArgs {
  url: Scalars["String"];
}

export interface QueryGetWeddingStoriesArgs {
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
}

export interface QueryGetWeddingStoriesByIdArgs {
  id: Scalars["ID"];
}

export interface RatingQuestions {
  name: Scalars["String"];
  label: Scalars["String"];
  description: Scalars["String"];
}

export interface Ratings {
  id?: Maybe<Scalars["String"]>;
  answer?: Maybe<Scalars["Boolean"]>;
}

export interface RatingsInput {
  id?: Maybe<Scalars["String"]>;
  answer?: Maybe<Scalars["Boolean"]>;
}

export interface Review {
  _id: Scalars["ID"];
  user?: Maybe<UserAuth>;
  profileID?: Maybe<Scalars["ID"]>;
  vendorID?: Maybe<Scalars["ID"]>;
  ratings?: Maybe<Array<Maybe<Ratings>>>;
  overall?: Maybe<Scalars["Int"]>;
  review?: Maybe<Scalars["String"]>;
  publishedOn?: Maybe<Scalars["String"]>;
  createdAt?: Maybe<Scalars["String"]>;
  updatedAt?: Maybe<Scalars["String"]>;
}

export interface ReviewDetail {
  profileID: Scalars["String"];
  ratings: RatingsInput[];
  review: Scalars["String"];
  overall: Scalars["Int"];
}

export enum Role {
  Author = "AUTHOR",
  Editor = "EDITOR",
  Admin = "ADMIN"
}

export interface Search {
  categories?: Maybe<Array<Maybe<Category>>>;
  profiles?: Maybe<Array<Maybe<Profile>>>;
}

export interface SearchInput {
  freeText?: Maybe<Scalars["String"]>;
  cityId: Scalars["ID"];
}

export interface SearchLog {
  uuid: Scalars["String"];
  userId?: Maybe<Scalars["String"]>;
  type: Scalars["String"];
}

export interface SearchLogMoreInput {
  type?: Maybe<Scalars["String"]>;
  keyword: Scalars["String"];
  section?: Maybe<Scalars["String"]>;
  position?: Maybe<Scalars["Int"]>;
  targetUrl?: Maybe<Scalars["String"]>;
  currentUrl?: Maybe<Scalars["String"]>;
}

export interface SearchLogUserInput {
  uuid: Scalars["String"];
  userId?: Maybe<Scalars["String"]>;
  city: Scalars["String"];
}

export interface Sem {
  bannerImage: BannerImg;
  bannerQuestion: Scalars["String"];
  category: Scalars["String"];
  city: Scalars["String"];
  footerQuestion?: Maybe<Scalars["String"]>;
  title: Scalars["String"];
  subtitle: Scalars["String"];
}

export interface SeoMeta {
  title: Scalars["String"];
  metaTitle: Scalars["String"];
  description: Scalars["String"];
  keywords?: Maybe<Array<Scalars["String"]>>;
}

export interface SimilarProfileInput {
  profileID: Scalars["String"];
}

export interface TopProfilesByCity {
  categoryId: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  needName?: Maybe<Scalars["String"]>;
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  profiles?: Maybe<Array<Maybe<Profile>>>;
}

export interface UserAuth {
  _id: Scalars["ID"];
  name: Scalars["String"];
  email: Scalars["String"];
  phone?: Maybe<Scalars["Int"]>;
  profilePicture: Media;
  customerID?: Maybe<Scalars["ID"]>;
  createdAt?: Maybe<Scalars["String"]>;
  updatedAt?: Maybe<Scalars["String"]>;
}

export enum UserRole {
  Author = "AUTHOR",
  Editor = "EDITOR",
  Admin = "ADMIN"
}

export interface View360Details {
  locality?: Maybe<Scalars["String"]>;
  title?: Maybe<Scalars["String"]>;
  embedCode?: Maybe<Scalars["String"]>;
  embedUrl?: Maybe<Scalars["String"]>;
}

export interface WeddingStory {
  id: Scalars["ID"];
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  name: Scalars["String"];
  city?: Maybe<Scalars["String"]>;
  couple: Couple;
  excerpt?: Maybe<Scalars["String"]>;
  heroPhoto: Media;
  categories?: Maybe<Array<Maybe<Category>>>;
  gallery?: Maybe<Media[]>;
  profiles?: Maybe<Array<Maybe<WeddingStoryProfiles>>>;
  meta?: Maybe<MetaDetails>;
}

export interface WeddingStoryComment {
  customerStory?: Maybe<Scalars["String"]>;
  profileStory?: Maybe<Scalars["String"]>;
}

export interface WeddingStoryProfiles {
  id: Scalars["ID"];
  slug: Scalars["String"];
  slugId: Scalars["String"];
  name: Scalars["String"];
  category?: Maybe<Category>;
  comments?: Maybe<WeddingStoryComment>;
  profilePhoto?: Maybe<Media>;
}

export interface WhatsappUrlInfo {
  vendorId: Scalars["ID"];
  vendorType: Scalars["Int"];
  mobileNumber: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  email?: Maybe<Scalars["String"]>;
}

export type ResolverTypeWrapper<T> = Promise<T> | T;

export interface LegacyStitchingResolver<TResult, TParent, TContext, TArgs> {
  fragment: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}

export interface NewStitchingResolver<TResult, TParent, TContext, TArgs> {
  selectionSet: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}
export type StitchingResolver<TResult, TParent, TContext, TArgs> =
  | LegacyStitchingResolver<TResult, TParent, TContext, TArgs>
  | NewStitchingResolver<TResult, TParent, TContext, TArgs>;
export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> =
  | ResolverFn<TResult, TParent, TContext, TArgs>
  | StitchingResolver<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterator<TResult> | Promise<AsyncIterator<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> {
  subscribe: SubscriptionSubscribeFn<
    { [key in TKey]: TResult },
    TParent,
    TContext,
    TArgs
  >;
  resolve?: SubscriptionResolveFn<
    TResult,
    { [key in TKey]: TResult },
    TContext,
    TArgs
  >;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<
  TResult,
  TKey extends string,
  TParent = {},
  TContext = {},
  TArgs = {}
> =
  | ((
      ...args: any[]
    ) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}> = (
  obj: T,
  info: GraphQLResolveInfo
) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<
  TResult = {},
  TParent = {},
  TContext = {},
  TArgs = {}
> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping between all available schema types and the resolvers types */
export interface ResolversTypes {
  Query: ResolverTypeWrapper<{}>;
  String: ResolverTypeWrapper<Scalars["String"]>;
  Banner: ResolverTypeWrapper<Banner>;
  ID: ResolverTypeWrapper<Scalars["ID"]>;
  Media: ResolverTypeWrapper<Media>;
  Boolean: ResolverTypeWrapper<Scalars["Boolean"]>;
  MediaTag: ResolverTypeWrapper<MediaTag>;
  MetaDetails: ResolverTypeWrapper<MetaDetails>;
  BlogType: BlogType;
  BlogPostFilterInput: BlogPostFilterInput;
  Int: ResolverTypeWrapper<Scalars["Int"]>;
  BlogPostView: BlogPostView;
  BlogStatus: BlogStatus;
  BlogPost: ResolverTypeWrapper<BlogPost>;
  BlogAccessibility:
    | ResolversTypes["BlogPost"]
    | ResolversTypes["BlogTagAdmin"];
  JSON: ResolverTypeWrapper<Scalars["JSON"]>;
  BlogTagAdmin: ResolverTypeWrapper<BlogTagAdmin>;
  DateTime: ResolverTypeWrapper<Scalars["DateTime"]>;
  BlogUser: ResolverTypeWrapper<BlogUser>;
  UserRole: UserRole;
  Blogs: ResolverTypeWrapper<Blogs>;
  BlogTag: ResolverTypeWrapper<BlogTag>;
  Category: ResolverTypeWrapper<Category>;
  FilterAttribute: ResolverTypeWrapper<FilterAttribute>;
  DisplayOptions: ResolverTypeWrapper<DisplayOptions>;
  DisplayOptionType: ResolverTypeWrapper<Scalars["DisplayOptionType"]>;
  FilterAttributeOptions: ResolverTypeWrapper<FilterAttributeOptions>;
  CategoryQuestion: ResolverTypeWrapper<CategoryQuestion>;
  Content: ResolverTypeWrapper<Content>;
  BlogsCategory: ResolverTypeWrapper<BlogsCategory>;
  HeroPhoto: ResolverTypeWrapper<HeroPhoto>;
  City: ResolverTypeWrapper<City>;
  LatestInquries: ResolverTypeWrapper<LatestInquries>;
  InquriesAttribute: ResolverTypeWrapper<InquriesAttribute>;
  WhatsappUrlInfo: ResolverTypeWrapper<WhatsappUrlInfo>;
  ProfileInput: ProfileInput;
  AttributesInput: AttributesInput;
  Profile: ResolverTypeWrapper<Profile>;
  DisplayAttribute: ResolverTypeWrapper<DisplayAttribute>;
  Badges: ResolverTypeWrapper<Badges>;
  Float: ResolverTypeWrapper<Scalars["Float"]>;
  ProfileRating: ResolverTypeWrapper<ProfileRating>;
  BranchDetails: ResolverTypeWrapper<BranchDetails>;
  Review: ResolverTypeWrapper<Review>;
  UserAuth: ResolverTypeWrapper<UserAuth>;
  Ratings: ResolverTypeWrapper<Ratings>;
  Offers: ResolverTypeWrapper<Offers>;
  OfferImage: ResolverTypeWrapper<OfferImage>;
  OverAllRating: ResolverTypeWrapper<OverAllRating>;
  View360Details: ResolverTypeWrapper<View360Details>;
  TopProfilesByCity: ResolverTypeWrapper<TopProfilesByCity>;
  BestSeries: ResolverTypeWrapper<BestSeries>;
  SimilarProfileInput: SimilarProfileInput;
  RatingQuestions: ResolverTypeWrapper<RatingQuestions>;
  SearchInput: SearchInput;
  Search: ResolverTypeWrapper<Search>;
  AutoSuggest: ResolverTypeWrapper<AutoSuggest>;
  AutoSuggestCategory: ResolverTypeWrapper<AutoSuggestCategory>;
  AutoCategoryProfiles: ResolverTypeWrapper<AutoCategoryProfiles>;
  AutoSuggestProfile: ResolverTypeWrapper<AutoSuggestProfile>;
  AutoSuggestAttribute: ResolverTypeWrapper<AutoSuggestAttribute>;
  Sem: ResolverTypeWrapper<Sem>;
  BannerImg: ResolverTypeWrapper<BannerImg>;
  SeoMeta: ResolverTypeWrapper<SeoMeta>;
  WeddingStory: ResolverTypeWrapper<WeddingStory>;
  Couple: ResolverTypeWrapper<Couple>;
  WeddingStoryProfiles: ResolverTypeWrapper<WeddingStoryProfiles>;
  WeddingStoryComment: ResolverTypeWrapper<WeddingStoryComment>;
  Mutation: ResolverTypeWrapper<{}>;
  BlogPostInput: BlogPostInput;
  BlogTagAdminInput: BlogTagAdminInput;
  BlogTagAdminUpdateInput: BlogTagAdminUpdateInput;
  BlogUserLogin: ResolverTypeWrapper<BlogUserLogin>;
  CustomerID: ResolverTypeWrapper<CustomerId>;
  CustomerFields: CustomerFields;
  Needs: Needs;
  PostAttribute: PostAttribute;
  ReviewDetail: ReviewDetail;
  RatingsInput: RatingsInput;
  SearchLogUserInput: SearchLogUserInput;
  SearchLogMoreInput: SearchLogMoreInput;
  SearchLog: ResolverTypeWrapper<SearchLog>;
  CacheControlScope: CacheControlScope;
  Role: Role;
  OffersType: OffersType;
  ProfileReview: ResolverTypeWrapper<ProfileReview>;
  ProfileReviewer: ResolverTypeWrapper<ProfileReviewer>;
}

/** Mapping between all available schema types and the resolvers parents */
export interface ResolversParentTypes {
  Query: {};
  String: Scalars["String"];
  Banner: Banner;
  ID: Scalars["ID"];
  Media: Media;
  Boolean: Scalars["Boolean"];
  MediaTag: MediaTag;
  MetaDetails: MetaDetails;
  BlogPostFilterInput: BlogPostFilterInput;
  Int: Scalars["Int"];
  BlogPost: BlogPost;
  BlogAccessibility:
    | ResolversParentTypes["BlogPost"]
    | ResolversParentTypes["BlogTagAdmin"];
  JSON: Scalars["JSON"];
  BlogTagAdmin: BlogTagAdmin;
  DateTime: Scalars["DateTime"];
  BlogUser: BlogUser;
  Blogs: Blogs;
  BlogTag: BlogTag;
  Category: Category;
  FilterAttribute: FilterAttribute;
  DisplayOptions: DisplayOptions;
  DisplayOptionType: Scalars["DisplayOptionType"];
  FilterAttributeOptions: FilterAttributeOptions;
  CategoryQuestion: CategoryQuestion;
  Content: Content;
  BlogsCategory: BlogsCategory;
  HeroPhoto: HeroPhoto;
  City: City;
  LatestInquries: LatestInquries;
  InquriesAttribute: InquriesAttribute;
  WhatsappUrlInfo: WhatsappUrlInfo;
  ProfileInput: ProfileInput;
  AttributesInput: AttributesInput;
  Profile: Profile;
  DisplayAttribute: DisplayAttribute;
  Badges: Badges;
  Float: Scalars["Float"];
  ProfileRating: ProfileRating;
  BranchDetails: BranchDetails;
  Review: Review;
  UserAuth: UserAuth;
  Ratings: Ratings;
  Offers: Offers;
  OfferImage: OfferImage;
  OverAllRating: OverAllRating;
  View360Details: View360Details;
  TopProfilesByCity: TopProfilesByCity;
  BestSeries: BestSeries;
  SimilarProfileInput: SimilarProfileInput;
  RatingQuestions: RatingQuestions;
  SearchInput: SearchInput;
  Search: Search;
  AutoSuggest: AutoSuggest;
  AutoSuggestCategory: AutoSuggestCategory;
  AutoCategoryProfiles: AutoCategoryProfiles;
  AutoSuggestProfile: AutoSuggestProfile;
  AutoSuggestAttribute: AutoSuggestAttribute;
  Sem: Sem;
  BannerImg: BannerImg;
  SeoMeta: SeoMeta;
  WeddingStory: WeddingStory;
  Couple: Couple;
  WeddingStoryProfiles: WeddingStoryProfiles;
  WeddingStoryComment: WeddingStoryComment;
  Mutation: {};
  BlogPostInput: BlogPostInput;
  BlogTagAdminInput: BlogTagAdminInput;
  BlogTagAdminUpdateInput: BlogTagAdminUpdateInput;
  BlogUserLogin: BlogUserLogin;
  CustomerID: CustomerId;
  CustomerFields: CustomerFields;
  Needs: Needs;
  PostAttribute: PostAttribute;
  ReviewDetail: ReviewDetail;
  RatingsInput: RatingsInput;
  SearchLogUserInput: SearchLogUserInput;
  SearchLogMoreInput: SearchLogMoreInput;
  SearchLog: SearchLog;
  ProfileReview: ProfileReview;
  ProfileReviewer: ProfileReviewer;
}

export interface AutoCategoryProfilesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AutoCategoryProfiles"] = ResolversParentTypes["AutoCategoryProfiles"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  needName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  seoCategoryName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  profilesCount?: Resolver<ResolversTypes["Int"], ParentType, ContextType>;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["AutoSuggestProfile"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AutoSuggestResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AutoSuggest"] = ResolversParentTypes["AutoSuggest"]
> {
  categories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["AutoSuggestCategory"]>>>,
    ParentType,
    ContextType
  >;
  categoryProfiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["AutoCategoryProfiles"]>>>,
    ParentType,
    ContextType
  >;
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["AutoSuggestAttribute"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AutoSuggestAttributeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AutoSuggestAttribute"] = ResolversParentTypes["AutoSuggestAttribute"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  attributeId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categorySlug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  optionValue?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  optionId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categoryId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categoryName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categoryNeedName?: Resolver<
    ResolversTypes["String"],
    ParentType,
    ContextType
  >;
  seoCategoryName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AutoSuggestCategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AutoSuggestCategory"] = ResolversParentTypes["AutoSuggestCategory"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  needName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  seoCategoryName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface AutoSuggestProfileResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["AutoSuggestProfile"] = ResolversParentTypes["AutoSuggestProfile"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  type?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categoryId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categoryName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categoryNeedName?: Resolver<
    ResolversTypes["String"],
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BadgesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Badges"] = ResolversParentTypes["Badges"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BannerResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Banner"] = ResolversParentTypes["Banner"]
> {
  city?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes["Media"]>, ParentType, ContextType>;
  redirect?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BannerImgResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BannerImg"] = ResolversParentTypes["BannerImg"]
> {
  mobile?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  desktop?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BestSeriesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BestSeries"] = ResolversParentTypes["BestSeries"]
> {
  header?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Profile"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogAccessibilityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogAccessibility"] = ResolversParentTypes["BlogAccessibility"]
> {
  __resolveType: TypeResolveFn<
    "BlogPost" | "BlogTagAdmin",
    ParentType,
    ContextType
  >;
  canReview?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  canEdit?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  canDelete?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
}

export interface BlogPostResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogPost"] = ResolversParentTypes["BlogPost"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  excerpt?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  heroImage?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  content?: Resolver<Maybe<ResolversTypes["JSON"]>, ParentType, ContextType>;
  metaTitle?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  metaDescription?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  metaKeywords?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  type?: Resolver<ResolversTypes["BlogType"], ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogTagAdmin"]>>>,
    ParentType,
    ContextType
  >;
  editor?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  author?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  status?: Resolver<
    Maybe<ResolversTypes["BlogStatus"]>,
    ParentType,
    ContextType
  >;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  canReview?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  canEdit?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  canDelete?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Blogs"] = ResolversParentTypes["Blogs"]
> {
  content?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  similar?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Blogs"]>>>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
  excerpt?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes["Media"]>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  slugId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogTag"]>>>,
    ParentType,
    ContextType
  >;
  category?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogsCategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogsCategory"] = ResolversParentTypes["BlogsCategory"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  excerpt?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogTag"]>>>,
    ParentType,
    ContextType
  >;
  heroPhoto?: Resolver<
    Maybe<ResolversTypes["HeroPhoto"]>,
    ParentType,
    ContextType
  >;
  category?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogTagResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogTag"] = ResolversParentTypes["BlogTag"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  image?: Resolver<ResolversTypes["Media"], ParentType, ContextType>;
  posts?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Blogs"]>>>,
    ParentType,
    ContextType
  >;
  excerpt?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogTagAdminResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogTagAdmin"] = ResolversParentTypes["BlogTagAdmin"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  metaTitle?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  metaDescription?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  metaKeywords?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  status?: Resolver<ResolversTypes["BlogStatus"], ParentType, ContextType>;
  createdBy?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  publishedBy?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  canReview?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  canEdit?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  canDelete?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogUserResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogUser"] = ResolversParentTypes["BlogUser"]
> {
  email?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  role?: Resolver<ResolversTypes["UserRole"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  active?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BlogUserLoginResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogUserLogin"] = ResolversParentTypes["BlogUserLogin"]
> {
  token?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  user?: Resolver<ResolversTypes["BlogUser"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface BranchDetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BranchDetails"] = ResolversParentTypes["BranchDetails"]
> {
  buildingName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  flat?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  floor?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  address?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  streetName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  locality?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  pincode?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  landmark?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  latitude?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  longitude?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  timings?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Category"] = ResolversParentTypes["Category"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  displaycategoryname?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  needName?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["FilterAttribute"]>>>,
    ParentType,
    ContextType
  >;
  ratingQuestions?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["CategoryQuestion"]>>>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<ResolversTypes["MetaDetails"], ParentType, ContextType>;
  content?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Content"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CategoryQuestionResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CategoryQuestion"] = ResolversParentTypes["CategoryQuestion"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  label?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["City"] = ResolversParentTypes["City"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  slugId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  categories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  stateName?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  stateId?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ContentResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Content"] = ResolversParentTypes["Content"]
> {
  section?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  question?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  answer?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CoupleResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Couple"] = ResolversParentTypes["Couple"]
> {
  bride?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  groom?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface CustomerIdResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CustomerID"] = ResolversParentTypes["CustomerID"]
> {
  customerId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface DateTimeScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["DateTime"], any> {
  name: "DateTime";
}

export interface DisplayAttributeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["DisplayAttribute"] = ResolversParentTypes["DisplayAttribute"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  values?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  forDistribution?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  forInformation?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  subtext?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  header?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface DisplayOptionsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["DisplayOptions"] = ResolversParentTypes["DisplayOptions"]
> {
  question?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  search?: Resolver<
    Maybe<ResolversTypes["DisplayOptionType"]>,
    ParentType,
    ContextType
  >;
  filter?: Resolver<
    Maybe<ResolversTypes["DisplayOptionType"]>,
    ParentType,
    ContextType
  >;
  form?: Resolver<
    Maybe<ResolversTypes["DisplayOptionType"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface DisplayOptionTypeScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["DisplayOptionType"], any> {
  name: "DisplayOptionType";
}

export interface FilterAttributeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["FilterAttribute"] = ResolversParentTypes["FilterAttribute"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  display?: Resolver<
    Maybe<ResolversTypes["DisplayOptions"]>,
    ParentType,
    ContextType
  >;
  options?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["FilterAttributeOptions"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface FilterAttributeOptionsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["FilterAttributeOptions"] = ResolversParentTypes["FilterAttributeOptions"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isDefault?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface HeroPhotoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["HeroPhoto"] = ResolversParentTypes["HeroPhoto"]
> {
  url?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isHero?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  caption?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  altText?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface InquriesAttributeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["InquriesAttribute"] = ResolversParentTypes["InquriesAttribute"]
> {
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  selected?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface JsonScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["JSON"], any> {
  name: "JSON";
}

export interface LatestInquriesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["LatestInquries"] = ResolversParentTypes["LatestInquries"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  date?: Resolver<Maybe<ResolversTypes["DateTime"]>, ParentType, ContextType>;
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["InquriesAttribute"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MediaResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Media"] = ResolversParentTypes["Media"]
> {
  altText?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  caption?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isHero?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  url?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["MediaTag"]>>>,
    ParentType,
    ContextType
  >;
  thumbnail?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
  type?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MediaTagResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["MediaTag"] = ResolversParentTypes["MediaTag"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MetaDetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["MetaDetails"] = ResolversParentTypes["MetaDetails"]
> {
  title?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  keywords?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface MutationResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Mutation"] = ResolversParentTypes["Mutation"]
> {
  createBlogPost?: Resolver<
    ResolversTypes["BlogPost"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateBlogPostArgs, "type" | "post">
  >;
  updateBlogPost?: Resolver<
    ResolversTypes["BlogPost"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateBlogPostArgs, "id" | "post">
  >;
  publishBlogPost?: Resolver<
    ResolversTypes["BlogPost"],
    ParentType,
    ContextType,
    RequireFields<MutationPublishBlogPostArgs, "id">
  >;
  deleteBlogPost?: Resolver<
    ResolversTypes["BlogPost"],
    ParentType,
    ContextType,
    RequireFields<MutationDeleteBlogPostArgs, "id">
  >;
  createBlogTag?: Resolver<
    ResolversTypes["BlogTagAdmin"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateBlogTagArgs, "tag">
  >;
  updateBlogTag?: Resolver<
    ResolversTypes["BlogTagAdmin"],
    ParentType,
    ContextType,
    RequireFields<MutationUpdateBlogTagArgs, "tagId">
  >;
  publishBlogTag?: Resolver<
    ResolversTypes["BlogTagAdmin"],
    ParentType,
    ContextType,
    RequireFields<MutationPublishBlogTagArgs, "tagId">
  >;
  deleteBlogTag?: Resolver<
    ResolversTypes["BlogTagAdmin"],
    ParentType,
    ContextType,
    RequireFields<MutationDeleteBlogTagArgs, "tagId">
  >;
  blogUserLogin?: Resolver<
    ResolversTypes["BlogUserLogin"],
    ParentType,
    ContextType,
    RequireFields<MutationBlogUserLoginArgs, "userId" | "password">
  >;
  otpVerify?: Resolver<
    Maybe<ResolversTypes["CustomerID"]>,
    ParentType,
    ContextType,
    RequireFields<MutationOtpVerifyArgs, "customerId" | "otp">
  >;
  otpRegen?: Resolver<
    Maybe<ResolversTypes["CustomerID"]>,
    ParentType,
    ContextType,
    RequireFields<MutationOtpRegenArgs, "customerId">
  >;
  postContact?: Resolver<
    ResolversTypes["CustomerID"],
    ParentType,
    ContextType,
    RequireFields<MutationPostContactArgs, "postData">
  >;
  postNeed?: Resolver<
    Maybe<ResolversTypes["CustomerID"]>,
    ParentType,
    ContextType,
    RequireFields<MutationPostNeedArgs, "postData">
  >;
  createReview?: Resolver<
    ResolversTypes["Review"],
    ParentType,
    ContextType,
    RequireFields<MutationCreateReviewArgs, "userID" | "review">
  >;
  addSearchLog?: Resolver<
    ResolversTypes["SearchLog"],
    ParentType,
    ContextType,
    RequireFields<MutationAddSearchLogArgs, "user" | "search">
  >;
  createUser?: Resolver<
    ResolversTypes["UserAuth"],
    ParentType,
    ContextType,
    RequireFields<
      MutationCreateUserArgs,
      "name" | "email" | "profilePicture" | "provider" | "idByProvider"
    >
  >;
}

export interface OfferImageResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["OfferImage"] = ResolversParentTypes["OfferImage"]
> {
  tile?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  tc?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  cover?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  coverDefault?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tileDefault?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface OffersResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Offers"] = ResolversParentTypes["Offers"]
> {
  type?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  typeName?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  title?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  description?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  complementaryDesc?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  flatValue?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  percentageValue?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  originalPrice?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  code?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  startDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  endDate?: Resolver<
    Maybe<ResolversTypes["DateTime"]>,
    ParentType,
    ContextType
  >;
  url?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  image?: Resolver<
    Maybe<ResolversTypes["OfferImage"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface OverAllRatingResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["OverAllRating"] = ResolversParentTypes["OverAllRating"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  answer?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Profile"] = ResolversParentTypes["Profile"]
> {
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["DisplayAttribute"]>>>,
    ParentType,
    ContextType
  >;
  badges?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Badges"]>>>,
    ParentType,
    ContextType
  >;
  category?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType
  >;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  heroPhoto?: Resolver<Maybe<ResolversTypes["Media"]>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  rating?: Resolver<Maybe<ResolversTypes["Float"]>, ParentType, ContextType>;
  ratingCount?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  reviewCount?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  gallery?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Media"]>>>,
    ParentType,
    ContextType
  >;
  averageRating?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileRating"]>>>,
    ParentType,
    ContextType
  >;
  specialities?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  localities?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  aboutUs?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  virtualNumber?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  branch?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BranchDetails"]>>>,
    ParentType,
    ContextType
  >;
  canonicalUrl?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  review?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Review"]>>>,
    ParentType,
    ContextType
  >;
  offers?: Resolver<
    Maybe<Array<ResolversTypes["Offers"]>>,
    ParentType,
    ContextType
  >;
  overallRatings?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["OverAllRating"]>>>,
    ParentType,
    ContextType
  >;
  view360?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["View360Details"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileRatingResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileRating"] = ResolversParentTypes["ProfileRating"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  rating?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileReviewResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileReview"] = ResolversParentTypes["ProfileReview"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  reviewer?: Resolver<
    Maybe<ResolversTypes["ProfileReviewer"]>,
    ParentType,
    ContextType
  >;
  rating?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileRating"]>>>,
    ParentType,
    ContextType
  >;
  review?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  event?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  date?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  createdOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ProfileReviewerResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileReviewer"] = ResolversParentTypes["ProfileReviewer"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  profilePhoto?: Resolver<
    Maybe<ResolversTypes["Media"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface QueryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Query"] = ResolversParentTypes["Query"]
> {
  getBannersByCityCategory?: Resolver<
    Array<Maybe<ResolversTypes["Banner"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetBannersByCityCategoryArgs, "category" | "city">
  >;
  blogPosts?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogPost"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryBlogPostsArgs, "type">
  >;
  blogPostCount?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType,
    RequireFields<QueryBlogPostCountArgs, "type">
  >;
  blogPostById?: Resolver<
    Maybe<ResolversTypes["BlogPost"]>,
    ParentType,
    ContextType,
    RequireFields<QueryBlogPostByIdArgs, "blogPostId">
  >;
  blogPostDraft?: Resolver<
    Maybe<Array<ResolversTypes["BlogPost"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryBlogPostDraftArgs, "type">
  >;
  blogTag?: Resolver<
    Maybe<Array<ResolversTypes["BlogTagAdmin"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryBlogTagArgs, never>
  >;
  blogTagById?: Resolver<
    ResolversTypes["BlogTagAdmin"],
    ParentType,
    ContextType,
    RequireFields<QueryBlogTagByIdArgs, "blogTagId">
  >;
  blogUser?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogUser"]>>>,
    ParentType,
    ContextType
  >;
  userInfo?: Resolver<ResolversTypes["BlogUser"], ParentType, ContextType>;
  getBlogs?: Resolver<
    Maybe<Array<ResolversTypes["Blogs"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetBlogsArgs, never>
  >;
  getTotalBlogsCount?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  getBlogsByID?: Resolver<
    ResolversTypes["Blogs"],
    ParentType,
    ContextType,
    RequireFields<QueryGetBlogsByIdArgs, never>
  >;
  getHomeBlogs?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Blogs"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetHomeBlogsArgs, never>
  >;
  getBlogsByCategoryID?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogsCategory"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetBlogsByCategoryIdArgs, never>
  >;
  getCategories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  getCategoriesByID?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCategoriesByIdArgs, "categoryID">
  >;
  getCategoriesBySlug?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCategoriesBySlugArgs, "slug">
  >;
  getCities?: Resolver<
    Maybe<Array<ResolversTypes["City"]>>,
    ParentType,
    ContextType
  >;
  getPopularCities?: Resolver<
    Maybe<Array<ResolversTypes["City"]>>,
    ParentType,
    ContextType
  >;
  getCitiesByID?: Resolver<
    Maybe<ResolversTypes["City"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCitiesByIdArgs, "cityId">
  >;
  getCitiesBySlug?: Resolver<
    Maybe<ResolversTypes["City"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCitiesBySlugArgs, "slug">
  >;
  getLatestInquries?: Resolver<
    Maybe<Array<ResolversTypes["LatestInquries"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetLatestInquriesArgs, "category" | "city">
  >;
  generateInquiries?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  Media?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Media"]>>>,
    ParentType,
    ContextType
  >;
  MetaDetails?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["MetaDetails"]>>>,
    ParentType,
    ContextType
  >;
  decryptWhatsappUrl?: Resolver<
    ResolversTypes["WhatsappUrlInfo"],
    ParentType,
    ContextType,
    RequireFields<QueryDecryptWhatsappUrlArgs, "urlId">
  >;
  getProfiles?: Resolver<
    Maybe<Array<ResolversTypes["Profile"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetProfilesArgs, "postData">
  >;
  getTotalProfilesCount?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetTotalProfilesCountArgs, "postData">
  >;
  getProfilesByID?: Resolver<
    Maybe<ResolversTypes["Profile"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetProfilesByIdArgs, "profileID">
  >;
  topProfilesByCity?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["TopProfilesByCity"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryTopProfilesByCityArgs, "cityId">
  >;
  getProfilesByCity?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["TopProfilesByCity"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetProfilesByCityArgs, "cityId">
  >;
  profileBestSeries?: Resolver<
    Maybe<ResolversTypes["BestSeries"]>,
    ParentType,
    ContextType,
    RequireFields<QueryProfileBestSeriesArgs, "url">
  >;
  similarProfiles?: Resolver<
    Maybe<Array<ResolversTypes["Profile"]>>,
    ParentType,
    ContextType,
    RequireFields<QuerySimilarProfilesArgs, "postData">
  >;
  ProfileRating?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileRating"]>>>,
    ParentType,
    ContextType
  >;
  getRatingQuestionsForCategory?: Resolver<
    Array<Maybe<ResolversTypes["RatingQuestions"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetRatingQuestionsForCategoryArgs, "slug">
  >;
  reviewByProfile?: Resolver<
    Maybe<Array<ResolversTypes["Review"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryReviewByProfileArgs, "profileId">
  >;
  search?: Resolver<
    Maybe<ResolversTypes["Search"]>,
    ParentType,
    ContextType,
    RequireFields<QuerySearchArgs, "postData">
  >;
  autoSuggest?: Resolver<
    Maybe<ResolversTypes["AutoSuggest"]>,
    ParentType,
    ContextType,
    RequireFields<QueryAutoSuggestArgs, "postData">
  >;
  getSEM?: Resolver<
    Maybe<Array<ResolversTypes["Sem"]>>,
    ParentType,
    ContextType
  >;
  getSEMByCityCategory?: Resolver<
    ResolversTypes["Sem"],
    ParentType,
    ContextType,
    RequireFields<QueryGetSemByCityCategoryArgs, "city" | "category">
  >;
  seoMeta?: Resolver<
    ResolversTypes["SeoMeta"],
    ParentType,
    ContextType,
    RequireFields<QuerySeoMetaArgs, "url">
  >;
  getWeddingStories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["WeddingStory"]>>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetWeddingStoriesArgs, never>
  >;
  getTotalWeddingCount?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType
  >;
  getWeddingStoriesByID?: Resolver<
    Maybe<ResolversTypes["WeddingStory"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetWeddingStoriesByIdArgs, "id">
  >;
}

export interface RatingQuestionsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["RatingQuestions"] = ResolversParentTypes["RatingQuestions"]
> {
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  label?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  description?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface RatingsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Ratings"] = ResolversParentTypes["Ratings"]
> {
  id?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  answer?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface ReviewResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Review"] = ResolversParentTypes["Review"]
> {
  _id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  user?: Resolver<Maybe<ResolversTypes["UserAuth"]>, ParentType, ContextType>;
  profileID?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  vendorID?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  ratings?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Ratings"]>>>,
    ParentType,
    ContextType
  >;
  overall?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  review?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  createdAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SearchResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Search"] = ResolversParentTypes["Search"]
> {
  categories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Profile"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SearchLogResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["SearchLog"] = ResolversParentTypes["SearchLog"]
> {
  uuid?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  userId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  type?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SemResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Sem"] = ResolversParentTypes["Sem"]
> {
  bannerImage?: Resolver<ResolversTypes["BannerImg"], ParentType, ContextType>;
  bannerQuestion?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  category?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  city?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  footerQuestion?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  title?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  subtitle?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface SeoMetaResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["SeoMeta"] = ResolversParentTypes["SeoMeta"]
> {
  title?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  metaTitle?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  description?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  keywords?: Resolver<
    Maybe<Array<ResolversTypes["String"]>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface TopProfilesByCityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["TopProfilesByCity"] = ResolversParentTypes["TopProfilesByCity"]
> {
  categoryId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  needName?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Profile"]>>>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface UserAuthResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["UserAuth"] = ResolversParentTypes["UserAuth"]
> {
  _id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  email?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  phone?: Resolver<Maybe<ResolversTypes["Int"]>, ParentType, ContextType>;
  profilePicture?: Resolver<ResolversTypes["Media"], ParentType, ContextType>;
  customerID?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  createdAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  updatedAt?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface View360DetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["View360Details"] = ResolversParentTypes["View360Details"]
> {
  locality?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  title?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  embedCode?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  embedUrl?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface WeddingStoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["WeddingStory"] = ResolversParentTypes["WeddingStory"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  couple?: Resolver<ResolversTypes["Couple"], ParentType, ContextType>;
  excerpt?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  heroPhoto?: Resolver<ResolversTypes["Media"], ParentType, ContextType>;
  categories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  gallery?: Resolver<
    Maybe<Array<ResolversTypes["Media"]>>,
    ParentType,
    ContextType
  >;
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["WeddingStoryProfiles"]>>>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface WeddingStoryCommentResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["WeddingStoryComment"] = ResolversParentTypes["WeddingStoryComment"]
> {
  customerStory?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  profileStory?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface WeddingStoryProfilesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["WeddingStoryProfiles"] = ResolversParentTypes["WeddingStoryProfiles"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  slugId?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  category?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType
  >;
  comments?: Resolver<
    Maybe<ResolversTypes["WeddingStoryComment"]>,
    ParentType,
    ContextType
  >;
  profilePhoto?: Resolver<
    Maybe<ResolversTypes["Media"]>,
    ParentType,
    ContextType
  >;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface WhatsappUrlInfoResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["WhatsappUrlInfo"] = ResolversParentTypes["WhatsappUrlInfo"]
> {
  vendorId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  vendorType?: Resolver<ResolversTypes["Int"], ParentType, ContextType>;
  mobileNumber?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  email?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType>;
}

export interface Resolvers<ContextType = any> {
  AutoCategoryProfiles?: AutoCategoryProfilesResolvers<ContextType>;
  AutoSuggest?: AutoSuggestResolvers<ContextType>;
  AutoSuggestAttribute?: AutoSuggestAttributeResolvers<ContextType>;
  AutoSuggestCategory?: AutoSuggestCategoryResolvers<ContextType>;
  AutoSuggestProfile?: AutoSuggestProfileResolvers<ContextType>;
  Badges?: BadgesResolvers<ContextType>;
  Banner?: BannerResolvers<ContextType>;
  BannerImg?: BannerImgResolvers<ContextType>;
  BestSeries?: BestSeriesResolvers<ContextType>;
  BlogAccessibility?: BlogAccessibilityResolvers<ContextType>;
  BlogPost?: BlogPostResolvers<ContextType>;
  Blogs?: BlogsResolvers<ContextType>;
  BlogsCategory?: BlogsCategoryResolvers<ContextType>;
  BlogTag?: BlogTagResolvers<ContextType>;
  BlogTagAdmin?: BlogTagAdminResolvers<ContextType>;
  BlogUser?: BlogUserResolvers<ContextType>;
  BlogUserLogin?: BlogUserLoginResolvers<ContextType>;
  BranchDetails?: BranchDetailsResolvers<ContextType>;
  Category?: CategoryResolvers<ContextType>;
  CategoryQuestion?: CategoryQuestionResolvers<ContextType>;
  City?: CityResolvers<ContextType>;
  Content?: ContentResolvers<ContextType>;
  Couple?: CoupleResolvers<ContextType>;
  CustomerID?: CustomerIdResolvers<ContextType>;
  DateTime?: GraphQLScalarType;
  DisplayAttribute?: DisplayAttributeResolvers<ContextType>;
  DisplayOptions?: DisplayOptionsResolvers<ContextType>;
  DisplayOptionType?: GraphQLScalarType;
  FilterAttribute?: FilterAttributeResolvers<ContextType>;
  FilterAttributeOptions?: FilterAttributeOptionsResolvers<ContextType>;
  HeroPhoto?: HeroPhotoResolvers<ContextType>;
  InquriesAttribute?: InquriesAttributeResolvers<ContextType>;
  JSON?: GraphQLScalarType;
  LatestInquries?: LatestInquriesResolvers<ContextType>;
  Media?: MediaResolvers<ContextType>;
  MediaTag?: MediaTagResolvers<ContextType>;
  MetaDetails?: MetaDetailsResolvers<ContextType>;
  Mutation?: MutationResolvers<ContextType>;
  OfferImage?: OfferImageResolvers<ContextType>;
  Offers?: OffersResolvers<ContextType>;
  OverAllRating?: OverAllRatingResolvers<ContextType>;
  Profile?: ProfileResolvers<ContextType>;
  ProfileRating?: ProfileRatingResolvers<ContextType>;
  ProfileReview?: ProfileReviewResolvers<ContextType>;
  ProfileReviewer?: ProfileReviewerResolvers<ContextType>;
  Query?: QueryResolvers<ContextType>;
  RatingQuestions?: RatingQuestionsResolvers<ContextType>;
  Ratings?: RatingsResolvers<ContextType>;
  Review?: ReviewResolvers<ContextType>;
  Search?: SearchResolvers<ContextType>;
  SearchLog?: SearchLogResolvers<ContextType>;
  Sem?: SemResolvers<ContextType>;
  SeoMeta?: SeoMetaResolvers<ContextType>;
  TopProfilesByCity?: TopProfilesByCityResolvers<ContextType>;
  UserAuth?: UserAuthResolvers<ContextType>;
  View360Details?: View360DetailsResolvers<ContextType>;
  WeddingStory?: WeddingStoryResolvers<ContextType>;
  WeddingStoryComment?: WeddingStoryCommentResolvers<ContextType>;
  WeddingStoryProfiles?: WeddingStoryProfilesResolvers<ContextType>;
  WhatsappUrlInfo?: WhatsappUrlInfoResolvers<ContextType>;
}

/**
 * @deprecated
 * Use "Resolvers" root object instead. If you wish to get "IResolvers", add "typesPrefix: I" to your config.
 */
export type IResolvers<ContextType = any> = Resolvers<ContextType>;
