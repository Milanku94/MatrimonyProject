import _flatMap from "lodash/flatMap";

import { slugify } from "../../services/slugify.utils";
import { BaseApi } from "./baseApi";

class CityApi extends BaseApi {
  public getCityById = async ({ cityId }: { cityId: number }) => {
    const response = await this.axios.get(`/cities/${cityId}/`);
    return await response.data.data[0];
  };
  public getCities = async () => {
    const { stateCities } = await this.fetchCities();

    const citiesByState = stateCities.map(
      ({ cities, stateId, stateName }: any) =>
        cities.map((city: any) => ({ ...city, stateId, stateName }))
    );

    return _flatMap(citiesByState);
  };
  public getPopularCities = async () => {
    const { popularCities } = await this.fetchCities();

    return popularCities;
  };
  public getCitiesBySlug = async ({ slug }: { slug: string }) => {
    const { stateCities } = await this.fetchCities();
    const citiesByState = stateCities.map(
      ({ cities, stateId, stateName }: any) =>
        cities.map((city: any) => ({ ...city, stateId, stateName }))
    );

    return _flatMap(citiesByState).find((t: any) => slugify(t.name) === slug);
  };
  private fetchCities = async () => {
    const response = await this.axios.get(`/cities/`);
    const { stateCities, popularCities } = response.data.data;
    return { stateCities, popularCities };
  };
}

export { CityApi };
