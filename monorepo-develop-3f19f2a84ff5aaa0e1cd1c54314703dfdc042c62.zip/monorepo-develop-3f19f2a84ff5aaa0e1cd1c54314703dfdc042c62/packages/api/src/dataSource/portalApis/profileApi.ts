import { ApolloError } from "apollo-server-express";
import { AttributesInput } from "../../generated/portal.models";
import { logger } from "../../services/logger.utils";
import { BaseApi } from "./baseApi";

class ProfileApi extends BaseApi {
  public getProfiles = async ({
    cityId,
    categoryId,
    page,
    limit,
    attributes,
    freeText,
    isAutoSearch
  }: {
    cityId: string;
    categoryId: string;
    page?: number | null;
    limit?: number | null;
    freeText?: string | null;
    attributes?: any;
    isAutoSearch?: boolean;
  }) => {
    const response = await this.axios.post(
      `profiles/p/${page || 1}/r/${limit || 10}/`,
      {
        category_id: categoryId,
        city_id: cityId,
        attributes: this.formatAttributes(attributes || []),
        free_txt: freeText || "",
        _method: isAutoSearch ? "autosearch" : ""
      }
    );
    return await response.data.data;
  };
  public getProfileCount = async ({
    cityId,
    categoryId,
    page,
    limit,
    attributes,
    freeText,
    isAutoSearch
  }: {
    cityId: string;
    categoryId: string;
    page?: number | null;
    limit?: number | null;
    freeText?: string | null;
    attributes?: any;
    isAutoSearch?: boolean;
  }) => {
    const response = await this.axios.post(
      `profiles/p/${page || 1}/r/${limit || 10}/`,
      {
        category_id: categoryId,
        city_id: cityId,
        attributes: this.formatAttributes(attributes || []),
        free_txt: freeText || "",
        _method: isAutoSearch ? "autosearch" : ""
      }
    );
    return await response.headers["x-total-items"];
  };
  public getProfileById = async ({ profileId }: { profileId: string }) => {
    if (!!profileId) {
      return await this.axios
        .get(`profiles/${profileId}/`)
        .then(({ data, ...rest }: any) => {
          if (data.code === 200) {
            return data.data[0];
          }
          logger.portalGQL.warn(data.message, { profileId });
          throw new ApolloError(data.message, "RESOURCE_NOT_FOUND");
        });
    } else {
      return null;
    }
  };
  public getBestSeries = async ({
    url
  }: {
    url: string;
  }): Promise<{
    code: number;
    status: string;
    message: string;
    h1: string;
    data: any;
  }> => {
    return await this.axios
      .post(`best_top_vendors/`, { url })
      .then(({ data }: any) => {
        if (data.code === 200) {
          return data;
        }
        logger.portalGQL.warn(data.message, { url });
        throw new ApolloError(data.message, "RESOURCE_NOT_FOUND");
      });
  };
  private formatAttributes = (attributes: Array<AttributesInput | null>) =>
    attributes.map(attr => {
      if (attr) {
        return { [attr.attributeId as string]: attr.optionIds };
      }
      return null;
    });
}

export { ProfileApi };
