import { AxiosInstance } from "axios";

class BaseApi {
  public axios: AxiosInstance;
  constructor({ axios }: { axios: AxiosInstance }) {
    this.axios = axios;
  }
}

export { BaseApi };
