import { BaseApi } from "./baseApi";

class CategoryApi extends BaseApi {
  public getCategories = async () => {
    const categoriesResp = await this.axios.get(`/categories/`);
    return categoriesResp.data.data;
  };
  public getCategoryByCity = async ({ cityId }: { cityId: number }) => {
    const categoriesResp = await this.axios.get(`/cities/${cityId}/category/`);
    const categoriesData = categoriesResp.data.data;
    return categoriesData.categories;
  };
  public getCategory = async ({ categoryId }: { categoryId: number }) => {
    const response = await this.axios.get(`/categories/${categoryId}/`);
    return response.data.data[0];
  };
}

export { CategoryApi };
