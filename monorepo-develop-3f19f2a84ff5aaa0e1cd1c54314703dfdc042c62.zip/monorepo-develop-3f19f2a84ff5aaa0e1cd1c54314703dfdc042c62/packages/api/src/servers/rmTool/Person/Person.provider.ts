import {
  MutationCreatePersonArgs,
  MutationUpdatePersonArgs
} from "../../../generated/rmtool.models";
import { provider as ParticipantProvider } from "../Participant";
import { model as PersonModel } from "../Person";

export default class PersonProvider {
  public add = async ({
    participantId,
    personInfo
  }: MutationCreatePersonArgs) => {
    const newPerson: any = new PersonModel({ ...personInfo });

    await new ParticipantProvider().addPersonById(
      participantId,
      newPerson.personType,
      newPerson._id
    );
    await newPerson.save();

    return newPerson;
  };
  public getById = async (personId: string) =>
    await PersonModel.findById(personId);
  public update = async ({
    personId,
    personInfo
  }: MutationUpdatePersonArgs) => {
    const updatedPerson: any = await PersonModel.findByIdAndUpdate(
      personId,
      { ...personInfo } as any,
      { new: true }
    );
    return updatedPerson;
  };
}
