import {
  MutationCreatePersonArgs,
  MutationUpdatePersonArgs
} from "../../../generated/rmtool.models";
import { provider as PersonProvider } from "../Person";
import { typeOfPerson } from "./Person.model";

export default {
  PersonType: {
    ...typeOfPerson
  },
  Mutation: {
    createPerson: async (
      _: any,
      { participantId, personInfo }: MutationCreatePersonArgs
    ) => await new PersonProvider().add({ participantId, personInfo }),
    updatePerson: async (
      _: any,
      { personId, personInfo }: MutationUpdatePersonArgs
    ) => await new PersonProvider().update({ personId, personInfo })
  }
};
