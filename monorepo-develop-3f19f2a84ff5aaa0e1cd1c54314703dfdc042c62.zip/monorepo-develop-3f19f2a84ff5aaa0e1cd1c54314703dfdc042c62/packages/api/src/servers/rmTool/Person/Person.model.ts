import { prop, Typegoose } from "typegoose";
export enum typeOfPerson {
  SELF = "self",
  POINT_OF_CONTACT = "pointOfContact",
  DECISION_MAKER = "decisionMaker"
}

const isEmail = (val: string) => {
  return true;
};

export class Person extends Typegoose {
  @prop({ required: true, lowercase: true })
  public name: string;
  @prop()
  public mobile?: string;
  @prop({
    validate: {
      validator: isEmail,
      message: `{VALUE} is not a valid email`
    }
  })
  public email?: string;
  @prop({ required: true, lowercase: true })
  public relationship: string;
  @prop()
  public professional: string;
  @prop()
  public community: string;
  @prop({ enum: typeOfPerson })
  public personType: string;
}

export default new Person().getModelForClass(Person, {
  schemaOptions: { collection: "people" }
});
