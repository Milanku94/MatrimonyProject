import model, { Person } from "./Person.model";
import provider from "./Person.provider";
import resolver from "./Person.resolver";

export { Person, model, provider, resolver };
