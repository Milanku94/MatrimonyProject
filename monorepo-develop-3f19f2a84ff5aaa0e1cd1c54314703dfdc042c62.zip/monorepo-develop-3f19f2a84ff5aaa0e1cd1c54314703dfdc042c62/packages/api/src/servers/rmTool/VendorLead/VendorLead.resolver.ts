import {
  MutationCreateVendorLeadArgs,
  MutationUpdateVendorLeadArgs
} from "../../../generated/rmtool.models";
import { provider as ParticipantProvider } from "../Participant";
import { provider as VendorLeadprovider } from "../VendorLead";

export default {
  Query: {
    vendorLeads: async () => await new VendorLeadprovider().getAll()
  },
  Mutation: {
    createVendorLead: async (_: any, args: MutationCreateVendorLeadArgs) =>
      await new VendorLeadprovider().add(args),
    updateVendorLead: async (_: any, args: MutationUpdateVendorLeadArgs) =>
      await new VendorLeadprovider().updateRoles(args)
  },
  VendorLead: {
    participants: async (root: any) => {
      const participantProvider = new ParticipantProvider();

      return await participantProvider.getAllById(root.participants);
    }
  }
};
