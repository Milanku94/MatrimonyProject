import {
  MutationCreateVendorLeadArgs,
  MutationUpdateVendorLeadArgs
} from "../../../generated/rmtool.models";
import { model as ParticipantsModel } from "../Participant";
import { model as PersonModel } from "../Person";
import { model as VendorLeadModel } from "../VendorLead";

export default class VendorLeadProvider {
  public add = async ({
    rmId,
    crmId,
    person,
    participantType
  }: MutationCreateVendorLeadArgs) => {
    // Todo: avoid dupilcate and if exist
    const { name, mobile, email, relationship, personType } = person;
    const newPerson = new PersonModel({ name, mobile, email, relationship });
    const newParticipant = new ParticipantsModel({
      basic: { [personType]: newPerson._id },
      participantType
    });
    const newVendorLead = new VendorLeadModel({
      rmId,
      crmId,
      participants: [newParticipant._id]
    });

    await newPerson.save();
    await newParticipant.save();
    await newVendorLead.save();

    return newVendorLead;
  };
  public updateRoles = async ({
    id,
    rmId,
    managerId
  }: MutationUpdateVendorLeadArgs) => {
    const updatingLead = {
      rmId,
      managerId
    };

    return await VendorLeadModel.findByIdAndUpdate(
      id,
      { ...updatingLead } as any,
      { new: true }
    );
  };
  public addParticipant = async (leadId: string, participantId: any) =>
    await VendorLeadModel.findByIdAndUpdate(
      leadId,
      { $push: { participants: participantId } },
      { new: true }
    );
  public getAll = async () => await VendorLeadModel.find();

  public getLeadByEmployee = async (employeeId: string) =>
    await VendorLeadModel.find({ employeeId });
}
