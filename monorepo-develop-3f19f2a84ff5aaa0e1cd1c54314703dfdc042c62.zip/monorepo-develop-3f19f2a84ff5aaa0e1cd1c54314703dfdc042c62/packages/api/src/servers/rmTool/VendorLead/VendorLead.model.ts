import { arrayProp, index, prop, Ref, Typegoose } from "typegoose";
import { Participant } from "../Participant";

export class VendorLead extends Typegoose {
  // note: reference from other src
  @prop()
  public rmId?: string;
  @prop()
  public crmId?: string;
  @prop()
  public managerId?: string;
  @prop()
  public districtId?: string;
  @arrayProp({ itemsRef: { name: "Participant" }, required: false })
  public participants?: Array<Ref<Participant>>;
}

export default new VendorLead().getModelForClass(VendorLead, {
  schemaOptions: { collection: "vendor_lead" }
});
