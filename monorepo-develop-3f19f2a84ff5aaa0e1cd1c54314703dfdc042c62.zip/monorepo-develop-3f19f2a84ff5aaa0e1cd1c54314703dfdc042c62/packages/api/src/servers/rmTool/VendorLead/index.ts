import model, { VendorLead } from "./VendorLead.model";
import provider from "./VendorLead.provider";
import resolver from "./VendorLead.resolver";

export { VendorLead, model, provider, resolver };
