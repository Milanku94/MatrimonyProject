export default class ProfileProvider {
  public all() {
    return testData;
  }
}
const testData = [
  {
    name: "test data"
  }
];
