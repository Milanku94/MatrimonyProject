import model, { Profile } from "./Profile.model";
import provider from "./Profile.provider";
import resolver from "./Profile.resolver";

export { Profile, model, provider, resolver };
