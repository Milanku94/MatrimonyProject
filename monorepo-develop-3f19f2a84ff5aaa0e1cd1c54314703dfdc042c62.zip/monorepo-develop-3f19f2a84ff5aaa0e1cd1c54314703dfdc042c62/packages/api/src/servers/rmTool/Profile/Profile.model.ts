import { arrayProp, prop, Typegoose } from "typegoose";

export class Profile extends Typegoose {
  // Todo: Vendor info came from other src
  @prop()
  public vendorId: string;
  @arrayProp({ items: String })
  public categories: string[];
  @prop()
  public leadStatus: string;
  @prop()
  public quote: string;
  @prop()
  public interactions: string;
  @prop()
  public notes: string;
}

export default new Profile().getModelForClass(Profile, {
  schemaOptions: { collection: "profiles" }
});
