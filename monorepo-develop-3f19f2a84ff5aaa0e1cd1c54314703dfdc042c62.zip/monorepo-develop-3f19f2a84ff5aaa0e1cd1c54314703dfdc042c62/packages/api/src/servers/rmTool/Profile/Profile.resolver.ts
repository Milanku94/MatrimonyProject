import ProfileModel from "./Profile.model";
import ProfileServices from "./Profile.provider";

export default {
  Query: {
    profiles: (parent: any, { id }: any, context: any, info: any) =>
      ProfileModel.find()
  },
  Profile: {
    shortlisted: (root: any) => {
      // Todo: business logic
      return null;
    },
    finalised: (root: any) => {
      // Todo: business logic
      return null;
    },
    rejected: (root: any) => {
      // Todo: business logic
      return null;
    }
    /** //Todo:
     * vendorName: String
     * businessName: String
     * profileURL: String
     * phoneString: String
     */
  }
  // Mutation: {
  //   createProfile: async (_: any, { name }: any) => {
  //     const Profile = new ProfileModel({ name });
  //     await Profile.save();
  //     return Profile;
  //   }
  // }
};
