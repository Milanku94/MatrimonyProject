import { InstanceType, ModelType, prop, Typegoose } from "typegoose";

export class City extends Typegoose {
  @prop()
  public name?: string;
}

export default new City().getModelForClass(City, {
  schemaOptions: { collection: "City" }
});
