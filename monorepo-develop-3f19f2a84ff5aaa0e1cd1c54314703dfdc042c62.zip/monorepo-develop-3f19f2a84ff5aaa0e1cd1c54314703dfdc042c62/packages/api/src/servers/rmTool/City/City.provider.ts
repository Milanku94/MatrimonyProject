import DB from "../../../config/db";

export default class CityProvider {
  public knex: any;
  constructor(knexInstance: any) {
    this.knex = knexInstance;
  }

  public getAll = async () => {
    const {
      table,
      fields: { id, name }
    } = DB.mBazaar.cities;

    return await this.knex(table).column({ id }, { name });
  };

  public getById = async (cityId: any) => {
    const {
      table,
      fields: { id, name }
    } = DB.mBazaar.cities;

    return await this.knex(table)
      .column({ id }, { name })
      .where({ [id]: cityId })[0];
  };
  public getByCityName = async (cityName: string) => {
    const { table, fields } = DB.mBazaar.cities;

    return await this.knex(table)
      .column(fields)
      .where({ [fields.name]: cityName });
  };
}
