import model, { City } from "./City.model";
import provider from "./City.provider";
import resolver from "./City.resolver";

export { City, model, provider, resolver };
