import { provider as CityProvider } from "../City";
export default {
  Query: {
    getCities: async (parent: any, args: any, context: any) =>
      await new CityProvider(context.mBazaar).getAll(),
    getCityById: async (parent: any, { cityId }: any, context: any) =>
      await new CityProvider(context.mBazaar).getById(cityId)
  }
};
