import { gql } from "apollo-server-express";
import { makeExecutableSchema } from "graphql-tools";
import { fileLoader, mergeResolvers, mergeTypes } from "merge-graphql-schemas";
import path from "path";
import { AuthDirective } from "../../directive/auth.directive";

import { ApolloServer } from "apollo-server-express";
import Knex = require("knex");
import config from "../../config/config.env";

const typesArray = fileLoader(path.join(__dirname, "./**/*.gql"));
const resolversArray = fileLoader(path.join(__dirname, "./**/*.resolver.*"));

const typeDef = gql`
  type Query {
    hello: String
  }
`;
const resolver = {
  Query: {
    hello: () => {
      return "welcome";
    }
  }
};

const typeDefs = mergeTypes([typeDef, ...typesArray], { all: true });
const resolvers = mergeResolvers([resolver, ...resolversArray]);

export const rmtoolServer = ({
  mBazaar,
  mBazaarServices
}: {
  mBazaar: Knex;
  mBazaarServices: Knex;
}) =>
  new ApolloServer({
    playground: !config.HIDE_APOLLO_PLAYGROUND,
    introspection: !config.HIDE_APOLLO_PLAYGROUND,
    schema: makeExecutableSchema({
      typeDefs,
      resolvers,
      schemaDirectives: {
        auth: AuthDirective
      }
    }),
    context: async ({ req }: any) => {
      return {
        mBazaar,
        mBazaarServices,
        headers: {
          authToken: req.headers[config.JWT.AUTH_TOKEN_NAME]
        }
      };
    }
  });
