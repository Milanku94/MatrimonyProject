import { arrayProp, prop, Ref, Typegoose } from "typegoose";
import { Event } from "../Event";
import { Profile } from "../Profile";
export class Category extends Typegoose {
  @prop() // Note: Category Id will be refer from other dataSource ie, SQL, postgres
  public categoryId: string;

  @arrayProp({ itemsRef: { name: "Event" } })
  public events?: Array<Ref<Event>>;

  @arrayProp({ itemsRef: { name: "Profile" } })
  public profiles?: Array<Ref<Profile>>;
}

export default new Category().getModelForClass(Category, {
  schemaOptions: { collection: "categories" }
});
