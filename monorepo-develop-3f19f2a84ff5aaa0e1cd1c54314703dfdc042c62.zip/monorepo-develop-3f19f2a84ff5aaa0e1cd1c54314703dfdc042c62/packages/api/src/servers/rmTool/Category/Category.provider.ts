import DB from "../../../config/db";

export default class CategoryProvider {
  public knex: any;
  constructor(knexInstance: any) {
    this.knex = knexInstance;
  }

  public getAll = async () => {
    const {
      table,
      fields: { id, name, displayName }
    } = DB.mBazaar.category;
    return await this.knex(table).column({ id }, { name }, { displayName });
  };

  public getById = async (categoryId: any) => {
    const {
      table,
      fields: { id, name, displayName }
    } = DB.mBazaar.category;

    return await this.knex(table)
      .column({ id }, { name }, { displayName })
      .where(id, categoryId);
  };
}
