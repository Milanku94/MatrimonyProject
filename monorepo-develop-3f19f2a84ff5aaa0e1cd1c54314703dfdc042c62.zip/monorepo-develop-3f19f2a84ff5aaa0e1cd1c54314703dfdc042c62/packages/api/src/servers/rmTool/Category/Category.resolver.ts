import { provider as CategoryProvider } from "../Category";
// import { QueryGetCategoriesByCityArgs } from "../../../generated/models";

export default {
  Query: {
    getCategories: async (parent: any, args: any, context: any) =>
      await new CategoryProvider(context.mBazaar).getAll(),
    getCategoryById: async (parent: any, { categoryId }: any, context: any) =>
      await new CategoryProvider(context.mBazaar).getById(categoryId)
  },
  Category: {
    events: (root: any) => {
      return root.events;
    }
  }
};
