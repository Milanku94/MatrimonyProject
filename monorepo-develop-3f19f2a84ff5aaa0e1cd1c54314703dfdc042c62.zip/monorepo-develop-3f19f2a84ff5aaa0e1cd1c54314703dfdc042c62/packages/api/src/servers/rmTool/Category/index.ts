import model, { Category } from "./Category.model";
import provider from "./Category.provider";
import resolver from "./Category.resolver";

export { Category, model, provider, resolver };
