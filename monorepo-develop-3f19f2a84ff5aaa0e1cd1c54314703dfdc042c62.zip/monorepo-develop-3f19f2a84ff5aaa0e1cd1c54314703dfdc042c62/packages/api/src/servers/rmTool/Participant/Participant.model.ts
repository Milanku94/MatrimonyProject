import { arrayProp, prop, Ref, Typegoose } from "typegoose";
import { Address } from "../Address";
import { Event } from "../Event";
import { Person } from "../Person";
import { Profile } from "../Profile";
export enum typeOfParticipant {
  BRIDE = "BRIDE",
  GROOM = "GROOM"
}
class Basic extends Typegoose {
  @prop({ ref: { name: "Person" } })
  public self?: Ref<Person>;
  @prop({ ref: { name: "Person" } })
  public pointOfContact?: Ref<Person>;
  @prop({ ref: { name: "Person" } })
  public decisionMaker?: Ref<Person>;
}
export class Participant extends Typegoose {
  @prop()
  public basic: Basic;
  @arrayProp({ itemsRef: { name: "Event" } })
  public events?: Array<Ref<Event>>;
  @arrayProp({ itemsRef: { name: "Profile" } })
  public profiles?: Array<Ref<Profile>>;
  @prop()
  public interactions?: string;
  @prop()
  public notes?: string;
  @prop({ enum: typeOfParticipant })
  public participantType: string;
  @arrayProp({ itemsRef: { name: "Address" } })
  public addresses?: Array<Ref<Address>>;
}

export default new Participant().getModelForClass(Participant, {
  schemaOptions: { collection: "participant" }
});
