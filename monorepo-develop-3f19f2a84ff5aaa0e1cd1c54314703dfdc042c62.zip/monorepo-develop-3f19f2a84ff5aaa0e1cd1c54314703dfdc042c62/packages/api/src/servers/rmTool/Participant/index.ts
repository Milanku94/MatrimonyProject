import model, { Participant } from "./Participant.model";
import provider from "./Participant.provider";
import resolver from "./Participant.resolver";

export { Participant, model, provider, resolver };
