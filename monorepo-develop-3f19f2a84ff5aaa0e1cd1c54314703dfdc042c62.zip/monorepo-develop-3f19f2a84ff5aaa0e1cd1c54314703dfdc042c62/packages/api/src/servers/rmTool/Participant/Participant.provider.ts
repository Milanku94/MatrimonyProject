import { MutationCreateParticipantArgs } from "../../../generated/rmtool.models";
import { model as ParticipantModel } from "../Participant";
import { provider as PersonProvider } from "../Person";
import { provider as LeadProvider } from "../VendorLead";

export default class ParticipantProvider {
  public add = async ({
    leadId,
    participantType,
    person
  }: MutationCreateParticipantArgs) => {
    const newParticipant: any = new ParticipantModel({ participantType });
    const newPerson: any = await new PersonProvider().add({
      participantId: newParticipant._id,
      personInfo: person
    });
    newParticipant.basic = { [person.personType]: newPerson._id };
    await new LeadProvider().addParticipant(leadId, newParticipant._id);
    await newParticipant.save();
    return newParticipant;
  };
  public getById = async (participationId: string) =>
    await ParticipantModel.findById(participationId);
  public getAllById = async (listOfId: string[]) => {
    const participants = await listOfId.map(
      async (id: any) => await ParticipantModel.findById(id)
    );

    return participants;
  };
  public addAddressById = async (participantId: string, addressId: any) =>
    await ParticipantModel.findByIdAndUpdate(
      participantId,
      { $push: { addresses: addressId } },
      { new: true } // note: do in model itself
    );
  public addPersonById = async (
    participantId: string,
    personType: string,
    personId: string
  ) =>
    await ParticipantModel.findByIdAndUpdate(
      participantId,
      { $set: { [`basic.${personType}`]: personId } },
      { new: true } // note: do in model itself
    );
  public addEventById = async (participationId: any, eventId: any) =>
    await ParticipantModel.findByIdAndUpdate(
      participationId,
      { $push: { events: eventId } },
      { new: true } // note: do in model itself
    );
  public getEvents = async (participantId: string) => {
    const { events }: any = await ParticipantModel.findById(participantId);

    return events;
  };
}
