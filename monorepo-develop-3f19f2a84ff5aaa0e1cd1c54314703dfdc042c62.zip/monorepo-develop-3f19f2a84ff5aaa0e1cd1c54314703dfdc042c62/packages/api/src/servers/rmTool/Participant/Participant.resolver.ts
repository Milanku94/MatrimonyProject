import { map as _map } from "lodash";
import { MutationCreateParticipantArgs } from "../../../generated/rmtool.models";
import { provider as AddressProvider } from "../Address";
import { provider as EventProvider } from "../Event";
import { provider as ParticipantProvider } from "../Participant";
import { provider as PersonProvider } from "../Person";
export default {
  Mutation: {
    createParticipant: async (_: any, args: MutationCreateParticipantArgs) =>
      await new ParticipantProvider().add(args)
  },
  Basic: {
    self: async (root: any) => await new PersonProvider().getById(root.self),
    pointOfContact: async (root: any) =>
      await new PersonProvider().getById(root.pointOfContact),
    decisionMaker: async (root: any) =>
      await new PersonProvider().getById(root.decisionMaker)
  },
  Participant: {
    addresses: async (root: any) => {
      const addressProvider = new AddressProvider();

      return root.addresses.map(async (addressId: any) =>
        addressProvider.getById(addressId)
      );
    },
    categories: async (root: any) => {
      const eventsByCategory = await new EventProvider().getEventsByCategory(
        root._id
      );
      const categories = _map(eventsByCategory, (val: any, key: string) => ({
        categoryId: key,
        events: val
      }));

      return categories;
    },
    events: async (root: any) => {
      return await root.events.map(
        async (eventid: any) => await new EventProvider().getById(eventid)
      );
    }
  }
};
