import { InstanceType, ModelType, prop, Typegoose } from "typegoose";

export class User extends Typegoose {
  @prop()
  public name?: string;
}

export default new User().getModelForClass(User, {
  schemaOptions: { collection: "User" }
});
