import { model as UserModel } from "../User";
import { provider as UserProvider } from "../User";

export default {
  Query: {
    Users: (parent: any, args: any, context: any, info: any) => UserModel.find()
  }
};
