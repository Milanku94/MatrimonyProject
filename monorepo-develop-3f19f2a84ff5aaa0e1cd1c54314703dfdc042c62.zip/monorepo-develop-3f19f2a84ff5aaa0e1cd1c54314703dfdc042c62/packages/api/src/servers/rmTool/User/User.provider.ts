export default class UserProvider {
  public all() {
    return testData;
  }
}
const testData = [
  {
    name: "test data"
  }
];
