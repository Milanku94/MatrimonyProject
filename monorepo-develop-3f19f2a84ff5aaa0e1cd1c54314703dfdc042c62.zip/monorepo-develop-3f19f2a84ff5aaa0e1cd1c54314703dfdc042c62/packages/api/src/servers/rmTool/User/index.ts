import model, { User } from "./User.model";
import provider from "./User.provider";
import resolver from "./User.resolver";

export { User, model, provider, resolver };
