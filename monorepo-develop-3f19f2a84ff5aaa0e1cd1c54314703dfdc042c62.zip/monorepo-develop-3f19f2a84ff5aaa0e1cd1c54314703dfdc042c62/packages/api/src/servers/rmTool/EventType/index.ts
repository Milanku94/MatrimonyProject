import model, { EventType } from "./EventType.model";
import provider from "./EventType.provider";
import resolver from "./EventType.resolver";

export { EventType, model, provider, resolver };
