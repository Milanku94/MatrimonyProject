import { InstanceType, ModelType, pre, prop, Typegoose } from "typegoose";

export class EventType extends Typegoose {
  @prop({ unique: true })
  public name: string;
  @prop()
  public description: string;
}

export default new EventType().getModelForClass(EventType, {
  schemaOptions: { collection: "event_types" }
});
