import {
  MutationCreateEventTypeArgs,
  MutationUpdateEventTypeArgs
} from "../../../generated/rmtool.models";
import EventTypeModel from "./EventType.model";
export default class EventTypeProvider {
  public getAll = () => EventTypeModel.find();
  public add = async ({ name, description }: MutationCreateEventTypeArgs) => {
    const EventType = new EventTypeModel({ name, description });
    await EventType.save();
    return EventType;
  };
  public update = async ({
    eventType,
    eventTypeId
  }: MutationUpdateEventTypeArgs) =>
    await EventTypeModel.findByIdAndUpdate(eventTypeId, {
      ...eventType
    } as any);
  public getById = async (eventId: string) =>
    await EventTypeModel.findById(eventId);
}
const testData = [
  {
    name: "test data"
  }
];
