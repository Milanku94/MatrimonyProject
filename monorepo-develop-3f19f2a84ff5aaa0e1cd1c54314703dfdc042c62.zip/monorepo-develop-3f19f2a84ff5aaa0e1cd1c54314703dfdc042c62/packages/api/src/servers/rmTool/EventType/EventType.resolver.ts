import EventTypeServices from "./EventType.provider";

export default {
  Query: {
    eventTypes: (parent: any, args: any, context: any, info: any) =>
      new EventTypeServices().getAll()
  },
  Mutation: {
    createEventType: async (_: any, { name, description }: any) =>
      await new EventTypeServices().add({ name, description }),
    updateEventType: async (_: any, { eventTypeId, eventType }: any) =>
      await new EventTypeServices().update({ eventType, eventTypeId })
  }
};
