import {
  MutationCreateAddressArgs,
  MutationUpdateAddressArgs
} from "../../../generated/rmtool.models";
import { model as AddressModel } from "../Address";
import { model as ParticipantModel } from "../Participant";
import { provider as ParticipantProvider } from "../Participant";

export default class AddressProvider {
  public add = async ({
    participantId,
    address
  }: MutationCreateAddressArgs) => {
    const newAddress: any = new AddressModel({ ...address });

    await new ParticipantProvider().addAddressById(
      participantId,
      newAddress._id
    );
    await newAddress.save();

    return newAddress;
  };
  public update = async ({ addressId, address }: MutationUpdateAddressArgs) => {
    const updatedAddress: any = await AddressModel.findByIdAndUpdate(
      addressId,
      { ...address } as any,
      { new: true }
    );
    return updatedAddress;
  };
  public getById = async (addressId: any) =>
    await AddressModel.findById(addressId);
  public getAllByParticipant = async (participantId: string) => {
    const { addresses }: any = await ParticipantModel.findOne({
      _id: participantId
    });

    return addresses.map(
      async (addressId: any) => await AddressModel.findOne({ _id: addressId })
    );
  };
}
