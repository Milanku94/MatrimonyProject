import {
  MutationCreateAddressArgs,
  MutationUpdateAddressArgs,
  QueryAddressesArgs,
  QueryGetAddressArgs
} from "../../../generated/rmtool.models";
import { provider as AddressProvider } from "../Address";
export default {
  Query: {
    addresses: async (parent: any, { participantId }: QueryAddressesArgs) =>
      await new AddressProvider().getAllByParticipant(participantId),
    getAddress: async (parent: any, { addressId }: QueryGetAddressArgs) =>
      await new AddressProvider().getById(addressId)
  },
  Mutation: {
    createAddress: async (
      _: any,
      { participantId, address }: MutationCreateAddressArgs
    ) => await new AddressProvider().add({ participantId, address }),
    updateAddress: async (
      _: any,
      { addressId, address }: MutationUpdateAddressArgs
    ) => await new AddressProvider().update({ addressId, address })
  }
};
