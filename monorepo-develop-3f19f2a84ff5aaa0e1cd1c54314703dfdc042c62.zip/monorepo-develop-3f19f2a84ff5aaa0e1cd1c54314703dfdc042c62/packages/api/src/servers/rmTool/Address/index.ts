import model, { Address } from "./Address.model";
import provider from "./Address.provider";
import resolver from "./Address.resolver";

export { Address, model, provider, resolver };
