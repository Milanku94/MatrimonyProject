import { pre, prop, Typegoose } from "typegoose";

@pre<Address>("save", async function(next) {
  try {
    this.createdAt = new Date().getTime();
    return next();
  } catch (error) {
    return next(error);
  }
})
export class Address extends Typegoose {
  @prop()
  public tag: string;
  @prop()
  public line1: string;
  @prop()
  public line2: string;
  @prop()
  public locality: string;
  @prop()
  public city: string;
  @prop()
  public pincode: number;
  @prop()
  public landmark: string;
  @prop()
  public createdAt: number;
  @prop()
  public updatedAt: number;
}

export default new Address().getModelForClass(Address, {
  schemaOptions: { collection: "addresses" }
});
