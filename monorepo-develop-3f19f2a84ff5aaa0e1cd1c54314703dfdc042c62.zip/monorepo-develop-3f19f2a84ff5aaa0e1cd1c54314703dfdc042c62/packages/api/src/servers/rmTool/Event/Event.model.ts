import { arrayProp, prop, Ref, Typegoose } from "typegoose";
import { Address } from "../Address";
import { EventType } from "../EventType";

export class Event extends Typegoose {
  @prop({ ref: { name: EventType } })
  public eventType: Ref<EventType>;
  @arrayProp({ items: String })
  public categories: string[];
  @prop()
  public date: string;
  @prop({ ref: Address })
  public address: Ref<Address>;
  @prop()
  public notes: string;
  @prop()
  public formFields: string;
}

export default new Event().getModelForClass(Event, {
  schemaOptions: { collection: "events" }
});
