import {
  filter as _filter,
  flattenDeep as _flattenDeep,
  forEach as _forEach,
  groupBy as _groupBy,
  includes as _includes,
  map as _map,
  uniq as _uniq
} from "lodash";
import {
  MutationCreateEventArgs,
  MutationUpdateEventArgs,
  MutationUpdateServiceByEventArgs,
  QueryEventsByCategoryArgs
} from "../../../generated/rmtool.models";
import { model as EventModel } from "../Event";
import { provider as ParticipantProvider } from "../Participant";

export default class EventProvider {
  public add = async ({
    participantId,
    eventInfo
  }: MutationCreateEventArgs) => {
    const newEvent = new EventModel({
      ...eventInfo
    });
    await new ParticipantProvider().addEventById(participantId, newEvent._id);
    await newEvent.save();

    return newEvent;
  };
  public update = async ({ eventId, eventInfo }: MutationUpdateEventArgs) => {
    const updatedEvent: any = await EventModel.findByIdAndUpdate(
      eventId,
      { ...eventInfo } as any,
      { new: true }
    );
    return updatedEvent;
  };
  public getById = async (eventId: string) =>
    await EventModel.findById(eventId);
  public getAllByCategory = async ({
    participantId,
    categoryId
  }: QueryEventsByCategoryArgs) => {
    const { events }: any = await new ParticipantProvider().getById(
      participantId
    );
    const eventList = await Promise.all(
      events.map(
        async (eventId: string) => await EventModel.findOne({ _id: eventId })
      )
    );

    // Fixme: null also coming
    return _filter(eventList, (event: any) =>
      _includes(event.categories, categoryId)
    );
  };
  public updateCategory = async ({
    categories,
    eventId
  }: MutationUpdateServiceByEventArgs) => {
    return await EventModel.findByIdAndUpdate(eventId, { categories } as any);
  };
  public getEventsByCategory = async (participantId: string) => {
    const { events }: any = await new ParticipantProvider().getById(
      participantId
    );
    const eventList = await Promise.all(
      events.map(async (eventId: string) => await EventModel.findById(eventId))
    );
    const availCategories = _uniq(_flattenDeep(_map(eventList, "categories")));
    const eventByGroup: any = {};
    _forEach(
      availCategories,
      (category: string) =>
        (eventByGroup[category] = _filter(eventList, (event: any) =>
          _includes(event.categories, category)
        ))
    );

    return eventByGroup;
  };
}
