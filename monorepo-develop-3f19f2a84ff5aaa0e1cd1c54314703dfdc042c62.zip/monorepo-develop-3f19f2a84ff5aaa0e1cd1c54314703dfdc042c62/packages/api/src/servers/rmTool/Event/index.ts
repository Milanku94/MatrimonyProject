import model, { Event } from "./Event.model";
import provider from "./Event.provider";
import resolver from "./Event.resolver";

export { Event, model, provider, resolver };
