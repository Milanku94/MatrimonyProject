import {
  MutationCreateEventArgs,
  MutationUpdateEventArgs,
  MutationUpdateServiceByEventArgs,
  QueryEventsArgs,
  QueryEventsByCategoryArgs
} from "../../../generated/rmtool.models";
import { provider as AddressProvider } from "../Address";
import { provider as EventProvider } from "../Event";
import { provider as EventTypeProvider } from "../EventType";
import { provider as ParticipantProvider } from "../Participant";

export default {
  Query: {
    events: async (parent: any, { participantId }: QueryEventsArgs) => {
      const { events }: any = await new ParticipantProvider().getById(
        participantId
      );
      return events.map(
        async (eventId: string) => await new EventProvider().getById(eventId)
      );
    },
    eventsByCategory: async (parent: any, args: QueryEventsByCategoryArgs) =>
      await new EventProvider().getAllByCategory(args)
  },
  Mutation: {
    createEvent: async (_: any, args: MutationCreateEventArgs) =>
      await new EventProvider().add(args),
    updateEvent: async (
      _: any,
      { eventId, eventInfo }: MutationUpdateEventArgs
    ) => await new EventProvider().update({ eventId, eventInfo }),
    updateServiceByEvent: async (
      _: any,
      { categories, eventId }: MutationUpdateServiceByEventArgs
    ) => await new EventProvider().updateCategory({ categories, eventId })
  },
  Event: {
    address: async (root: any) =>
      await new AddressProvider().getById(root.address),
    eventType: async (root: any) => {
      if (root.eventType) {
        const reqEventType: any = await new EventTypeProvider().getById(
          root.eventType
        );
        return reqEventType.name;
      }
      return null;
    },
    categories: async (root: any) => {
      const catForEvent = root.categories.map(async (category: any) => ({
        categoryId: category,
        events: [await new EventProvider().getById(root._id)]
      }));
      return await Promise.all(catForEvent);
    }
  }
};
