/**
 * modified as of requirement
 * Source from  apollo-server-cache-redis (https://www.npmjs.com/package/apollo-server-cache-redis)
 * https://github.com/apollographql/apollo-server/blob/master/packages/apollo-server-cache-redis/src/RedisCache.ts
 */
import {
  KeyValueCacheSetOptions,
  TestableKeyValueCache
} from "apollo-server-caching";
import DataLoader from "dataloader";
import Redis, { RedisOptions } from "ioredis";

export class CustomeRedisCache implements TestableKeyValueCache<string> {
  public readonly read: any;
  public readonly write: any;
  public readonly defaultSetOptions: KeyValueCacheSetOptions = {
    ttl: 300
  };

  private loader: DataLoader<string, string | null>;

  constructor({ read, write }: { read: RedisOptions; write: RedisOptions }) {
    const clientWrite = new Redis(write);
    const clientRead = new Redis(read);
    this.read = clientRead;
    this.write = clientWrite;

    this.loader = new DataLoader(keys => clientRead.mget(...keys), {
      cache: false
    });
  }

  public async set(
    key: string,
    value: string,
    options?: KeyValueCacheSetOptions
  ): Promise<void> {
    const { ttl } = Object.assign({}, this.defaultSetOptions, options);
    if (typeof ttl === "number") {
      await this.write.set(key, value, "EX", ttl);
    } else {
      // We'll leave out the EXpiration when no value is specified.  Of course,
      // it may be purged from the cache for other reasons as deemed necessary.
      await this.write.set(key, value);
    }
  }

  public async get(key: string): Promise<string | undefined> {
    const reply = await this.loader.load(key);
    if (reply !== null) {
      return reply;
    }
    return;
  }

  public async delete(key: string): Promise<boolean> {
    return await this.write.del(key);
  }

  // Drops all data from Redis. This should only be used by test suites ---
  // production code should never drop all data from an end user Redis cache!
  public async flush(): Promise<void> {
    await this.write.flushdb();
  }

  public async close(): Promise<void> {
    await this.write.quit();
    return;
  }
}
