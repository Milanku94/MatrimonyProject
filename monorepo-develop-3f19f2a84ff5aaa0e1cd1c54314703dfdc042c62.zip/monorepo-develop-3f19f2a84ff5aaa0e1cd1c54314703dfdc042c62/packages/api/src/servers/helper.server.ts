import apolloServerResponseCachePlugin from "apollo-server-plugin-response-cache";
import { GraphQLRequestContext } from "apollo-server-types";
import { formatError, GraphQLError } from "graphql";
import ENV from "../config/config.env";
import { logger } from "../services/logger.utils";
import { CustomeRedisCache } from "./customRedisCache.server";
export const apolloRedisCache = () =>
  process.env.NODE_ENV === "development"
    ? null
    : new CustomeRedisCache({
        write: {
          host: ENV.REDIS.MASTER_URL.split(":")[0],
          port: +ENV.REDIS.MASTER_URL.split(":")[1],
          password: ENV.REDIS.PWD
        },
        read: {
          host: ENV.REDIS.SLAVE_URL.split(":")[0],
          port: +ENV.REDIS.SLAVE_URL.split(":")[1],
          password: ENV.REDIS.PWD,
          role: "slave"
        }
      });
export const apolloCachePlugin = ({ sessionId }: { sessionId: string }) =>
  apolloServerResponseCachePlugin({
    sessionId: ({ request }: GraphQLRequestContext) =>
      request.http ? request.http.headers.get(sessionId) || null : null
  });

export const apolloErrorFormatting = (
  { message, path: errPath, ...err }: GraphQLError,
  serverDomain: string
) => {
  // Don't give the specific errors to the client.
  if (err.extensions && err.extensions.exception.code) {
    console.warn(`ER_${serverDomain}`, {
      err,
      code: err.extensions.code || null,
      exCode: err.extensions.exception.code || null,
      exErrNo: err.extensions.exception.errno || null,
      path: errPath || null,
      sqlPath: err.extensions.exception.sqlMessage || null
    });
    return formatError({
      message: "Internal Server error"
    } as GraphQLError);
  }
  console.log(`ER_${serverDomain}`, message, errPath);

  // Otherwise return the original error.  The error can also
  // be manipulated in other ways, so long as it's returned.
  return { message, errPath, err };
};
export const apolloLogPlugin = ({
  loggerName
}: {
  loggerName: "vendorGQL" | "portalGQL";
}) => ({
  serverWillStart() {
    logger[loggerName].info(`Server starting up!`);
  },
  requestDidStart(reqCtx: GraphQLRequestContext) {
    const startTime = new Date().getTime();

    return {
      // parsingDidStart({
      //   request: { variables, query },
      //   queryHash
      // }: GraphQLRequestContext) {
      //   logger[loggerName].info("Parsing started!", { queryHash });
      // },

      // validationDidStart({ ...rest }: GraphQLRequestContext) {
      //   logger[loggerName].info("Validation started!", { queryHash });
      // },

      // didResolveOperation({ operation, operationName }: GraphQLRequestContext) {
      //   logger[loggerName].info(
      //     "Resolved started!",
      //     {
      //       operation: operation?.operation,
      //       operationName,
      //       queryHash
      //     }
      //   );
      // },
      // responseForOperation({
      //   metrics,
      //   response,
      //   source,
      //   queryHash,
      //   request: { variables }
      // }: GraphQLRequestContext) {
      //   logger[loggerName].info("Response operation!", {
      //     queryHash,
      //     source,
      //     variables,
      //     metrics
      //   });
      // },
      didEncounterErrors({ errors, source, queryHash }: GraphQLRequestContext) {
        logger[loggerName].error("Error captured!", {
          source,
          queryHash,
          errors
        });
      },
      willSendResponse({
        metrics,
        response,
        queryHash
      }: GraphQLRequestContext) {
        logger[loggerName].info("Response send!", {
          queryHash,
          responseCacheHit: metrics.responseCacheHit,
          responseTime: new Date().getTime() - startTime,
          response
        });
      }
    };
  }
});
export const apollo401Plugin = () => ({
  requestDidStart: () => ({
    willSendResponse({ errors, response }: any) {
      if (response && response.http) {
        if (
          errors &&
          errors.some(
            (err: GraphQLError) =>
              err.name === "AuthenticationError" ||
              (err.extensions && err.extensions.code === "UNAUTHENTICATED")
          )
        ) {
          response.data = undefined;
          response.http.status = 401;
        }
      }
    }
  })
});
