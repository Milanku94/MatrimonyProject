// import { MutationCreateUserArgs } from "../../../generated/portal.models";
import AuthProvider from "../auth.provider";
import UserAuthModel from "./UserAuth.model";

export default class UserAuthProvider extends AuthProvider {
  public getUser = async (args: any) => {
    return await UserAuthModel.findOne({
      email: args.email
    });
  };

  public add = async (args: any) => {
    const user = await this.getUser(args);
    if (user) {
      return user;
    }
    const { name, email, profilePicture, provider, idByProvider } = args;
    return await new UserAuthModel({
      name,
      email,
      profilePicture,
      provider: [{ provider, id: idByProvider }]
    }).save();
  };
}
