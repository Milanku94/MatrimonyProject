/**
 * Todo: config the table related info by DB
 * @path ie, import { DB_ALIAS_NAME } from "../../../config/config.db";
 *
 */

import { InstanceType, ModelType, prop, Ref, Typegoose } from "typegoose";

const isEmail = (val: string) => {
  return true;
};

export class UserAuth extends Typegoose {
  @prop({ required: true })
  public name: string;

  @prop({
    validate: {
      validator: isEmail,
      message: `{VALUE} is not a valid email`
    }
  })
  public email: string;

  @prop()
  public profilePicture: string;

  @prop()
  public phoneNumber: string;

  @prop()
  public customerID: string;

  @prop()
  public provider: [{ provider: string; id: string }];
}

export default new UserAuth().getModelForClass(UserAuth, {
  schemaOptions: {
    collection: "userAuth",
    shardKey: { _id: 1 },
    timestamps: { createdAt: true, updatedAt: true }
  }
});
