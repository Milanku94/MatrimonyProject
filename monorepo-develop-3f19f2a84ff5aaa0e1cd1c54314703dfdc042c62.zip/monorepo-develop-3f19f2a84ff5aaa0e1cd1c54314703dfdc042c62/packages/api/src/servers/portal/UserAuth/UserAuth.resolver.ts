import { provider as UserAuthProvider } from ".";
import { PortalContext } from "../../../types";

export default {
  UserAuth: {
    profilePicture: async (parent: any) => {
      return { url: parent.profilePicture, slug: parent.profilePicture };
    }
  },
  Mutation: {
    createUser: async (_: any, args: any, context: PortalContext) => {
      return await new UserAuthProvider(context).add(args);
    }
  }
};
