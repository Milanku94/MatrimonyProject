import _flatMap from "lodash/flatMap";
import { QueryGetCityByIdArgs } from "../../../generated/rmtool.models";
import { getSlug, getSlugId, slugify } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";

export default {
  City: {
    slug: (city: any) => getSlug(city),
    slugId: (city: any) => getSlugId(city),
    categories: async ({ id }: any, _: null, ctx: PortalContext) => {
      const categoriesResp = await ctx.axios.get(`/cities/${id}/category/`);
      const categoriesData = categoriesResp.data.data;
      return categoriesData.categories;
    }
  },
  Query: {
    getCities: async (_: null, __: null, context: PortalContext) => {
      const response = await context.axios.get(`/cities/`);
      const citiesByState = response.data.data.stateCities.map(
        ({ cities, stateId, stateName }: any) =>
          cities.map((city: any) => ({ ...city, stateId, stateName }))
      );

      return _flatMap(citiesByState);
    },
    getPopularCities: async (_: null, __: null, context: PortalContext) => {
      const response = await context.axios.get(`/cities/`);
      const popularCities = response.data.data.popularCities;

      return popularCities;
    },
    getCitiesByID: async (
      _: null,
      args: QueryGetCityByIdArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`/cities/${args.cityId}/`);
      return await response.data.data[0];
    },
    getCitiesBySlug: async (_: null, { slug }: any, context: PortalContext) => {
      const response = await context.axios.get(`/cities/`);
      const citiesByState = response.data.data.stateCities.map(
        ({ cities, stateId, stateName }: any) =>
          cities.map((city: any) => ({ ...city, stateId, stateName }))
      );

      return _flatMap(citiesByState).find((t: any) => slugify(t.name) === slug);
    }
  }
};
