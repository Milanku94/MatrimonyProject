// import CityModel from "./City.model";
// import provider from "./City.provider";
import resolver from "./City.resolver";

export { resolver };
