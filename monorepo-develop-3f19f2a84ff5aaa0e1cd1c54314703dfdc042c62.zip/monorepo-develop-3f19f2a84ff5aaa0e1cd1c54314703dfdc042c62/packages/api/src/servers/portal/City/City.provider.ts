// import Axios from"axios"
// import AuthProvider from "../auth.provider";
// import { PortalContext } from '../../../types'

// export default {
//   Query:{
//     Cities : async(_:any,context: PortalContext) => {
//       const response = await context.axios.get('/cities')
//       return await response.data.data
//     }
//   }

// }
