import SearchLogModel from "./SearchLog.model";
import provider from "./SearchLog.provider";
import resolver from "./SearchLog.resolver";

export { SearchLogModel, provider, resolver };
