import { MutationAddSearchLogArgs } from "../../../generated/portal.models";
import AuthProvider from "../auth.provider";
import { SearchLogModel } from "./";

export default class SearchLogProvider extends AuthProvider {
  public addSearchLog = async ({ user, search }: MutationAddSearchLogArgs) => {
    const {
      origin,
      originalUrl,
      os,
      platform,
      browser,
      browserVersion,
      ipAddress,
      isDesktop,
      isSmartTV,
      isTablet,
      isMobile
    } = this.getUserAgent();
    return new SearchLogModel({
      uuid: user.uuid,
      ...(user.userId !== "" && user.userId ? { userId: user.userId } : {}),
      keyword: search.keyword,
      type: search.type,
      city: user.city,
      deviceInfo: {
        device: this.getDeviceInfo({
          isDesktop,
          isSmartTV,
          isTablet,
          isMobile
        }),
        os,
        platform,
        browser,
        browserVersion,
        ipAddress
      },
      moreInfo: {
        section: search.section,
        position: search.position,
        targetUrl: search.targetUrl,
        currentUrl: search.currentUrl || origin + originalUrl
      }
    }).save();
  };
}
