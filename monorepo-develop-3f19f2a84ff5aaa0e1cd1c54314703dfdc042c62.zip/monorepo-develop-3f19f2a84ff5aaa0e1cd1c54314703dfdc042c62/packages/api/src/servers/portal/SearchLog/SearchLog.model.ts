import { prop, Ref, Typegoose } from "typegoose";
import { searchLogType } from "../../../config/config.portal.enum";
import { UserAuth } from "../UserAuth";

interface ClientDevice {
  device: string;
  os: string;
  platform: string;
  browser: string;
  browserVersion: string;
  ipAddress: string;
}
interface AutoSuggestAction {
  section: string;
  position: number;
  targetUrl: string;
  currentUrl: string;
}

export class SearchLog extends Typegoose {
  @prop()
  public uuid: string;
  @prop({ ref: { name: UserAuth } })
  public userId?: Ref<UserAuth>;

  @prop({ default: searchLogType.SEARCH })
  public type: searchLogType;
  @prop()
  public keyword: string;
  @prop()
  public city: string;

  @prop()
  public deviceInfo?: ClientDevice;
  @prop()
  public moreInfo?: AutoSuggestAction;
}

export default new SearchLog().getModelForClass(SearchLog, {
  schemaOptions: {
    shardKey: { _id: 1 },
    collection: "searchLog",
    timestamps: { createdAt: true }
  }
});
