import { provider as SearchLogProvider } from ".";
import { MutationAddSearchLogArgs } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";

export default {
  Mutation: {
    addSearchLog: async (
      _: any,
      args: MutationAddSearchLogArgs,
      context: PortalContext
    ) => await new SearchLogProvider(context).addSearchLog(args)
  }
};
