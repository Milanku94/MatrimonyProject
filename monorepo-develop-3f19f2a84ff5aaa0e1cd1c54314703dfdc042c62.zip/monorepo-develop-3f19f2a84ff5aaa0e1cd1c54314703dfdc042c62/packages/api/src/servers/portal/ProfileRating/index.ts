import ProfileRatingModel from "./ProfileRating.model";
import provider from "./ProfileRating.provider";
import resolver from "./ProfileRating.resolver";

export { ProfileRatingModel, provider, resolver };
