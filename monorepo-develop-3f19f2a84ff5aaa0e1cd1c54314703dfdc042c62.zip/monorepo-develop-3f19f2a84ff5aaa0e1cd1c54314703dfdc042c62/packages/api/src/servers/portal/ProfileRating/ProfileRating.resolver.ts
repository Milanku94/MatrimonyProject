import { provider as ProfileRatingProvider } from ".";
import { PortalContext } from "../../../types";

export default {
  Query: {
    ProfileRating: async (_: null, args: null, context: PortalContext) =>
      await new ProfileRatingProvider(context).getAll()
  }
};
