import BannerModel from "./Banner.model";
import provider from "./Banner.provider";
import resolver from "./Banner.resolver";

export { BannerModel, provider, resolver };
