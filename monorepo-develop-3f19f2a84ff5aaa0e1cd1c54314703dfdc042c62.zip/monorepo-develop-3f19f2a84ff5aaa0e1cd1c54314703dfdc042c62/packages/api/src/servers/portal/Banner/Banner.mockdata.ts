export const premiumBanners = [
  // R S Brothers
  {
    city: "hyderabad", // Hyderabad
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/rsbros-jwl_280x130.jpg"
    },
    redirect: "/hyderabad/wedding-jewellers/r-s-brothers-dfolhwllcxh/"
  },
  {
    city: "vijayawada", // Vijayawada
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/rsbros-jwl_280x130.jpg"
    },
    redirect: "/vijayawada/wedding-jewellers/r-s-brothers-oopahwhhcntl/"
  },
  {
    city: "hyderabad", // Hyderabad
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/rsbros-jwl_280x130.jpg"
    },
    redirect: "/hyderabad/wedding-wear/r-s-brothers-oopahwhhcntl/"
  },
  {
    city: "vijayawada", // Vijayawada
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/rsbros-jwl_280x130.jpg"
    },
    redirect: "/vijayawada/wedding-wear/r-s-brothers-hfotystdkrpn/"
  },

  // South India Shopping Mall
  {
    city: "rajahmundry", // Rajahmundry
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm_280x130.jpg"
    },
    redirect: "/rajahmundry/wedding-wear/south-india-shopping-mall-vhtaokiykon/"
  },
  {
    city: "guntur", // Guntur
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm2_280x130.jpg"
    },
    redirect: "/guntur/wedding-wear/south-india-shopping-mall-vhtaokiykzf/"
  },
  {
    city: "hyderabad", // Hyderabad
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm_280x130.jpg"
    },
    redirect: "/hyderabad/wedding-wear/south-india-shopping-mall-zytdoqfvqxa/"
  },
  {
    city: "karimnagar", // Karimnagar
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm2_280x130.jpg"
    },
    redirect: "/karimnagar/wedding-wear/south-india-shopping-mall-vhtaokiykxx/"
  },
  {
    city: "vijayawada", // Vijayawada
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm_280x130.jpg"
    },
    redirect: "/vijayawada/wedding-wear/south-india-shopping-mall-nfoaxqarqvpu/"
  },
  {
    city: "nellore", // Nellore
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm2_280x130.jpg"
    },
    redirect: "/nellore/wedding-wear/south-india-shopping-mall-jioaxkarkviy/"
  },
  {
    city: "visakhapatnam", // Visakhapatnam
    category: "wedding-boutiques",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/southindia-sm_280x130.jpg"
    },
    redirect:
      "/visakhapatnam/wedding-wear/south-india-shopping-mall-rhtaoqiyqryl/"
  },
  {
    city: "mysore", // Mysore
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/malabar-1.jpg"
    },
    redirect: "/mysore/wedding-jewellers/malabar-gold-diamond-oltfxkhhqta/"
  },
  {
    city: "hubli", // Hubli
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/malabar-1.jpg"
    },
    redirect: "/hubli/wedding-jewellers/malabar-gold-diamond-oltfxkhhqta/"
  },
  {
    city: "mangalore", // Mangalore
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/malabar-1.jpg"
    },
    redirect: "/mangalore/wedding-jewellers/malabar-gold-diamond-oltfxkhhqta/"
  },
  {
    city: "bangalore", // Bangalore
    category: "wedding-jewellers",
    image: {
      url: "//www.weddingbazaar.com/assets/banners/malabar-1.jpg"
    },
    redirect: "/bangalore/wedding-jewellers/malabar-gold-diamond-oltfxkhhqta/"
  }
];
