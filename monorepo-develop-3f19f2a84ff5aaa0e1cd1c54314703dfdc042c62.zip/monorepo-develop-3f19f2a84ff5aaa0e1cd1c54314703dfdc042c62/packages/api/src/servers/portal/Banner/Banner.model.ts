/**
 * Todo: config the table related info by DB
 * @path ie, import { DB_ALIAS_NAME } from "../../../config/config.db";
 *
 */
export default {
  table: "TABLE_NAME",
  fields: {
    columnAliasName: "ACTUAL_COL_NAME"
  }
};
