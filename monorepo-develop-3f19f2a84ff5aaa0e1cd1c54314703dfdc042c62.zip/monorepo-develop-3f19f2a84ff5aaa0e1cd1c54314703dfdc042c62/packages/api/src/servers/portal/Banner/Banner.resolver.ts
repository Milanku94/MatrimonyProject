import { provider as BannerProvider } from ".";
import { premiumBanners } from "../Banner/Banner.mockdata";

export default {
  Query: {
    getBannersByCityCategory: async (_: null, { category, city }: any) =>
      premiumBanners.filter(
        (banner: any) => banner.city === city && banner.category === category
      )
  }
};
