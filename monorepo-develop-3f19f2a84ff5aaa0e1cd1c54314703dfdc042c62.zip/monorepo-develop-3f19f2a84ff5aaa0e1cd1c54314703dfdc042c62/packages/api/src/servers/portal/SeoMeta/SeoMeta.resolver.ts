import { QuerySeoMetaArgs } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";

export default {
  SeoMeta: {
    metaTitle: ({ meta_title }: any) => meta_title
  },
  Query: {
    seoMeta: async (
      _: null,
      { url }: QuerySeoMetaArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post(`/seo_meta/`, { url });
      return response.data.data;
    }
  }
};
