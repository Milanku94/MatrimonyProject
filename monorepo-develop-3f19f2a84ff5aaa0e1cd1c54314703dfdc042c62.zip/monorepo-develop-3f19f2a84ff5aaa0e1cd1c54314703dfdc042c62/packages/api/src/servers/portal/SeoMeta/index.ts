import SeoMetaModel from "./SeoMeta.model";
import provider from "./SeoMeta.provider";
import resolver from "./SeoMeta.resolver";

export { SeoMetaModel, provider, resolver };
