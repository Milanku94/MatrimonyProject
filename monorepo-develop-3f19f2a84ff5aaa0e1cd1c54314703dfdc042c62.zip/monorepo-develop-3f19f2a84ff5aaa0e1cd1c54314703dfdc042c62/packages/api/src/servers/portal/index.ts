import { ApolloServer, Config, gql } from "apollo-server-express";
import { GraphQLError, GraphQLScalarType, Kind } from "graphql";
import { makeExecutableSchema } from "graphql-tools";
import GraphQLJSON from "graphql-type-json";
import { fileLoader, mergeResolvers, mergeTypes } from "merge-graphql-schemas";
import Path from "path";
import ENV from "../../config/config.env";
import {
  blogPostView,
  blogStatus,
  blogType,
  offersType,
  userRole
} from "../../config/config.portal.enum";
import { CategoryApi, CityApi, ProfileApi } from "../../dataSource/portalApis";
import { VendorAuthDirective } from "../../directive/vendorAuth.directive";
import { decodePortalJWT } from "../../services/jwt.utils";
import { enumToResolver, enumToSchema } from "../../services/utils";
import { PortalContext } from "../../types";
import {
  apolloCachePlugin,
  apolloErrorFormatting,
  apolloLogPlugin,
  apolloRedisCache
} from "../helper.server";
import { axios } from "./axios";

const typesArray = fileLoader(Path.join(__dirname, "./**/*.gql"));
const resolversArray = fileLoader(Path.join(__dirname, "./**/*.resolver.*"));

const typeDef = gql`
  directive @auth(
    requires: [Role],
  ) on OBJECT | FIELD_DEFINITION
  directive @cacheControl(
    maxAge: Int,
    scope: CacheControlScope
  ) on OBJECT | FIELD_DEFINITION
  enum CacheControlScope {
    PUBLIC
    PRIVATE
  }

  scalar JSON
  scalar DateTime

  enum Role{
    ${enumToSchema(userRole)}
  },
  enum UserRole{
    ${enumToSchema(userRole)}
  },
  enum BlogType{
    ${enumToSchema(blogType)}
  }
  enum OffersType{
    ${enumToSchema(offersType)}
  }
  
  enum BlogStatus{
    ${enumToSchema(blogStatus)}
  }
  enum BlogPostView{
    ${enumToSchema(blogPostView)}
  }
`;

const resolver = {
  JSON: GraphQLJSON,
  UserRole: enumToResolver(userRole),
  BlogStatus: enumToResolver(blogStatus),
  BlogType: enumToResolver(blogType),
  OffersType: enumToResolver(offersType),
  BlogPostView: enumToResolver(blogPostView),
  DateTime: new GraphQLScalarType({
    name: "DateTime",
    description: "DateTime custom scalar type",
    parseValue(value) {
      return new Date(value); // value from the client
    },
    serialize(value) {
      return value instanceof Date ? value.getTime() : null; // value sent to the client
    },
    parseLiteral(ast: any) {
      if (ast.kind === Kind.INT || ast.kind === Kind.FLOAT) {
        return new Date(parseInt(ast.value, 10)); // ast value is always in string format
      }
      return null;
    }
  })
};

const typeDefs = mergeTypes([typeDef, ...typesArray], { all: true });
const resolvers = mergeResolvers([resolver, ...resolversArray]);
export const mbPortalServer = ({
  mBazaar,
  mBazaarServices
}: Omit<PortalContext, "axios" | "user" | "userAgent" | "dataSources">) =>
  new ApolloServer({
    playground: !ENV.HIDE_APOLLO_PLAYGROUND,
    introspection: !ENV.HIDE_APOLLO_PLAYGROUND,
    schema: makeExecutableSchema({
      typeDefs,
      resolvers,
      schemaDirectives: {
        auth: VendorAuthDirective
      }
    }),
    cache: apolloRedisCache(),
    cacheControl: { defaultMaxAge: 15 },
    dataSources: () => ({ CategoryApi, CityApi, ProfileApi }),
    plugins: [
      apolloCachePlugin({ sessionId: "uuid" }),
      ...(ENV.GQL_QUERY_LOG
        ? [() => apolloLogPlugin({ loggerName: "portalGQL" })]
        : [])
    ],
    formatError: (error: GraphQLError) =>
      apolloErrorFormatting(error, "PORTAL_GQL"),
    context: async ({ req }: any) => {
      const authorization = req.headers.authorization;
      const user: any = decodePortalJWT(authorization);
      const {
        headers: { origin, referer, cookie },
        useragent: {
          isBot,
          os,
          platform,
          isDesktop,
          isSmartTV,
          isTablet,
          isMobile,
          isAndroid,
          isMac,
          isBlackberry,
          isKindleFire,
          browser,
          version: browserVersion
        },
        ip: ipAddress,
        ips,
        originalUrl
      } = req;
      return {
        mBazaar,
        axios,
        mBazaarServices,
        user,
        userAgent: {
          isBot,
          os,
          platform,
          isDesktop,
          isSmartTV,
          isTablet,
          isMobile,
          isAndroid,
          isMac,
          isBlackberry,
          isKindleFire,
          browser,
          browserVersion,
          ips,
          ipAddress,
          originalUrl,
          origin,
          referer,
          cookie
        }
      };
    }
  } as Config);
