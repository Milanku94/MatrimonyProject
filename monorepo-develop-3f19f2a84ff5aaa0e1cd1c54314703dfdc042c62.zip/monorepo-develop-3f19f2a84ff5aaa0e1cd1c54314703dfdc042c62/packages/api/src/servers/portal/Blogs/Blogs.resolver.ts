import { provider as BlogsProvider } from ".";
import {
  Blogs,
  QueryGetBlogsArgs,
  QueryGetBlogsByIdArgs
} from "../../../generated/portal.models";
import { getSlug, getSlugId } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";
import { blogsHomePage } from "./Blogs.mockdata";

export default {
  Blogs: {
    slug: async (parent: Blogs) => {
      return getSlug(parent);
    },
    slugId: async (parent: Blogs) => {
      return getSlugId(parent);
    }
  },
  Query: {
    getBlogs: async (
      _: null,
      { page = 1, limit = 10 }: QueryGetBlogsArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`blogs/p/${page}/r/${limit}/`);
      return await response.data.data;
    },
    getBlogsByID: async (
      _: null,
      { blogID }: QueryGetBlogsByIdArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`blogs/${blogID}/`);
      return await response.data.data[0];
    },
    getTotalBlogsCount: async (_: null, __: null, context: PortalContext) => {
      const response = await context.axios.get(`blogs/p/1/r/10/`);
      return await response.headers["x-total-items"];
    },
    getHomeBlogs: async (
      _: null,
      { limit = 5 }: any,
      context: PortalContext
    ) => {
      return await blogsHomePage.map(async ({ slugId, image }) => {
        const response = await context.axios.get(
          `blogs/${slugId.split("-").slice(-1)}/`
        );
        if (response.data.status === "Error") {
          return null;
        }
        return await { ...response.data.data, image: { url: image } };
      });
    },
    getBlogsByCategoryID: async (
      _: null,
      { categoryId }: any,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`blogs/c/${categoryId}/`);
      return await response.data.data;
    }
  }
};
