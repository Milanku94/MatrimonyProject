import BlogsModel from "./Blogs.model";
import provider from "./Blogs.provider";
import resolver from "./Blogs.resolver";

export { BlogsModel, provider, resolver };
