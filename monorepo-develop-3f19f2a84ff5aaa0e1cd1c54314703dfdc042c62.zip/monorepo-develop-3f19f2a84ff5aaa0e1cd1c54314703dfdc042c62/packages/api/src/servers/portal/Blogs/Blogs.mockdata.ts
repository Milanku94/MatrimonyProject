export const blogsHomePage = [
  {
    slugId:
      "the-different-styles-of-draping-a-bridal-saree-in-an-indian-wedding-151",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/3.png"
  },
  {
    slugId:
      "what-to-do-on-the-day-week-and-the-month-before-your-wedding-groom-edition-147",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/7.png"
  },
  {
    slugId: "15-european-honeymoon-destinations-144",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/1.png"
  },
  {
    slugId:
      "interested-in-wedding-photography-a-guide-for-amateur-photographers-117",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/6.png"
  },
  {
    slugId: "a-brief-description-of-the-unique-ritual-of-mangalasnanam-74",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/2.png"
  },
  {
    slugId: "what-is-a-nichayathartham-ceremony-75",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/4.png"
  },
  {
    slugId: "the-banana-leaf-and-its-importance-in-south-indian-weddings-56",
    image:
      "https://s3.ap-south-1.amazonaws.com/content.matrimonybazaar.com/webpage/5.png"
  }
];
