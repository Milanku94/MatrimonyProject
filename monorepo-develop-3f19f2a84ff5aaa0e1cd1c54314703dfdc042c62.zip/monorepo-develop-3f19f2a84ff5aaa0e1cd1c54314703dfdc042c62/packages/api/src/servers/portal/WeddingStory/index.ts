import WeddingStoryModel from "./WeddingStory.model";
import provider from "./WeddingStory.provider";
import resolver from "./WeddingStory.resolver";

export { WeddingStoryModel, provider, resolver };
