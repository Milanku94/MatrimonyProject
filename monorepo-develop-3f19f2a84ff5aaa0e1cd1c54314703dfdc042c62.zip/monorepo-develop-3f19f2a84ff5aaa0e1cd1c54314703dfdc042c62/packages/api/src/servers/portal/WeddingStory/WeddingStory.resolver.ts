import { provider as WeddingStoryProvider } from ".";
import {
  QueryGetWeddingStoriesArgs,
  QueryGetWeddingStoriesByIdArgs,
  WeddingStory,
  WeddingStoryProfiles
} from "../../../generated/portal.models";
import { getSlug, getSlugId, slugify } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";

export default {
  WeddingStory: {
    slug: async (parent: WeddingStory) => {
      return getSlug({
        id: parent.id,
        slug: `${parent.couple.bride}-${parent.couple.groom}`
      });
    },
    slugId: async (parent: WeddingStory) => {
      return getSlugId({
        id: parent.id,
        slug: `${parent.couple.bride}-${parent.couple.groom}`
      });
    }
  },
  WeddingStoryProfiles: {
    profilePhoto: async (parent: any) => {
      return parent["profile-photo"];
    },
    id: async (parent: WeddingStoryProfiles) => {
      return slugify(`${parent.name} ${parent.category!.needName || ""}`);
    },
    slug: async (parent: WeddingStoryProfiles) => {
      return slugify(`${parent.name} ${parent.category!.needName || ""}`);
    },
    slugId: async (parent: WeddingStoryProfiles) => {
      return slugify(`${parent.name} ${parent.category!.needName || ""}`);
    }
  },
  WeddingStoryComment: {
    customerStory: async (parent: any) => {
      return parent["customer-story"] || null;
    },
    profileStory: async (parent: any) => {
      return parent["profile-story"] || null;
    }
  },
  Query: {
    getWeddingStories: async (
      _: null,
      { page = 1, limit = 10 }: QueryGetWeddingStoriesArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`stories/p/${page}/r/${limit}/`);
      return await response.data.data;
    },
    getWeddingStoriesByID: async (
      _: null,
      { id }: QueryGetWeddingStoriesByIdArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`stories/${id}/`);

      return await response.data.data[0];
    },
    getTotalWeddingCount: async (_: null, __: null, context: PortalContext) => {
      const response = await context.axios.get(`stories/p/1/r/10/`);
      return await response.headers["x-total-items"];
    }
  }
};
