import Knex from "knex";
import { userRole } from "../../config/config.portal.enum";
import { PortalContext, PortalUserAgent, PortalUserContext } from "../../types";

export default class AuthProvider {
  public context: PortalContext;
  public actualDB: Knex;
  public servicesDB: Knex;
  public userAgent: PortalUserAgent;
  public readonly user: PortalUserContext;

  constructor(context: PortalContext) {
    this.context = context;
    this.actualDB = context.mBazaar;
    this.servicesDB = context.mBazaarServices;
    this.userAgent = context.userAgent;
    this.user = this.context.user;
  }
  public getUserId = () => this.user.mailId;
  public getUserAgent = () => this.userAgent;
  public getDeviceInfo = (devices: any) =>
    deviceMeta[
      Object.keys(devices).find((deviceKey: any) => devices[deviceKey]) ||
        "default"
    ];
  public isUserCanDelete = () =>
    this.user && [userRole.EDITOR].includes(this.user.role);
  public isUserCanEdit = () =>
    this.user && [userRole.AUTHOR, userRole.EDITOR].includes(this.user.role);
  public isUserCanReview = () =>
    this.user && [userRole.EDITOR].includes(this.user.role);
}
const deviceMeta: any = {
  // Note: For devices
  isDesktop: "Desktop",
  isSmartTV: "SmartTv",
  isTablet: "Tablet",
  isMobile: "Mobile",
  // Note: For device Types
  isAndroid: "Android",
  isMac: "Mac",
  isKindleFire: "KindleFire",
  isBlackberry: "Blackberry",

  default: "Others"
};
