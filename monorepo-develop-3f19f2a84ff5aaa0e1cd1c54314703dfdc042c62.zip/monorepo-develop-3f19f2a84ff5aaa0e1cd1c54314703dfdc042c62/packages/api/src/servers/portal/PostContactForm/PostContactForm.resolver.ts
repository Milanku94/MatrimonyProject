import { provider as PostContactFormProvider } from ".";
import {
  MutationPostContactArgs,
  QueryDecryptWhatsappUrlArgs
} from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
import { unCachedAxios } from "../axios";

// Todo: this kind of meta infomation should be store in common place
const enquirySrc: { [key: string]: number } = {
  home: 49,
  listing: 51,
  profile: 52,
  sempage: 74,
  default: 2001,
  waportal: 41,
  wasem: 47
};

export default {
  Query: {
    decryptWhatsappUrl: async (
      _: any,
      args: QueryDecryptWhatsappUrlArgs,
      ctx: PortalContext
    ) => {
      const {
        vendorId,
        vendorType,
        mobileNumber
      } = new PostContactFormProvider(ctx).decryptProfileSlug(args);
      const response = await unCachedAxios.get(
        `https://api.weddingbazaar.com/v1.0/whatsapp_info/id/${vendorId}/type/${vendorType}/`
      );
      return await {
        vendorId,
        vendorType,
        mobileNumber,
        ...response.data.data
      };
    }
  },
  Mutation: {
    postContact: async (
      _: null,
      { postData }: MutationPostContactArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post(`leads/basic/`, {
        ...postData,
        enquirySource: enquirySrc[postData.enquirySource] || enquirySrc.default
      });

      return await response.data.data;
    }
  }
};
