import { hashIds } from "../../../dataSource/vendor";
import { QueryDecryptWhatsappUrlArgs } from "../../../generated/portal.models";
import AuthProvider from "../auth.provider";
export default class PostContactFormProvider extends AuthProvider {
  public getAll = async () => {
    return testData;
  };

  public decryptProfileSlug = ({
    urlId
  }: QueryDecryptWhatsappUrlArgs): {
    vendorId: number;
    vendorType: number;
    mobileNumber: number;
  } => {
    const [vendorId, vendorType, mobileNumber]: any = hashIds.decrypt(urlId);
    return { vendorId, vendorType, mobileNumber };
  };
}
const testData = [
  {
    name: "test data"
  }
];
