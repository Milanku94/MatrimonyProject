import {
  arrayProp,
  InstanceType,
  ModelType,
  prop,
  Ref,
  Typegoose
} from "typegoose";

interface InquriesAttribute {
  name: string;
  selected: string;
}

export class LatestInquries extends Typegoose {
  @prop()
  public name: string;
  @prop()
  public city: string;
  @prop()
  public category: string;
  @prop()
  public date: Date;
  @prop()
  public attributes: InquriesAttribute[];
}

export default new LatestInquries().getModelForClass(LatestInquries, {
  schemaOptions: {
    collection: "latestInquries",
    shardKey: { _id: 1 },
    timestamps: { createdAt: true, updatedAt: true }
  }
});
