import { provider as LatestInquriesProvider } from ".";
import { PortalContext } from "../../../types";
import { batchGenerateInquiry } from "./GenerateInquries";

export default {
  Query: {
    getLatestInquries: async (
      _: null,
      { category, city, limit = 5 }: any,
      context: PortalContext
    ) => {
      return await new LatestInquriesProvider(context).getInquries({
        category,
        city
      });
    },
    generateInquiries: async () => {
      try {
        await batchGenerateInquiry({ mode: "past" });
      } catch (e) {
        console.log(e);
        return false;
      }
      return true;
    }
  }
};
