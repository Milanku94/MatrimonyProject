import faker from "faker";
import { slugify } from "../../../services/slugify.utils";
import { axios } from "./../axios";
import LatestInquriesModel from "./LatestInquries.model";
faker.locale = "en_IND";

export interface GenerateInquiryProps {
  mode?: "past" | "future";
}

export const generateInquiry = async ({
  mode = "future"
}: GenerateInquiryProps) => {
  const cities = await (await axios.get(`/cities/`)).data.data;
  const selectedCity: any = faker.random.arrayElement(cities);
  const selectedCategory: any = faker.random.arrayElement(
    selectedCity.categories
  );
  const selectedCategoryDetails: any = await (
    await axios.get(`/categories/${selectedCategory.id}/`)
  ).data.data[0];
  const attributes = selectedCategoryDetails.attributes
    .filter((attribute: any) => !!attribute.display.form)
    .map((attribute: any) => ({
      name: attribute.name,
      selected: (faker.random.arrayElement(attribute.options) as any).name
    }));

  const date1 = new Date();
  const date2 = new Date(date1);
  if (mode === "future") {
    date2.setDate(date2.getDate() + 1);
  } else {
    date1.setDate(date1.getDate() - 1);
  }
  return new LatestInquriesModel({
    name: faker.name.firstName().slice(0, 3) + "****",
    city: slugify(selectedCity.name),
    category: slugify(selectedCategory.name),
    date: faker.date.between(date1, date2),
    attributes
  }).save();
};

// Verify on mongo with the following query:
//
// db.LatestInquries.aggregate([
//   {
//     $match: {
//       date: { $lte:  new Date() },
//     }
//   },
//   { "$group": {
//       "_id": {
//           "city": "$city",
//           "category": "$category",
//           "dateLteNow": "$dateLteNow"
//       },
//       "count": { "$sum": 1 }
//     }
//   },
//   { "$sort": { "count": -1 } },
//   { "$limit": 3 }
// ])

export const batchGenerateInquiry = async ({
  mode = "future"
}: GenerateInquiryProps) => {
  for (let i = 0; i < 100; i++) {
    await generateInquiry({ mode });
  }
};
