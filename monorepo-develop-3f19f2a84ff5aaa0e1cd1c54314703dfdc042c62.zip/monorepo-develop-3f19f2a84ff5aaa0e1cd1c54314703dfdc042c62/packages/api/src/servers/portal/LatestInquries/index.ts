import { generateInquiry } from "./GenerateInquries";
import LatestInquriesModel from "./LatestInquries.model";
import provider from "./LatestInquries.provider";
import resolver from "./LatestInquries.resolver";
export { LatestInquriesModel, provider, resolver, generateInquiry };
