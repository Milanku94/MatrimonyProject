import AuthProvider from "../auth.provider";
import LatestInquriesModel from "./LatestInquries.model";
export default class LatestInquriesProvider extends AuthProvider {
  public getInquries = async ({ city, category }: any) => {
    return await LatestInquriesModel.find({
      city,
      category,
      date: { $lt: (new Date().getTime() as unknown) as Date }
    })
      .sort({ date: -1 })
      .limit(3);
  };
}
