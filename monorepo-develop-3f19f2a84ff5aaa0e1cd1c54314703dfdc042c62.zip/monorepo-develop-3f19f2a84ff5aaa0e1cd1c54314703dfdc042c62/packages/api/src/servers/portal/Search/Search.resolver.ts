import { QuerySearchArgs } from "../../../generated/portal.models";
import { slugify } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";

export default {
  Query: {
    search: async (
      _: any,
      { postData: { cityId, freeText } }: QuerySearchArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post(`search/`, {
        city_id: cityId,
        free_txt: freeText
      });
      return await response.data.data;
    },
    autoSuggest: async (
      _: null,
      { postData: { cityId, freeText } }: QuerySearchArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post(`autosearch/`, {
        city_id: cityId,
        free_txt: freeText
      });
      return response.data.data;
    }
  },
  AutoSuggestAttribute: {
    id: ({ id, option_id }: any) => `${id}_${option_id}`,
    attributeId: ({ id }: any) => id,
    categorySlug: ({ categoryName }: any) => slugify(categoryName),
    optionValue: ({ option_value }: any) => option_value,
    optionId: ({ option_id }: any) => option_id
  }
};
