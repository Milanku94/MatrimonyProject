import AuthProvider from "../auth.provider";

export default class SearchProvider extends AuthProvider {
  public getAll = async () => {
    return testData;
  };
}
const testData = [
  {
    name: "test data"
  }
];
