import { MetaDetails } from "../../../generated/portal.models";

export default {
  Query: {
    MetaDetails: async ({
      title = "Title",
      description = "Description",
      ...parent
    }: MetaDetails) => (
      console.log("parent", parent),
      {
        title,
        description,
        ...parent
      }
    )
  }
};
