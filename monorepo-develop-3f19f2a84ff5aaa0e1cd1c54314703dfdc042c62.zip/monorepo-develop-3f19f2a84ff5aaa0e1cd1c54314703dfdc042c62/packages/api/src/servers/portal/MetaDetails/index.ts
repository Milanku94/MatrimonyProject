import MetaDetailsModel from "./MetaDetails.model";
import provider from "./MetaDetails.provider";
import resolver from "./MetaDetails.resolver";

export { MetaDetailsModel, provider, resolver };
