import { Media } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";

export default {
  Media: {
    slug: (parent: any) => parent.slug || parent.url
  },
  Query: {
    Media: async (parent: Media, __: null, context: PortalContext) => parent
  }
};
