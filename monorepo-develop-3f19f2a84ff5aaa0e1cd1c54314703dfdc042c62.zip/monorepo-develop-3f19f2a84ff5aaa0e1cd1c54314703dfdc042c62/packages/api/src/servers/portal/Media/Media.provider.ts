import AuthProvider from "../auth.provider";

export default class MediaProvider extends AuthProvider {
  public getAll = async () => {
    return testData;
  };
}
const testData = [
  {
    name: "test data"
  }
];
