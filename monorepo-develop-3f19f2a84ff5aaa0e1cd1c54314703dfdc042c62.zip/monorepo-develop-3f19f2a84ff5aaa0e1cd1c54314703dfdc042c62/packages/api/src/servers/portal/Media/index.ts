import MediaModel from "./Media.model";
import provider from "./Media.provider";
import resolver from "./Media.resolver";

export { MediaModel, provider, resolver };
