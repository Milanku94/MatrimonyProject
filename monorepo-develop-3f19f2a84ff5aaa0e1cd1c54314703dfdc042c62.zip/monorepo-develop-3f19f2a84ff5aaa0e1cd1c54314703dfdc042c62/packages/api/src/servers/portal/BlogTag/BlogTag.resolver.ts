import { BlogTagProvider } from ".";
import {
  MutationCreateBlogTagArgs,
  MutationDeleteBlogTagArgs,
  MutationPublishBlogTagArgs,
  MutationUpdateBlogTagArgs,
  QueryBlogTagArgs,
  QueryBlogTagByIdArgs
} from "../../../generated/portal.models";
import { PortalContext } from "../../../types";

export const blogTagAdminResolverShare = {
  canReview: (parent: any, _: null, ctx: PortalContext) =>
    new BlogTagProvider(ctx).isUserCanReview(),
  canEdit: (parent: any, _: null, ctx: PortalContext) =>
    new BlogTagProvider(ctx).isUserCanEdit(),
  canDelete: (parent: any, _: null, ctx: PortalContext) =>
    new BlogTagProvider(ctx).isUserCanDelete()
};

export default {
  Query: {
    blogTag: async (_: null, args: QueryBlogTagArgs, ctx: PortalContext) =>
      await new BlogTagProvider(ctx).getBlogTag(args),
    blogTagById: async (
      _: null,
      args: QueryBlogTagByIdArgs,
      ctx: PortalContext
    ) => await new BlogTagProvider(ctx).getBlogTagById(args)
  },
  Mutation: {
    createBlogTag: async (
      _: null,
      args: MutationCreateBlogTagArgs,
      ctx: PortalContext
    ) => await new BlogTagProvider(ctx).createBlogTag(args),

    updateBlogTag: async (
      _: null,
      args: MutationUpdateBlogTagArgs,
      ctx: PortalContext
    ) => await new BlogTagProvider(ctx).updateBlogTag(args),
    publishBlogTag: async (
      _: null,
      args: MutationPublishBlogTagArgs,
      ctx: PortalContext
    ) => await new BlogTagProvider(ctx).publishBlogTag(args),
    deleteBlogTag: async (
      _: null,
      args: MutationDeleteBlogTagArgs,
      ctx: PortalContext
    ) => await new BlogTagProvider(ctx).deleteBlogTag(args)
  },
  BlogAccessibility: {
    __resolveType() {
      return null;
    }
  },
  BlogTagAdmin: {
    ...blogTagAdminResolverShare
  }
};
