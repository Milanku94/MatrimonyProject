import { prop, Typegoose } from "typegoose";
import { blogStatus } from "../../../config/config.portal.enum";

export class BlogTag extends Typegoose {
  @prop()
  public slug: string; // - slugified title
  @prop()
  public name: string; // - name of tag
  @prop()
  public description: string; // - description of tag
  @prop()
  public metaTitle: string;
  @prop()
  public metaDescription: string;
  @prop()
  public metaKeywords: string;
  @prop({ default: blogStatus.REVIEW })
  public status: blogStatus; // - boolean flag to keep track of published posts
  @prop()
  public publishedBy: string;
  @prop()
  public createdBy: string;
}

export const BlogTagModel = new BlogTag().getModelForClass(BlogTag, {
  schemaOptions: {
    shardKey: { _id: 1 },
    collection: "blogTag",
    timestamps: { createdAt: true, updatedAt: true }
  }
});
