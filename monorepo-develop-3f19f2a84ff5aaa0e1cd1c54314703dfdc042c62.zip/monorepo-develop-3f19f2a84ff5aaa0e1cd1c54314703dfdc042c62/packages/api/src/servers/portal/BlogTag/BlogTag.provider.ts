import { snakeCase as _snakecase } from "lodash";
import { blogStatus } from "../../../config/config.portal.enum";
import {
  BlogPostView,
  BlogStatus,
  MutationCreateBlogTagArgs,
  MutationDeleteBlogTagArgs,
  MutationPublishBlogTagArgs,
  MutationUpdateBlogTagArgs,
  QueryBlogTagArgs,
  QueryBlogTagByIdArgs
} from "../../../generated/portal.models";
import AuthProvider from "../auth.provider";
import { BlogTagModel } from "./";

export default class BlogTagProvider extends AuthProvider {
  public getBlogTag = async ({
    status = BlogStatus.Published,
    viewAs = BlogPostView.Public
  }: QueryBlogTagArgs) => {
    const conditionObj: any = {
      status
    };
    if (viewAs !== BlogPostView.Public) {
      if (viewAs !== BlogPostView.Author) {
        conditionObj.createdBy = this.getUserId();
      }
      if (viewAs !== BlogPostView.Editor) {
        conditionObj.publishedBy = this.getUserId();
      }
    }
    return await BlogTagModel.find(conditionObj);
  };
  public getBlogTagById = async ({ blogTagId }: QueryBlogTagByIdArgs) =>
    await BlogTagModel.findById(blogTagId);
  public getBlogTagByIds = async ({ blogTagIds }: { blogTagIds: any[] }) =>
    await BlogTagModel.find({ _id: { $in: blogTagIds } });
  public createBlogTag = async ({ tag }: MutationCreateBlogTagArgs) =>
    await new BlogTagModel({
      createdBy: this.getUserId(),
      slug: _snakecase(tag.name),
      ...tag
    }).save();
  public publishBlogTag = async ({ tagId }: MutationPublishBlogTagArgs) =>
    await BlogTagModel.findByIdAndUpdate(
      tagId,
      {
        publishedBy: this.getUserId(),
        status: blogStatus.PUBLISHED
      },
      { new: true }
    );
  public updateBlogTag = async ({ tagId, tag }: MutationUpdateBlogTagArgs) =>
    await BlogTagModel.findByIdAndUpdate(
      tagId,
      {
        ...tag
      },
      { new: true }
    );
  public deleteBlogTag = async ({ tagId }: MutationDeleteBlogTagArgs) =>
    await BlogTagModel.findByIdAndUpdate(
      tagId,
      {
        status: blogStatus.INACTIVE
      },
      { new: true }
    );
}
