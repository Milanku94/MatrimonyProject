import { provider as SemProvider } from ".";
import {
  BannerImg,
  QueryGetSemByCityCategoryArgs,
  Sem
} from "../../../generated/portal.models";
import { PortalContext } from "../../../types";

const indexCategory = (category: string) =>
  category === "wedding-assist" ? "wedding-assist" : "*";

const C = (str: string) => {
  return str
    .split("-")
    .map(word => `${word[0].toLocaleUpperCase()}${word.slice(1)}`)
    .join(" ");
};

const defaultSEM = {
  "*": {
    bannerImage: {
      desktop: "//www.weddingbazaar.com/assets/bg/home-banner.jpg",
      mobile: "//www.weddingbazaar.com/assets/bg/home_586.jpg"
    },
    bannerQuestion: "Budget",
    title: (city: string, category: string) =>
      `Find the best ${C(category)} in ${C(city)}`,
    subtitle: (city: string, category: string) =>
      `WeddingBazaar's WeddingAssist connects with you a dedicated wedding planning expert who will help you shortlist and finalize the perfect ${C(
        category
      )} in ${C(city)}`
  },
  "wedding-assist": {
    bannerImage: {
      desktop: "//www.weddingbazaar.com/assets/bg/wa-banner.jpg",
      mobile: "//www.weddingbazaar.com/assets/bg/wa-home-couple.jpg"
    },
    bannerQuestion: "Budget",
    title: (city: string) => `Find the best in ${C(city)}`,
    subtitle: (city: string) =>
      `WeddingBazaar's WeddingAssist connects with you a dedicated wedding planning expert who will help you shortlist in ${C(
        city
      )}`
  }
};

export default {
  // BannerImg: {
  //   desktop: async (parent: BannerImg) => {
  //     console.log(parent);
  //     return (
  //       parent.desktop ||
  //       defaultSEM[indexCategory(parent.category)].bannerImage.desktop
  //     );
  //   },
  //   mobile: async (parent: BannerImg) => {
  //     return (
  //       parent.mobile ||
  //       defaultSEM[indexCategory(parent.category)].bannerImage.mobile
  //     );
  //   }
  // },
  Sem: {
    bannerImage: async (parent: Sem) => {
      return (
        parent.bannerImage ||
        defaultSEM[indexCategory(parent.category)].bannerImage
      );
    },
    bannerQuestion: async (parent: Sem) => {
      return (
        parent.bannerQuestion ||
        defaultSEM[indexCategory(parent.category)].bannerQuestion
      );
    },
    title: async (parent: Sem) => {
      return (
        parent.title ||
        defaultSEM[indexCategory(parent.category)].title(
          parent.city,
          parent.category
        )
      );
    },
    subtitle: async (parent: Sem) => {
      return (
        parent.subtitle ||
        defaultSEM[indexCategory(parent.category)].subtitle(
          parent.city,
          parent.category
        )
      );
    }
  },
  Query: {
    getSEM: async (_: null, __: null, context: PortalContext) => {
      const response = await context.axios.get(`sem/`);
      return response.data.data;
    },
    getSEMByCityCategory: async (
      _: null,
      { city, category }: QueryGetSemByCityCategoryArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`sem/`);
      return (
        (await response.data.data.filter(
          (data: any) => data.city === city && data.category === category
        )[0]) || {
          city,
          category
        }
      );
    }
  }
};
