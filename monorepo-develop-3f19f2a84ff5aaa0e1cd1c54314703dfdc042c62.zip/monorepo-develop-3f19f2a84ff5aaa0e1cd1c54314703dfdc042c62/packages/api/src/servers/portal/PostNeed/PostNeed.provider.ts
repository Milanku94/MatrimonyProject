import AuthProvider from "../auth.provider";

export default class PostNeedProvider extends AuthProvider {
  public getAll = async () => {
    return testData;
  };
}
const testData = [
  {
    name: "test data"
  }
];
