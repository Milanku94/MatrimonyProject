import { provider as PostNeedProvider } from ".";
import { MutationPostNeedArgs } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";

export default {
  Mutation: {
    postNeed: async (
      _: null,
      { postData }: MutationPostNeedArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post("leads/add-needs/", postData);
      return await response.data.data;
    }
  }
};
