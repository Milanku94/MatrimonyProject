import { provider as ReviewProvider } from ".";
import { QueryGetRatingQuestionsForCategoryArgs } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
import UserAuthModel from "../UserAuth/UserAuth.model";
import { questions } from "./Review.staticdata";

export default {
  Review: {
    user: async (parent: any) => await UserAuthModel.findById(parent.user)
  },
  Query: {
    getRatingQuestionsForCategory: async (
      _: any,
      { slug }: QueryGetRatingQuestionsForCategoryArgs
    ) => {
      return questions[slug]
        .map(question => ({
          ...question,
          name: question.label.toLowerCase().replace(/ /g, "-")
        }))
        .sort((a, b) => (a.label < b.label ? -1 : 0));
    },
    reviewByProfile: async (_: null, { profileId }: any, ctx: PortalContext) =>
      await new ReviewProvider(ctx).getReviews({ profileId })
  },
  Mutation: {
    createReview: async (_: any, args: any, context: PortalContext) => {
      return await new ReviewProvider(context).add(args);
    }
  }
};
