// import { MutationCreateReviewArgs } from "../../../generated/portal.models";
import { userReviewStatus } from "../../../config/config.portal.enum";
import AuthProvider from "../auth.provider";
import UserAuth from "../UserAuth/UserAuth.model";
import ReviewModel from "./Review.model";
export default class ReviewProvider extends AuthProvider {
  public add = async (args: any) => {
    const user = await UserAuth.findOne({ _id: args.userID });
    if (!user) {
      throw Error("Not a valid user");
    }
    return await ReviewModel.find({
      user,
      profileID: args.review.profileID,
      status: userReviewStatus.ACTIVE
    }).then(async (review: any) => {
      if (review.length) {
        return review[0];
      }
      return await new ReviewModel({
        user,
        overall: args.review.overall,
        review: args.review.review,
        profileID: args.review.profileID,
        ratings: args.review.ratings,
        status: userReviewStatus.ACTIVE
      }).save();
    });
  };
  public getReviewCount = async ({
    profileId: profileID
  }: {
    profileId: string;
  }) => await ReviewModel.count({ profileID, status: userReviewStatus.ACTIVE });
  public getReviews = async ({ profileId: profileID }: { profileId: string }) =>
    await ReviewModel.find({ profileID, status: userReviewStatus.ACTIVE });
  public getAverageRating = async ({ profileId }: { profileId: string }) =>
    await ReviewModel.aggregate([
      {
        $match: { profileID: profileId, status: userReviewStatus.ACTIVE }
      },
      { $group: { _id: null, averageRating: { $avg: "$overall" } } }
    ]);

  public getOverAllRating = async ({ profileId }: { profileId: string }) =>
    await ReviewModel.aggregate([
      {
        $match: { profileID: profileId, status: userReviewStatus.ACTIVE }
      },
      {
        $unwind: "$ratings"
      },
      {
        $group: {
          _id: "$ratings.id",
          answer: { $sum: { $cond: ["$ratings.answer", 1, 0] } },
          total: { $sum: { $cond: ["$ratings.answer", 1, 1] } }
        }
      },
      {
        $project: {
          id: "$_id",
          answer: { $divide: [{ $multiply: ["$answer", 5] }, "$total"] }
        }
      }
    ]);
}
