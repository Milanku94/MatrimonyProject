export const questions: {
  [key: string]: Array<{ label: string; description: string }>;
} = {
  "wedding-venues": [
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-caterers": [
    {
      label: "Quality",
      description: "Was the quality of the food good?"
    },
    {
      label: "Attention to detail",
      description:
        "Did the caterer pay attention to your suggestions and requests?"
    },
    {
      label: "Customer Service",
      description: "Were the catering staff friendly?"
    },
    {
      label: "Punctuality",
      description: "Was the caterer punctual in serving the meals?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-decorators": [
    {
      label: "Quality",
      description: "Did the quality of the decoration match your expectations?"
    },
    {
      label: "Attention to detail",
      description:
        "Did the decorator pay attention to your suggestions and requests?"
    },
    {
      label: "Punctuality",
      description: "Was the decorator punctual?"
    },
    {
      label: "Customer Service",
      description: "Was the decorator staff friendly?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  entertainers: [
    {
      label: "Punctuality",
      description: "Did the entertainers arrive on time?"
    },
    {
      label: "Customer Service",
      description: "Were the entertainers friendly?"
    },
    {
      label: "Attention to detail",
      description:
        "Did the entertainers pay attention to your suggestions and requests?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "honeymoon-tour-operators": [
    {
      label: "Quality",
      description: "Was your honeymoon planned perfectly by the tour operator?"
    },
    {
      label: "Adherence",
      description: "Did you visit all the places as mentioned in the itinerary?"
    },
    {
      label: "Attention to detail",
      description:
        "Did the planners pay attention to your suggestions and requests?"
    },
    {
      label: "Customer Service",
      description: "Were the staff friendly?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "marriage-certificate-services": [
    {
      label: "Quality",
      description:
        "Were the service providers helpful in obtaining your certificate?"
    },
    {
      label: "Punctuality",
      description: "Did you receive the certificate on time?"
    },
    {
      label: "Customer Service",
      description: "Were the staff friendly?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "invitation-card-dealers": [
    {
      label: "Range",
      description: "Were you satisfied with the number of designs available?"
    },
    {
      label: "Quality",
      description: "How was the quality of your invitation cards?"
    },
    {
      label: "Attention to detail",
      description:
        "Did the service provider listen to all your requests and suggestions?"
    },
    {
      label: "Punctuality",
      description: "Did the service provider deliver the invitations on time?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-jewellers": [
    {
      label: "Quality",
      description: "Were you able to get your hands on the latest designs?"
    },
    {
      label: "Customer Service",
      description: "Was the jewellery staff friendly?"
    },
    {
      label: "Punctuality",
      description: "Was the jeweller able to deliver your orders on time?"
    },
    {
      label: "Satisfaction",
      description: "Were you happy with the quality of the jewellery?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-makeup-artists": [
    {
      label: "Attention to detail",
      description:
        "Did the makeup artist pay attention to your suggestions and requests?"
    },
    {
      label: "Quality",
      description: "Did you like the quality of the makeup products used?"
    },
    {
      label: "Satisfaction",
      description: "Did you achieve the look you were expecting?"
    },
    {
      label: "Punctuality",
      description:
        "Were the makeup artists available when required during your event?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "bridal-mehndi-artists": [
    {
      label: "Skill",
      description:
        "Was the mehndi artist skilled enough to make all the required designs?"
    },
    {
      label: "Quality",
      description: "Was the mehndi/henna good?"
    },
    {
      label: "Punctuality",
      description: "Were the mehndi artists available on time?"
    },
    {
      label: "Attention to detail",
      description: "Was the mehndi artist paying attention to your requests?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "music-services": [
    {
      label: "Punctuality",
      description: "Were the musicians available on time?"
    },
    {
      label: "Customer Service",
      description: "Were the musicians friendly?"
    },
    {
      label: "Quality",
      description: "Was the audio quality good?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "pandits-and-priests": [
    {
      label: "Proficency",
      description:
        "Did the pandits exhibit knowledge of all the rituals involved?"
    },
    {
      label: "Punctuality",
      description: "Were the pandits on time to conduct the rituals?"
    },
    {
      label: "Clarity",
      description: "Were they able to instruct you clearly on the rituals?"
    },
    {
      label: "Customer Service",
      description: "Were the pandits friendly?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-photographers": [
    {
      label: "Customer Service",
      description: "Were the photographers friendly?"
    },
    {
      label: "Quality",
      description: "Were you happy with the photos/videos/albums?"
    },
    {
      label: "Attention to detail",
      description:
        "Were they able to capture all the key moments in your wedding?"
    },
    {
      label: "Proficiency",
      description: "Did the photographers exhibit knowledge in poses and shots?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-return-gift-dealers": [
    {
      label: "Range",
      description: "Were there sufficient options for you to choose from?"
    },
    {
      label: "Quality",
      description: "Were the products of good quality?"
    },
    {
      label: "Customer Service",
      description: "Was the service provider friendly?"
    },
    {
      label: "Punctuality",
      description: "Were the products delivered on time?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "vehicles-rental-services": [
    {
      label: "Range",
      description: "Were there sufficient vehicles for you to choose from?"
    },
    {
      label: "Quality",
      description: "Were the vehicles in good condition?"
    },
    {
      label: "Customer Service",
      description: "Was the service provider friendly?"
    },
    {
      label: "Punctuality",
      description: "Did the vehicles/drivers arrive on time?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-venue": [
    {
      label: "Cleanliness",
      description: "Was the wedding venue clean before your event?"
    },
    {
      label: "Customer Service",
      description: "Were the venue staff friendly?"
    },
    {
      label: "Amenities",
      description: "Were the amenities good?"
    },
    {
      label: "Support",
      description: "Were the staff available to you throughout your event?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-wear": [
    {
      label: "Range",
      description:
        "Were there sufficient trends and designs available to choose from?"
    },
    {
      label: "Customer Service",
      description: "Were the staff friendly?"
    },
    {
      label: "Quality",
      description: "Was the quality of the outfits good?"
    },
    {
      label: "Customisation",
      description: "Were you happy with the fit?"
    },
    {
      label: "Recommended",
      description: "Would you recommend this service provider to others?"
    }
  ],
  "wedding-planners": [
    {
      label: "Quality",
      description:
        "Were the wedding planners able to cater to all your wedding - related needs ?"
    },
    {
      label: "Proficiency",
      description:
        "Were they knowledgeable regarding the wedding - related events and rituals ?"
    },
    {
      label: "Punctuality",
      description: "Were they punctual in planning and executing everything ?"
    },
    {
      label: "Support",
      description: " Were the staff available to you throughout your event ?"
    },
    {
      label: "Recommended",
      description: " Would you recommend this wedding planner to others ?"
    }
  ]
};
