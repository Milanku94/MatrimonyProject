import { prop, Ref, Typegoose } from "typegoose";
import { userReviewStatus } from "../../../config/config.portal.enum";
import { UserAuth } from "../UserAuth/UserAuth.model";

class Ratings extends Typegoose {
  @prop()
  public id: string;

  @prop()
  public answer: boolean;
}

export class Review extends Typegoose {
  @prop({ ref: "user" })
  public user: Ref<UserAuth>;

  @prop()
  public profileID: string;

  @prop()
  public vendorID: string;

  @prop({ default: { name: "test", answer: true } })
  public ratings: [Ratings];

  @prop()
  public overall: number;

  @prop()
  public review: string;

  @prop()
  public publishedOn: number;
  @prop()
  public status: userReviewStatus;
}

export default new Review().getModelForClass(Review, {
  schemaOptions: {
    collection: "ratings",
    shardKey: { _id: 1 },
    timestamps: { createdAt: true, updatedAt: true }
  }
});
