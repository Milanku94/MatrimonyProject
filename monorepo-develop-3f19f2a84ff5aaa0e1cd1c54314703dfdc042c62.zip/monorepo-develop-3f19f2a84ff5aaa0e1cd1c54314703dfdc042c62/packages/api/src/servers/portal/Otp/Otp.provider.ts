import AuthProvider from "../auth.provider";

export default class OtpVerifyProvider extends AuthProvider {
  public getAll = async () => {
    return testData;
  };
}
const testData = [
  {
    name: "test data"
  }
];
