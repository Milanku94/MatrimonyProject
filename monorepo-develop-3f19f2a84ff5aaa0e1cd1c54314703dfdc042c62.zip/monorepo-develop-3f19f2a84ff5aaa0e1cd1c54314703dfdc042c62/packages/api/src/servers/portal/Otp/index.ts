import OtpVerifyModel from "./Otp.model";
import provider from "./Otp.provider";
import resolver from "./Otp.resolver";

export { OtpVerifyModel, provider, resolver };
