import {
  MutationOtpRegenArgs,
  MutationOtpVerifyArgs
} from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
export default {
  Mutation: {
    otpVerify: async (
      _: null,
      { customerId, otp }: MutationOtpVerifyArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post("leads/otp-verify/", {
        customerId,
        otp
      });
      const data = await response.data;
      if (!!data.data) {
        return await data.data;
      }
      throw new Error(data.message);
    },
    otpRegen: async (
      _: null,
      { customerId }: MutationOtpRegenArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post("leads/otp-regen/", {
        customerId
      });
      const data = await response.data;
      if (!!data.data) {
        return await data.data;
      }
      throw new Error(data.message);
    }
  }
};
