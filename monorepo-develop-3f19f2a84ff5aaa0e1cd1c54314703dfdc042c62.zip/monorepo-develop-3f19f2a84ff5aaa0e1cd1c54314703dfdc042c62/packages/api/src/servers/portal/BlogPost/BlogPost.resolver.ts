import { BlogPostProvider } from ".";
import {
  MutationCreateBlogPostArgs,
  MutationUpdateBlogPostArgs,
  QueryBlogPostByIdArgs,
  QueryBlogPostCountArgs,
  QueryBlogPostDraftArgs,
  QueryBlogPostsArgs
} from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
import { blogTagAdminResolverShare, BlogTagProvider } from "../BlogTag";
export default {
  Query: {
    blogPosts: async (_: null, args: QueryBlogPostsArgs, ctx: PortalContext) =>
      await new BlogPostProvider(ctx).blogPosts(args),
    blogPostCount: async (
      _: null,
      args: QueryBlogPostCountArgs,
      ctx: PortalContext
    ) => await new BlogPostProvider(ctx).blogPostCount(args),
    blogPostById: async (
      _: null,
      args: QueryBlogPostByIdArgs,
      ctx: PortalContext
    ) => await new BlogPostProvider(ctx).getBlogPostById(args),
    blogPostDraft: async (
      _: null,
      args: QueryBlogPostDraftArgs,
      ctx: PortalContext
    ) => await new BlogPostProvider(ctx).getBlogPostDraft(args)
  },
  Mutation: {
    createBlogPost: async (
      _: null,
      args: MutationCreateBlogPostArgs,
      ctx: PortalContext
    ) => new BlogPostProvider(ctx).createBlogPost(args),
    updateBlogPost: async (
      _: null,
      args: MutationUpdateBlogPostArgs,
      ctx: PortalContext
    ) => new BlogPostProvider(ctx).updateBlogPost(args),
    publishBlogPost: async (
      _: null,
      args: MutationUpdateBlogPostArgs,
      ctx: PortalContext
    ) => new BlogPostProvider(ctx).publishBlogPost(args),

    deleteBlogPost: async (
      _: null,
      args: MutationUpdateBlogPostArgs,
      ctx: PortalContext
    ) => new BlogPostProvider(ctx).deleteBlogPost(args)
  },
  BlogPost: {
    ...blogTagAdminResolverShare,
    tags: async ({ tags: blogTagIds }: any, _: null, ctx: PortalContext) =>
      blogTagIds.length
        ? new BlogTagProvider(ctx).getBlogTagByIds({ blogTagIds })
        : null
  }
};
