import { arrayProp, prop, Ref, Typegoose } from "typegoose";
import { BlogStatus, BlogType } from "../../../generated/portal.models";
import { BlogTag, BlogTagModel } from "../BlogTag";
import { BlogUser } from "../BlogUser";
export class BlogPost extends Typegoose {
  @prop()
  public vendorId: string;

  @prop()
  public slug: string; // - slugified title
  @prop()
  public title: string; // - name of the post
  @prop()
  public content: JSON; // - actual content, as string
  @prop()
  public excerpt: string; // - short content, for showing in listing pages
  @prop()
  public metaTitle: string; // -
  @prop()
  public metaDescription: string; // -
  @prop()
  public metaKeywords: string; // -
  @prop()
  public heroImage: string; // - url for the image
  @prop({ default: BlogStatus.Draft })
  public status: BlogStatus; // - boolean flag to keep track of published posts
  @prop()
  public publishedOn?: Date; // - date of publish
  @arrayProp({ itemsRef: { name: BlogTag } })
  public tags: Array<Ref<BlogTag>>; // - many-to-many relationship with Tags table
  @prop()
  public type: BlogType; // - many-to-one relationship with Type table
  // @prop({ ref: { name: BlogUser } })
  // public editor?: Ref<BlogUser>; // - many-to-many relationship with User table for EDITOR role
  @prop()
  public editor?: string; // - many-to-many relationship with User table for EDITOR role
  @prop()
  public author: string; // - many-to-many relationship with User table for AUTHOR role
}

export const BlogPostModel = new BlogPost().getModelForClass(BlogPost, {
  schemaOptions: {
    shardKey: { _id: 1 },
    collection: "blogPost",
    timestamps: { createdAt: true, updatedAt: true }
  }
});
