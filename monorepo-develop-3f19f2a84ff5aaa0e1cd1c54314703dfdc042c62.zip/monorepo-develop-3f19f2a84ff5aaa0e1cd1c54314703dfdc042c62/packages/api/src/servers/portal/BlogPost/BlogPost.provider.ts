import _snakecase from "lodash/snakeCase";
import {
  BlogPostView,
  BlogStatus,
  MutationCreateBlogPostArgs,
  MutationUpdateBlogPostArgs,
  QueryBlogPostByIdArgs,
  QueryBlogPostCountArgs,
  QueryBlogPostDraftArgs,
  QueryBlogPostsArgs
} from "../../../generated/portal.models";
import AuthProvider from "../auth.provider";
import { BlogPostModel } from "./";
export default class BlogPostProvider extends AuthProvider {
  public blogPosts = async ({ type, filter }: QueryBlogPostsArgs) => {
    const conditionObj: any = { type, status: BlogStatus.Published };
    if (filter && filter.viewAs && filter.viewAs !== BlogPostView.Public) {
      if (filter.viewAs === BlogPostView.Author) {
        conditionObj.author = this.getUserId();
      }
      if (filter.viewAs === BlogPostView.Editor) {
        conditionObj.editor = this.getUserId();
      }
    }
    if (filter && filter.status) {
      conditionObj.status = filter.status;
    }
    const query = BlogPostModel.find(conditionObj).sort({
      updatedAt: "desc"
    });

    if (filter && filter.page && filter.limit) {
      const pageNumber = filter.page - 1;
      query.skip(pageNumber * filter.limit).limit(filter.limit);
    }
    return await query;
  };
  public blogPostCount = async ({
    type,
    viewAs,
    status
  }: QueryBlogPostCountArgs) => {
    const conditionObj: any = { type, status: BlogStatus.Published };
    if (viewAs && viewAs !== BlogPostView.Public) {
      if (viewAs && viewAs === BlogPostView.Author) {
        conditionObj.author = this.getUserId();
      }
      if (viewAs && viewAs === BlogPostView.Editor) {
        conditionObj.editor = this.getUserId();
      }
    }
    if (status) {
      conditionObj.status = status;
    }
    // BlogPostModel.aggregate([
    //   {
    //     $match: {
    //       type,
    //       author: {
    //         $if: [
    //           viewAs && viewAs === BlogPostView.Author,
    //           this.getUserId(),
    //           undefined,
    //         ],
    //       },
    //       status: {
    //         $cond: [status, status, BlogStatus.Published],
    //       },
    //     },
    //   },
    //   {
    //     $count: "count",
    //   },
    // ]);

    return await BlogPostModel.countDocuments(conditionObj);
  };
  public getBlogPostById = async ({ blogPostId }: QueryBlogPostByIdArgs) =>
    await BlogPostModel.findById(blogPostId);
  public getBlogPostDraft = async ({ type }: QueryBlogPostDraftArgs) =>
    await BlogPostModel.find({
      type,
      status: BlogStatus.Draft,
      author: this.getUserId()
    });
  public createBlogPost = async ({ type, post }: MutationCreateBlogPostArgs) =>
    await new BlogPostModel({
      type,
      author: this.getUserId(),
      slug: _snakecase(post && post.title ? post.title : "untitled post"),
      ...post
    }).save();
  public updateBlogPost = async ({ id, post }: MutationUpdateBlogPostArgs) =>
    await BlogPostModel.findByIdAndUpdate(
      id,
      {
        ...post,
        ...(post &&
          post.title && {
            slug: _snakecase(post.title)
          })
      } as any,
      { new: true }
    );
  public publishBlogPost = async ({ id }: any) =>
    await BlogPostModel.findByIdAndUpdate(
      id,
      {
        status: BlogStatus.Published,
        editor: this.getUserId()
      },
      { new: true }
    );
  public deleteBlogPost = async ({ id }: MutationUpdateBlogPostArgs) =>
    await BlogPostModel.findByIdAndUpdate(
      id,
      { status: BlogStatus.Inactive },
      { new: true }
    );
}
