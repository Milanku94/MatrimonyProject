import { InstanceType, ModelType, prop, Typegoose } from "typegoose";
import { userRole } from "../../../config/config.portal.enum";
export class BlogUser extends Typegoose {
  @prop()
  public email: string;
  @prop()
  public name: string;
  @prop()
  public bio: string;
  @prop()
  public role: userRole;
  @prop()
  public active: boolean;
}

export const BlogUserModel = new BlogUser().getModelForClass(BlogUser, {
  schemaOptions: {
    shardKey: { _id: 1 },
    collection: "blogUser",
    timestamps: { createdAt: true, updatedAt: true }
  }
});
