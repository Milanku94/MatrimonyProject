import { getPortalJwtToken } from "../../../services/jwt.utils";
import AuthProvider from "../auth.provider";
import { BlogUserModel } from "./";
export default class BlogUserProvider extends AuthProvider {
  public getAll = async () => BlogUserModel.find();
  public getUserbyId = async () =>
    await BlogUserModel.findOne({ email: this.getUserId() });

  public blogUserLogin = async ({ userId }: any) => {
    const loggedUser = await BlogUserModel.findOne({ email: userId });
    if (!loggedUser) {
      throw new Error("Invalid userId/password");
    }
    return {
      token: getPortalJwtToken({
        id: loggedUser.email,
        role: loggedUser.role,
        mailId: loggedUser.email
      }),
      user: loggedUser
    };
  };
}
