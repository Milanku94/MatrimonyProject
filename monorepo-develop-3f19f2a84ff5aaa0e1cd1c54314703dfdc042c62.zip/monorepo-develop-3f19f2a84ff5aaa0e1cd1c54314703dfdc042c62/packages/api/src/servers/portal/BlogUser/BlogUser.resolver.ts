import { BlogUserProvider } from ".";
import { PortalContext } from "../../../types";

export default {
  Query: {
    blogUser: async (_: any, args: any, context: PortalContext) =>
      await new BlogUserProvider(context).getAll(),
    userInfo: async (_: any, args: any, context: PortalContext) =>
      await new BlogUserProvider(context).getUserbyId()
  },
  Mutation: {
    blogUserLogin: async (_: any, args: any, context: PortalContext) =>
      await new BlogUserProvider(context).blogUserLogin(args)
  }
};
