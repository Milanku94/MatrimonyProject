import Axios, { AxiosAdapter, AxiosInstance } from "axios";
import { setupCache } from "axios-cache-adapter";
import { addSlug } from "../../services/slugify.utils";

const cache = setupCache({
  maxAge: 15 * 60 * 1000
});

export const unCachedAxios = Axios.create({
  baseURL: process.env.API_BASE_URL
});

export const axios: AxiosInstance = Axios.create({
  baseURL: process.env.API_BASE_URL,
  adapter: cache.adapter as AxiosAdapter
});

axios.interceptors.response.use(
  response => {
    const data = response.data.data;
    if (typeof data === "object") {
      response.data.data = addSlug(data);
    }
    return response;
  },
  error => {
    return Promise.reject(error);
  }
);
