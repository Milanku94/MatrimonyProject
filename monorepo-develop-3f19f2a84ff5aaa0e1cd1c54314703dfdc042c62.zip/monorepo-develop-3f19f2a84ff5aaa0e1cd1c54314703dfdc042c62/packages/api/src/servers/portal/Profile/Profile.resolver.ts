import { ApolloError } from "apollo-server-express";
import { mapSeries, retry } from "async";
import { find as _find } from "lodash";

import { offersImagetype } from "../../../config/config.portal.enum";
import {
  AttributesInput,
  OfferImage,
  OffersType,
  Profile,
  QueryGetProfilesArgs,
  QueryGetProfilesByIdArgs,
  QueryGetTotalProfilesCountArgs
} from "../../../generated/portal.models";
import { logger } from "../../../services/logger.utils";
import { getSlug, getSlugId } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";
import ReviewProvider from "../Review/Review.provider";
import { provider as ProfileProvider } from "./";
import { covidcontent } from "./covidcontent.mockdata";

const formatAttributes = (attributes: Array<AttributesInput | null>) =>
  attributes.map(attr => {
    if (attr) {
      return { [attr.attributeId as string]: attr.optionIds };
    }
    return null;
  });
const offerImageMap: { [key: string]: keyof OfferImage } = {
  [offersImagetype.OFFER_IMAGE]: "tile",
  [offersImagetype.TC_IMAGE]: "tc"
};
// attributes.reduce((acc: any, attr: any) => {
//   acc[+attr.attributeId] = attr.optionIds;
//   return acc;
// }, {});

const covidsafe = { id: "covidsafe", name: "COVID-safe" };
export default {
  Profile: {
    name: (parent: Profile) => unescape(parent.name),
    slug: async (parent: Profile) => {
      return getSlug(parent);
    },
    slugId: async (parent: Profile) => {
      return getSlugId(parent);
    },

    badges: async (parent: any) => {
      const badges = [...parent.badges];

      if (covidcontent.some(id => id === parent.id)) {
        badges.push(covidsafe);
      }
      if ((parent as any).crisilBadge !== "") {
        badges.push({ id: "crisilBadge", name: (parent as any).crisilBadge });
      }
      return badges.map(badge => ({
        id: `${badge!.name}-${badge!.id}`,
        name: badge!.name
      }));
    },
    rating: async (
      { id: profileId, badges }: any,
      _: any,
      ctx: PortalContext
    ) => {
      const profData = await new ProfileProvider(
        ctx
      ).getProfileByCityCategoryId({ profileId });
      const rating = profData
        ? (profData.baseRating * 10 + profData.rating * profData.totalRaters) /
          (profData.totalRaters + 10)
        : 0;
      const minRating =
        badges &&
        badges.length &&
        badges.find(({ name }: any) => name.toLowerCase() === "premium")
          ? 4.5
          : 3;
      return rating >= minRating ? rating : minRating;
    },
    view360: ({ view_360 }: any) => view_360,
    reviewCount: async ({ id: profileId }: any, _: null, ctx: PortalContext) =>
      await new ReviewProvider(ctx).getReviewCount({ profileId }),
    review: async ({ id: profileId }: any, _: null, ctx: PortalContext) =>
      await new ReviewProvider(ctx).getReviews({ profileId }),
    overallRatings: async (
      { id: profileId }: any,
      _: null,
      ctx: PortalContext
    ) => {
      try {
        const overallCount = await new ReviewProvider(ctx).getOverAllRating({
          profileId
        });
        return overallCount;
      } catch (e) {
        console.log(e);
      }
    }
  },
  View360Details: {
    embedCode: ({ embed_code }: any) => embed_code,
    embedUrl: ({ embed_url }: any) => embed_url
  },
  DisplayAttribute: {
    slug: async (parent: Profile) => {
      return getSlug(parent);
    }
  },
  Offers: {
    startDate: ({ startDate }: any) => new Date(startDate),
    endDate: ({ endDate }: any) => new Date(endDate),
    image: ({ offerImage, type }: any) => {
      const image: OfferImage = {
        tileDefault: `https://stgwww.weddingbazaar.com/assets/images/offer_${type}_tile.png`,
        coverDefault: `https://stgwww.weddingbazaar.com/assets/images/offer_${type}_cover.png`
      };
      if (offerImage.length) {
        offerImage.map(
          ({ offerImageType, imageUrl }: any) =>
            (image[offerImageMap[offerImageType]] = imageUrl)
        );
      }
      return image;
    },
    complementaryDesc: ({ otherOffers }: any) => otherOffers
  },
  Query: {
    getProfiles: async (
      _: null,
      {
        postData: { categoryId, cityId, attributes, freeText, isAutoSearch },
        page = 1,
        limit = 10
      }: QueryGetProfilesArgs,
      { axios, dataSources: { ProfileApi } }: PortalContext
    ) => {
      const { getProfiles } = new ProfileApi({ axios });
      return await getProfiles({
        cityId,
        categoryId,
        attributes,
        page,
        limit,
        freeText,
        isAutoSearch: !!isAutoSearch
      });
    },
    // Todo: revamp, need to avoid api call
    getTotalProfilesCount: async (
      _: null,
      {
        postData: { categoryId, cityId, attributes, freeText, isAutoSearch }
      }: QueryGetTotalProfilesCountArgs,
      { axios, dataSources: { ProfileApi } }: PortalContext
    ) => {
      const { getProfileCount } = new ProfileApi({ axios });
      return await getProfileCount({
        cityId,
        categoryId,
        attributes,
        freeText,
        isAutoSearch: !!isAutoSearch
      });
    },
    getProfilesByID: async (
      _: null,
      { profileID }: QueryGetProfilesByIdArgs,
      { axios, dataSources: { ProfileApi } }: PortalContext
    ) =>
      await new ProfileApi({ axios }).getProfileById({ profileId: profileID }),
    profileBestSeries: async (
      _: null,
      { url }: any,
      { axios, dataSources: { ProfileApi } }: PortalContext
    ) => {
      const { getBestSeries } = new ProfileApi({ axios });
      const bestSeries = await getBestSeries({ url });
      return { header: bestSeries.h1, profiles: bestSeries.data };
    },
    similarProfiles: async (
      _: null,
      { postData: { profileID } }: any,
      context: PortalContext
    ) => {
      const response = await context.axios.post(`similar_vendors/`, {
        vendor_slug: profileID
      });
      return await response.data.data;
    },

    topProfilesByCity: async (
      _: null,
      { cityId }: any,
      { axios, dataSources: { CategoryApi, ProfileApi } }: PortalContext
    ) => {
      const categories = await new CategoryApi({ axios }).getCategoryByCity({
        cityId
      });
      const { getProfiles } = new ProfileApi({ axios });
      let list = 0;
      return mapSeries(categories, ({ id: categoryId, ...rest }: any, cb) => {
        list < 4
          ? getProfiles({ cityId, categoryId })
              .then((profiles: any) => {
                if (profiles.length > 9) {
                  list++;
                  cb(null, {
                    categoryId,
                    ...rest,
                    profiles
                  });
                } else {
                  cb(null);
                }
              })
              .catch((er: any) => cb(er))
          : cb(null);
      })
        .then(re => {
          return re.filter(Boolean);
        })
        .catch((er: any) => {
          throw new ApolloError(er, "INERNAL_ERROR");
        });
    },
    getProfilesByCity: async (
      _: null,
      { cityId }: any,
      { axios, dataSources: { CategoryApi, ProfileApi } }: PortalContext
    ) => {
      const categories = await new CategoryApi({ axios }).getCategoryByCity({
        cityId
      });
      const { getProfiles } = new ProfileApi({ axios });
      return mapSeries(categories, ({ id: categoryId, ...rest }: any, cb) => {
        getProfiles({ cityId, categoryId })
          .then((profiles: any) => {
            if (profiles.length > 9) {
              cb(null, {
                categoryId,
                ...rest,
                profiles
              });
            } else {
              cb(null);
            }
          })
          .catch((er: any) => cb(er));
      })
        .then(re => {
          return re.filter(Boolean);
        })
        .catch((er: any) => {
          throw new ApolloError(er, "INERNAL_ERROR");
        });
    }
  }
};
