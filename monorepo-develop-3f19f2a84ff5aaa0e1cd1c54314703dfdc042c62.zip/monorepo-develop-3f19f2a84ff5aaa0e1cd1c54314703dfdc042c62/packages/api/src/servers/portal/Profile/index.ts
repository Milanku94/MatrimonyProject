import ProfileModel from "./Profile.model";
import provider from "./Profile.provider";
import resolver from "./Profile.resolver";

export { ProfileModel, provider, resolver };
