import { decryptProfileSlug, ProfileModel } from "../../vendor/Profile";
import AuthProvider from "../auth.provider";

export default class ProfileProvider extends AuthProvider {
  public getProfileByCityCategoryId = async ({
    profileId
  }: {
    profileId: string;
  }) => {
    const { vendorId, categoryId, cityId } = decryptProfileSlug(profileId);

    const { table, fields } = ProfileModel("actual");
    return (
      await this.actualDB(table)
        .column(fields)
        .where({
          [fields.vendorId]: vendorId,
          [fields.subCategoryId]: categoryId,
          [fields.cityId]: cityId
        })
    )[0];
  };
}
