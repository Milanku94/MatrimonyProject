import { GraphQLScalarType, Kind } from "graphql";
import { provider as CategoryProvider } from ".";
import {
  Category,
  QueryGetCategoriesByIdArgs
} from "../../../generated/portal.models";
import { getSlug, getSlugId } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";
import { content } from "./content.mockdata";

const DisplayOptionTypeEnum = ["false", "radio", "checkbox", "textbox"];
export default {
  DisplayOptionType: new GraphQLScalarType({
    name: "DisplayOptionType",
    description: "Boolean or enum(radio|checkbox|textbox)",
    parseValue(value) {
      return value === "false" ? false : value;
    },
    serialize(value) {
      return value === "false" ? false : value;
    },
    parseLiteral(ast) {
      if (
        ast.kind === Kind.STRING &&
        DisplayOptionTypeEnum.includes(ast.value)
      ) {
        return ast.value === "false" ? false : ast.value;
      }
      return null;
    }
  }),
  Category: {
    slug: async (parent: Category) => {
      return getSlug(parent);
    },
    slugId: async (parent: Category) => {
      return getSlugId(parent);
    },
    meta: (parent: Category) => {
      return {
        ...parent.meta,
        title: parent.meta.title || "Title",
        description: parent.meta.description || "Description"
      };
    },
    content: (parent: Category) => {
      return content[getSlug(parent)];
    }
    // cities: async (parent: Category, args: null, context: PortalContext) => {
    //   const cities = await (await context.axios.get(`/cities/`)).data.data;
    //   return cities.filter((city: any) => {
    //     return city.categories.find(
    //       (category: any) => parent.name === category.name
    //     );
    //   });
    // }
  },
  Query: {
    getCategories: async (_: null, args: null, context: PortalContext) => {
      const response = await context.axios.get(`/categories/`);
      return await response.data.data;
    },
    getCategoriesByID: async (
      _: null,
      args: QueryGetCategoriesByIdArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(
        `/categories/${args.categoryID}/`
      );
      return await response.data.data[0];
    },
    getCategoriesBySlug: async (
      _: null,
      { slug }: any,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`/categories/`);
      const temp = await response.data.data;
      return temp.find((t: any) => t.slug === slug);
    }
  }
};
