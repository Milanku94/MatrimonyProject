export const content: {
  [key: string]: Array<{ section: string; question: string; answer: string }>;
} = {
  "wedding-planners": [
    {
      section: "Main",
      question: "What are the advantages of hiring a wedding planner",
      answer:
        "Here are some [advantages of hiring wedding planners](https://bit.ly/advantagesofweddingplanners):  \n  \n1. You can be relieved of all the stresses of planning a wedding  \n2. Research and negotiating with the vendors will be done by the wedding planner  \n3. Need not attend every meeting with the vendors. Just give your requirements and the wedding planners will find the perfect vendors for you  \n4. Even the wedding day coordination will be done by the planners themselves  \n5. You can avoid any hiccups that might happen in your wedding"
    },
    {
      section: "Main ",
      question: "Are there different types of wedding planners",
      answer:
        "Every wedding planner will have a speciality. One wedding planner might be a specialist in [Telugu weddings](https://bit.ly/teluguWeddingRituals), one might be a specialist in [Tamil Brahmin weddings](https://bit.ly/ritualsofatamilbrahminwedding), the other might be an expert in [Kannada weddings](https://bit.ly/dishesinKannadaBrahminWedding), one might have wealth of knowledge in [beach weddings](https://bit.ly/beachweddingdecoration), [destination weddings](https://bit.ly/2oSmJUJ) and so on. You will have to find the wedding planner who is specialised in your style of wedding. It is because they will have an intricate knowledge of the rituals and will make the necessary arrangements. For instance, [Tamil Brahmin weddings](https://bit.ly/ritualsofatamilbrahminwedding) have a [oonjal ceremony](https://bit.ly/OonjalCeremony) where the bride and groom are made to sit on a oonjal swing. If your wedding planner does not have any idea about the rituals, they cannot arrange for rituals like these."
    },
    {
      section: "Price",
      question: "The price range of wedding planners in <city>*",
      answer:
        "|Category  |Cost  |\n|--|--|\n\n|For a wedding in India|Rs.50,000 to Rs. 6,00,000|\n\n**Prices may vary according to individual preferences and services required.*"
    },
    {
      section: "Main",
      question: "What does a wedding planner do?",
      answer:
        "A wedding planner handles each and every arrangement in a wedding. Some people only give a part of the work to wedding planners. Here are some things that a wedding planner does.  \n  \n1. A wedding planner negotiates and fix the service providers for various services like [wedding catering](https://www.weddingbazaar.com/<citySlug>/wedding-caterers), [wedding decoration](https://www.weddingbazaar.com/<citySlug>/wedding-decorators), [wedding photography](https://www.weddingbazaar.com/<citySlug>/wedding-photographers) etc..  \n  \n2. A wedding planner coordinates wedding day process such as setting up required things for a specific ritual like [mangalasnanam](https://www.weddingbazaar.com/ideas/a-brief-description-of-the-unique-ritual-of-mangalasnanam-74), [haldi ceremony](https://www.weddingbazaar.com/blog/how-to-plan-and-celebrate-haldi-ceremony) or [Kaasi yatra](https://www.weddingbazaar.com/ideas/all-you-need-to-know-about-kashi-yatra-ritual-131)  \n  \n3. A wedding planner also makes necessary arrangements for entertaining the guests and keeping them engaged"
    },
    {
      section: "Main",
      question: "Tips to find the best wedding planner",
      answer:
        "Finding the best wedding planner makes all the difference. If you hire the wrong one they can derail your wedding plans. Here are some tips to find the best wedding planner. \n\n1. Ask your married friends about the wedding planner who made their wedding beautiful. Known references are all always safe. \n\n2. Look for reviews on various social media platforms including Google reviews\n\n3. Personally check with people who have already hired a wedding planner and get their insights\n\n4. Have a face to face meeting with the wedding planners you have shortlisted and see whether there is a potential to work together\n\n5. Make a list of all the things that you expect your wedding planner to do and find the one that checks all the boxes\n\n "
    },
    {
      section: "Main",
      question: "What questions should I ask before hiring a wedding planner?",
      answer:
        "Hiring a wedding planner is a huge step towards a wonderful wedding. You would want to make it right. Before hiring a wedding planner, you will have ask certain questions and make sure that they are the one you are looking for.  \n  \n1. Ask questions that will test their knowledge on your type of wedding. For instance, if you are having a [beach wedding](https://bit.ly/beachweddingdecoration), ask them about any previous [beach wedding](https://bit.ly/beachweddingdecoration) assignments that they have had.  \n  \n2. Check out whether they have extensive knowledge of the rituals that will take place in your wedding.  \n  \n3. Ask for the contact numbers of their previous customers and if possible even get some photographs on the decor, seating arrangements, etc..  \n  \n4. Ask for suggestions from them to get to know their ideas"
    },
    {
      section: "FAQ",
      question: "Do we really need planners for a wedding?",
      answer:
        "Wedding planners are not a basic necessity but if you hire one, you can have a peaceful wedding and enjoy yourself without worrying about anything else. "
    },
    {
      section: "FAQ",
      question: "Why do you need a wedding planner for a destination wedding?",
      answer:
        "In destination weddings, you never know what problem you are going to run into. It will mostly be a place that you have not been to. So, it is always good to have a wedding planner who chas local contacts and knowledge of the destination. "
    },
    {
      section: "FAQ",
      question:
        "Will wedding planners help plan other ceremonies like engagement too?",
      answer:
        "Yes, wedding planners can help you plan separate ceremonies like engagement, mehndi, haldi , etc.."
    },
    {
      section: "FAQ",
      question: "Is it really helpful to hire a wedding planner for wedding?",
      answer:
        "Yes, wedding planners can reduce your stress levels and let you concentrate only on the ceremonies and posing for photos. "
    },
    {
      section: "FAQ",
      question: "How do I find a wedding planner? ",
      answer:
        "Almost all the wedding planners are active on social media channels such as Instagram, Facebook and Twitter. You can even look up in Google for wedding planners. "
    },
    {
      section: "FAQ",
      question: "Can you plan a successful wedding without a wedding planner?",
      answer:
        "Yes, you can plan a successful wedding without a wedding planner but a wedding planner takes away all the stress that you will encounter while planning a wedding. "
    },
    {
      section: "FAQ",
      question: "Is hiring a wedding planner an expensive decision?",
      answer:
        "In most of the cases, wedding planners reduce the cost that you will usually spend on a wedding because they have contacts with regular service providers who will do the service for them at a discounted rate. "
    },
    {
      section: "FAQ",
      question:
        "What is the difference between event planner and event coordinator?",
      answer:
        "A event planner will plan an event for you and handover everything for you to coordinate. A event coordinator on the other hand is present on the venue to make sure that everything goes smooth as planned. "
    },
    {
      section: "FAQ",
      question: "Do we have to pay any advance for wedding planners?",
      answer:
        "Yes, most of the wedding planners will ask for a advance payment. The exact advance amount usually varies with each wedding planner. "
    },
    {
      section: "FAQ",
      question: "Will the wedding planners coordinate everything?",
      answer:
        "Yes, if all the works are handed over, the wedding planners will coordinate everything. "
    },
    {
      section: "FAQ",
      question: "Will the wedding planner be there on the wedding day?",
      answer:
        "Yes, the wedding planner or a coordinator will be there on the wedding day to coordinate everything. "
    },
    {
      section: "FAQ",
      question: "Should I do research before hiring a wedding planner?",
      answer:
        "Yes, you will have to do a lot of research before hiring the perfect wedding planner. Ask your friends, read google reviews, surf through social media, leave no stone unturned while doing the research. "
    },
    {
      section: "FAQ",
      question: "Can I hire freelance wedding planners?",
      answer:
        "Yes, you can hire freelance wedding planners too. Check with their former clients and review the work they have done in the past to know more about them. "
    }
  ],
  "wedding-decorators": [
    {
      section: "Main",
      question: "Wedding decorators",
      answer:
        "We all know how [wedding decoration](https://www.weddingbazaar.com/ideas/7-unique-ideas-for-wedding-decoration-64) is one of the vital parts of any wedding. It not only creates that joyful vibe around but also represents a version of you. Indian weddings are nothing less than a festival and festivals are an occasion which need decoration. Be it a simple temple wedding or a grand [palace wedding](https://www.weddingbazaar.com/<citySlug>/wedding-venues), the look created just by adding a few flowers and clothes in a symmetrical pattern gives a whole new and attractive look. \n\nYou know there's a wedding happening if you see the decorated name board in front of the [wedding hall](https://www.weddingbazaar.com/<citySlug>/wedding-venues). Our eyes always get attracted to beautiful and colourful things. That's where decoration stands.\n\nOver the years, [wedding decoration](https://www.weddingbazaar.com/ideas/mesmerizing-stage-decoration-ideas-for-a-south-indian-wedding-113) has evolved tremendously. From using only hanging flowers to starting the trend of stage decoration, this field is in its peak with respect to creativity.\n\nThere are different types of [wedding decoration](https://www.weddingbazaar.com/ideas/mesmerizing-stage-decoration-ideas-for-a-south-indian-wedding-113) - Floral decoration, satin cloth decoration, eco-friendly decoration, stage decoration, theme decoration, entrance decoration, etc.. All these provide a welcoming atmosphere and it has the power to change the whole wedding mood into a celebration mood.\n\nWell thought decorations not only bring that atmosphere of festivity but also sets the theme for you wedding or any other function like grihapravesham or house warming ceremony, naming ceremony, seemantham, birthday party, etc.. Some unique decorations that are specific to certain functions are, Haldi ceremony / mangalasnanam decor in a yellow theme, grand entrance decor for the wedding reception, lighting for the house, Shamiyana / tent house, etc..\n\nHowever, in order to make your dream wedding a reality, you need an artist who can transform a plain [wedding venue](https://www.weddingbazaar.com/wedding-venues) to a mind-blowing one. \n\nGo through more about our [wedding decorators](https://www.weddingbazaar.com/ideas/how-to-find-and-book-the-best-wedding-decorator-7) and proceed to get a quote from the best wedding decorators in <city>"
    },
    {
      section: "Main",
      question:
        "Things to consider while shortlisting wedding decorators in <city>",
      answer:
        "Here are a few things to keep in mind before finalizing on a wedding decorator: \n\n**Decide on the venue**\n\nDecoration depends on the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) and you need to decide on where you will conduct all the ceremonies like [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), mehendi ceremony, muhurtham, etc... Some usually have their [engagement ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-an-engagement-ceremony-13) in a small [party hall](https://www.weddingbazaar.com/<citySlug>/wedding-venues) or a big [wedding hall](https://www.weddingbazaar.com/<citySlug>/wedding-venues) & the mehendi ceremony and [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5) in their homes. The main wedding rituals and [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) is usually held at a different venue. Based on what you decide, the style and price of the [wedding decoration](https://www.weddingbazaar.com/ideas/7-unique-ideas-for-wedding-decoration-64) will vary accordingly.\n\n**Set your budget**\n\nCompared to the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues), [wedding jewellery](https://www.weddingbazaar.com/<citySlug>/wedding-jewellers), and [wedding outfits](https://www.weddingbazaar.com/<citySlug>/wedding-wear), [wedding decoration](https://www.weddingbazaar.com/<citySlug>/wedding-decorators) isn't too expensive but the price does impact your whole [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19) to a considerable extent. Set a budget before meeting the wedding decorators.\n\n**Explore the trending decor options**\n\nBefore visiting the wedding decorators, it is always better to explore  [trendy decor ideas](https://www.weddingbazaar.com/ideas/top-20-south-indian-wedding-decor-trends-that-are-making-the-rounds-96) so that you have a general idea of the wedding theme that you want. You can even ask the decorators for their catalogue and compare whether they have experience with the latest decoration themes and ideas.\n\n**Interview decorators**\n\nConsult multiple decorators and keep your options open. Some decorators might be closer to the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) and thus cheaper when it comes to transportation expenses. A few decorators expect you to get all the decor items while some get it themselves. Ask questions and shortlist a bunch of wedding decorators before you choose the perfect wedding decorator. If you are unable to do this, fret not, our [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform has expert wedding planners who do this job for you!\n\n**Communicate your requirements**\n\nIf you are particular about any [wedding decoration theme](https://www.weddingbazaar.com/ideas/7-unique-ideas-for-wedding-decoration-64) or need any particular item at your [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) like a swing or reception sofas, mention that clearly to your wedding decorator. Miscommunication is the one thing that leads to many mishaps."
    },
    {
      section: "Price",
      question: "Price range of wedding decorations in <city>*",
      answer:
        "| Event |Price  |\n|--|--|\n| Engagement ceremony |Rs. 10,000 to Rs. 30,000  |\n| Mehendi ceremony | Rs. 5,000 to Rs. 10,000 |\n|Haldi ceremony|Rs. 5,000 to Rs. 10,000|\n|Wedding ceremony  | Rs. 30,000 to Rs. 10,00,000 |\n|Wedding reception|Rs. 50,000 to Rs. 30,00,000|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best wedding decorator in <city>",
      answer:
        "Here are a few tips to find the best wedding decorator:\n\n**Research beforehand**  \n\nResearch and make notes of all the things necessary before meeting a decorator. This way you will be ready for the meeting and can ask better questions. In case you have any doubts or questions make a note of it and clarify with the [wedding decorator](https://www.weddingbazaar.com/ideas/top-20-south-indian-wedding-decor-trends-that-are-making-the-rounds-96).\n\n**Explore more**\n\nSometimes, the real gems are hidden and you need keen eyes to search to find them. It’s possible only by exploring more. Shortlist a few decorators who are closer to the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues), and meet your budget. \n\n**Compare and select**\n\nAfter shortlisting a few [wedding decorators](https://www.weddingbazaar.com/ideas/mesmerizing-stage-decoration-ideas-for-a-south-indian-wedding-113), compare their pricing, availability, and experience before finalising on one.\n\n**Select the decorators from WeddingBazaar**\n\nInstead of running behind the decorators and researching too much, you can simply take our assistance. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required negotiations to give you the best deals."
    },
    {
      section: "Main",
      question: "What makes decorators in WeddingBazaar different from others",
      answer:
        "Our wedding decorators' success mantra is always good service. They believe that when they deliver beyond expectation, the customers would not just be happy but also satisfied. Another perk of our wedding decorators is being on par with latest trends. Be it any customisations or any preferences, our wedding decorators are here to listen and implement.   "
    },
    {
      section: "Main",
      question: "Popular wedding decoration themes in <city>",
      answer:
        "Some of the most popular wedding decoration themes are fairytale decor theme, royal indian wedding decor theme, Rajasthani wedding decor theme, eco-friendly wedding decor theme, etc.."
    },
    {
      section: "Main",
      question: "Steps involved in hiring a wedding decorator",
      answer:
        "Here are the steps involved in hiring a wedding decorator:\n\n 1. Set your budget\n 2. Make a note of all your preferences\n 3. Meet the wedding decorators \n 4. Shortlist the decorators based on the price, preference, availability, and experience\n 5. Filter out the decorators as and when they don't meet any of your criteria. Have another discussion if need be. \n 6. Book a wedding decorator"
    },
    {
      section: "Main",
      question:
        "How to request a quote for wedding decoration from WeddingBazaar",
      answer:
        "After you select the wedding decorator, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "FAQ",
      question: "Will the wedding decorator use flowers suggested by us?",
      answer:
        "Yes, the wedding decorator will use the flowers suggested by you. "
    },
    {
      section: "FAQ",
      question:
        "If I book a decorator, will they be available for all the ceremonies that require decoration?",
      answer:
        "If the contract mentions that the decorator has to deliver their services for all the ceremonies, then yes, they will be available. There are certain cases where the hosts will request the decoration services only for specific ceremonies. For instance, if the hosts want the decorator for [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5), and [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), they will be rendering their services only for the specified ceremonies."
    },
    {
      section: "FAQ",
      question: "What if we are allergic to the flowers used for decoration?",
      answer:
        "In case of allergies, please mention clearly to the decorator about the flowers you are allergic to and ask them not to use such flowers. "
    },
    {
      section: "FAQ",
      question: "What is the approximate cost of wedding decoration in <city>?",
      answer:
        "Cost of wedding decoration varies with decorators and depends on the season, variety of flowers used, and amount of decoration needed. Wedding costs usually lie in between Rs. 50,000 and Rs. 2,00,000. Depending on the requirements the wedding decoration prices may increase or decrease accordingly. "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book a decorator in <city>?",
      answer:
        "It entirely depends on the dates of the wedding ceremonies. Usually, if it is during the wedding season, you can book them at least 3 to 4 months in advance. The most famous and sought after decorators get booked even 6 months before the wedding. "
    },
    {
      section: "FAQ",
      question: "What are the trendy wedding decors?",
      answer:
        "Flower decorations, royal seating, antique chandeliers, unique centrepieces, candle decor, colourful drapes, fairy light decor, etc.. are some of the trendy Indian wedding decors. "
    },
    {
      section: "FAQ",
      question: "What types of wedding venues can you decorate?",
      answer:
        "Banquet halls, party halls, outdoor sangeet stage setup, rooftops, beaches, resorts, etc., are some of the [wedding venues](https://www.weddingbazaar.com/<citySlug>/wedding-venues) that can be decorated."
    },
    {
      section: "FAQ",
      question: "Will you do both indoor and outdoor wedding decoration?",
      answer:
        "Yes, wedding decorators from [WeddingBazaar](https://www.weddingbazaar.com/) do both indoor and outdoor wedding decoration."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for wedding decoration?",
      answer:
        "Advance payment for wedding decoration varies with each decorator. While some prefer full payment in advance, others prefer to take a percentage of their payment as advance. "
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for wedding decoration?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding decoration services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    }
  ],
  "wedding-caterers": [
    {
      section: "Main",
      question: "Wedding caterers",
      answer:
        "Have you guys ever attended a wedding where there is no food? That can never be possible, right? Weddings are fun because of the food that is served.\n\nFood is one mandatory element in [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15). Different types of cuisines, more than 15 dishes, banana-leaf meals, live counters, chaat, etc.. Mouth-watering, isn't it?\n\nA wedding is never complete until the [wedding guests](https://www.weddingbazaar.com/ideas/wedding-games-to-keep-your-guests-entertained-71) come to the hosts and talk about the wedding meal. Wedding is an occasion where the energy must be at its peak and food is essential to create that energy. \n\nIndian weddings have seen different cuisines apart from home cuisine. For example, the inclusion of live momo counters, manchurian, cheese balls, burgers, etc.. They have also seen different style of serving apart from the usual plate service. For example, buffet stalls at [wedding receptions](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) is one such area where all the creativity is used. Be it the inclusion of live counters, food trucks,  multi-cuisine dishes, etc..\n\nApart from the wedding day, Indian weddings have some pre-wedding rituals like [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5), [mehendi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-the-mehendi-ceremony-168), [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), etc.. Food along with drinks are a common element in these ceremonies. Here, as the guest count would be comparatively less, the serving style and dishes served can be experimented with. With different types on meals and cuisines like welcome drinks, high tea, North Indian thali, South Indian cuisine, Chinese, Italian, and mediterranean cuisines,  etc., there are lot of options to choose from.\n\nWhat needs to be kept in mind is the quality of food. You don't want guests to fall sick after having your wedding meal. To keep the quality of food, you need [wedding caterers](https://www.weddingbazaar.com/ideas/how-to-choose-the-best-catering-services-for-your-wedding-91) who can maintain hygiene and provide tasty food. Moreover, with the rise of various viruses and diseases, food hygiene has become a mandatory protocol to follow. However, one question that bothers is - who will provide hygienic and tasty food?\n\nHere is the answer - Go through our wedding catering section to know about our wedding caterers. Book them and have lip-smacking food at your wedding!"
    },
    {
      section: "Main",
      question: "Things to consider while shortlisting caterers in <city>",
      answer:
        "Here are a few things to consider before booking a [wedding caterer](https://www.weddingbazaar.com/ideas/how-to-hire-a-caterer-for-your-wedding-10):\n\n**Stick to your budget**\n\n[Wedding catering](https://www.weddingbazaar.com/ideas/wedding-catering-101-a-guide-to-north-indian-style-wedding-catering-18) is one of the most important factors at your wedding. Also, it is important to note that this is the area where there are high chances to go off the [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19). Therefore, keep in mind the budget and stick to it. \n\n**Make your preferences very clear**\n\nIf you need pure veg food, iyengar style food, [kannada bramhin style food](https://www.weddingbazaar.com/ideas/popular-dishes-used-in-kannada-brahmin-wedding-cuisine-154), or any other cuisines, mention the preferences clearly. \n\n**Explore the specialists around you**\n\nThere are many caterers who are exemplary in certain cuisines. Select them for your wedding catering as they deliver the best work for you. \n\n **Note down**\n\nBefore meeting any caterer, note down the questions or doubts that you have and never miss to ask important details like no onion no garlic food, vegan food, hygienic food, etc.. Be it the kitchen, number of staff, or the raw material procurement. Ask everything. \n\n**Meet multiple caterers**\n\nOnly by meeting multiple caterers, you get the chance to increase your choices and select the best one among the shortlisted ones. "
    },
    {
      section: "Price",
      question: "The price range of caterers in <city>*",
      answer:
        "| Style|South Indian   |North Indian  |Multi cuisine|\n|--|--|--|--|\n|Vegetarian|Rs.100 to Rs.500|Rs.100 to Rs.500|Rs.100 to Rs.500+|\n|Veg and non-veg |Rs.250 to Rs.750|Rs.250 to Rs.750|Rs.250 to Rs.750+|\n\n\n**Prices may vary according to individual preferences.*\n\n**All prices are per plate.*"
    },
    {
      section: "Main",
      question: "Tips to find the best caterers in <city>",
      answer:
        "Here are a few tips to find the best [wedding caterers](https://www.weddingbazaar.com/ideas/how-to-hire-a-caterer-for-your-wedding-10):  \n  \n**Research and explore**  \n  \nResearch and make notes of all the things necessary like menu options, dessert options, welcome drink options, etc., before meeting a caterer. This way you will be ready for the meeting and can ask better questions. Explore for multiple options so that you will have more choices. \n  \n**Communicate efficiently**  \n  \nWhen you meet any [wedding caterer](https://www.weddingbazaar.com/ideas/how-to-hire-a-caterer-for-your-wedding-10), explain your requirements clearly. Mention if you need pure veg food or non-veg food, no onion no garlic food, or any vegetable or dish that you don't need, etc.. Observe how the caterers respond for all your requirements.  \n\n**Compare and select**  \n\nCompare all the shortlisted [wedding caterers](https://www.weddingbazaar.com/ideas/how-to-hire-a-caterer-for-your-wedding-10). Check thier per plate offering and request for tasting sessions before finalising one. \n  \n**Select the caterers from WeddingBazaar**  \n  \nInstead of running behind the caterers and researching too much, you can simply take our assitance. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required negotiations to give you the best deals."
    },
    {
      section: "Main",
      question: "What makes caterers in WeddingBazaar different from others",
      answer:
        "We have hand-picked caterers who are the best at wedding catering. They always deliver one step more than your requirements and make sure that you are satisfied with the service. "
    },
    {
      section: "Main",
      question: "Popular catering styles in <city>",
      answer:
        "The most popular catering styles are plated dinner, buffet, food stations, live counters, food trucks, family style, cocktail style, South Indian meals, North Indian thali, Chinese, Italian, Andhra cuisine, etc.."
    },
    {
      section: "Main",
      question:
        "How to request a quote for wedding catering from WeddingBazaar",
      answer:
        "After you select the wedding caterer, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "Main",
      question: "Steps involved in hiring a caterer",
      answer:
        "Here are the steps involved in hiring a wedding caterer: \n\n1. Set your budget \n2. Discuss with your families about what kind of food has to served for different wedding ceremonies\n3. If you have any dishes or cuisines in mind, make a note of it \n4. Meet different wedding caterers\n5. Shortlist the caterers based on the price, preference, and availability\n6. Filter out the caterers as and when they don't meet any of your criteria. Have another round discussion if need be along with a tasting session \n7. Book the wedding caterer"
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional catering service providers?",
      answer:
        "Professional caterers offer catering services to all kinds of wedding ceremonies and provide options like live counters for dosa, salad, pasta, pan etc., contents of thamboolam, any food items required for ceremonies with snacks and beverages. Apart from these, they also provide required manpower to handle all these tasks. "
    },
    {
      section: "FAQ",
      question: "What is corporate catering?",
      answer:
        "If catering is done for corporate events such as meetings and conferences, then it is called as corporate catering. "
    },
    {
      section: "FAQ",
      question: "Is the food prepared at the wedding venue?",
      answer:
        "It entirely depends on the facilities at the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) and the caterer's comfort. If it is a small event the caterers usually prepare the food at their own kitchen and deliver at the venue. If it is a big event like a wedding, the caterers prefer to prepare the food at the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues)."
    },
    {
      section: "FAQ",
      question: "How do you prepare the veg and non-veg dishes?",
      answer:
        "Most of the caterers from [WeddingBazaar](https://www.weddingbazaar.com/) either only do pure veg cuisine or pure non veg cuisine. There are rarely any caterers who do both. but for those who handle both styles, they use separate vessels and utensils for preparing vegetarian and non-vegetarian dishes. This ensures that there is no cross-contamination between dishes."
    },
    {
      section: "FAQ",
      question: "Do your caterers offer tasting sessions?",
      answer:
        "Tasting sessions depend on the size of the order. For a large order like wedding ceremonies, almost every wedding caterer will offer tasting sessions on request."
    },
    {
      section: "FAQ",
      question: "How many servers are required for wedding catering?",
      answer:
        "The number of servers required for wedding catering depends on the size of the guest list. If the guest list is big the number of servers required for will also go up. Usually around 12 to 15 serving staff are hired for a wedding with 600 guests."
    },
    {
      section: "FAQ",
      question: "Can the food menu be customized?",
      answer:
        "Yes, the wedding food menu can be customised as per the requirement of the hosts. The caterers will also have their own set of menus from which the hosts can choose or they can also customise the entire menu. "
    },
    {
      section: "FAQ",
      question: "What is the approximate cost of catering services in <city>?",
      answer:
        "The cost for catering services depend on various factors like guest list, menu, number of items, extra amenities like plastic cups, spoons, bowls, etc.. Though every caterer charges differently the approximate cost of catering for 300 guests in <city> lies in between 1,00,000 and 3,00,000. "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book a caterer in <city>?",
      answer:
        "The best caterers in <city> get booked even a year in advance. But, the ideal time to book wedding caterer will be at least 6 months prior to your wedding day."
    },
    {
      section: "FAQ",
      question: "Do you offer a buffet for weddings?",
      answer:
        "Yes, our caterers also offer wedding buffet if requested by the hosts. "
    },
    {
      section: "FAQ",
      question: "Will you do both indoor and outdoor catering?",
      answer:
        "Yes, most of the caterers from [WeddingBazaar](https://www.weddingbazaar.com/) offer both indoor and outdoor catering services."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment?",
      answer:
        "Advance payment for wedding catering service varies from caterer to caterer. While some prefer a percentage of their payment in advance, others prefer to have full payment in advance. "
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for catering?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding catering services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Do you provide live counters?",
      answer:
        "Yes, wedding caterers from [WeddingBazaar](https://www.weddingbazaar.com/) provide live food counters if requested by the hosts."
    },
    {
      section: "FAQ",
      question: "Do you serve alcohol at weddings?",
      answer:
        "Yes, the caterers equipped with alcohol license will serve them at the weddings, provided the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) does not have any restrictions."
    },
    {
      section: "FAQ",
      question: "Do you offer bartending services?",
      answer:
        "Yes, bartending services are also provided by our wedding caterers if requested by the hosts. Also, it depends on the wedding venue's policies and restrictions."
    },
    {
      section: "FAQ",
      question: "WIll your caterers take only a cooking contract?",
      answer:
        "It depends on the wedding caterer. While some may accept only a cooking contract, the others might not accept it. "
    },
    {
      section: "FAQ",
      question: "Will tamboolams be provided?",
      answer:
        "Yes, thamboolam will be provided by wedding caterers if they are part of the agreement. "
    },
    {
      section: "FAQ",
      question: "What is a cooking contract?",
      answer:
        "A cooking contract is when the hosts provide all the raw materials needed for the cooking. The caterer only cooks with the materials that you provide. "
    }
  ],
  entertainers: [
    {
      section: "Main",
      question: "Entertainers",
      answer:
        "Indian weddings are nothing but a celebration of two souls joining their hands to start a new life. We consider weddings as a grand affair and plan accordingly. When it comes to [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15), the basics like booking a [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues), booking [wedding caterers](https://www.weddingbazaar.com/<citySlug>/wedding-caterers), purchasing [wedding jewellery](https://www.weddingbazaar.com/<citySlug>/wedding-jewellers), etc., are perfectly taken care off. We take utter precaution while doing all these and ask a bunch of questions before deciding on something.\n\nHowever, these are mandatory basic stuff in [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15) but what makes a wedding more special than other events? The entertainers!\n\nImagine a normal [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) with everyone busy in their own world of selfies and conversations. Now, imagine a flash mob all of a sudden and the couple joining them for a romantic choreographed dance fit for the movies! The whole mood  is different and everyone concentrates on one thing - the dance! That's the power of entertainers. They know the right way to attract people. Once people start dancing, then understand that your wedding was a grand success! With professional choreographers, who can rehearse with you for the sangeet ceremony, to dance performers who bring life to your wedding party, entertainers add theat 'oomph factor' to your wedding.\n\nApart from dance performers, you can also hire the best Emcee to host your wedding like a grand event. From engaging the kids in some cute little games to engaging the elderly guests with appropriate games, they know all the secrets in engaging any kind of crowd.\n\nTo make your wedding more special and remembered for a long time, you need entertainers who not just entertain your [wedding guests](https://www.weddingbazaar.com/ideas/wedding-games-to-keep-your-guests-entertained-71), but also pull out the talent hidden in you. You can find such specially talented entertainers here!\n\nExplore our entertainers section to know more about them."
    },
    {
      section: "Main",
      question: "Things to consider while shortlisting entertainers in <city>",
      answer:
        " Here are a few things to consider before booking wedding entertainers:  \n  \n**Decide on your preference**\n\nEntertainers are dance choreographers, emcees, and dance performers. Decide who you need for your wedding ceremony. You may need their services for different ceremonies for e.g., a choreographer for the Sangeet and emcee for the wedding reception. \n\n**Decide on the number of occasions**\n\nSome need dance performers and/or choreographers for [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-hire-a-choreographer-for-a-sangeet-ceremony-28), emcee for [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), and so on. You decide on the number of occasions and select the entertainers accordingly.\n\n**Budget for entertainment**  \nThere are many weddings where the entertainers are in your own family. This will alter the budget of your wedding entertainers. Make sure you make the budget according to the needs. \n  \n**Explore**  \nMany people around you will know entertainers or are entertainers. Try to get more contacts so that you can make a better choice.  "
    },
    {
      section: "Price",
      question: "The price range of entertainers in <city>*",
      answer:
        "|Category | Cost |\n|--|--|\n|Dance performers  | Rs. 15,000 to Rs. 60,000 |\n|Emcee |Rs. 10,000 to Rs. 1,00,000|\n|Choreographer|Rs. 15,000 to Rs. 50,000|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best entertainer in <city>",
      answer:
        "Indian weddings are nothing but a celebration of two souls joining their hands to start a new life. We consider weddings as a grand affair and plan accordingly. When it comes to [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15), the basics like booking a [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues), booking [wedding caterers](https://www.weddingbazaar.com/<citySlug>/wedding-caterers), purchasing [wedding jewellery](https://www.weddingbazaar.com/<citySlug>/wedding-jewellers), etc., are perfectly taken care off. We take utter precaution while doing all these and ask a bunch of questions before deciding on something.\n\nHowever, these are mandatory basic stuff in [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15) but what makes a wedding more special than other events? The entertainers!\n\nImagine a normal [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) with everyone busy in their own world of selfies and conversations. Now, imagine a flash mob all of a sudden and the couple joining them for a romantic choreographed dance fit for the movies! The whole mood  is different and everyone concentrates on one thing - the dance! That's the power of entertainers. They know the right way to attract people. Once people start dancing, then understand that your wedding was a grand success! With professional choreographers, who can rehearse with you for the sangeet ceremony, to dance performers who bring life to your wedding party, entertainers add theat 'oomph factor' to your wedding.\n\nApart from dance performers, you can also hire the best Emcee's to host your wedding like a grand event. From engaging the kids in some cute little games to engaging the elderly guests with appropriate games, they know all the secrets in engaging any kind of crowd.\n\nTo make your wedding more special and remembered for a long time, you need entertainers who not just entertain your [wedding guests](https://www.weddingbazaar.com/ideas/wedding-games-to-keep-your-guests-entertained-71), but also pull out the talent hidden in you. You can find such specially talented entertainers here!\n\nExplore our entertainers section to know more about them."
    },
    {
      section: "Main",
      question:
        "What makes dance choreographers from WeddingBazaar different from others",
      answer:
        "We have hand-picked choreographers who understand your preference and make you comfortable for your dance performance. They listen to any of your concerns and get instant solutions. We do have professional choreographers for particular styles of dance."
    },
    {
      section: "Main",
      question: "What makes emcees from WeddingBazaar different from others",
      answer:
        "Our emcees are very professional and fluent in any language that you expect. They are expert crowd pullers and are sure to make your wedding, a memory to cherish forever.  They keep the guests engaged and arrange interactive games as well."
    },
    {
      section: "Main",
      question:
        "What makes dance performers from WeddingBazaar different from others",
      answer:
        "One quality of our dance performers that even we are proud of is that they encourage participation from your side. They train you and bring out the inner dancer in you as well apart from dancing like angels!"
    },
    {
      section: "Main",
      question: "How to request a quote for entertainers from WeddingBazaar",
      answer:
        "After you select the wedding entertainers, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "Main",
      question: "Steps involved in hiring choreographers in <city>",
      answer:
        "Here are the steps involved in hiring a wedding choreographer: \n\n1. Set your budget and requirements\n2. Meet the choreographers and watch their live performance\n3. Mention the number of dancers and non-dancers that are interested to dance for the sangeet\n4. Mention all your other preferences like songs, dance genre, etc., to the choreographers\n5. Shortlist the choreographers based on the price, preference, and availability \n6. Filter out the choreographers as and when they don't meet any of your criteria. Have another round discussion if need be\n7. Book wedding choreographers"
    },
    {
      section: "Main",
      question: "Steps involved in hiring emcees in <city>",
      answer:
        "Here are the steps involved in hiring a wedding emcee: \n\n1. Set your budget \n2. Meet the emcee and watch their live performance or recorded show\n3. Mention the number of occasions for which you need the emcee\n4. Mention all your other preferences to emcees. Plan out all the events that you're gonna need the emcee for and briefly map out the course of events that'll happen\n5. Shortlist the emcees based on the price, preference, and availability\n6. Filter out the emcees as and when they don't meet any of your criteria. Have another round discussion if need be \n7. Book the wedding emcee"
    },
    {
      section: "Main",
      question: "Steps involved in hiring dance performers in <city>",
      answer:
        "Here are the steps involved in hiring wedding dance performers: \n\n1. Set your budget \n2. Meet the performers and watch their live performance \n3. Mention whether they can perform with the dancers in your family\n4. Mention all your other preferences to dance performers\n5. Shortlist the dance performers based on the price, preference, availability\n6. Filter out the dance performers as and when they don't meet any of your criteria. Have another round discussion if need be\n7. Book wedding dance performers"
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional choreographers?",
      answer:
        "Professional wedding choreographers will train the couple and their friends or family. Right from wedding entry dance, [sangeet dance](https://www.weddingbazaar.com/ideas/how-to-hire-a-choreographer-for-a-sangeet-ceremony-28), group dance, and your [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) dance, they can choreograph for every event at your wedding."
    },
    {
      section: "FAQ",
      question: "What kind of services can I expect from professional emcees?",
      answer:
        "Professional emcees keep the guests engaged while the couple and their family is busy performing all the rituals. They can also conduct games for kids and adults and give away gifts to the winners. "
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional dance performers?",
      answer:
        "Professional dance performers give fabulous performances during your wedding ceremony. It can be traditional dance, bollywood dance, dandiya, folk dance, or contemporary. They also engage you during the dance at your [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), or even in your entry into the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues)."
    },
    {
      section: "FAQ",
      question:
        "What is the approximate cost of professional choreography services in <city>?",
      answer:
        "The cost for professional choreography services in <city> varies anywhere between Rs. 15,000 to Rs. 60,000. "
    },
    {
      section: "FAQ",
      question:
        "What is the approximate cost of professional emcees in <city>?",
      answer:
        "Professional emcees in <city> will cost around Rs. 25,000 to Rs 1,00,000. "
    },
    {
      section: "FAQ",
      question:
        "What is the approximate cost of professional dance performers in <city>?",
      answer:
        "The dance performers in the <city> charge anywhere between Rs. 15,000 to Rs. 60,000 depending on the number of dancers. "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book a wedding choreographer in <city>?",
      answer:
        "Wedding choreographers can be booked a couple of months before the wedding. "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book an emcee in <city>?",
      answer:
        "If you are going for renowned MC's then you might have to book them at least 6 months in advance. Other emcees can be booked even a couple of months before the wedding. "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book dance performers in <city>?",
      answer:
        "Dance performers from an established dance studio should be booked 6 months in advance. For some studios, even a month's notice will be enough. "
    },
    {
      section: "FAQ",
      question: "Can I see the live performance of the artist before booking?",
      answer:
        "Yes, you can (based on the availability of the artist.) You can view a recording or you can either visit a venue where they are performing or you can request for a small performance at your location. "
    },
    {
      section: "FAQ",
      question:
        "What are the different styles of the entertainment the artist can offer?",
      answer:
        "There are wide range of entertainment services like magic shows, engaging games, dance shows, etc.. Depending on the styles, artists can be chosen. "
    },
    {
      section: "FAQ",
      question: "Do you provide dancers for the wedding if requested?",
      answer:
        "Yes, dancers for wedding ceremonies like [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), mehndi ceremony, [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), etc.. are available on request."
    },
    {
      section: "FAQ",
      question: "How many dance choreographers will be booked for us?",
      answer:
        "The number of dance choreographers depends on the number of people to be choreographed. It is sometimes decided by the clients or sometimes by the service provider. "
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for entertainment services?",
      answer:
        "Advance payment for entertainment services varies with every service provider. While some prefer a percentage of their payment in advance, the others prefer to have full payment in advance. "
    },
    {
      section: "FAQ",
      question: "Do your entertainers need rehearsal at the venue?",
      answer:
        "It is entirely up to the entertainers. If the entertainers have no idea about the venue then they will request for a rehearsal there. "
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for entertainment services?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding entertainment services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Who is an emcee?",
      answer:
        "Emcee or MC's are the official host of a party, staged activity, or any event. They make sure that everything runs on time and the guests are engaged. "
    },
    {
      section: "FAQ",
      question: "Why are dance performers or choreographers required?",
      answer:
        "Dance performers are sometimes needed to accompany the dancing couples or for an on-stage performance for keeping the guests engaged. Choreographers are required to train the couple, their family, and friends for their dance performances in [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-hire-a-choreographer-for-a-sangeet-ceremony-28), [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), or while entering the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) or the stage."
    },
    {
      section: "FAQ",
      question: "What is the difference between emcees and anchors?",
      answer:
        "There is just a slight difference between emcee and anchors. While emcees engage the guests with games or activities, anchors just take a role of what is going to happen next. "
    },
    {
      section: "FAQ",
      question: "Who will set the sangeet stage?",
      answer:
        "The sangeet stage will be decorated and set by the [wedding decorator](https://www.weddingbazaar.com/<citySlug>/wedding-decorators) and not by the entertainers. Make sure you discuss this with both the choreographer and the decorator."
    }
  ],
  "honeymoon-tour-operators": [
    {
      section: "Main",
      question: "Honeymoon tour operators",
      answer:
        "What is the first thing you do after the wedding? Go for your honeymoon ofcourse! After so much of hustle and bustle at your wedding, with all the stress of [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15), all you would want is some peaceful time with your partner.\n\nThe honeymoon period is very crucial to you and your partner as this is the time you get to spend with each other. Especially in an arranged marriage, this is the time where you get to understand your partner. This is the transition time for you and your partner to move into a different lifestyle.\n\nFor [Honeymoon planning](https://www.weddingbazaar.com/wedding-assist) you have to first decide whether you want a domestic destination or an international one. Based on this you can pack your luggage. You also need to finalise on the duration of your vacation. Standard all-inclusive packages are for 6 days 5 nights, 4 days 3 nights, 8 days 7 nights, etc..\n\nThere are many places in India and abroad which are particularly famous as [honeymoon destinations](https://www.weddingbazaar.com/ideas/best-honeymoon-packages-and-places-to-visit-after-your-wedding-60). Some very popular honeymoon destinations are Ooty, Uttrakhand, Shimla, Kulu, Manali, Switzerland, Paris, Bali, Maldives, Malaysia, Bhutan, Kerala, etc.. \n\nDeciding and finding a place is all fine, but there's more to it - you have to figure out local transportation, places to stay, food, best places to visit, etc.. All of this needs [smart planning](https://www.weddingbazaar.com/wedding-assist). WE can help you with all of this so that you can sit back and relax!\n\nBrowse through our honeymoon tour operators section to understand how we can make your honeymoon the most memorable one!"
    },
    {
      section: "Main",
      question:
        "Things to consider while shortlisting Honeymoon tour operators in <city>",
      answer:
        "These are things to be considered before booking your honeymoon package: \n\n**Set your budget**\n\nAmidst [wedding planning](https://www.weddingbazaar.com/wedding-assist) and sorting budget for it, one might ignore or forget to dedicate some [wedding budget](https://www.weddingbazaar.com/wedding-assist) for honeymoon. Make sure you keep the amount dedicated for honeymoon and later sort for other requirements. \n\n**Decide the honeymoon spot**\n\nNow, this is a tricky discussion. You might like beaches while your partner likes hills. While discussing make sure you are open to options. Be very clear on your likes and dislikes on any place that you choose so that later it becomes easy for the two fo you to decide on a place. \n\n**Book the tickets** \n\nMost couples plan the honeymoon right after their wedding. One mistake that is common is waiting till the last moment to book the travel tickets. Be it the train, bus, or airplane, make sure you book the tickets even before you start [wedding planning](https://www.weddingbazaar.com/wedding-assist). Most travel operators book everything from you flight tickets to hotel accommodation. So choose an all-inclusive package to avoid confusion. \n\n**Enquire offers and options**\n\nMost honeymoon tour operators have travel tickets, transport, stay, and food in their package. Watch out for offers season where all these including the taxes will cost you less."
    },
    {
      section: "Price",
      question: "The price range of Honeymoon tour operators in <city>*",
      answer:
        "|Category  |Stay duration |Cost|\n|--|--|--|\n|Domestic|5 nights 6 days|Starts from Rs. 25,000|\n|International|6 nights 7 days|Starts from Rs. 60,000|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best honeymoon packages in <city>",
      answer:
        "Here are a few tips to find the best [honeymoon package](https://www.weddingbazaar.com/ideas/how-to-plan-your-romantic-honeymoon-getaway-30): \n\n**Explore the ocean of options**\n\nBe it the domestic travel or international, there are plethora of [honeymoon spots and packages](https://www.weddingbazaar.com/ideas/best-honeymoon-packages-and-places-to-visit-after-your-wedding-60) and the more you search, the better deal you get. \n\n**Opt the packages instead of ala carte**\n\nMostly packages are convenient and cost less compared to ala carte. This is because of the offers that run around packages. This also saves you the headache from booking flight tickets and making hotel bookings. \n\n**Longer honeymoon period**\n\nThis might sound crazy, but the cost is inversely proportional to the number of days you've planned for your honeymoon. Of course, it looks more, but the comparative price difference will be less. \n\n **Select the honeymoon tour operators from WeddingBazaar** \n\nInstead of worrying about ticket bookings or continuous monitoring, you can simply take our assistance. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required negotiations to give you the best deals."
    },
    {
      section: "Main",
      question:
        "What makes Honeymoon tour operators in WeddingBazaar different from others",
      answer:
        "Our honeymoon tour operators are best in the industry with good amount of experience. They are available 24/7 during your travel period and their only goal is to make your trip the most romantic. Their service will surely make you want to have a second, third, and more number of honeymoons! "
    },
    {
      section: "Main",
      question: "Steps involved in hiring Honeymoon tour operators in <city>",
      answer:
        "Here are the steps involved in hiring a honeymoon tour operator: \n\n1. Set your budget \n2. Decide the place you would want to visit and the number of vacation days\n3. Explore and meet several honeymoon operators  \n4. Ask about their service, experience, facilities provided, and other requirements\n5. Shortlist the honeymoon tour operators based on the price, preference, service\n6. Filter out the honeymoon tour operators as and when they don't meet any of your criteria. Have another round discussion if need be\n7. Book a honeymoon tour operator"
    },
    {
      section: "Main",
      question:
        "How to request a quote for honeymoon packages from WeddingBazaar",
      answer:
        "After you select your honeymoon package, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional honeymoon tour operators?",
      answer:
        "Professional honeymoon tour operators ensure that your safety and comfort is taken care of. They also provide you with a honeymoon kit and special honeymoon decorations during your stay. "
    },
    {
      section: "FAQ",
      question: "What is the approximate cost of honeymoon packages in <city>?",
      answer:
        "Domestic honeymoon packages from <city> starts from Rs. 25,000 while international packages starts from Rs. 30,000. The price range varies depending on the number of days involved.  "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book honeymoon services in <city>?",
      answer:
        "It is advisable to book honeymoon services from <city> before 6 months. This is done to ensure that the cost of flights and other travel arrangements are made properly at the best possible cost. "
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for honeymoon services?",
      answer:
        "Advance payment for honeymoon packages varies with every service provider. Mostly, all the service providers request for full payment before the travel commences. "
    },
    {
      section: "FAQ",
      question:
        "In case of issues or change of plans, how can we contact you during the travel?",
      answer:
        "Representatives from the travel agencies will always be in constant touch with you via calls or messaging apps. Any changes of plans or issues can be communicated to them immediately. "
    },
    {
      section: "FAQ",
      question: "Can I customize my honeymoon package?",
      answer:
        "Yes, there are customisations available for both domestic and international honeymoon packages."
    },
    {
      section: "FAQ",
      question:
        "What are the documents to be submitted before booking a honeymoon package?",
      answer:
        "Domestic honeymoon travel requires basic documents like address proof and ID proof. However, international travel will require passport along with the address proof and ID proof. Additional documents may be required depending on the travel destination.  "
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for honeymoon services?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on honeymoon packages. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question:
        "Will the tours and travels agency receive us at the airport/railway station?",
      answer:
        "Yes, representatives from the travel agency will receive you from the airport/railway station. Please confirm with the service provider before hand about these details."
    },
    {
      section: "FAQ",
      question: "What is the refund policy?",
      answer:
        "Every honeymoon tour operator has their own refund policy and there are no standard rules. Please check with individual service providers for their policy. "
    },
    {
      section: "FAQ",
      question: "Where do your honeymoon tours start from?",
      answer:
        "The starting locations of different tours and [Bangalore](https://www.weddingbazaar.com/bangalore/), [Mumbai](https://www.weddingbazaar.com/mumbai/), [Delhi](https://www.weddingbazaar.com/delhi/), [Chennai](https://www.weddingbazaar.com/chennai/), [Hyderabad](https://www.weddingbazaar.com/hyderabad/), [Vijayawada](https://www.weddingbazaar.com/vijayawada/), etc.. Choose a convenient starting point and check with the service provider."
    }
  ],
  "invitation-card-dealers": [
    {
      section: "Main",
      question: "Invitation card dealers",
      answer:
        "Wedding invitations play a very important role in communicating your wedding details to others. You have seen many [wedding invitations,](https://www.weddingbazaar.com/ideas/top-10-unique-wedding-invitation-card-ideas-62) but only some of them would be remembered. Why? Because of the creativity with respect to the design, content, and colours used.\n\nIn Indian weddings, there are certain ways that elders follow with respect to [wedding cards](https://www.weddingbazaar.com/ideas/top-15-design-ideas-for-wedding-cards-116). For example, they insist on having specific content written in a certain style on the invitation card. However, the younger generation concentrates on getting the most creative [wedding cards](https://www.weddingbazaar.com/ideas/wedding-card-design-ideas-for-millennial-couples-51) with innovative ways to invite the guests for the wedding.\n\nAlong with it, [e-invites](https://www.weddingbazaar.com/ideas/eco-friendly-wedding-planning-with-e-wedding-invites-127) are getting a lot of prominence because it is eco-friendly, time-saving, and fast. However, card invitation is considered extremely important in many cases. Over the years, the creative ways in which the cards are printed are becoming more and more unique. Everyone wants a different invitation card. Where can you get such innovative cards? Who can customise the cards to suit your preference? Who can guarantee you the quality of the cards?\n\nWe can!\n\nRead more in our invitation card section and get a beautiful wedding card for your wedding!"
    },
    {
      section: "Main",
      question:
        "Things to consider while shortlisting wedding invitation designers in <city>",
      answer:
        "Here are the things to consider before finalising a [wedding invitation card designer](https://www.weddingbazaar.com/ideas/how-to-style-and-design-your-wedding-card-29):\n\n**Make a note of your preferences**\n\nSome families will prefer having a single invitation for both bride and groom with certain changes while some prefer different service providers. You discuss with your partner and decide on your choice. Get the content ready and double check all the spellings. Also decide whether you want an english only invitation card or a bilingual one. If you want e-invites only, then discuss on what type of designs you would like. \n\n**Number of guests**\n\nThis is an obvious checklist to be done before going to the invitation card service provider. Try to get an additional 50 copies of the [invitation cards](https://www.weddingbazaar.com/ideas/wedding-card-design-ideas-for-millennial-couples-51) apart from the total number of guests for emergencies. \n\n**Type of invitation card**\n\nSome prefer traditional invitation cards while some modern ones. Decide on the count of the number of invitation cards that you need. \n\n**Look out for options**\n\nGet a quote from multiple service providers and compare them with each other. There are many trendy invitation cards which are both traditional and modern as well. \n\n**E-invites and eco-friendly invitation cards**\n\nThese invites are getting popular nowadays. [E-invites](https://www.weddingbazaar.com/ideas/eco-friendly-wedding-planning-with-e-wedding-invites-127) are preferred as it's easy to send, faster, and good for the environment. Eco-friendly invitation cards are preferred as the name suggests, they are friends of nature.  In eco-friendly wedding cards,  cloth invites, seed paper invites, etc., are used. "
    },
    {
      section: "Price",
      question: "The price range of wedding invitation cards in <city>*",
      answer:
        "|Category |Cost  |\n|--|--|\n|Design and printing invitation cards  | Rs. 10 to Rs. 500 \n|E-invite designing| Rs 200 to Rs 5,000|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question:
        "Tips to find the best wedding invitation designer and printer in <city>",
      answer:
        "These are the tips to find the best invitation designer and printer:\n\n**Try local markets** \n\nSome local shopping markets have a street dedicated to the invitation card printers and designers. One visit to the street and the options rain in front of you.\n\n**Explore options**\n\nDon't just look for materials or printing ink. Look for both and also ask the service provider the various materials and font styles available. \n\n**Mix and match**\n\nCheck for various samples and choose the best fonts, paper quality, and sizes\n\n**Select the invitation card service provider from WeddingBazaar** \n\nConfused with so many options? Fret not! Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform are here to take care of all the required negotiations and will filter out the best options for you."
    },
    {
      section: "Main",
      question:
        "What makes wedding invitation card services in WeddingBazaar different from others",
      answer:
        "Out of so many options and invitation card printers and designers, we have filtered out the best ones. They are experienced at playing around with the designs and materials, and give you the most creative options for your wedding card."
    },
    {
      section: "Main",
      question: "Popular wedding invitation card styles in <city>",
      answer:
        "Some of the popular invitation card styles are geometric, origami, eco-friendly, laser cut shapes, newsprints, social media style, etc.."
    },
    {
      section: "Main",
      question:
        "Steps involved in getting wedding invitation services in <city>",
      answer:
        "Here are the steps involved in getting the invitation card: \n\n1. Set your budget \n2. Decide on the count and style of the invitation card\n3. Try to mix and match\n4. Explore options and designs\n5. Shortlist the invitation card designers and printers based on the price, preference, style\n6. Filter out the invitation card designers as and when they don't meet any of your criteria. Have another round discussion if need be \n7. Select the invitation card and give the details to be printed on it"
    },
    {
      section: "Main",
      question:
        "How to request a quote for wedding invitation cards from WeddingBazaar",
      answer:
        "After you choose the invitation card service provider, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "FAQ",
      question:
        "What is the approximate cost of wedding invitations in <city>?",
      answer:
        "The approximate cost of one wedding invitation in <city> will range between Rs. 10  - Rs. 70 per piece.  "
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to order invitation cards for printing in <city>?",
      answer:
        "Printing invitation cards in <city> usually takes around 5 days depending on the quantity. "
    },
    {
      section: "FAQ",
      question: "What are the trendy wedding invitation cards?",
      answer:
        "Eco-friendly invitation cards, royal wedding cards, handcrafted invitations, acrylic invitations are some of the trendy wedding invitation cards. "
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for invitation cards?",
      answer:
        "Advance payment varies with every service provider. In most of the cases, a percentage of the payment is paid as advance the rest is paid after the delivery of the invitations. "
    },
    {
      section: "FAQ",
      question: "Will you also help with e-invites along with printing?",
      answer: "Yes, most of our service providers help with e-invites as well. "
    },
    {
      section: "FAQ",
      question: "Can we take the photo of the invitation card?",
      answer:
        "No, most of the service providers do not allow people to photograph the invitation cards."
    },
    {
      section: "FAQ",
      question: "What are the font choices for my wedding invitation cards?",
      answer:
        "Every service provider will provide the customers with a lot of options to choose from. The customers can select the ones depending on their taste. "
    },
    {
      section: "FAQ",
      question: "Will you provide an RSVP card?",
      answer:
        "Yes, if it is requested by the customer an RSVP card will be provided along with the invitation card. "
    },
    {
      section: "FAQ",
      question:
        "Will you print separate cards for the bride's side and groom's side?",
      answer:
        "It entirely depends on the request from the couples. If the couples want separate invitations for both their sides, it can also be done."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for invitation cards?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding invitation services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Do you provide invitation cards only for weddings?",
      answer:
        "We provide invitations for all kinds of events but weddings are our service provider's speciality. "
    },
    {
      section: "FAQ",
      question:
        "What are the paper/material choices for my wedding invitation cards?",
      answer:
        "Matte paper, handmade paper, recycled paper, linen paper. seed paper etc., are some of the choices for wedding invitation cards"
    },
    {
      section: "FAQ",
      question: "Do you offer eco-friendly seed paper invitation cards?",
      answer:
        "Yes, upon request eco-friendly seed paper invitation cards can be printed. "
    },
    {
      section: "FAQ",
      question: "What is the content to be printed on the wedding invitation?",
      answer:
        "The content to be printed on the wedding invitation has to be given by the couples. However, the service providers will have a fair idea and can help the couple with the content. "
    }
  ],
  "marriage-certificate-services": [
    {
      section: "Main",
      question: "Marriage certificate services",
      answer:
        "The moment the [wedding ceremony](https://www.weddingbazaar.com/wedding-assist) is completed, you concentrate on post-wedding rituals, [honeymoon travel](https://www.weddingbazaar.com/<citySlug>/honeymoon-tour-operators), etc.. What gets ignored in all these? The marriage certificate.\n\nA marriage certificate is essential for any legal procedures like visa, passport, etc.. For any legal procedures, this certificate acts as proof of your marital status. That is the reason, it is essential to get your marriage certificate immediately after your [wedding ceremony](https://www.weddingbazaar.com/wedding-assist).\n\nEvery state has its own rules and process with respect to the marriage certificate. Some keep a time frame within which if the certificate isn't taken, you may have to pay some fine. Some offices also offer tatkal facilities.\n\nTherefore, it is necessary to plan and get your marriage certificate, the moment you are free from your [wedding ceremony](https://www.weddingbazaar.com/wedding-assist). If you are planning your honeymoon immediately after the wedding, then plan to get the certificate after coming back. However, if you have a day or two in between, make sure to get it done that time.\n\nWondering where to get the certificate and who can get you the certificate on time? That's why we from are here!\n\nGo through our marriage certificate section and get a marriage certificate for your wedding without any stress."
    },
    {
      section: "Main",
      question: "Why is a marriage certificate required?",
      answer:
        "A marriage certificate is usually required for any legal requirements. For example, visa, passport application, changing names, etc..  It also serves as a proof in the court of law for your marital status. "
    },
    {
      section: "Price",
      question: "The price range of marriage certificate*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Acc. to Hindu marriage act |Rs. 100 |\n|Acc. to special marriage act|Rs. 150 |\n|Additional charges to get affidavit|Rs. 400 to Rs. 500|\n|Tatkal  |Rs.10,000|\n\n**Prices may vary based on the location.*"
    },
    {
      section: "Main",
      question: "Tips to get the marriage certificate easily in <city>",
      answer:
        "Here are the tips that will help you get a marriage certificate easily:\n\n**First things first**\n\nThe moment you get married, you should take this up as your priority. If you are travelling to your [honeymoon](https://www.weddingbazaar.com/ideas/top-10-romantic-honeymoon-destinations-in-india-88) immediately after the wedding, get the certificate done once you are back. If you have a day or two before your honeymoon, try taking this as a priority and get it done. \n\n**Get advice**\n\nIf there are any newlyweds in your circle, enquire with them on how and where they got their marriage certificate done.\n\n**Time**\n\nIf you have to travel abroad and need a visa, search for tatkal options to get the marriage certificate online. \n\n**Documents required**\n\nAmidst wedding planning, you might forget to get all the required documents ready for the marriage certificate. However, that causes an additional delay in getting your marriage certificate. Try to arrange all the documents before you get in the loop of [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15).\n\nCheck out the FAQ section to know what documents are needed for your marriage certificate. "
    },
    {
      section: "Main",
      question:
        "What makes marriage certificate services in WeddingBazaar different from others?",
      answer:
        "Our professional marriage certificate service providers understand the importance of a marriage certificate in the first place. Their speed, quality, and overall service is the best in <city>. Also, they do understand that getting a marriage certificate is something new to all the newlyweds. Hence, they guide you in getting the certificate in an easy way. "
    },
    {
      section: "Main",
      question:
        "How to request a quote for marriage certificate services from WeddingBazaar",
      answer:
        "After you select the marriage certificate service provider, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "Main",
      question:
        "Steps involved in getting marriage certificate services in <city>",
      answer:
        "Here are the steps to get a marriage certificate:\n\n 1. Get all the documents ready prior to the wedding\n 2. Search for the nearest marriage certificate service provider\n 3. Inquire with them in case of any clarifications required\n 4. Once the wedding is done, get a photo which is required for the certificate\n 5. Go as a couple to the service provider with the documents and get the marriage certificate"
    },
    {
      section: "FAQ",
      question:
        "What are the documents to be submitted to get a marriage certificate?",
      answer:
        "Below are the documents required to get a marriage certificate. \n\n1. Proof of Marriage\n\nWedding Invitation (or) Temple Marriage Receipts (or) Any proof of marriage solemnization\n\n2. Proof of Residence\n\nEmployee ID Card (or) Ration Card (or) Driving License (or) Passport or Visa\n\n3. Proof of Age\n\nBirth Certificate (or) School/College Certificate (or) Passport / Visa"
    },
    {
      section: "FAQ",
      question:
        "What is the approximate cost of marriage certificate in <city>?",
      answer:
        "The approximate cost will range anywhere between Rs. 100 to Rs. 10,000."
    },
    {
      section: "FAQ",
      question:
        "Where can I find the fastest marriage certificate providers in <city>?",
      answer:
        "You can opt for Tatkal option to get your marriage certificate immediately. All service providers at [WeddingBazaar](https://www.weddingbazaar.com/) offer this service."
    },
    {
      section: "FAQ",
      question:
        "Is there a time limit within which I need to get my wedding certificate?",
      answer:
        "Yes, there is a time limit for getting the wedding certificate. However, it varies with every state in India. For example, in Tamil Nadu, marriage certificate can be obtained within 90 days of wedding without fine and 90-150 days with fine. "
    },
    {
      section: "FAQ",
      question: "Can we apply for a marriage certificate online?",
      answer:
        "Yes, you can apply for a marriage certification online. However, your presence is required at the later stages of the process."
    },
    {
      section: "FAQ",
      question: "How will marriage certificate affect visa application?",
      answer:
        "Depending the country for which you will need visa, the importance of marriage certificate will vary."
    },
    {
      section: "FAQ",
      question: "Is marriage license and marriage certificate same?",
      answer:
        "No, marriage license is obtained before the wedding, which allows you to get married. Marriage certificate is a document that you will get with all the details of your marriage and mentions your partner's details too."
    },
    {
      section: "FAQ",
      question: "What is the photo size required for the marriage certificate?",
      answer:
        "This varies based on the location where you apply for the marriage certificate. Some require passport size photographs of the bride and groom are required for marriage certificate while others ask for a wedding photo with the bride and the groom. Check with the service provider in advance. "
    },
    {
      section: "",
      question: "What type of photo is required for the marriage certificate?",
      answer: ""
    },
    {
      section: "",
      question: "How to get a marriage certificate for registered marriages?",
      answer: ""
    }
  ],
  "wedding-jewellers": [
    {
      section: "Main",
      question: "Wedding jewellers",
      answer:
        "Wedding jewellery is not just any other accessory for the bride and groom. It is the symbol of pride, love, and respect. When the couple selects an [engagement ring](https://www.weddingbazaar.com/ideas/5-pro-tips-for-buying-an-engagement-ring-40), they don't select any random ring.  They select something which closely represents their love. When parents select a necklace for their daughter or a bracelet for their son-in-law, they don't just select a random design. They select something which closely represents their love for their kids.\n\nDecades and centuries have passed, but the love for [wedding jewellery](https://www.weddingbazaar.com/ideas/importance-of-jewellery-in-an-indian-wedding-84) has remained the same. This is because jewellery is timeless and everyone wants to dazzle on their most important day. There are a lot of designs and styles. Be it the imitation jewellery, Kundan jewellery, etc., you name a ceremony and you can buy apt jewellery for that ceremony. For example, for the [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5), floral jewellery is in trend.\n\nWhat's important is the authenticity of the [wedding jewellery](https://www.weddingbazaar.com/ideas/how-to-choose-gold-jewellery-for-your-wedding-134). You expect a trusted brand that provides jewellery which is pure and has all the required certificates as proof. One more thing is the wastage and making charges. The lesser this is, the better.\n\nHowever, how can you blindly trust someone and purchase jewellery? You need someone who can guide you as to what's original and what's not. That's where we come into the picture.\n\nOur trusted partners believe in one thing - Customer's trust. That's possible by being honest with the customers. Go through our wedding jewellery section to understand more about our partners."
    },
    {
      section: "Main",
      question:
        "Things to consider while shortlisting wedding jewellers in <city>",
      answer:
        "Here are a few things to consider before getting [wedding jewellery](https://www.weddingbazaar.com/ideas/wedding-accessories-for-the-bride-32): \n\n**Fix a budget** \n\nWedding jewellery is more like an asset. During weddings, there are hundreds of areas of expenses. Wedding jewellery almost takes up 20% to 25% of your [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19). Keeping in mind of all these, plan the budget for the wedding jewellery accordingly. \n\n**Explore the varieties** \n\nFrom gold or platinum jewellery to imitation jewellery, there are plenty of choices to make. Based on yours and your partner's likes and dislikes, select the jewellery. \n\n**Concentrate on the engagement ring and mangalasutra** \n\nWe know that every piece of jewellery has its own importance. However, the [engagement ring](https://www.weddingbazaar.com/ideas/5-pro-tips-for-buying-an-engagement-ring-40) and mangalasutra become the most essential jewellery for weddings. Give priority for these and later see look at the other options.\n\n**Certificate and other documents** \n\nAsk for the verified certificates and hallmark for every piece of jewellery that you purchase. \n\n**EMI and other options** \n\nAsk for EMI and instalment options and the interest rate for the same.\n\n**Don't forget the Groom**\n\nThe moment we think of wedding jewellery we only picture bridal jewellery options but don't forget the Groom. There are tonnes of options for the Groom's jewellery like rings, chains, bracelets, cufflinks, etc., that you can choose from.  "
    },
    {
      section: "Price",
      question: "The price range of wedding jewellery in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Mangalsutra |Rs. 20,000 to Rs.1,00,000|\n|Necklace|Rs. 50,000 to Rs. 10,00,000|\n|Long chain|Rs. 40,000 to Rs. 4,00,000|\n|Ear ring|Rs. 30,000 to Rs. 3,00,000|\n|Finger ring|Rs. 20,000 to Rs. 1,00,000|\n|Maang tikka|Rs. 30,000 to Rs. 1,00,000|\n|Bangles|Rs. 1 lakh to Rs. 5,00,000|\n|Bracelet|Rs. 50,000 to Rs. 1,00,000|\n|Armlet|Rs. 50,000 to Rs. 3,00,000|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best wedding jewellers in <city>",
      answer:
        " 122 Here are a few tips to find the best wedding jewellers: \n\n**Research**\n\nResearch about every wedding jeweller before meeting them and compare their [wedding jewellery](https://www.weddingbazaar.com/ideas/the-best-of-the-south-indian-wedding-jewellery-sets-137) collections.\n\n**Get advice**\n\nAsk people around your circle if they know any good jewellers in the city. Make a list of all of them.\n\n**Compare between store-bought jewellery and customised jewellery from the goldsmith**\n\nIn some places, the store purchased jewellery would be good while in some a goldsmith's jewellery can be trusted upon. Pay a visit and enquire with both and compare to get the best deals.\n\n**Compare and negotiate**\n\nThe making charges vary from one jeweller to another. After this, try to negotiate on it and the jeweller who gives you the best deal is the winner!\n\n **Select the wedding jewellery services from WeddingBazaar** \n\nIf you are not sure of what's authentic and what's not, worry not. We can help you out! \nOur wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required negotiations to give you the best deals.\n "
    },
    {
      section: "Main",
      question:
        "What makes wedding jewellers in WeddingBazaar different from others",
      answer:
        "We have carefully selected only those jewellers who are best in <city>. Our wedding jewellers do not compromise when it comes to quality and service. They make sure to give their 100% to satisfy the customer requirements. They also have a wide range of bridal jewellery collections."
    },
    {
      section: "Main",
      question: "Popular jewellery styles in <city>",
      answer:
        "Popular wedding jewelleries include lotus motif jewellery, cocktail rings, chokers, floral jewellery, maang tikka, matha patti, jhumkas, etc.."
    },
    {
      section: "Main",
      question:
        "How to request a quote for wedding jewellery from WeddingBazaar",
      answer:
        "After you select the wedding jeweller, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process."
    },
    {
      section: "Main",
      question: "Steps involved while purchasing wedding jewellery in <city>",
      answer:
        "Here are the steps to purchase wedding jewellery:\n\n1. Plan your budget\n2. Explore jewellery options\n3. Explore jewellers around you\n4. Ask advice from people if need be\n5. Compare and negotiate the price of the wedding jewellery\n6. Inquire the certificates, installment options, etc.\n7. Get your wedding jewellery"
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional jewellers?",
      answer:
        "Our wedding jewellers commit to an honest service and provide you the best jewellery across the city. From EMI to online payments, from authentic traditional jewellery to imitation jewellery, etc., our wedding jewellers always work towards providing the best to the customer. "
    },
    {
      section: "FAQ",
      question: "What is the approximate cost of bridal jewellery in <city>?",
      answer:
        "Bridal jewellery costs vary across the cities and is very dependant on gold prices at the time of purchase. The approximate range of cost lies in between Rs. 2,00,000 to Rs. 1,00,00,000. It depends on the type of jewellery, the material, and the service provider."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for wedding jewellery?",
      answer:
        "Advance payment is taken only for the jewellery that is custom made. The rest of the jewellery can be bought right off the shelf with full payment."
    },
    {
      section: "FAQ",
      question: "Where can I get customized wedding jewellery?",
      answer:
        "Customized wedding jewellery can be made, if they are pre-ordered. Delivery time varies with every service provider and also depends on the work on that specific set of jewellery."
    },
    {
      section: "FAQ",
      question: "Is the jewellery available for rent?",
      answer:
        "Imitation jewellery is usually available on rent. Some brides prefer to opt for artificial jewellery instead of expensive gold jewellery. "
    },
    {
      section: "FAQ",
      question: "Can I get imitation jewellery?",
      answer:
        "Yes, imitation jewellery is available with most of our service providers. "
    },
    {
      section: "",
      question: "Is all the jewellery certified?",
      answer: ""
    },
    {
      section: "FAQ",
      question: "What are the exchange policies?",
      answer:
        "Exchange policies are different for different service providers. Please check with individual service providers before purchasing the jewellery. "
    },
    {
      section: "",
      question: "What are the T&C's for lifetime policy?",
      answer: ""
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for wedding jewellery?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding jewellery. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Is EMI available for wedding jewellery?",
      answer:
        "Some jewellers offer EMI options for bridal jewellery while others expect full payment while buying."
    },
    {
      section: "FAQ",
      question: "What are the options for artificial jewellery?",
      answer:
        "You can either opt for artificial jewellery for the entire wedding and have some pieces in imitation and some real jewellery. Most brides prefer to wear real jewellery for the muhurtham ceremony and wear heavier and grand artificial jewellery for the [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24)."
    },
    {
      section: "FAQ",
      question: "What type of jewellery do you offer?",
      answer:
        "We offer all kinds of jewellery like bridal jewellery sets, necklaces, diamond jewellery, platinum jewellery, platinum love bands, engagement rings, anklets, mangalsutras, bracelets, long chains, matha pattis, maang tikkas, floral jewellery, imitation jewellery, etc.."
    },
    {
      section: "FAQ",
      question: "Are there any exclusive engagement ring collections?",
      answer:
        "Yes, there will be exclusive engagement ring collections from our service providers. You can choose from a wide range of ring options. "
    },
    {
      section: "FAQ",
      question: "What are the different mangalsutra options?",
      answer:
        "The Mangalsutram aka thali, mangalyam, etc., is available in different designs. The type of chain varies from culture to culture. Some wear black beads while others wear coral mangalsutras. There are also shorter mangalsutras that are trendy and modern that are suitable for everyday wear for working women and women who travel often. "
    },
    {
      section: "FAQ",
      question: "What are the jewellery options for grooms?",
      answer:
        "Jewellery for grooms include short chains, bracelets, finger rings, cufflinks, etc.. There are a lot of variations in these jewellery for grooms. "
    },
    {
      section: "FAQ",
      question: "What is the making charge and is that negotiable?",
      answer:
        "Making charges varies based on the jeweller. While some people negotiate on the making charges, the others have fixed making charges. "
    },
    {
      section: "FAQ",
      question: "Can I get the wedding jewellery catalogue online?",
      answer:
        "Some of our service providers have their bridal jewellery catalogue online. For other you will have to visit their store to checkout the bridal jewellery collection. "
    },
    {
      section: "FAQ",
      question: "Where can I buy floral jewellery?",
      answer:
        "Floral jewellery typically used in Haldi ceremony or mehendi ceremony is available with specific service providers. Please check beforehand to get trendy floral jewellery. "
    },
    {
      section: "FAQ",
      question: "Are Bridal Jewellery sets available? ",
      answer:
        "Yes. Bridal jewellery sets are available. The sets have combinations of necklace and earrings, or long chains with bracelets and earrings. Check with the service provider about different bridal jewellery sets available at their stores. "
    }
  ],
  "wedding-makeup-artists": [
    {
      section: "Main",
      question: "Wedding makeup artists",
      answer:
        "It's your wedding day and you should look your best on that day. You will be busy with all the rituals on the wedding day and in this small time frame, you need someone who can make you look as beautiful as an angel! The moment your partner looks at you, he/she should fall in love with you all over again.\n\nWho can make you look that beautiful? Of course, the beautician. The main reason to book a professional makeup artist for all your [wedding makeup](https://www.weddingbazaar.com/ideas/top-10-mesmerising-bridal-makeup-ideas-118) is that they know what exactly your skin needs. Apart from that, they also take care of your [hairstyles, saree draping](https://www.weddingbazaar.com/ideas/how-to-plan-for-your-bridal-look-makeup-hairstyles-saree-draping-22), and offer these services to your family members as well. This way, you'll not have to worry about not knowing how to drape a saree!\n\nThere are many types of makeup techniques like HD makeup, natural makeup, airbrush makeup, etc.. All of them will suit certain skin types and you must select that which suits you. Also, care should be taken while using concealers, foundation, etc.. and only choose shades that matches your skin tone. It is a sensitive area which needs expert eyes to understand this. Who else can be better than a professional makeup artist?\n\nHowever, where can you find an expert beautician? Who can guarantee you that you will look like a bride and not a bridezilla?\n\nWe can!\n\n[WeddingBazaar](https://www.weddingbazaar.com/) has professional makeup service providers who are the best in their field!\n\nVisit our makeup artists section to know more."
    },
    {
      section: "Main",
      question:
        "Things to consider while shortlisting bridal makeup artists in <city>",
      answer:
        "Here are a few things to consider before booking a bridal makeup artist:\n\n**Set your budget**\n\nConsider this as your first priority whenever you think of [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15). The obvious reason is that your preferences and priorities are greatly altered by the [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19). \n\n**Decide on the bridal makeup artist**\n\nThere are many brides who would want their bff's to take care of the [bridal makeup](https://www.weddingbazaar.com/ideas/9-diy-bridal-makeup-tips-for-your-sangeet-ceremony-67) or they choose to do it themselves. Some even take suggestions from their friends and relatives and then decide. Take your time and decide who your choice of artist would be. Keep in mind that you will also need the makeup artist to handle the hairstyling and [saree draping](https://www.weddingbazaar.com/ideas/the-different-styles-of-draping-a-bridal-saree-in-an-indian-wedding-151). \n\n**Check for any skin allergies**\n\nSome of you might have certain allergies or skin infections. Make sure you visit a dermatologist and ask their suggestion on makeup. Use only those products that are recommended.\n\n**Research on the bridal makeup artists**\n\nBe it any famous stylist or your regular parlour aunty, you will have some particulars and are only comfortable with some people. Research, ask people and know the parlours or salons near you. There are different types of makeup like HD makeup, 3D makeup, airbrush makeup, natural makeup, no-makeup makeup, contouring,  etc.. Check the various styles and decide on which style you want to go for. \n\n**Prepare your questionnaire**\n\nPrepare questions beforehand and never hesitate to ask any of those questions to the beautician. Make sure you have taken note of all the questions and doubts that you have. Opt for a trial makeup session which might help you finalise on a beautician. \n\n**Check if you need any additional service**\n\nAlong with makeup on the wedding day you might also want makeup for friends and family, waxing, a spa session, manicures, pedicures, facials, body polishing, etc.. Discuss this with the makeup artist and check if they have special bridal makeup packages that you can choose.  "
    },
    {
      section: "Price",
      question: "The price range of makeup artists in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Bridal makeup  | Rs. 10,000 to Rs. 50,000 |\n|Bridal and family makeup| Rs. 20,000 to Rs. 60,000  |\n|Saree draping |Rs. 1,000 to Rs. 3,000|\n|Hair styling| Rs 1,000 to 5,000|\n|All-inclusive package| Rs 35,000 onwards|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best bridal makeup artist in <city>",
      answer:
        "Here are a few tips to help you find the best bridal makeup artist:\n\n**Scroll through their social media page**\n\nNowadays, most bridal makeup artists have their own social media platform. Scroll through all of their pages to get an idea of their work. They will have before-after pictures of brides  which could help you decide. \n\n**Questions to the rescue**\n\nFrom skin allergies to number of services provided, you will have lot of questions and there are chances of missing to ask anything to the beautician. Therefore, make a note of all your questions and have a thorough discussion with the makeup artist. This way, it will be easy to filter out the options. \n\n**Catalogue or portfolio**\n\nIf the beautician is not having any social media pages, ask them if they have any catalogue or portfolio where you can see their work. Note the points that you observe which later helps you with filtering. \n\n**Services provided**\n\nAs mentioned above, ask them about the services provided. From saree draping, hair styling, to makeup and styling for the family, there are many services that come in [bridal makeup packages](https://www.weddingbazaar.com/ideas/how-to-plan-for-your-bridal-look-makeup-hairstyles-saree-draping-22). Also, enquire on how many people would be accompanying the [bridal makeup](https://www.weddingbazaar.com/ideas/top-10-mesmerising-bridal-makeup-ideas-118) artist.\n\n**Select the bridal makeup artists from WeddingBazaar** \n\nConfused with the pool of options? Need help in filtering out to find the best bridal makeup artist? Well, we are here to help you. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required negotiations to give you the best deals."
    },
    {
      section: "Main",
      question:
        "What makes bridal makeup artists in WeddingBazaar different from others",
      answer:
        "Our hand-picked, professional bridal makeup artists are the best in their field. Not only do they understand the needs of the customers but they always deliver more than expected. They believe that honest service is the key to customer satisfaction. They use good quality and skin-friendly products."
    },
    {
      section: "Main",
      question: "Popular bridal makeup styles in <city>",
      answer:
        "Popular bridal makeup styles are monochromatic makeup, natural makeup, evening makeup, airbrush makeup, HD makeup, mehendi makeup, updo hairstyle, etc.."
    },
    {
      section: "Main",
      question: "Steps involved in hiring bridal makeup artists in <city>",
      answer:
        "These are the steps involved in hiring a beautician:\n\n1. Set your budget\n2. Search for options and styles\n3. Research on the bridal makeup artists around you\n4. Keep your questions ready \n5. Ask questions and note down their answers \n6. Scroll through the bridal makeup artists' social media page\n7. Filter out the beautician's and finally pick one"
    },
    {
      section: "Main",
      question: "How to request a quote for bridal makeup from WeddingBazaar",
      answer:
        "After you select the bridal makeup artist, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process."
    },
    {
      section: "Main",
      question: "Are salon services included in the bridal makeup packages",
      answer:
        "Yes. Some of our bridal makeup service providers also have salon services.  You can opt for all-inclusive bridal makeup packages or choose various services based on your requirement."
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from a professional bridal makeup artist?",
      answer:
        "A bridal makeup artist takes care of the bridal makeup along with hairstyle and [saree draping](https://www.weddingbazaar.com/ideas/5-different-ways-of-draping-the-traditional-south-indian-saree-110) for the bride. They also assist the bride in [wearing jewellery](https://www.weddingbazaar.com/<citySlug>/wedding-jewellers). Some artists even offer pre-wedding beauty services like waxing, hair spa, facials, body polishing, haircuts, manicure, pedicure, etc.."
    },
    {
      section: "FAQ",
      question:
        "What is the approximate cost of bridal makeup services in <city>?",
      answer:
        "The cost for bridal makeup based on the makeup artist, services opted for, and products used. However, an approximate cost for bridal makeup in <city> will be around Rs. 20,000 to Rs 1,00,000."
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book a wedding makeup artist in <city>?",
      answer:
        "Bridal makeup artists can be booked a couple of months before the wedding date. "
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for bridal makeup?",
      answer:
        "Advance payment for bridal makeup services varies with every service provider. While some prefer a percentage of their payment in advance, the others prefer to have full payment in advance."
    },
    {
      section: "FAQ",
      question: "How many trial makeup sessions are done?",
      answer:
        "It is mutually decided by the service provider and the client. Usually 1 to 2 trial make up sessions are done before the wedding."
    },
    {
      section: "FAQ",
      question: "How long does the bridal makeup take?",
      answer:
        "Depending on the sophistication of the makeup, it usually takes a 1 - 2 of hours to get the entire bridal makeup and hairstyle done."
    },
    {
      section: "FAQ",
      question: "What brands do you use and are they specific to the skin?",
      answer:
        "The common products that are used include Lakme, Krylon, Nykaa, Maybelline, M.A.C., etc.. If you inform any of your skin issues or specifications to the beautician, they bring the products accordingly. "
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for bridal makeup?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on bridal makeup services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Do your makeup artists do makeup only for weddings?",
      answer:
        "No. Some of them even handle makeup for occasions like [engagement ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-an-engagement-ceremony-13), baby naming ceremony, photoshoots, etc.."
    },
    {
      section: "FAQ",
      question: "Will your makeup artists get the makeup products as well?",
      answer:
        "Yes, if mentioned in the contract, the makeup artists will also get the makeup products. "
    },
    {
      section: "FAQ",
      question: "Is saree draping included in bridal makeup package?",
      answer:
        "Yes, [saree draping](https://www.weddingbazaar.com/ideas/5-different-ways-of-draping-the-traditional-south-indian-saree-110) for the bride is included in most bridal makeup packages."
    },
    {
      section: "FAQ",
      question: "Is makeup done only for brides?",
      answer:
        "If requested by the client, even family members, friends and bridesmaids can be included in the package at additional cost."
    },
    {
      section: "FAQ",
      question: "What are the groom makeup packages?",
      answer:
        "Some of our beauty experts also offer groom makeup packages. It includes makeup, hairstyling, salon services, etc.."
    },
    {
      section: "FAQ",
      question: "Does your bridal makeup package include hairstyling?",
      answer:
        "Yes, the bridal makeup package also includes hairstyling for the bride."
    }
  ],
  "bridal-mehndi-artists": [
    {
      section: "Main",
      question: "Bridal mehendi artists",
      answer:
        "Mehendi is the one thing all Indian ladies get excited for. There's some beauty that is hidden behind mehendi that makes it so lovely. Maybe that's a reason, why this is included in Indian weddings.\n\nThe [mehendi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-the-mehendi-ceremony-168) is performed on the day before the wedding. The major reason is that the natural herbs present in mehendi or henna cools the body and calms the mind. During the [wedding ceremony](https://www.weddingbazaar.com/wedding-assist), it is common that the soon-to-be couple will be under stress. Be it the [wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15) or the life that starts post-wedding. They need some stress buster which can help them cope up with this stress and actually enjoy the wedding.\n\nEvery bride will have a dream mehendi design, agree, lady? The last thing that you would want is someone to ruin that for you. However, professional makeup artists know how to make your dream mehendi design a reality. Do you know where to find them?\n\n[WeddingBazaar](https://www.weddingbazaar.com/), the one-stop wedding planning destination.\n\nVisit our mehendi artists section to know everything about our wedding mehendi artists."
    },
    {
      section: "Main",
      question:
        "Things to consider while shortlisting mehendi artists in <city>",
      answer:
        " Here are a few things to consider before booking a mehendi artist: \n\n**Number of people**\n\nMake a note of the number of people who will be getting the mehendi applied apart from the bride. There are cases where both the bride and groom's family get mehendi at the same place. In this case, make sure the count is proper.  An approximate number is also fine.\n\n**Decide on the venue**\n\nIf you are hosting a small and intimate mehendi ceremony, you can plan and have the mehendi ceremony at your home. However, if you want a bigger function then decide on the venue. It can be a small party hall, resort, or even the backyard of your house. Decide the place based on the size of the guests.\n\n**Research on the mehendi designs**\n\nMany artists and many platforms have trendy, beautiful, and eye-catchy [mehendi designs](https://www.weddingbazaar.com/ideas/the-latest-mehndi-designs-to-have-this-wedding-season-106). Do your part of the research and if need be, ask your family members likes and dislikes. Take note of everyone's preferences. \n\n**Fetching the mehendi artist**\n\nAt [WeddingBazaar](https://www.weddingbazaar.com/), we have a plethora of mehendi artists and you can select any one based on your preferences. When you meet the mehendi artist, make sure to tell him or her your requirements and number of days you need thier services."
    },
    {
      section: "Price",
      question: "The price range of mehendi artists in <city>*",
      answer:
        "|Category| Cost  |\n|--|--|\n|Bridal mehendi design  | Rs. 1,000 to Rs. 1,500  |\n|Bridal and Family mehendi| Rs. 2,500 to Rs. 12,000 |\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best mehendi artist in <city>",
      answer:
        "Here are a few tips to help you find the best bridal makeup artist:\n\n**The more, the merrier**\n\nResearch and find out about a few mehendi artists. Some places even have a street dedicated for mehendi artists. Find out and talk to as many artists as possible.\n\n**Live work and speed**\n\nSome artists will have stalls where they put mehendi on the spot. See if you can find them and observe their work. Even if the design that they put is simple or the length is short, observe their strokes and speed. You will get an idea of their work then.\n\n**Collections**\n\nAsk the mehendi artists to show their collections and their work. Go through their collections and check for the versatality in each design.\n\n**Services provided**\n\nCheck with the service provider on how many mehendi artists will be accompanying them. Also check with them if they get a specialist for the bridal mehendi.\n\n**Select the mehendi artists from WeddingBazaar**\n\nUnsure of where to start? Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required research for mehendi artists and will filter out the best options based on your needs.."
    },
    {
      section: "Main",
      question:
        "What makes mehendi artists in WeddingBazaar different from others?",
      answer:
        "Our mehendi artists are very professional and are the best in the industry. There concentration always lies in providing the best service to the customers. Don't believe us? Try their services yourself! They use the latest mehendi designs and the best quality of mehendi."
    },
    {
      section: "Main",
      question: "Popular mehendi design ideas in <city>",
      answer:
        "Popular mehendi designs are plain arabic, arabic design with motifs, trail designed arabic, classic Indian, traditional dulha dulhan mehendi,  raja rani mehendi, etc.."
    },
    {
      section: "Main",
      question: "Steps involved in hiring a mehendi artist in <city>",
      answer:
        "These are the steps involved in hiring a mehendi artist: \n\n1. Search for options and styles \n2. Decide on the venue\n3. Research on the mehendi artists around you \n4. Ask all your queries\n5. Check their collection and live work if possible \n6. Enquire with their services\n7. Filter out the artists and finally pick one"
    },
    {
      section: "Main",
      question: "How to request a quote for mehendi artists from WeddingBazaar",
      answer:
        "After you select the mehendi artist, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process."
    },
    {
      section: "Main",
      question: "What kind of bridal mehendi packages are offered",
      answer:
        "Bridal mehendi packages include mehendi for bride and her family (the number of people varies.)"
    },
    {
      section: "FAQ",
      question: "What is the approximate cost of mehendi artists in <city>?",
      answer:
        "The approximate cost for mehndi artists in <city> will be around Rs. 1500 to Rs. 5,000 for the bridal mehndi and around Rs. 100 to Rs. 500 /person apart from the bride."
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book a mehendi artist in <city>?",
      answer:
        "Mehndi artists in <city> have to be booked at least a couple of months before the wedding."
    },
    {
      section: "FAQ",
      question: "Is there advance payment to be done for mehendi artist?",
      answer:
        "Yes, some mehndi artists prefer to get a small amount as advance payment, while some collect one time payment after the wedding."
    },
    {
      section: "FAQ",
      question: "Is the mehendi done for the members of the family?",
      answer:
        "Yes, if mentioned in the contract it can also be done for the members of the family."
    },
    {
      section: "FAQ",
      question: "How many mehendi artists will be sent to my wedding?",
      answer:
        "Depending on the scale of the mehendi ceremony and request from the client, the number of mehendi artists for a wedding can be decided mutually."
    },
    {
      section: "FAQ",
      question: "What kind of mehendi do the artists use?",
      answer: "Our service providers use the best quality mehendi."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for mehendi artist?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on mehndi services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Will your mehendi artist use the designs suggested by us?",
      answer:
        "Yes, mehendi artists usually take suggestions from clients regarding the designs."
    },
    {
      section: "FAQ",
      question:
        "Will your mehendi artist be available on the day of the wedding?",
      answer:
        "Yes, if requested the mehendi artist can be available on the day of the wedding too."
    }
  ],
  "music-services": [
    {
      section: "Main",
      question: "Things to consider while shortlisting musicians in <city>",
      answer:
        "These are the things to consider while hiring musicians for your wedding:\n\n**Set your budget**\n\nThis is the main step while you are [planning a wedding](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15). Make sure you set the budget for the musicians.\n\n**Decide on the style**\n\nDecide on whether you need classical music, light music, or DJ beats. Check with your family members for their preference. Don't forget to ask your grandparents for their likes and dislikes! For traditional weddings, you might also need Nadaswaram, thavil, or chenda melam artists as well.\n\n**Decide on the occasions**\n\nBe it the [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4) or the [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), decide on what kind of music you need and on which occasions you need them. Be very clear and specific here.\n\n**Check where the musicians can play at the venue**\n\nCheck if the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) has exclusive space / stage for wedding musicians. Make sure the artists get a proper place to show their art!  If you have to set a stage, you will have to contact you [wedding decorator](https://www.weddingbazaar.com/<citySlug>/wedding-decorators) for this.\n\n**Research and explore**\n\nCheck the internet, go to live shows, and speak with people to gain more knowledge. Be prepared with questions when you meet the artists for music.\n\n**Talent hunt amongst family**\n\nCheck if your family has a hidden gem.  Especially for sangeet and mehendi ceremonies, along with the main artist you can also include family members to keep the event more engaging.  Also check with the artist if they can include your hidden gem in their performance. Imagine the surprise amongst your family when they see the secret performance!"
    },
    {
      section: "Main",
      question: "Music services",
      answer:
        "No wedding is complete without music. Music creates a sense of positive vibes around. With the inclusion of music, any boring ceremony would get interesting. Music makes people groove, sing, enjoy the occasion. Music keeps wedding guests engaged while you are busy with all the rituals. \n\nMusic is a divine form of entertainment and only when we respect it, it gives all its powers to us. Only the right musicians know how to respect music and devote themselves to it. Only they have the power to make their surroundings fill with positive thoughts. \n\nIn a wedding, be it the [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4) or [https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), music is mandatory. A step further it to organise an orchestra or DJ party and bam! your wedding will be the most memorable. \n\nWhere can you get such musicians who can make your day? If you are reading this, you should know who can get you such musicians. \n\nBrowse through our musicians to book your favourite ones among them!"
    },
    {
      section: "Price",
      question: "The price range of musicians in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Orchestra  |Rs.25,000 to Rs.60,000|\n|Band  | Rs. 20,000 to Rs. 40,000 |\n|Nadaswaram*|Rs. 15,000 to Rs. 30,000|\n|DJ  | Rs. 15,000 to Rs, 1,50,000 |\n\n**Charges per hour*\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best musicians in <city>",
      answer:
        "These are the tips to find the best musicians:\n\n**Versatality**\n\nArtists who are good in different styles of music is always a plus point. They are the main crowd pullers and will engage the guests with their talent while you get ready for your [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) or any ceremony.\n\n**Live shows**\nVisit their live shows and observe how they attract the crowd. Make notes if necessary.\n\n**Instrumental music**\n\nMore than karoke, live instruments create more attention. The live fusions, live performance will make your wedding the best!\n\n**Open to talents**\n\nWhat more do you need than an artist who helps in getting the talent out from the crowd? You can even explore the hidden talent in you!\n\n**Availablity**\n\nThis is an obvious point, however, what we are trying to mention is that they are available on the multiple occasions and can help you with last minute performances.\n\n**Select the musicians from WeddingBazaar**\n\nNot interested in taking any risks? Okay then, we are here to help you. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform does all the required research for musicians and will filter out the best options based on your needs."
    },
    {
      section: "Main",
      question: "What makes musicians in WeddingBazaar different from others",
      answer:
        "Our music experts are not just pros in music, but also have the art of gaining crowd attention throughout the show. From being on time to agreeing to any last-minute song requests, they are the best one can find. Try their service yourselves if you don't believe us!"
    },
    {
      section: "Main",
      question: "Popular music styles in <city>",
      answer:
        "Popular music styles are classical, modern, DJ, fusion, light music, nadaswaram, carnatic music, bollywood romantic hits, etc.."
    },
    {
      section: "Main",
      question: "Steps involved in hiring musicians in <city>",
      answer:
        "These are the steps involved in hiring musicians:\n\n1. Set your budget\n2. Meet the musicians and watch their live performance\n3. Mention whether they will perform with the musicians in your family\n4. Mention all your other preferences to the musicians\n5. Shortlist the musicians based on the price, preference, availability\n6. Filter out the musicians as and when they don't meet any of your criteria. Have another round discussion if need be\n7. Book a musician"
    },
    {
      section: "Main",
      question: "How to request a quote for musicians from WeddingBazaar",
      answer:
        "After you select the musicians, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process."
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional musicians?",
      answer:
        "Musicians provide services like light music orchestra, DJ, karaoke, nadhaswaram, chenda melam, instrumental music, etc.."
    },
    {
      section: "FAQ",
      question: "What is the approximate cost of musicians in <city>?",
      answer:
        "Depending on the genre of music, the cost of musicians in <city> will be around Rs. 10,000 to Rs. 50,000."
    },
    {
      section: "FAQ",
      question:
        "How many days in advance do I need to book musicians in <city>?",
      answer:
        "Musicians need to be booked at least 6 months before the wedding."
    },
    {
      section: "FAQ",
      question: "Do you play both classical and modern music?",
      answer:
        "Yes, depending on your preference the musicians can play either classical or modern music."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for musicians?",
      answer:
        "Musicians expect a certain percentage of their payment as advance to confirm the booking."
    },
    {
      section: "FAQ",
      question: "Can we see any live performance of the artist?",
      answer:
        "It depends on the artist. Some artists do an exclusive live performance while the other do not."
    },
    {
      section: "FAQ",
      question: "What are the occasions for which the musicians perform?",
      answer:
        "Musicians can perform for occasions like the [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24), [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5), band for baraat ceremony, and during the wedding."
    },
    {
      section: "FAQ",
      question: "How many artists will you accompany with you?",
      answer:
        "Depending on the kind and scale of performance the number of artists will vary. Please check this with the service provider."
    },
    {
      section: "FAQ",
      question: "Do the musicians need rehearsals at the venue?",
      answer:
        "In most cases, music artists do not request for a rehearsal at the venue."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for musicians?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding music services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Are DJ services available?",
      answer: "Yes, DJ services are available."
    },
    {
      section: "FAQ",
      question: "Will the musicians get mics and speakers?",
      answer:
        "Yes, if mentioned in the contract the musicians will bring the audio system. In some cases you will have to arrange this with the help of your [wedding decorator](https://www.weddingbazaar.com/<citySlug>/wedding-decorators)."
    }
  ],
  "pandits-and-priests": [
    {
      section: "Main",
      question:
        "Things to consider while shortlisting priests/pandits in <city>",
      answer:
        "These are the things to consider while hiring a priest or pandit:\n\n**Set your budget**\n\nStart your search by first fixing a budget for the pandits or priests. Try to speak with people who have recently had a wedding. They will have an idea of good and reliable pandits or priests.\n\n**Family or outside**\n\nSome families will have priests or pandits known to them or are part of the family. Decide on whether you want to book them or want to search elsewhere.\n\n**Community specific**\n\nIf you need a specific community priest, make a note of it. Search and enquire on where you can find them and discuss with them to get all possible information.\n\n**Requirements**\n\nAny specific requirements that you have, make a note of it. Explain your needs to all the priests or pandits that you meet and get their response."
    },
    {
      section: "Main",
      question: "Pandits and priests",
      answer:
        "Pandits or priests are the pillars of any [wedding ceremony](https://www.weddingbazaar.com/wedding-assist). We know that you, being the hosts are supposed to be the pillars, but only a pandit or a priest knows the rituals of the wedding. Only they can make a wedding divine with their presence. Their blessings are much needed for any couple to start their married life.\n\nHowever, we have also seen many pandits or priests who are frauds and it is highly difficult to differentiate the innocent ones with frauds. They have just the subtle difference and that leads us to not believe even the truthful ones.\n\nFret not, now, we have handpicked those pandits and priests who have the knowledge and devotion towards the almighty. They only have one thing in mind - sharing goodness among people.\n\nWe do believe in their thought and would want to share this goodness in every possible way.\n\nGo through our pandits and priests section to know more!"
    },
    {
      section: "Price",
      question: "The price range of priests/pandits in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Pandit for Hindu wedding#  |Rs. 30,000 to Rs. 1,00,000|\n|Imam for Muslim wedding  |Rs. 7,000 to Rs. 10,000  |\n|Priest for Christian wedding*|Rs. 7,000 to Rs. 10,000|\n\n**Inclusive of pooja samagri*\n\n**There is no set fee for the priest. This is just for reference.*\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best priest/pandit in <city>",
      answer:
        "These are the tips to find the best priest or pandit:\n\n**Language preference**\n\nCheck whether the priest or pandit can speak in languages that you are comfortable with.\n\n**Explanation**\n\nAsk the priest or pandit whether they can explain about all the rituals that will be done during the wedding. Again, if he can explain in the language which everyone are comfortable, it would be a plus point.\n\n**Pooja materials / samagri**\n\nCheck with the priest or pandit if he can arrange the items required for the wedding. If not, ask him if he can provide the list of items needed beforehand so that you will have time to get it.\n\n**Availability**\n\nCheck if the pandit or priest is available for all the days of the wedding. Some groom's will have their upanayanam done just before the wedding. Ask if the pandit can do that as well. Likewise, there will be many rituals before and after the wedding as well. Make sure the pandit or priest is available for all of them.\n\n**Select the pandits or priests from WeddingBazaar**\n\nUnsure of where to start? Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required research for pandits or priests and will filter out the best options based on your needs."
    },
    {
      section: "Main",
      question:
        "What makes the priests/pandits of WeddingBazaar different from others",
      answer:
        "With abundant knowledge and devotion towards almighty, our pandits and priests are believer of good service. They not only make the rituals in the traditional way, but also provide a fun atmosphere with positive vibes around. "
    },
    {
      section: "Main",
      question: "Steps involved in hiring priests/pandits in <city>",
      answer:
        "These are the steps involved in hiring a pandit or priest:\n\n1. Set your budget\n2. Note your specific requirements\n3. Note down the rituals to be done before and after the wedding. Also see if you want the pandit to get all the samagri\n4. Search for community-specific priests or pandits if needed\n5. Check the priest or pandit's availability and language preference\n6. Filter out the pandits and priests based on price, availability, and service\n7. Select pandit or priest for your wedding"
    },
    {
      section: "Main",
      question: "How to request a quote for priests/pandits from WeddingBazaar",
      answer:
        "After you select the pandit or priest, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for pandits?",
      answer: "The advance payment for pandits vary depending on the event."
    },
    {
      section: "FAQ",
      question: "Can you find me religion-specific pandits?",
      answer:
        "Yes, [WeddingBazaar](https://www.weddingbazaar.com/) can help you find both religion and caste specific pandits."
    },
    {
      section: "FAQ",
      question: "Will the pandit get all the items required for the wedding?",
      answer:
        "Yes, the pandits can get all the items required for the wedding, if it is mentioned in the contract."
    },
    {
      section: "FAQ",
      question: "How many people will assist the pandit?",
      answer:
        "Depending on the scale of the event the number of people assisting the pandit will vary. Typically 1-5 pandits are present to conduct a traditional wedding ceremony."
    },
    {
      section: "FAQ",
      question: "Can the pandit do both upanayana and marriage rituals?",
      answer:
        "Yes, the pandit can perform both the upanayana and marriage rituals."
    },
    {
      section: "FAQ",
      question: "How many days in advance do I have to book the pandit?",
      answer: "Pandits have to be booked 6 months in advance."
    },
    {
      section: "FAQ",
      question: "Should the bride and groom know any mantras beforehand?",
      answer:
        "No, it is not necessary since they will be repeating the mantras after the pandit."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for pandits?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding pandits. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "What languages do your priests/pandits know?",
      answer:
        "Since [WeddingBazaar](https://www.weddingbazaar.com/) is spread across India, we can help you find pandits with knowledge in almost any Indian language. Be it a pandit who speaks Kannada, Tamil, Marathi, Bengali, or a Hindi-speaking pandit."
    },
    {
      section: "FAQ",
      question: "How to choose a pandit for interfaith weddings?",
      answer:
        "This depends on the couple and their families. Typically for inter-faith or inter-caste weddings, a priest or pandit from both the bride and the groom's side are present to combine and perform the rituals. In some cases priest or purohit will belong to only one side of the family."
    },
    {
      section: "FAQ",
      question:
        "Will the pandit give a proper explanation of all the wedding rituals?",
      answer:
        "Yes, if requested by the hosts, the pandits can give proper explanation about all the wedding rituals in english or in other languages that you know."
    }
  ],
  "wedding-photographers": [
    {
      section: "Main",
      question:
        "Things to consider while shortlisting wedding photographers in <city>",
      answer:
        "These are things to consider before hiring a wedding photographer:\n\n**Set your budget**\n\nLeave 15% of your [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19) for [wedding photography](https://www.weddingbazaar.com/ideas/interested-in-wedding-photography-a-guide-for-amateur-photographers-117). Make sure all your requirements fall under this and try not to exceed the budget.\n\n**Choices of photoshoot**\n\nSome like pre-wedding photoshoots while some don't. Some like photoshoot with bridesmaids and groomsmen and some like post-wedding photoshoots. Sit with your partner and decide on how many photoshoots you would want to have.\n\n**Research and explore**\n\nExplore the styles of photoshoots and wedding photographers. Make a note of your requirement and mention all your needs clearly to the photographers.  Decided whether you want candid photography or traditional photography.\n\n**Date and venue**\n\nFor the wedding ceremony, you already have the date and venue fixed. However, for the pre-wedding and post-wedding photoshoot, you need to finalise on a venue too. Based on yours and the venue's availability, finalise the shoot dates.\n\n**Venue preferences**\n\nSome [wedding venues](https://www.weddingbazaar.com/<citySlug>/wedding-venues) will be exclusive to photoshoots. They allot the place to you on an hourly basis. Make sure you discuss with the photographers and mention the approximate hours needed at the venue."
    },
    {
      section: "Main",
      question: "Wedding photographers",
      answer:
        "Capture your beautiful memories and store it in your heart and the wedding album forever. While your eyes capture sweet memories, you also expect the camera lens to capture the same. [Wedding photography](https://www.weddingbazaar.com/ideas/wedding-photography-and-video-2) is hands down the most demanded area. Most aspiring photographers have ended up getting successful in their careers because of this demand.\n\n[Wedding photography](https://www.weddingbazaar.com/ideas/wedding-photography-101-a-guide-to-all-things-related-to-wedding-photography-17) exclusively has a demand as there are multiple times, the photo shoot takes place. Be it the [pre-wedding photoshoot](https://www.weddingbazaar.com/ideas/pre-wedding-photoshoot-props-and-themes-148), [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), [mehendi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-the-mehendi-ceremony-168), [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5), wedding day, etc.. More than one photographer is required to capture all the memories.\n\nThere are different types of photo shoots available. Candid photoshoot, drone photo shoot, wide-angle photoshoot, etc.. There are hundreds of themes for photography. Architectural photography, monochrome photography, vintage photography, etc..\n\nWondering where to find a wedding photographer talented enough to capture your wedding memories?\n\n[WeddingBazaar](https://www.weddingbazaar.com/) is our answer then.\n\nCheck out our wedding photography section to know more."
    },
    {
      section: "Price",
      question: "The price range of wedding photography in <city>*",
      answer:
        "|Category|Cost|\n|--|--|\n|Traditional Wedding photography*  |Rs. 20,000 to Rs. 40,000|\n|Traditional videography  |Rs. 20,000 to Rs. 40,000  |\n|Candid Photography| Rs 40,000 to Rs 2,00,000|\n|Cinematic Videography|Rs. 60,000 to Rs. 80,000|\n|Drone photo and video shoot|Rs. 80,000 to Rs. 1,00,000|\n\n**Prices may vary based on photographers, location, and number of photoshoots.*"
    },
    {
      section: "Main",
      question: "Tips to find the best wedding photographers in <city>",
      answer:
        "These are the tips to find the best [wedding photographers](https://www.weddingbazaar.com/ideas/wedding-photography-and-video-2): \n\n**One for all**\n\nIt will be a plus point if you have the same wedding photographer for all your shoots. You will have a clear understanding between each other and the photographer would be aware of all your preferences. It is also cheaper to book the same photographer for a shoots starting from pre-wedding photoshoot, wedding shoot, to post wedding photoshoot.\n\n**Lighting and location knowledge** \n\nPhotographers should have sound knowledge of the lighting and locations where the best photos can be shot. They also will carry interesting props for the photoshoots, check for those as well.\n\n**Couple's comfort**\n\nCouple photoshoot is different from the family photoshoot. It needs certain intimacy and comfort while shooting. The best [wedding photographers](https://www.weddingbazaar.com/ideas/wedding-photography-and-video-2) are aware of this and will make the couple get to their comfort zone before getting the photos.\n\n**Turnaround time**\n\nCheck for the turnaround time, that is the duration between the photoshoot and the time taken to give the hardcopy or softcopy of the photos. The lesser the duration, the better the photographer is. Also, make sure the quality isn't compromised here. If you need your wedding photo album, discuss the charges before finalising.\n\n**Check their work**\n\nCheck for the photographer's previous photoshoots and most of them would be having pages across social media. Scroll through their work and observe their versatilities.\n\n**Google reviews**\n\nCheck the reviews on google and find out about their work.\n\n**Select the photographers from WeddingBazaar**\n\nInstead of finding and exploring so much to find the photographers for your wedding, you can simply contact us. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required research for wedding photographers and will filter out the best options based on your needs."
    },
    {
      section: "Main",
      question:
        "What makes wedding photographers in WeddingBazaar different from others",
      answer:
        "Our experienced and verified photographers' secret is the goal to achieve customer satisfaction. They put their 100% in their work and get the best output for you. Their experience and reviews talk more than themselves."
    },
    {
      section: "Main",
      question: "Popular wedding photography styles in <city>",
      answer:
        "Popular wedding photoshoot styles are traditional photoshoot, illustrative photoshoot, fashion photoshoot, black and white photoshoot, cinematic photoshoot,  candid photography and videography, etc.. "
    },
    {
      section: "Main",
      question: "Steps involved in hiring wedding photographers in <city>",
      answer:
        "These are the steps involved in hiring the wedding photographers:\n\n1. Set your budget\n2. Decide on the number of photoshoots and photo albums you might require\n3. Research about the photographer\n4. Explore the venue for pre-wedding and post-wedding photoshoot\n5. Fix the date and venue\n6. Filter the wedding photographers based on the availability, price, and quality\n7. Book the wedding photographer"
    },
    {
      section: "Main",
      question:
        "How to request a quote for wedding photography from WeddingBazaar",
      answer:
        "After you select the wedding photographer, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process."
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from a professional wedding photographer?",
      answer:
        "You can expect services like [pre-wedding photoshoot](https://www.weddingbazaar.com/ideas/pre-wedding-photoshoot-props-and-themes-148), candid wedding photography, traditional wedding photography, cinematic wedding video, traditional wedding videography, drone photography, aerial photoshoot, and post-wedding photoshoot."
    },
    {
      section: "FAQ",
      question: "What are the trendy wedding photoshoot ideas?",
      answer:
        "Candid beach photoshoot, candid photoshoot in cafes, candid photoshoot in resorts, aerial drone photoshoot, etc.. are some of the trendy wedding photoshoot ideas."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for wedding photography?",
      answer:
        "The amount of advance payment varies based on the photographer you hire."
    },
    {
      section: "FAQ",
      question:
        "Can the photographer just do a pre-wedding photoshoot for my wedding?",
      answer: "Yes, only pre-wedding photoshoot can also be done if requested."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for wedding photography?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding photography services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "How are photography services priced?",
      answer:
        "Photography services are priced based on event basis or time basis. In some cases, there will be a whole package that will be priced based on number of sessions."
    },
    {
      section: "FAQ",
      question: "Do wedding photographers show samples?",
      answer:
        "Yes, the sample works of all the photographers listed in [WeddingBazaar](https://www.weddingbazaar.com/) can be found on their WeddingBazaar profile page and on the photographers social media pages."
    },
    {
      section: "FAQ",
      question: "How many days prior do I need to book your service?",
      answer:
        "Popular photographer get booked a year in advance. Hence, book your favorite photographer as soon as your wedding date is fixed."
    },
    {
      section: "FAQ",
      question: "Can you provide a wedding invitation video?",
      answer:
        "Yes, if requested by the clients a [wedding invitation](https://www.weddingbazaar.com/<citySlug>/invitation-card-dealers) video can also be provided."
    },
    {
      section: "FAQ",
      question: "How many people will accompany you for the photoshoot?",
      answer:
        "Depending on the scale of the wedding, the number of accompanying photographers will be decided."
    },
    {
      section: "FAQ",
      question: "Is post-wedding photoshoot available?",
      answer: "Yes, post-wedding photoshoot is also available."
    },
    {
      section: "FAQ",
      question:
        "Will the same photographer shoot for all of my wedding-related photoshoots?",
      answer:
        "Yes, the same photographer can shoot all your wedding related photoshoots."
    },
    {
      section: "FAQ",
      question: "Is candid videography available?",
      answer: "Yes, candid and cinematic videography is available."
    },
    {
      section: "FAQ",
      question: "Are drone photo and video shoot available?",
      answer: "Yes, drone photoshoot and video shoot is also available."
    },
    {
      section: "FAQ",
      question:
        "Will props be provided for a pre-wedding and post-wedding photoshoot?",
      answer:
        "Yes, the photographers usually carry all the props required for a pre-wedding and post-wedding photoshoot."
    }
  ],
  "wedding-return-gift-dealers": [
    {
      section: "Main",
      question: "Things to consider while shortlisting wedding gifts in <city>",
      answer:
        "Here are a few things to consider before purchasing gifts / return gifts for weddings:\n\n**Set your budget** \n\nFor the gifts, decide and set a budget. You might need to talk to a few service providers before you come up with this number.\n\n**Number of guests**\n\nBased on the number of guests, you can plan on whether you prefer giving the [return gifts](https://www.weddingbazaar.com/ideas/5-simple-wedding-return-gift-ideas-72) on a per family basis or return gift for every guest. The cost increase multifold for the latter.\n\n**Trends and styles**\n\nExplore the options to provide the gifts. There are hundreds of trendy gift options that don't burn your pocket. Look for those."
    },
    {
      section: "Main",
      question: "Wedding return gift dealers",
      answer:
        "Wedding ceremony means the exchange of gifts. While your wedding guests plan the gift for you, you should plan it for them as well. From a simple showpiece to a [grand jewellery](https://www.weddingbazaar.com/<citySlug>/wedding-jewellers), any gift will have a value in everyone's life. People talk about it, remember it, keep in their house, etc..\n\nThe smart way to buy [return gifts](https://www.weddingbazaar.com/ideas/5-simple-wedding-return-gift-ideas-72) for your [wedding guests](https://www.weddingbazaar.com/ideas/wedding-games-to-keep-your-guests-entertained-71) is to order in bulk. Once you know the approximate guest count, order the gifts in bulk to get maximum gifts. Order in such a way that even if there is some left, you can still use it for your own.\n\nAt [WeddingBazaar,](https://www.weddingbazaar.com/) you can get some amazing deals with respect to the gifts. Visit the gifts section for more!"
    },
    {
      section: "Price",
      question: "The price range of wedding gifts in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Couple gifts  |Rs.10,000 to Rs.1,00,000|\n|Return gifts for guests*  |Rs.40,000 to Rs. 2,00,000|\n|Idols, Showpieces, Clocks| Rs 100 (per piece) onwards|\n\n**In bulk order*\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question:
        "What makes wedding gift dealers of WeddingBazaar different from others",
      answer:
        "Our gift partners are well-versed in their field and are fully aware of all the trendy options. From luxury gifts to cute budget-friendly showpieces, they have an ocean of options."
    },
    {
      section: "Main",
      question: "Popular wedding gift styles in <city>",
      answer:
        "Popular wedding return gifts are eco-friendly saplings, showpieces, diyas, Idols, clocks, wall hangings, etc..  "
    },
    {
      section: "Main",
      question: "How to request a quote for gifts on WeddingBazaar",
      answer:
        "After you select the gift service provider, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "Main",
      question: "Steps involved in getting wedding gifts in <city>",
      answer:
        " Here are the steps to purchase the gifts:\n\n1. Set your budget\n2. Get an estimation of the guest count\n3. Research on the trendy gift options\n4. Visit multiple stores or check online \n5. Shortlist a few gifts and filter out based on price, quality, and delivery charges \n6. Purchase the gifts"
    },
    {
      section: "FAQ",
      question: "What kind of gifts can be given as return gifts for guests?",
      answer:
        "Gifts such as plants, seeds, fancy carry bags, sweets, jute bags, wall clocks, wall hangings, idols, showpieces, handmade soaps, mobile pouches,  etc.. are some of the wedding gifts provided."
    },
    {
      section: "FAQ",
      question: "What are the trendy gifts to give for the couple?",
      answer:
        "Eco-friendly saplings, showpieces, diyas, kitchen appliances, domestic/international tour tickets, etc.."
    },
    {
      section: "FAQ",
      question: "What is the mode of payment for gifts?",
      answer:
        "This depends on the service provider. Most service providers accept a cheque or online payments as well."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for gifts?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding gifts. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Is it ok to just give some money as a gift for the couple?",
      answer:
        "Yes, the couple can be gifted some money in a close envelope as a gift."
    },
    {
      section: "FAQ",
      question:
        "Do you send the items gift packed or do we need to pack it separately?",
      answer:
        "If requested by the client, the gifts can be packed at additional charges."
    },
    {
      section: "FAQ",
      question: "Can we order the gifts online?",
      answer: "Yes, the gifts can be ordered online too."
    },
    {
      section: "FAQ",
      question: "What is the replacement or return policy?",
      answer:
        "This varies from one service provider to another. Please check the return policies with individual service providers beforehand."
    },
    {
      section: "FAQ",
      question: "Do you offer wedding registry services?",
      answer:
        "No, [WeddingBazaar](https://www.weddingbazaar.com/) does not provide wedding registry services."
    }
  ],
  "vehicle-rental-services": [
    {
      section: "Main",
      question:
        "Things to consider while shortlisting vehicle rentals in <city>",
      answer:
        "Here are a few things to consider while renting a vehicle: \n\n**Set your budget**\n\n[Wedding planning](https://www.weddingbazaar.com/ideas/wedding-planning-made-easy-15) revolves around the [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19). Set a budget for renting vehicles.\n\n**Decided the starting point(s) and ending point(s) for transport**\n\nYou might need a separate vehicle like a 4-seater car for airport / railway station pickup and drop and a 25-seater tempo traveller for guests to travel from their hotel / service apartment to the wedding venues. Discuss with your family and decide how many vehicle you would need. Also, for 4-wheelers, think about whether you want an additional driver or whether someone in your family can drive the car around.\n\n**What about the wedding car?**\n\nYou might want to arrive in style for your wedding. In this case, you can book a decorated wedding car.  You can book a simple decorated car or a luxury car or even luxury motorbikes for this.\n\n**Transport facility around the wedding venue**\n\nAt the wedding venue, check the transport facilities like the traffic caused or the parking capacity that the space around the [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues), etc.. \n\n**One vehicle for multiple uses**\n\nLet's take an example of your relative arriving to your city. If two or more relatives come to the same station, ask them to plan their trip in such a way that they come approximately at the same time. This way, you can send only one vehicle which can accomodate all the guests.\n\n**Destination wedding**\n\nVehicle rentals play an important role if you are having a [destination wedding](https://www.weddingbazaar.com/ideas/top-indian-destinations-to-have-your-perfect-destination-wedding-48). Plan about this well in advance.\n "
    },
    {
      section: "Main",
      question: "Vehicle rental services",
      answer:
        "A wedding means roaming here and there for each small errands. Especially, on the wedding day, you will have thousands of work and need transport to the maximum possible extent.\n\nIt may be to pick the guests from the station, dropping them to the nearest hotel, getting wedding related items, baarat preparation, picking the bride and groom, etc., the list is endless.\n\nThe last thing you would want is to miss out anything or delay things waiting for the transport. Why so stress? We are here, right?\n\nWe know how important is your big day and that everything should happen according to the specified time.\n\nWe make your 'safar' stress-free with our vehicle rental options. Visit the section for more information about vehicle rentals."
    },
    {
      section: "Price",
      question: "The price range of vehicle rentals in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Car  |Rs. 10,000 to Rs. 20,000  |\n|SUV  |Rs. 15,000 to Rs. 30,000  |\n|Bus/van|Rs. 30,000 to Rs. 50,000|\n|Vintage cars*  |Rs. 20,000 to Rs. 65,000  |\n|Luxury cars  |Rs. 20,000 to Rs. 60,000  |\n|Fancy bikes|Rs. 20,000 to Rs. 50,000|\n|Horse or elephant (baraat)* |Rs. 30,000 to Rs.75,000  |\n\n**Per hour with driver*\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best vehicle rental services in <city>",
      answer:
        "Here are a few tips to get the best vehicle rental services: \n\n**Book the vehicle using your credit card**\n\nSome vehicle rental companies charge extra amount if you use debit card while payment, although not all. If you are planning to pay using a debit card, enquire about the policies before proceeding further. Also, paying with your credit card will make the vehicle eligible for insurance in some cases. \n\n**Enquire about drivers**\n\nEnquire whether they provide drivers while booking the vehicle. It also depends on how many vehicles you need. Some vehicle rental service providers send drivers along with the vehicle while some wouldn't. You might also require the services of a professional uniformed driver. Based on your needs, shortlist the vehicle rentals. \n\n**Vehicle insurance documents**\n\nCheck all the insurance documents and policies. This is the most essential thing to do. If you have any doubts or confusions, make sure to clear all of them with the service provider. \n\n**Baarat**\n\nThe baarat horses are usually priced based on hours. A wise choice is to book the horse nearest to your [wedding venue](https://www.weddingbazaar.com/<citySlug>/wedding-venues) so that you can save time here. In some cases,  the distance to the venue matters and is charged extra for transportation. Speak with the person in charge and based on the factors that affect the price and availability, decide your choice. \n\n**Select the vehicle rental service from WeddingBazaar** \n\nOur wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required research for rental services and will filter out the best options based on your needs."
    },
    {
      section: "Main",
      question:
        "What makes vehicle rentals in WeddingBazaar different from others",
      answer:
        "Vehicle rental service at [WeddingBazaar](https://www.weddingbazaar.com/) is a one-stop destination for any kind of vehicles that you need. Be it the fancy two wheelers or baarat horse or elephants, you can find them all here. Also, we can guarantee you hassle-free service from our service providers."
    },
    {
      section: "Main",
      question: "Steps involved in booking vehicle rentals in <city>",
      answer:
        "Here are the steps involved in renting a vehicle: \n\n1. Set your budget\n2. Decide on the number and kind of vehicles required\n3. Decide on whether you need drivers or not\n4. Make a note of all the questions to be asked\n5. Talk to all the service providers and shortlist a few of them\n6. Filter out the service providers based on price, availability, distance, etc..\n7. Rent the vehicles"
    },
    {
      section: "Main",
      question: "How to request a quote for vehicle rentals from WeddingBazaar",
      answer:
        "After you select the vehicle rental service provider, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "FAQ",
      question: "What kind of vehicles will be provided?",
      answer:
        "Vehicles such as hatchback cars, sedan, luxury cars, SUV's, vans for guests, tempo travellers, shuttle services, buses, vans, horse for baraat, elephants, motorbikes, etc., are some of the vehicles that will be provided."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available vehicle rentals?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding vehicle rental services. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment vehicle rentals?",
      answer:
        "Advance payment for vehicles depend on the type of vehicle and differs with every service provider. "
    },
    {
      section: "FAQ",
      question:
        "What is the maximum distance that you can help with transport?",
      answer:
        "This depends on the service provider. Some people cater to inter-state distances as well while some only offer intra-city services. "
    },
    {
      section: "FAQ",
      question: "Will you send a driver along with a vehicle?",
      answer:
        "A driver will also be sent along with the vehicle if you specifically mention this. Some people prefer to rent cars and drive around by themselves."
    },
    {
      section: "FAQ",
      question: "How many vehicles can you provide?",
      answer:
        "Our service providers can provide you with as many number of vehicles as you want."
    },
    {
      section: "FAQ",
      question:
        "We need a vehicle for our honeymoon trip, can we book that here?",
      answer:
        "Check our [honeymoon tour operators](https://www.weddingbazaar.com/<citySlug>/honeymoon-tour-operators) section. Honeymoon service providers offer this service as a part of their honeymoon tour package."
    },
    {
      section: "FAQ",
      question:
        "Will the vehicle dedicated for the couple be decorated or not?",
      answer:
        "Yes, if requested the couple, the vehicle can have special decoration. "
    },
    {
      section: "FAQ",
      question: "Are there any restrictions on decorating the vehicles?",
      answer:
        "Some vehicle rental service providers might have certain conditions. However, they will have dedicated wedding cars which can be decorated. "
    },
    {
      section: "FAQ",
      question: "Are uniformed drivers available?",
      answer: "Yes, uniformed drivers are also available upon request."
    },
    {
      section: "FAQ",
      question: "Are luxury cars provided?",
      answer: "Yes, luxury cars can also be provided. "
    },
    {
      section: "FAQ",
      question: "What is the insurance policy?",
      answer:
        "This varies from service provider to service provider. Please check these details before booking."
    },
    {
      section: "FAQ",
      question: "Are luxury motorbikes provided?",
      answer:
        "Luxury motorbikes can also be provided for wedding entry or travel. "
    },
    {
      section: "FAQ",
      question:
        "I need a horse and an elephant for my baarat ceremony, will that be available as well?",
      answer:
        "Yes, horses and elephants can also be provided on a rental basis. "
    },
    {
      section: "FAQ",
      question: "I have to decorate my wedding car. Who can do this?",
      answer:
        "You will have to check with your [wedding decorator](https://www.weddingbazaar.com/<citySlug>/wedding-decorators) to decorate your own wedding vehicle."
    }
  ],
  "wedding-venues": [
    {
      section: "Main",
      question:
        "Things to consider while shortlisting wedding venues in <city>",
      answer:
        "These are the things to consider before booking a [wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6): \n\n**Set your budget** \n\n[Wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-perfect-wedding-hall-11) takes upto 20% of your wedding budget. This should be the first thing for which the budget should be decided for. \n\n**Immediate action** \n\nEverything else in wedding planning can wait, but not the wedding venue. This is because most of the wedding venues will be booked for almost a year and it will be difficult to find one. Therefore, as soon as the wedding is fixed, go for a wedding venue quest! \n\n**Requirements for a wedding venue** \n\nMake note of what you prefer to have in the wedding venue. Note the number of green rooms, guest rooms, fans, AC, parking availability, Valet services, dining halls, kitchen and other things that you need at the wedding venue. Make a note of all the questions and clarifications that you would want from the wedding venue provider. \n\n**Check for the availability**\n\nThis can easily be your main filter. Most wedding venues get booked well in advance. So you need to look immediately to get yours booked. If there's any chance, ask for some buffer time to the wedding venue provider before vacating the wedding venue. This way, you will have some time to relax after a long day's affair.\n\n**Special requirements** \n\nSome prefer having western toilets, hot water, or other special requirements. Discuss with your close family members who stay at the wedding venue about their preferences.  Also check if the venue is wheelchair-friendly.\n\n**Explore and visit** \n\nAfter noting down all the requirements, explore the wedding venues near your household. It is best if you can personally visit all those wedding venues and speak with the owner or the person in charge. \n\n**Ask questions** \n\nThe more questions you ask, the more clearer picture you will get about the wedding venue. Be it the extras provided or the number of guest rooms that are available, ask all questions that you have noted. \n\n**Parking space and valet service** \n\nCheck the parking space and valet service provided. Enquire the transport facilities that are there around the wedding venue from around the city. \n\n**Installment options and interests** \n\nCheck with the wedding venue provider about the installment and/or EMI options available. Ask the interest percentage that they have. \n\n**In-house service providers** \n\nSome of the [wedding venues](https://www.weddingbazaar.com/ideas/how-to-find-the-perfect-wedding-hall-11) like resorts or hotel suites will have in-house service providers. Enquire about the price range, services, and other details. Also, enquire if service providers from outside are allowed."
    },
    {
      section: "Main",
      question: "Wedding venues",
      answer:
        "The first thing anybody does the moment the wedding date is announced is to book a [wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6). The obvious reason being the demand and availability. It is highly difficult to find a [wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6) which matches to all our preferences and budget. There are some mandatory [questions to ask before booking a wedding venue](https://www.weddingbazaar.com/ideas/questions-to-ask-before-booking-a-wedding-venue-169).\n\nSome criteria which the [wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6) has to clear is the security, room availability, kitchen availability, parking and valet services, etc.. There are different types of [wedding venues](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6) available like wedding halls, banquet halls, hotels, resorts, barns, farms, etc.. Each wedding venue will have certain policies. Some of them will have in-house caterers and some don't.\n\nMany people book the [wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6) around 6 months to 1 year in advance. It is difficult to find a wedding venue in such a case. Consider the wedding venue for [destination wedding](https://www.weddingbazaar.com/ideas/top-indian-destinations-to-have-your-perfect-destination-wedding-48), it should be planned a year in advance, else the destination will be taken.\n\nSo much for a wedding venue, but don't get stressed. We take that from you.\n\nThe wedding venue providers from [WeddingBazaar](https://www.weddingbazaar.com/) know how important the big day is for you. Our wedding planning experts make sure that you get your dream wedding destination with their art of negotiation."
    },
    {
      section: "Price",
      question: "The price range of wedding venues in <city>*",
      answer:
        "|Category|Cost  |\n|--|--|\n|Resorts  |Rs. 1,00,000 to Rs. 50,00,000  |\n|Wedding halls|Rs. 75,000 to Rs.25,00,000  |\n|Hotel suites|Rs. 1,00,000 to Rs. 50,00,000|\n|Barn weddings  |Rs. 1,00,000 to Rs, 10,00,000  |\n|Palace weddings  |Rs. 10,00,000 to Rs. 60,00,000  |\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best wedding venue in <city>",
      answer:
        " These are the tips to find the best wedding venue: \n\n**Communication is the king**\n\nSpeak with the wedding venue provider and ask as many questions as possible. Do your homework and clarify eerything with the owner or the person in charge. Some will agree with all your needs while some will not be having facilities for your special reuirements. There, you will have a filter to decide the wedding venue. \n\n**Number of guests**\n\nPlan the approximate number of guests that are attending your wedding. After getting the estimation of the guest count, you will have a fair idea of how big the wedding venue must be. \n\n**Personally visit the wedding venue**\n\nHowever good the photos on google are, whatever be the comments of people who have seen the wedding venue, at the end you are the one to decide. Therefore, it is best if you can personally visit the wedding venue. \n\n**Venue policies**\n\nCarefully listen to all the [wedding venue](https://www.weddingbazaar.com/ideas/how-to-find-the-best-wedding-venue-6) policies that are present. You can decide later on the wedding venue by keeping this as a filter. \n\n**Capacity of the wedding venue**\n\nCheck the guest capacity and the dining hall capacity. If you wish to have a themed [wedding reception](https://www.weddingbazaar.com/ideas/how-to-plan-a-wedding-reception-24) or the whole wedding, check if the wedding venue supports it or not. If there are any particular rituals to be done, like the [oonjal ceremony](https://www.weddingbazaar.com/ideas/a-guide-to-the-oonjal-ceremony-ritual-155), check if there is provision for that to be performed. \n\n**Select the wedding outfits from WeddingBazaar** \n\nInstead of roaming around the city in confusion, you can simply avail our assistance. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required research for wedding venues and will filter out the best options based on your needs."
    },
    {
      section: "Main",
      question:
        "What makes wedding venues in WeddingBazaar different from others",
      answer:
        "Our wedding venue service providers are hand-picked and are the best in the industry. They understand the customer needs and any assistance that can be done from their end, they are always ready to do. Having said that, don't entirely believe us, try their services yourselves! "
    },
    {
      section: "Main",
      question: "Popular types of wedding venues in <city>",
      answer:
        "Popular wedding venue types are traditional wedding halls, outdoor lawns, resorts, hotels, party halls, Kalyanamadapams, convention halls, etc.. "
    },
    {
      section: "Main",
      question: "Steps involved in booking wedding venues in <city>",
      answer:
        "These are the steps involved in booking a wedding venue:\n\n1. Set your budget\n2. Decide on the type of wedding venue that you prefer\n3. Note down the questions, special requirements, and any clarifications needed\n4. Research and note down wedding venues available around your household\n5. Filter them based on the availability\n6. Personally pay a visit to the shortlisted wedding venues \n7. Check for parking space, transport facility, valet services, and other services \n8. Enquire about the EMI, installment options, and interest rate \n9. Book the wedding venue "
    },
    {
      section: "Main",
      question:
        "How to request a quote for a wedding venues from WeddingBazaar",
      answer:
        "After you select the wedding venue that you have shortlisted, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "FAQ",
      question: "What are the in-house services available?",
      answer:
        "The in-house services varies with every wedding venue.  Usually the in-house services that are offered are catering and decoration services."
    },
    {
      section: "FAQ",
      question: "Can I get a service provider from outside?",
      answer:
        "Yes, some of the wedding venues will allow service providers from outside, while others are strictly against using service providers from outside and prefer only their in-house caterers or in-house decorators. "
    },
    {
      section: "FAQ",
      question: "Is there a discount if I choose an in-house service provider?",
      answer: "It entirely depends on the wedding venue and service providers. "
    },
    {
      section: "FAQ",
      question: "What is the parking capacity of the venue?",
      answer:
        "The parking capacity of the wedding venue will vary from place to place depending on the available real estate. Please check this beforehand."
    },
    {
      section: "FAQ",
      question: "What are the add-ons provided at the wedding venue?",
      answer:
        "The usual add-ons provided are extra beds, generator, AC, homa kundam(a place where the rituals happen,) seats for guests, etc.. "
    },
    {
      section: "FAQ",
      question: "What are the facilities available at the wedding venue?",
      answer:
        "The facilities at the wedding venues include rooms for the bride, groom, and family members (upon request), parking facilities, restroom, kitchen etc.. The exact facilities will vary with every venue and make sure you check about this with the venue owner before booking."
    },
    {
      section: "FAQ",
      question: "Is there a place to perform the oonjal ceremony?",
      answer:
        "Yes, most of the wedding venues will have a dedicated place to perform [oonjal ceremony](https://www.weddingbazaar.com/ideas/a-guide-to-the-oonjal-ceremony-ritual-155). They also provide the oonjal or swing for this."
    },
    {
      section: "FAQ",
      question: "Is there a place to perform haldi ceremony?",
      answer:
        "Yes, almost all the wedding venues will have a dedicated place to perform [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5)."
    },
    {
      section: "FAQ",
      question: "Can the sangeet ceremony be held at your wedding venue?",
      answer:
        "Yes, the majority of the wedding venues can be used for [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4). Make sure you contact you [wedding decorator](https://www.weddingbazaar.com/<citySlug>/wedding-decorators) to set the sangeet stage."
    },
    {
      section: "FAQ",
      question: "How many months prior do I need to book for a wedding venue?",
      answer:
        "Some of the renowned wedding venues even get booked a year in advance. Usually, advance booking before 6 months will be ideal. "
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for a wedding venue?",
      answer: "The amount of advance payment varies with every wedding venue. "
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for wedding venues?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding venues. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "Is EMI available for a wedding venue?",
      answer:
        "EMI options is not provided by most of the wedding venues. Please check with the service provider."
    },
    {
      section: "FAQ",
      question: "What is the buffer time before vacating the venue?",
      answer:
        "Some wedding venue providers offer 4 hours to half day buffer time before vacating the wedding venue. It depends on the next event that will be happening at the venue."
    },
    {
      section: "FAQ",
      question:
        "What is the maximum guest capacity that wedding venues can have?",
      answer:
        "Depending on the size of the wedding venue, the guest capacity will vary. For wedding with 20 guests, 500 guests, 750 guests, 1000 guests, and 2000 guests there are different types of wedding venues. For wedding above 2000, you might have to look for an open air option that can host a large gathering."
    },
    {
      section: "FAQ",
      question:
        "How many green rooms are available to use in the wedding venue?",
      answer:
        "The number of green rooms available will vary with each wedding venue. Usually one for the bride and the groom will be provided. "
    },
    {
      section: "FAQ",
      question: "Is the kitchen available?",
      answer: "Most of the wedding venues will have a functional kitchen. "
    },
    {
      section: "FAQ",
      question: "What is the capacity of the dining hall?",
      answer:
        "Dining hall capacity will vary with each wedding venue. Before you book a wedding venue check if the dining hall has tables and chairs and also check if they have buffet stalls for buffet service."
    },
    {
      section: "FAQ",
      question: "Are valet services available?",
      answer:
        "If requested, valet services can be arranged by the wedding venue. "
    },
    {
      section: "FAQ",
      question: "Is there a separate kitchen available for non-veg cooking?",
      answer:
        "Most wedding venues have a separate kitchen for non vegetarian cooking. Otherwise, the venues will be exclusively of veg cooking and non veg cooking. No mixing is done. "
    },
    {
      section: "FAQ",
      question: "Is the outdoor wedding venue available?",
      answer:
        "Yes, [outdoor wedding](https://www.weddingbazaar.com/ideas/how-to-plan-an-outdoor-wedding-25) venues like lawns, gardens, rooftop venue, etc.are also available."
    },
    {
      section: "FAQ",
      question: "Is lodging facility available at the wedding venue?",
      answer:
        "Lodging services varies with every wedding venue. Check with the service provider before booking."
    },
    {
      section: "FAQ",
      question: "Is mist fan available?",
      answer:
        "Some wedding venues will have mist fan and if requested, they shall provide. "
    }
  ],
  "wedding-wear": [
    {
      section: "Main",
      question:
        "Things to consider while shortlisting wedding apparel in <city>",
      answer:
        "Here are a few things to consider before purchasing [wedding outfits](https://www.weddingbazaar.com/ideas/the-ultimate-guide-to-choosing-your-wedding-outfit-82): \n\n**Plan the budget** \n\nWedding outfits will take around 15% of your [wedding budget](https://www.weddingbazaar.com/ideas/how-to-manage-your-wedding-budget-and-not-get-intimidated-by-it-19). During a wedding, there are hundreds of areas of expenses. Keep in mind of all of these, plan your budget, and try to stick to it. \n\n**Time to purchase**\n\nPlan and purchase the wedding outfits in such a way that you have time for alterations in case of misfitting clothes. \n\n**Explore the varieties** \n\nScroll through Instagram and Pinterest pages, and multiple stores around you to understand the trend and to know things better. \n\n**Requirements**\n\nTake a note of all the [wedding outfits](https://www.weddingbazaar.com/ideas/bridal-sarees-v-s-bridal-lehengas-which-one-is-perfect-for-you-135) that you would need and for the occasion that you need it for. Try to find the outfits based on the occasions and sort it out when you find the outfits. \n\n**Explain your requirement to the designer**\n\nIf you're planning to purchase designer wear for your wedding, be sure and clear with the designer as to what your likes and dislikes are.\n\n**Explore the tailors around you**\n\nThere are many cases where the tailors ruin your wedding outfit. Make sure you research all the tailors around you and shortlist the best ones among them. "
    },
    {
      section: "Main ",
      question: "Wedding wear",
      answer:
        "What's the most appealing part of a wedding? It's the outfit! We get excited when we plan to go for [wedding outfit](https://www.weddingbazaar.com/ideas/the-ultimate-guide-to-choosing-your-wedding-outfit-82) shopping. Different designs, various styles, plenty of outfits, and whatnot. There are many things to be kept in mind while purchasing the wedding outfits.\n\nOur elders specifically wore only sarees or lehengas for their wedding ceremonies. However, the younger generation is good at experimenting with different outfits for each wedding ceremonies. For example, Kurta-pyjama for [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5), a gown for [sangeet ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-a-sangeet-ceremony-4), salwar-kameez for [mehendi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-the-mehendi-ceremony-168), etc.. However, they make sure they wear the traditional outfit of their community for the muhurtham.\n\nFor a [wedding ceremony](https://www.weddingbazaar.com/wedding-assist), there are more than 5 to 6 outfits that the couple needs to purchase. Needless to say that, all of them are supposed to be significantly grand. This means that the outfits would be expensive. Therefore, care should be taken that the quality of the outfit is worth every single penny.\n\nHow to know the best place to buy your wedding outfits? [WeddingBazaar](https://www.weddingbazaar.com/)!\n\nOur wedding planning experts know the right place for your wedding outfits based on your specification. Go through our apparel section for more"
    },
    {
      section: "Price",
      question: "The price range of wedding outfits in <city>*",
      answer:
        "|Category  |Cost  |\n|--|--|\n|Lehenga  |Rs.20,000 to Rs.2,50,000  |\n|Sherwani  | Rs. 10,000 to Rs.50,000|\n|Suit| Rs.10,000 to Rs. 1,00,000|\n|Silk sarees  |Rs. 10,000 to Rs. 20,00,000 |\n|Veshti  |Rs. 500 to Rs. 2,000           |\n|Non-silk sarees|Rs. 1,000 to Rs. 1,50,000|\n|Gowns  |Rs. 10,000 to Rs. 30,000 |\n|Formal pants and shirt sets  |Rs. 5,000 to Rs. 40,000|\n|Kurtas or kurtis|Rs.1,500 to Rs. 10,000|\n\n**Prices may vary according to individual preferences.*"
    },
    {
      section: "Main",
      question: "Tips to find the best wedding outfit in <city>",
      answer:
        "These are the tips to find the best wedding outfits:\n\n**Time to purchase**\n\nGive enough time for purchasing and be very patient while having all the trials. Purchase the clothes well in advance so that you can have time for trial and error. \n\n**Purchasing partners**\n\nWhile purchasing the wedding outfit, take people who are patient and can help you with the selection. Make sure you take a maximum of 4 people with you. \n\n**Galli main khazana**\n\nThe best [wedding lehengas and sarees](https://www.weddingbazaar.com/ideas/bridal-sarees-v-s-bridal-lehengas-which-one-is-perfect-for-you-135) are available in places like Delhi's chandni chowk or [WeddingBazaar](https://www.weddingbazaar.com/)'s wedding outfits section. Try these places to get a steal deal for all your wedding outfits.\n\n**Stitched vs readymade**\n\nFor some people ready-made clothes look beautiful while for some, a stitched garment gives a better fit. Decide on your preference and then go for shopping.\n\n**Select the wedding outfits from WeddingBazaar** \n\nAs mentioned above, the wedding outfits from our partners are a steal deal. Our wedding planning experts from [WeddingAssist](https://www.weddingbazaar.com/wedding-assist) platform do all the required research for wedding outfits and will filter out the best options based on your needs."
    },
    {
      section: "Main",
      question:
        "What makes clothing stores and boutiques in WeddingBazaar different from others",
      answer:
        "Our service providers for wedding outfits consider outfit designing as an art and they have magic in their hands!\nWe can assure you that once you visit our service providers, you will not go empty-handed."
    },
    {
      section: "Main",
      question: "Popular apparel styles in <city>",
      answer:
        "Popular wedding outfits are silk sarees, bridal lehengas, palazzos, suits, veshtis, sherwanis, kanjeevaram sarees, etc.. "
    },
    {
      section: "Main",
      question: "How to request a quote for apparel from WeddingBazaar",
      answer:
        "After you select the wedding apparel service provider, mention your name, email ID, phone number, and the best time to reach you. One of our wedding planning experts will then contact you for further process. "
    },
    {
      section: "Main",
      question: "Steps involved in getting apparel in <city>",
      answer:
        "These are the steps involved in getting your wedding apparel:\n\n1. Plan your budget\n2. Decide your choice of clothing\n3. Decide on the time of purchase\n4. Accompany less people with you for purchasing \n5. Have enough time for trial and error\n6. Enquire about payment modes and purchase your wedding outfits"
    },
    {
      section: "FAQ",
      question:
        "What kind of services can I expect from professional Apparel service providers?",
      answer:
        "You can expect professional stitching and quality apparel from the service providers of [WeddingBazaar](https://www.weddingbazaar.com/). Our apparel partners have exclusive wedding collections which is sure to make you look dazzling."
    },
    {
      section: "FAQ",
      question: "How much is the advance payment for apparel?",
      answer:
        "Apparel service providers mostly ask for one time payment after the purchase of the wedding outfits. Only if the apparel is custom-made, they ask for advance payment."
    },
    {
      section: "FAQ",
      question: "Any discounts or offers available for apparel?",
      answer:
        "Watch out for the 'Offers' section in our website to find out about great deals and discounts on wedding apparels. To get notified about latest offers sign up [here](https://www.weddingbazaar.com/get-quote?city=<citySlug>&category=<categorySlug>&ref=listing)."
    },
    {
      section: "FAQ",
      question: "What wedding outfits are available for women?",
      answer:
        "Sarees, lehengas, gowns, salwar kameez, anarkalis, chudidars, etc.. are some of the wedding outfits available of the women. "
    },
    {
      section: "FAQ",
      question: "What wedding outfits are available for men?",
      answer:
        "Sherwanis, dhotis, shirts, suits, blazers, etc.. are some of the wedding outfits available for men."
    },
    {
      section: "FAQ",
      question:
        "Are the wedding outfits readymade or can we get the material and get it stitched?",
      answer:
        "Both the options of stitching, and buying readymade apparel are available from the service providers of [WeddingBazaar](https://www.weddingbazaar.com/)."
    },
    {
      section: "FAQ",
      question: "What are the different sarees that you have?",
      answer:
        "[Kancheepuram silk sarees](https://www.weddingbazaar.com/ideas/the-most-beautiful-and-elegant-kanjivaram-wedding-sarees-69), designer sarees, Mysore silks sarees, Banarasi silk sarees, etc., are some of the sarees available with the service providers of [WeddingBazaar](https://www.weddingbazaar.com/)."
    },
    {
      section: "FAQ",
      question: "What is the starting price of sarees and suits?",
      answer:
        "The price of Sarees for weddings starts from around Rs. 5,000 and goes upto Rs. 4,00,000. Suits can start from Rs. 10,000 and go upto Rs. 50,000. "
    },
    {
      section: "FAQ",
      question: "Where can I do the trial of the dress before purchasing?",
      answer:
        "The outfit trials can be done at the shop where your are purchasing the outfits. "
    },
    {
      section: "FAQ",
      question: "Can I order the wedding outfits online?",
      answer:
        "Yes, if the service providers support online orders, you can order your wedding outfits online. "
    },
    {
      section: "FAQ",
      question: "Do you have only traditional outfits?",
      answer:
        "Along with traditional outfits, we have trendy and modern outfits as well."
    },
    {
      section: "FAQ",
      question: "Do you have designer wedding wear?",
      answer: "Yes, our service providers also provide designer wedding wear. "
    },
    {
      section: "FAQ",
      question: "Do you provide accessories like footwear along with apparels?",
      answer:
        "Yes, accessories like footwear, imitation jewellery, are also available along with apparel. "
    },
    {
      section: "FAQ",
      question: "Are designer lehengas available?",
      answer: "Yes, designer lehengas are also available. "
    },
    {
      section: "FAQ",
      question: "Are sherwanis available?",
      answer: "Yes, sherwanis are available. "
    },
    {
      section: "FAQ",
      question: "Are haldi outfits available?",
      answer:
        "Yes, outfits for [haldi ceremony](https://www.weddingbazaar.com/ideas/how-to-plan-and-celebrate-haldi-ceremony-5) are available."
    }
  ]
};
