import Axios, { AxiosInstance } from "axios";
import Knex from "knex";
import * as vendorEnum from "./config/config.enum";
import * as portalEnum from "./config/config.portal.enum";
import { CategoryApi, CityApi, ProfileApi } from "./dataSource/portalApis";
import { hashIds } from "./services/hashIds.utils";
import { objectDeepMap } from "./services/utils";
import { templateToMessage } from "./services/utils";

export interface ReferenceTable {
  table: string;
  fields: {
    [key: string]: string;
  };
  prospect?: {
    [key: string]: string;
  };
  actual?: {
    [key: string]: string;
  };
}

export interface ReferenceDatabase {
  [keys: string]: ReferenceTable;
}
export interface VendorProfiles {
  categoryId: number;
  cityId: number;
  stateId: number;
  designation: vendorEnum.vendorRole;
}
export interface UserContext {
  id: any;
  vendorId: number;
  prospectId: number;
  businessName: string;
  role: vendorEnum.userRole;
  profiles: VendorProfiles[];
}
export interface PortalUserContext {
  id: any;
  role: portalEnum.userRole;
  mailId: string;
}
export interface PortalUserAgent {
  isBot: boolean;
  os: string;
  platform: string;
  isDesktop: boolean;
  isSmartTV: boolean;
  isTablet: boolean;
  isMobile: boolean;
  isAndroid: boolean;
  isMac: boolean;
  isBlackberry: boolean;
  isKindleFire: boolean;
  browser: boolean;
  browserVersion: string;
  ips: string[];
  ipAddress: string;
  originalUrl: string;
  origin: string;
  referer: string;
  cookie: any;
}
export interface PortalContext {
  mBazaar: Knex;
  axios: AxiosInstance;
  mBazaarServices: Knex;
  user: PortalUserContext;
  userAgent: PortalUserAgent;
  dataSources: {
    CategoryApi: typeof CategoryApi;
    CityApi: typeof CityApi;
    ProfileApi: typeof ProfileApi;
  };
}

export interface VendorContext {
  mBazaar: Knex;
  mBazaarServices: Knex;
  mBazaarProspect: Knex;
  user: UserContext;
  deviceToken: string;
  accessToken: string;
  dataSources: {
    vendorEnum: typeof vendorEnum;
    hashIds: typeof hashIds;
    objectDeepMap: typeof objectDeepMap;
    templateToMessage: typeof templateToMessage;
  };
}
