// in cookiecutter.config.js
module.exports = [
  {
    name: "Add Portal Domain",
    templatePath: "templates/PORTAL_",
    outputPath: "src/servers/portal/",
    fields: [
      {
        templateVariable: "PORTAL_",
        question: "What is the domain's name?",
        errorMessage:
          "A domain must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
  {
    name: "Add RMTool Domain",
    templatePath: "templates/RMTOOL_",
    outputPath: "src/servers/rmTool/",
    fields: [
      {
        templateVariable: "RMTOOL_",
        question: "What is the domain's name?",
        errorMessage:
          "A domain must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
  {
    name: "Add VendorApp Domain",
    templatePath: "templates/VENDOR_",
    outputPath: "src/servers/vendor/",
    fields: [
      {
        templateVariable: "VENDOR_",
        question: "What is the domain's name?",
        errorMessage:
          "A domain must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
  {
    name: "Add VendorApp Domain/noSql",
    templatePath: "templates/RMTOOL_",
    outputPath: "src/vendor/",
    fields: [
      {
        templateVariable: "RMTOOL_",
        question: "What is the domain's name?",
        errorMessage:
          "A domain must be in PascalCase and can only include letters.",
        isValid(value) {
          return !!value.match(/^[A-Z][a-z]+(?:[A-Z][a-z]+)*$/g);
        }
      }
    ]
  },
];
