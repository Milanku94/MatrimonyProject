import { provider as VENDOR_Provider } from ".";
import { VendorContext } from "../../types";

export default {
  Query: {
    VENDOR_: async (_: any, args: any, context: VendorContext) =>
      await new VENDOR_Provider(context).getAll()
  }
};
