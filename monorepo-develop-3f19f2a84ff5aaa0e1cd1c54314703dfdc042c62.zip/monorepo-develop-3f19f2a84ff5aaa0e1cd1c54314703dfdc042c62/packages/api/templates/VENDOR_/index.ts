import provider from "./VENDOR_.provider";
import VENDOR_Model from "./VENDOR_.model";
import resolver from "./VENDOR_.resolver";

export { VENDOR_Model, provider, resolver };
