export default class RMTOOL_Provider {
  public all() {
    return testData;
  }
}
const testData = [
  {
    name: "test data"
  }
];
