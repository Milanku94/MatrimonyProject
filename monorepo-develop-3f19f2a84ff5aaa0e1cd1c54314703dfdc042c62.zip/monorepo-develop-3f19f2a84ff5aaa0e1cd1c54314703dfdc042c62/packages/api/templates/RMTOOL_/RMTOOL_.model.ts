import { prop, Typegoose, ModelType, InstanceType } from "typegoose";

export class RMTOOL_ extends Typegoose {
  @prop()
  public name?: string;
}

export default new RMTOOL_().getModelForClass(RMTOOL_, {
  schemaOptions: { collection: "RMTOOL_" }
});
