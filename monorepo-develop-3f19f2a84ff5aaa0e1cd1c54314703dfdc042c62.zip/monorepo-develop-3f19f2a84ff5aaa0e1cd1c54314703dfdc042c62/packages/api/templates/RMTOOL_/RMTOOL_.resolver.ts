import { model as RMTOOL_Model } from ".";
import { provider as RMTOOL_Provider } from ".";

export default {
  Query: {
    RMTOOL_dev: (_: any, args: any, context: any) => {
      const getRMTOOL_ = new RMTOOL_Provider();
      return getRMTOOL_.all();
    },
    RMTOOL_s: (_: any, args: any, context: any) => RMTOOL_Model.find()
  },
  Mutation: {
    createRMTOOL_: async (_: any, { name }: any) => {
      const newRMTOOL_ = new RMTOOL_Model({ name });
      await newRMTOOL_.save();
      return newRMTOOL_;
    }
  }
};
