import provider from "./PORTAL_.provider";
import PORTAL_Model from "./PORTAL_.model";
import resolver from "./PORTAL_.resolver";

export { PORTAL_Model, provider, resolver };
