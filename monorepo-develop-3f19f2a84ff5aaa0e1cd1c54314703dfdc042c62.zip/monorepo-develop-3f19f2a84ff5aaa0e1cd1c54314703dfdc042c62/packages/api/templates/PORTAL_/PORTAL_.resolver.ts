import { provider as PORTAL_Provider } from ".";
import { PortalContext } from "../../../types";

export default {
  Query: {
    PORTAL_: async (_: any, args: any, context: PortalContext) =>
      await new PORTAL_Provider(context).getAll()
  }
};
