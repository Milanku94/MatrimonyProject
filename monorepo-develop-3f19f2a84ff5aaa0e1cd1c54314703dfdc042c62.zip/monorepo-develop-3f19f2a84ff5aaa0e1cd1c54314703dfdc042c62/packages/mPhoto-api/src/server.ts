import bodyParser from "body-parser";
import { exec } from "child_process";
import express, { Express } from "express";
import mongoose from "mongoose";
import config from "./config/config.env";
import { mBazaar, mBazaarProspect, mBazaarServices } from "./knex";
import { logMetrics } from "./middlewares/logMetrics";
import { portalServer } from "./servers";

const app: Express = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

mongoose
  .connect(config.MONGO_URI, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false
  })
  .then(
    (success: any) => console.log("Successfully Connected with MongoDB"),
    (error: any) => console.log("Connection failed MongoDB..!!!!!!")
  );

app.use("/portal", logMetrics);
portalServer({ mBazaar, mBazaarServices }).applyMiddleware({
  app,
  path: "/portal"
});

app.listen({ port: config.PORT }, () => {
  console.log(`🚀  Server ready at ${config.PORT}`);
  exec("yarn generate:all", (err, stdout, stderr) => {
    if (err) {
      console.warn("types generating error:", err);
    }
    console.info("types generated \n", stdout);
  });
});
