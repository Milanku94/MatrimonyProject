import {
  GraphQLResolveInfo,
  GraphQLScalarType,
  GraphQLScalarTypeConfig
} from "graphql";
export type Maybe<T> = T | null;
export type RequireFields<T, K extends keyof T> = {
  [X in Exclude<keyof T, K>]?: T[X];
} &
  { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export interface Scalars {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  /** Boolean or enum(radio|checkbox|textbox) */
  DisplayOptionType: any;
  /** The `JSON` scalar type represents JSON values as specified by [ECMA-404](http://www.ecma-international.org/publications/files/ECMA-ST/ECMA-404.pdf). */
  JSON: any;
}

export interface AttributesInput {
  attributeId?: Maybe<Scalars["String"]>;
  optionIds?: Maybe<Array<Maybe<Scalars["String"]>>>;
  value?: Maybe<Scalars["String"]>;
}

export interface Badges {
  id?: Maybe<Scalars["ID"]>;
  name?: Maybe<Scalars["String"]>;
}

export interface BannerImg {
  mobile?: Maybe<Scalars["String"]>;
  desktop?: Maybe<Scalars["String"]>;
}

export interface Blogs {
  content?: Maybe<Scalars["String"]>;
  similar?: Maybe<Array<Maybe<Blogs>>>;
  meta?: Maybe<MetaDetails>;
  excerpt?: Maybe<Scalars["String"]>;
  heroPhoto?: Maybe<Media>;
  id: Scalars["ID"];
  name: Scalars["String"];
  publishedOn?: Maybe<Scalars["String"]>;
  slug?: Maybe<Scalars["String"]>;
  tags?: Maybe<Array<Maybe<BlogTag>>>;
}

export interface BlogTag {
  id: Scalars["ID"];
  name: Scalars["String"];
  slug?: Maybe<Scalars["String"]>;
  heroPhoto: Media;
  posts?: Maybe<Array<Maybe<Blogs>>>;
  excerpt: Scalars["String"];
  meta?: Maybe<MetaDetails>;
}

export interface Category {
  id: Scalars["ID"];
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  name?: Maybe<Scalars["String"]>;
  needName?: Maybe<Scalars["String"]>;
  attributes?: Maybe<Array<Maybe<FilterAttribute>>>;
  /** ratings: [Ratings] */
  meta: MetaDetails;
}

export interface City {
  id: Scalars["ID"];
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  name?: Maybe<Scalars["String"]>;
  categories?: Maybe<Array<Maybe<Category>>>;
}

export interface CustomerFields {
  categoryId: Scalars["ID"];
  cityId: Scalars["ID"];
  email: Scalars["String"];
  enquirySource: Scalars["Int"];
  name: Scalars["String"];
  phone: Scalars["String"];
  sourceUrl: Scalars["String"];
  userUniqueId: Scalars["ID"];
}

export interface CustomerId {
  customerId: Scalars["ID"];
}

export interface DisplayAttribute {
  id: Scalars["ID"];
  name: Scalars["String"];
  values?: Maybe<Array<Maybe<Scalars["String"]>>>;
  slug: Scalars["String"];
  forDistribution?: Maybe<Scalars["Boolean"]>;
  forInformation?: Maybe<Scalars["Boolean"]>;
  subtext?: Maybe<Scalars["String"]>;
  header: Scalars["String"];
}

export interface DisplayOptions {
  question?: Maybe<Scalars["String"]>;
  search?: Maybe<Scalars["DisplayOptionType"]>;
  filter?: Maybe<Scalars["DisplayOptionType"]>;
  form?: Maybe<Scalars["DisplayOptionType"]>;
}

export interface FilterAttribute {
  id: Scalars["ID"];
  name: Scalars["String"];
  display?: Maybe<DisplayOptions>;
  options?: Maybe<Array<Maybe<FilterAttributeOptions>>>;
}

export interface FilterAttributeOptions {
  id?: Maybe<Scalars["ID"]>;
  name?: Maybe<Scalars["String"]>;
  isDefault?: Maybe<Scalars["Boolean"]>;
}

export interface Media {
  altText?: Maybe<Scalars["String"]>;
  caption?: Maybe<Scalars["String"]>;
  isHero?: Maybe<Scalars["Boolean"]>;
  slug: Scalars["String"];
  url: Scalars["String"];
  tags?: Maybe<Array<Maybe<MediaTag>>>;
  thumbnail?: Maybe<Scalars["String"]>;
  meta?: Maybe<MetaDetails>;
}

export interface MediaTag {
  id: Scalars["ID"];
  name: Scalars["String"];
}

export interface MetaDetails {
  title: Scalars["String"];
  description: Scalars["String"];
  keywords?: Maybe<Scalars["String"]>;
  image?: Maybe<Scalars["String"]>;
}

export interface Mutation {
  otpVerify?: Maybe<CustomerId>;
  otpRegen?: Maybe<CustomerId>;
  postContact: CustomerId;
  postNeed: CustomerId;
}

export interface MutationOtpVerifyArgs {
  customerId: Scalars["String"];
  otp: Scalars["String"];
}

export interface MutationOtpRegenArgs {
  customerId: Scalars["String"];
}

export interface MutationPostContactArgs {
  postData: CustomerFields;
}

export interface MutationPostNeedArgs {
  postData: Needs;
}

export interface Needs {
  categoryId: Scalars["ID"];
  attributes?: Maybe<Array<Maybe<PostAttribute>>>;
  isDate: Scalars["String"];
  notes: Scalars["String"];
  posted?: Maybe<Scalars["Boolean"]>;
  sourceUrl: Scalars["String"];
  cityId: Scalars["ID"];
  customerId: Scalars["String"];
  timeslot: Scalars["String"];
}

export interface PostAttribute {
  attributeId: Scalars["ID"];
  optionId: Array<Scalars["ID"]>;
}

export interface Profile {
  attributes?: Maybe<Array<Maybe<DisplayAttribute>>>;
  badges?: Maybe<Array<Maybe<Badges>>>;
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Category>;
  heroPhoto?: Maybe<Media>;
  id: Scalars["ID"];
  name: Scalars["String"];
  rating?: Maybe<Scalars["String"]>;
  ratingCount?: Maybe<Scalars["String"]>;
  reviewCount?: Maybe<Scalars["String"]>;
  slug?: Maybe<Scalars["String"]>;
  slugId?: Maybe<Scalars["String"]>;
  type?: Maybe<Scalars["String"]>;
  gallery?: Maybe<Array<Maybe<Media>>>;
  averageRating?: Maybe<Array<Maybe<ProfileRating>>>;
  specialities?: Maybe<Array<Maybe<Scalars["String"]>>>;
  localities?: Maybe<Array<Maybe<Scalars["String"]>>>;
  aboutUs?: Maybe<Scalars["String"]>;
  virtualNumber?: Maybe<Scalars["String"]>;
}

export interface ProfileInput {
  attributes: Array<Maybe<AttributesInput>>;
  categoryId: Scalars["ID"];
  cityId: Scalars["ID"];
}

export interface ProfileRating {
  id: Scalars["ID"];
  name: Scalars["String"];
  rating?: Maybe<Scalars["String"]>;
  description?: Maybe<Scalars["String"]>;
}

export interface ProfileReview {
  id: Scalars["ID"];
  name: Scalars["String"];
  reviewer?: Maybe<ProfileReviewer>;
  rating?: Maybe<Array<Maybe<ProfileRating>>>;
  review?: Maybe<Scalars["String"]>;
  event?: Maybe<Scalars["String"]>;
  date?: Maybe<Scalars["String"]>;
  createdOn?: Maybe<Scalars["String"]>;
  publishedOn?: Maybe<Scalars["String"]>;
}

export interface ProfileReviewer {
  id: Scalars["ID"];
  name?: Maybe<Scalars["String"]>;
  profilePhoto?: Maybe<Media>;
}

export interface Query {
  getBlogs?: Maybe<Blogs[]>;
  getBlogsByID: Blogs;
  getCategories?: Maybe<Array<Maybe<Category>>>;
  getCategoriesByID?: Maybe<Category>;
  getCategoriesBySlug?: Maybe<Category>;
  getCities?: Maybe<City[]>;
  getCitiesByID?: Maybe<City>;
  getCitiesBySlug?: Maybe<City>;
  Media?: Maybe<Array<Maybe<Media>>>;
  MetaDetails?: Maybe<Array<Maybe<MetaDetails>>>;
  getProfiles?: Maybe<Profile[]>;
  getTotalProfilesCount?: Maybe<Scalars["Int"]>;
  getProfilesByID?: Maybe<Profile>;
  ProfileRating?: Maybe<Array<Maybe<ProfileRating>>>;
  search?: Maybe<Search>;
  getSEM?: Maybe<Sem[]>;
  getSEMByCityCategory?: Maybe<Sem>;
}

export interface QueryGetBlogsArgs {
  page?: Maybe<Scalars["Int"]>;
}

export interface QueryGetBlogsByIdArgs {
  blogID?: Maybe<Scalars["Int"]>;
}

export interface QueryGetCategoriesByIdArgs {
  categoryID: Scalars["ID"];
}

export interface QueryGetCategoriesBySlugArgs {
  slug: Scalars["String"];
}

export interface QueryGetCitiesByIdArgs {
  cityId: Scalars["ID"];
}

export interface QueryGetCitiesBySlugArgs {
  slug: Scalars["String"];
}

export interface QueryGetProfilesArgs {
  postData: ProfileInput;
  page?: Maybe<Scalars["Int"]>;
  limit?: Maybe<Scalars["Int"]>;
}

export interface QueryGetTotalProfilesCountArgs {
  postData: ProfileInput;
}

export interface QueryGetProfilesByIdArgs {
  profileID?: Maybe<Scalars["String"]>;
}

export interface QuerySearchArgs {
  postData: SearchInput;
}

export interface QueryGetSemByCityCategoryArgs {
  city?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
}

export enum Role {
  Vendor = "VENDOR",
  Admin = "ADMIN"
}

export interface Search {
  /** categories: [Category] */
  profiles?: Maybe<Array<Maybe<Profile>>>;
}

export interface SearchInput {
  freeText: Scalars["String"];
  cityId: Scalars["ID"];
}

export interface Sem {
  bannerImage?: Maybe<BannerImg>;
  bannerQuestion?: Maybe<Scalars["String"]>;
  category?: Maybe<Scalars["String"]>;
  city?: Maybe<Scalars["String"]>;
  footerQuestion?: Maybe<Scalars["String"]>;
}

export type ResolverTypeWrapper<T> = Promise<T> | T;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export interface StitchingResolver<TResult, TParent, TContext, TArgs> {
  fragment: string;
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
}

export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> =
  | ResolverFn<TResult, TParent, TContext, TArgs>
  | StitchingResolver<TResult, TParent, TContext, TArgs>;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterator<TResult> | Promise<AsyncIterator<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> {
  subscribe: SubscriptionSubscribeFn<
    { [key in TKey]: TResult },
    TParent,
    TContext,
    TArgs
  >;
  resolve?: SubscriptionResolveFn<
    TResult,
    { [key in TKey]: TResult },
    TContext,
    TArgs
  >;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<
  TResult,
  TKey extends string,
  TParent,
  TContext,
  TArgs
> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<
  TResult,
  TKey extends string,
  TParent = {},
  TContext = {},
  TArgs = {}
> =
  | ((
      ...args: any[]
    ) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<
  TResult = {},
  TParent = {},
  TContext = {},
  TArgs = {}
> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping between all available schema types and the resolvers types */
export interface ResolversTypes {
  Query: ResolverTypeWrapper<{}>;
  Int: ResolverTypeWrapper<Scalars["Int"]>;
  Blogs: ResolverTypeWrapper<Blogs>;
  String: ResolverTypeWrapper<Scalars["String"]>;
  MetaDetails: ResolverTypeWrapper<MetaDetails>;
  Media: ResolverTypeWrapper<Media>;
  Boolean: ResolverTypeWrapper<Scalars["Boolean"]>;
  MediaTag: ResolverTypeWrapper<MediaTag>;
  ID: ResolverTypeWrapper<Scalars["ID"]>;
  BlogTag: ResolverTypeWrapper<BlogTag>;
  Category: ResolverTypeWrapper<Category>;
  FilterAttribute: ResolverTypeWrapper<FilterAttribute>;
  DisplayOptions: ResolverTypeWrapper<DisplayOptions>;
  DisplayOptionType: ResolverTypeWrapper<Scalars["DisplayOptionType"]>;
  FilterAttributeOptions: ResolverTypeWrapper<FilterAttributeOptions>;
  City: ResolverTypeWrapper<City>;
  ProfileInput: ProfileInput;
  AttributesInput: AttributesInput;
  Profile: ResolverTypeWrapper<Profile>;
  DisplayAttribute: ResolverTypeWrapper<DisplayAttribute>;
  Badges: ResolverTypeWrapper<Badges>;
  ProfileRating: ResolverTypeWrapper<ProfileRating>;
  SearchInput: SearchInput;
  Search: ResolverTypeWrapper<Search>;
  Sem: ResolverTypeWrapper<Sem>;
  BannerImg: ResolverTypeWrapper<BannerImg>;
  Mutation: ResolverTypeWrapper<{}>;
  CustomerID: ResolverTypeWrapper<CustomerId>;
  CustomerFields: CustomerFields;
  Needs: Needs;
  PostAttribute: PostAttribute;
  JSON: ResolverTypeWrapper<Scalars["JSON"]>;
  ProfileReview: ResolverTypeWrapper<ProfileReview>;
  ProfileReviewer: ResolverTypeWrapper<ProfileReviewer>;
  Role: Role;
}

/** Mapping between all available schema types and the resolvers parents */
export interface ResolversParentTypes {
  Query: {};
  Int: Scalars["Int"];
  Blogs: Blogs;
  String: Scalars["String"];
  MetaDetails: MetaDetails;
  Media: Media;
  Boolean: Scalars["Boolean"];
  MediaTag: MediaTag;
  ID: Scalars["ID"];
  BlogTag: BlogTag;
  Category: Category;
  FilterAttribute: FilterAttribute;
  DisplayOptions: DisplayOptions;
  DisplayOptionType: Scalars["DisplayOptionType"];
  FilterAttributeOptions: FilterAttributeOptions;
  City: City;
  ProfileInput: ProfileInput;
  AttributesInput: AttributesInput;
  Profile: Profile;
  DisplayAttribute: DisplayAttribute;
  Badges: Badges;
  ProfileRating: ProfileRating;
  SearchInput: SearchInput;
  Search: Search;
  Sem: Sem;
  BannerImg: BannerImg;
  Mutation: {};
  CustomerID: CustomerId;
  CustomerFields: CustomerFields;
  Needs: Needs;
  PostAttribute: PostAttribute;
  JSON: Scalars["JSON"];
  ProfileReview: ProfileReview;
  ProfileReviewer: ProfileReviewer;
  Role: Role;
}

export interface BadgesResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Badges"] = ResolversParentTypes["Badges"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
}

export interface BannerImgResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BannerImg"] = ResolversParentTypes["BannerImg"]
> {
  mobile?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  desktop?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
}

export interface BlogsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Blogs"] = ResolversParentTypes["Blogs"]
> {
  content?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  similar?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Blogs"]>>>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
  excerpt?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  heroPhoto?: Resolver<Maybe<ResolversTypes["Media"]>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["BlogTag"]>>>,
    ParentType,
    ContextType
  >;
}

export interface BlogTagResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["BlogTag"] = ResolversParentTypes["BlogTag"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  heroPhoto?: Resolver<ResolversTypes["Media"], ParentType, ContextType>;
  posts?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Blogs"]>>>,
    ParentType,
    ContextType
  >;
  excerpt?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
}

export interface CategoryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Category"] = ResolversParentTypes["Category"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  needName?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["FilterAttribute"]>>>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<ResolversTypes["MetaDetails"], ParentType, ContextType>;
}

export interface CityResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["City"] = ResolversParentTypes["City"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  categories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
}

export interface CustomerIdResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["CustomerID"] = ResolversParentTypes["CustomerID"]
> {
  customerId?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
}

export interface DisplayAttributeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["DisplayAttribute"] = ResolversParentTypes["DisplayAttribute"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  values?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  forDistribution?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  forInformation?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
  subtext?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  header?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
}

export interface DisplayOptionsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["DisplayOptions"] = ResolversParentTypes["DisplayOptions"]
> {
  question?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  search?: Resolver<
    Maybe<ResolversTypes["DisplayOptionType"]>,
    ParentType,
    ContextType
  >;
  filter?: Resolver<
    Maybe<ResolversTypes["DisplayOptionType"]>,
    ParentType,
    ContextType
  >;
  form?: Resolver<
    Maybe<ResolversTypes["DisplayOptionType"]>,
    ParentType,
    ContextType
  >;
}

export interface DisplayOptionTypeScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["DisplayOptionType"], any> {
  name: "DisplayOptionType";
}

export interface FilterAttributeResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["FilterAttribute"] = ResolversParentTypes["FilterAttribute"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  display?: Resolver<
    Maybe<ResolversTypes["DisplayOptions"]>,
    ParentType,
    ContextType
  >;
  options?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["FilterAttributeOptions"]>>>,
    ParentType,
    ContextType
  >;
}

export interface FilterAttributeOptionsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["FilterAttributeOptions"] = ResolversParentTypes["FilterAttributeOptions"]
> {
  id?: Resolver<Maybe<ResolversTypes["ID"]>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isDefault?: Resolver<
    Maybe<ResolversTypes["Boolean"]>,
    ParentType,
    ContextType
  >;
}

export interface JsonScalarConfig
  extends GraphQLScalarTypeConfig<ResolversTypes["JSON"], any> {
  name: "JSON";
}

export interface MediaResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Media"] = ResolversParentTypes["Media"]
> {
  altText?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  caption?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  isHero?: Resolver<Maybe<ResolversTypes["Boolean"]>, ParentType, ContextType>;
  slug?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  url?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  tags?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["MediaTag"]>>>,
    ParentType,
    ContextType
  >;
  thumbnail?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  meta?: Resolver<
    Maybe<ResolversTypes["MetaDetails"]>,
    ParentType,
    ContextType
  >;
}

export interface MediaTagResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["MediaTag"] = ResolversParentTypes["MediaTag"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
}

export interface MetaDetailsResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["MetaDetails"] = ResolversParentTypes["MetaDetails"]
> {
  title?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  description?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  keywords?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  image?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
}

export interface MutationResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Mutation"] = ResolversParentTypes["Mutation"]
> {
  otpVerify?: Resolver<
    Maybe<ResolversTypes["CustomerID"]>,
    ParentType,
    ContextType,
    RequireFields<MutationOtpVerifyArgs, "customerId" | "otp">
  >;
  otpRegen?: Resolver<
    Maybe<ResolversTypes["CustomerID"]>,
    ParentType,
    ContextType,
    RequireFields<MutationOtpRegenArgs, "customerId">
  >;
  postContact?: Resolver<
    ResolversTypes["CustomerID"],
    ParentType,
    ContextType,
    RequireFields<MutationPostContactArgs, "postData">
  >;
  postNeed?: Resolver<
    ResolversTypes["CustomerID"],
    ParentType,
    ContextType,
    RequireFields<MutationPostNeedArgs, "postData">
  >;
}

export interface ProfileResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Profile"] = ResolversParentTypes["Profile"]
> {
  attributes?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["DisplayAttribute"]>>>,
    ParentType,
    ContextType
  >;
  badges?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Badges"]>>>,
    ParentType,
    ContextType
  >;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  category?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType
  >;
  heroPhoto?: Resolver<Maybe<ResolversTypes["Media"]>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  rating?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  ratingCount?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  reviewCount?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  slug?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  slugId?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  type?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  gallery?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Media"]>>>,
    ParentType,
    ContextType
  >;
  averageRating?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileRating"]>>>,
    ParentType,
    ContextType
  >;
  specialities?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  localities?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["String"]>>>,
    ParentType,
    ContextType
  >;
  aboutUs?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  virtualNumber?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
}

export interface ProfileRatingResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileRating"] = ResolversParentTypes["ProfileRating"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  rating?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  description?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
}

export interface ProfileReviewResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileReview"] = ResolversParentTypes["ProfileReview"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<ResolversTypes["String"], ParentType, ContextType>;
  reviewer?: Resolver<
    Maybe<ResolversTypes["ProfileReviewer"]>,
    ParentType,
    ContextType
  >;
  rating?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileRating"]>>>,
    ParentType,
    ContextType
  >;
  review?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  event?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  date?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  createdOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  publishedOn?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
}

export interface ProfileReviewerResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["ProfileReviewer"] = ResolversParentTypes["ProfileReviewer"]
> {
  id?: Resolver<ResolversTypes["ID"], ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  profilePhoto?: Resolver<
    Maybe<ResolversTypes["Media"]>,
    ParentType,
    ContextType
  >;
}

export interface QueryResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Query"] = ResolversParentTypes["Query"]
> {
  getBlogs?: Resolver<
    Maybe<Array<ResolversTypes["Blogs"]>>,
    ParentType,
    ContextType,
    QueryGetBlogsArgs
  >;
  getBlogsByID?: Resolver<
    ResolversTypes["Blogs"],
    ParentType,
    ContextType,
    QueryGetBlogsByIdArgs
  >;
  getCategories?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Category"]>>>,
    ParentType,
    ContextType
  >;
  getCategoriesByID?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCategoriesByIdArgs, "categoryID">
  >;
  getCategoriesBySlug?: Resolver<
    Maybe<ResolversTypes["Category"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCategoriesBySlugArgs, "slug">
  >;
  getCities?: Resolver<
    Maybe<Array<ResolversTypes["City"]>>,
    ParentType,
    ContextType
  >;
  getCitiesByID?: Resolver<
    Maybe<ResolversTypes["City"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCitiesByIdArgs, "cityId">
  >;
  getCitiesBySlug?: Resolver<
    Maybe<ResolversTypes["City"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetCitiesBySlugArgs, "slug">
  >;
  Media?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Media"]>>>,
    ParentType,
    ContextType
  >;
  MetaDetails?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["MetaDetails"]>>>,
    ParentType,
    ContextType
  >;
  getProfiles?: Resolver<
    Maybe<Array<ResolversTypes["Profile"]>>,
    ParentType,
    ContextType,
    RequireFields<QueryGetProfilesArgs, "postData">
  >;
  getTotalProfilesCount?: Resolver<
    Maybe<ResolversTypes["Int"]>,
    ParentType,
    ContextType,
    RequireFields<QueryGetTotalProfilesCountArgs, "postData">
  >;
  getProfilesByID?: Resolver<
    Maybe<ResolversTypes["Profile"]>,
    ParentType,
    ContextType,
    QueryGetProfilesByIdArgs
  >;
  ProfileRating?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["ProfileRating"]>>>,
    ParentType,
    ContextType
  >;
  search?: Resolver<
    Maybe<ResolversTypes["Search"]>,
    ParentType,
    ContextType,
    RequireFields<QuerySearchArgs, "postData">
  >;
  getSEM?: Resolver<
    Maybe<Array<ResolversTypes["Sem"]>>,
    ParentType,
    ContextType
  >;
  getSEMByCityCategory?: Resolver<
    Maybe<ResolversTypes["Sem"]>,
    ParentType,
    ContextType,
    QueryGetSemByCityCategoryArgs
  >;
}

export interface SearchResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Search"] = ResolversParentTypes["Search"]
> {
  profiles?: Resolver<
    Maybe<Array<Maybe<ResolversTypes["Profile"]>>>,
    ParentType,
    ContextType
  >;
}

export interface SemResolvers<
  ContextType = any,
  ParentType extends ResolversParentTypes["Sem"] = ResolversParentTypes["Sem"]
> {
  bannerImage?: Resolver<
    Maybe<ResolversTypes["BannerImg"]>,
    ParentType,
    ContextType
  >;
  bannerQuestion?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
  category?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  city?: Resolver<Maybe<ResolversTypes["String"]>, ParentType, ContextType>;
  footerQuestion?: Resolver<
    Maybe<ResolversTypes["String"]>,
    ParentType,
    ContextType
  >;
}

export interface Resolvers<ContextType = any> {
  Badges?: BadgesResolvers<ContextType>;
  BannerImg?: BannerImgResolvers<ContextType>;
  Blogs?: BlogsResolvers<ContextType>;
  BlogTag?: BlogTagResolvers<ContextType>;
  Category?: CategoryResolvers<ContextType>;
  City?: CityResolvers<ContextType>;
  CustomerID?: CustomerIdResolvers<ContextType>;
  DisplayAttribute?: DisplayAttributeResolvers<ContextType>;
  DisplayOptions?: DisplayOptionsResolvers<ContextType>;
  DisplayOptionType?: GraphQLScalarType;
  FilterAttribute?: FilterAttributeResolvers<ContextType>;
  FilterAttributeOptions?: FilterAttributeOptionsResolvers<ContextType>;
  JSON?: GraphQLScalarType;
  Media?: MediaResolvers<ContextType>;
  MediaTag?: MediaTagResolvers<ContextType>;
  MetaDetails?: MetaDetailsResolvers<ContextType>;
  Mutation?: MutationResolvers<ContextType>;
  Profile?: ProfileResolvers<ContextType>;
  ProfileRating?: ProfileRatingResolvers<ContextType>;
  ProfileReview?: ProfileReviewResolvers<ContextType>;
  ProfileReviewer?: ProfileReviewerResolvers<ContextType>;
  Query?: QueryResolvers<ContextType>;
  Search?: SearchResolvers<ContextType>;
  Sem?: SemResolvers<ContextType>;
}

/**
 * @deprecated
 * Use "Resolvers" root object instead. If you wish to get "IResolvers", add "typesPrefix: I" to your config.
 */
export type IResolvers<ContextType = any> = Resolvers<ContextType>;
