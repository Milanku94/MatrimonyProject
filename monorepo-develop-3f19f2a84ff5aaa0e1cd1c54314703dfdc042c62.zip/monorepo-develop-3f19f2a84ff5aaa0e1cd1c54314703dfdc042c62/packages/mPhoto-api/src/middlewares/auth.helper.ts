import jwt from "jsonwebtoken";
import config from "../config/config.env";

export interface User {
  _id: string;
  username: string;
  role: string;
}

const getUser = async (token: string) => {
  if (token.startsWith("Bearer ")) {
    // Remove Bearer from string
    token = token.slice(7, token.length);
  }
  jwt.verify(token, config.JWT.SECRET, (err: any, decoded: any) => {
    if (decoded) {
      // todo:
      return {
        _id: "1234",
        username: "test",
        role: "MANAGER"
      };
    }
  });
};
const checkToken = (req: any, res: any, next: any) => {
  let token =
    req.headers[config.JWT.AUTH_TOKEN_NAME] || req.headers.authorization;

  if (token) {
    if (token.startsWith("Bearer ")) {
      // Remove Bearer from string
      token = token.slice(7, token.length);
    }
    jwt.verify(token, config.JWT.SECRET, (err: any, decoded: any) => {
      if (err) {
        return res.json({
          success: false,
          message: "Token is not valid"
        });
      } else {
        req.decoded = decoded;
        // console.log("!!!!!", decoded);
        next();
      }
    });
  } else {
    return res.json({
      success: false,
      message: "Auth token is not supplied"
    });
  }
};
export { getUser, checkToken };
