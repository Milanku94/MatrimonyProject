import { GraphQLScalarType, Kind } from "graphql";
import { provider as CategoryProvider } from ".";
import {
  Category,
  QueryGetCategoriesByIdArgs,
  QueryGetCategoriesBySlugArgs
} from "../../../generated/portal.models";
import { getSlug, getSlugId } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";

const DisplayOptionTypeEnum = ["false", "radio", "checkbox", "textbox"];
const CATEGORY_DATA = `/categories/`;
export default {
  DisplayOptionType: new GraphQLScalarType({
    name: "DisplayOptionType",
    description: "Boolean or enum(radio|checkbox|textbox)",
    parseValue(value) {
      return value === "false" ? false : value;
    },
    serialize(value) {
      return value === "false" ? false : value;
    },
    parseLiteral(ast) {
      if (
        ast.kind === Kind.STRING &&
        DisplayOptionTypeEnum.includes(ast.value)
      ) {
        return ast.value === "false" ? false : ast.value;
      }
      return null;
    }
  }),
  Category: {
    slug: async (parent: Category) => {
      return getSlug(parent);
    },
    slugId: async (parent: Category) => {
      return getSlugId(parent);
    }
  },
  Query: {
    getCategories: async (_: null, args: null, context: PortalContext) => {
      const response = await context.axios.get(CATEGORY_DATA);
      return await response.data.data;
    },
    getCategoriesByID: async (
      _: null,
      args: QueryGetCategoriesByIdArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(
        `${CATEGORY_DATA}${args.categoryID}/`
      );
      return await response.data.data[0];
    },
    getCategoriesBySlug: async (
      _: null,
      { slug }: QueryGetCategoriesBySlugArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(CATEGORY_DATA);
      const tem = await response.data.data;
      return tem.find((t: any) => t.slug === slug);
    }
  }
};
