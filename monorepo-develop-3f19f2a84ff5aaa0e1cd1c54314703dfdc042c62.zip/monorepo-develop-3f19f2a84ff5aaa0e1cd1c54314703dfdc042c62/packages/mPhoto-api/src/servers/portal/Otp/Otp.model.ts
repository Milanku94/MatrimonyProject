// import { mBazaar } from "../../../config/config.db";
// export default mBazaar.userOtp;
export default {
  table: "TABLE_NAME",
  fields: {
    columnAliasName: "ACTUAL_COL_NAME"
  }
};
