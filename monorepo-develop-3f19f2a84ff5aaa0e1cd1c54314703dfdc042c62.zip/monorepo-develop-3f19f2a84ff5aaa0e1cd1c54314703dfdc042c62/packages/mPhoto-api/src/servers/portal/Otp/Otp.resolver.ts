// import { exportDefaultSpecifier } from "@babel/types";
// import { provider as Otp } from ".";
import {
  MutationOtpRegenArgs,
  MutationOtpVerifyArgs
} from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
export default {
  //   Mutation: {
  //     otpVerify: async (
  //       _: null,
  //       { customerId, otp }: any,
  //       context: PortalContext
  //     ) => {
  //       return await new Otp(context).verify({ customerId, otp });
  //     },
  //     otpRegen: async (_: null, { customerId }: any, context: PortalContext) => {
  //       return await new Otp(context).regen({ customerId });
  //     }
  //   }
  // };
  //
  Mutation: {
    otpVerify: async (
      _: null,
      { customerId, otp }: MutationOtpVerifyArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post("leads/otp-verify/", {
        customerId,
        otp
      });
      const data = await response.data;
      if (!!data.data) {
        return await data.data;
      }
      throw new Error(data.message);
    },
    otpRegen: async (
      _: null,
      { customerId }: MutationOtpRegenArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post("leads/otp-regen/", {
        customerId
      });
      const data = await response.data;
      if (!!data.data) {
        return await data.data;
      }
      throw new Error(data.message);
    }
  }
};
