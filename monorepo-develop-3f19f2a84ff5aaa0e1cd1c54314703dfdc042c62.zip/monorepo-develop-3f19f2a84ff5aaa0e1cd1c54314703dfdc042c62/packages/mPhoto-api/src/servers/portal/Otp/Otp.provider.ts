// import { OtpVerifyModel as CUSTOMER_VENDOR_OTP } from ".";
// import configMessage from "../../../config/config.message";
// import TEMPLATE from "../../../config/config.message";
// import { sendMessage } from "../../../services/sms.utils";
// import { generateOTP, templateToMessage } from "../../../services/utils";
import AuthProvider from "../auth.provider";
export default class OtpVerifyProvider extends AuthProvider {
  // public verify = async ({ customerId, otp }: any) => {
  //   const result = await this.actualDB(CUSTOMER_VENDOR_OTP.table)
  //     .column(CUSTOMER_VENDOR_OTP.fields)
  //     .where({
  //       [CUSTOMER_VENDOR_OTP.fields.customerId]: customerId,
  //       [CUSTOMER_VENDOR_OTP.fields.otp]: otp,
  //       [CUSTOMER_VENDOR_OTP.fields.source]: "1"
  //     })
  //     .andWhere(CUSTOMER_VENDOR_OTP.fields.status, "!=", 3);
  //   if (result.length > 0) {
  //     return { customerId };
  //   }
  //   throw new Error(TEMPLATE.customerLogin.otpMisMatch);
  // };

  // public regen = async ({ customerId }: any) => {
  //   const otp = generateOTP();
  //   const textMessage = templateToMessage(
  //     configMessage.smsProvider.otpMessage,
  //     {
  //       otp
  //     }
  //   );
  //   const msg = await sendMessage({ to: customerId, text: textMessage });
  //   if (msg.acknowledge) {
  //     return { customerId };
  //   }
  //   return { error: "Error" };
  // };

  public getAll = async () => {
    return testData;
  };
}
const testData = [
  {
    name: "test data"
  }
];
