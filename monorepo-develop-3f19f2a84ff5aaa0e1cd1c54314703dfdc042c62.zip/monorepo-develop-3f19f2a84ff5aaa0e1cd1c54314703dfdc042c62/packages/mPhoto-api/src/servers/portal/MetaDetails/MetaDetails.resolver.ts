import { PortalContext } from "../../../types";
import { provider as MetaDetailsProvider } from "../MetaDetails";

export default {
  MetaDetails: {
    title: (parent: any) => parent.title || "Best Wedding-photographers",
    description: (parent: any) => parent.description || "Description"
  },
  Query: {
    MetaDetails: async (_: any, args: any, context: PortalContext) =>
      await new MetaDetailsProvider(context).getAll()
  }
};
