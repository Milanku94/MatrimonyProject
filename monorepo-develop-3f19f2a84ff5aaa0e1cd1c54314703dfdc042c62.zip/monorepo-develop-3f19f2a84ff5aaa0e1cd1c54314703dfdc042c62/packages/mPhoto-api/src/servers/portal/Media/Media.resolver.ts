import { PortalContext } from "../../../types";
import { provider as MediaProvider } from "../Media";

export default {
  Query: {
    Media: async (_: any, args: any, context: PortalContext) =>
      await new MediaProvider(context).getAll()
  }
};
