import { PortalContext } from "../../../types";
import { provider as BlogsProvider } from "../Blogs";

export default {
  Query: {
    getBlogs: async (_: any, { page = 1 }: any, context: PortalContext) => {
      const response = await context.axios.get(`blogs/p/${page}/r/10/`);
      return await response.data.data;
    },
    getBlogsByID: async (
      _: any,
      { blogID = 45 }: any,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`blogs/${blogID}/`);
      return await response.data.data;
    }
  }
};
