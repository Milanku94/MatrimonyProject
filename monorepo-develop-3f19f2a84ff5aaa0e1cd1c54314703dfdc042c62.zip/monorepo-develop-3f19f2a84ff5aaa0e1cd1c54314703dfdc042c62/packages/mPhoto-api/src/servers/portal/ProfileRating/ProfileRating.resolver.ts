import { PortalContext } from "../../../types";
import { provider as ProfileRatingProvider } from "../ProfileRating";

export default {
  Query: {
    ProfileRating: async (_: any, args: any, context: PortalContext) =>
      await new ProfileRatingProvider(context).getAll()
  }
};
