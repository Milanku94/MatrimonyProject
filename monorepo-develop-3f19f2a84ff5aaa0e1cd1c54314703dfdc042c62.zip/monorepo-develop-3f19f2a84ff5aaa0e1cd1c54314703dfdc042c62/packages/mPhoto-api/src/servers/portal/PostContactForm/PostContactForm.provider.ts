// import FormData from "form-data";
// import { PostContactFormModel as customerRequest } from ".";
// import TEMPLATE from "../../../config/config.message";
// import {
//   CustomerFields,
//   MutationPostContactArgs
// } from "../../../generated/portal.models";
// import { crmEncrypt } from "../../../services/crmCrypt.utils";
import AuthProvider from "../auth.provider";

// interface TriggerCRM extends CustomerFields {
//   customerId: string;
// }
export default class PostContactFormProvider extends AuthProvider {
  public getAll = async () => {
    return testData;
  };
}
const testData = [
  {
    name: "test data"
  }
];
//   public getCustomerId = async ({
//     postData: { name, phone, email, userUniqueId, enquirySource, cityId }
//   }: MutationPostContactArgs) => {
//     if (!name.match(/^[a-z ]+$/g)) {
//       throw new Error(TEMPLATE.PostContactForm.name);
//     }
//     if (!phone.match(/^[6-9][0-9]{9}$/)) {
//       throw new Error(TEMPLATE.PostContactForm.phone);
//     }
//     if (
//       !email.match(
//         /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
//       )
//     ) {
//       throw new Error(TEMPLATE.PostContactForm.email);
//     }
//     if (userUniqueId === "") {
//       throw new Error(TEMPLATE.PostContactForm.userUniqueId);
//     }
//     const { table, fields } = customerRequest;
//     const reqData = {
//       [fields.phone]: phone,
//       [fields.name]: name,
//       [fields.email]: email,
//       [fields.cityId]: cityId,
//       [fields.enquirySource]: enquirySource,
//       [fields.userUniqueId]: userUniqueId,
//       [fields.status]: 1
//     };
//     const searchParams = {
//       [fields.phone]: phone,
//       [fields.status]: 1
//     };

//     const customerData = await this.actualDB(table)
//       .update(reqData)
//       .where(searchParams)
//       .then((record: any) => {
//         if (record === 0) {
//           return this.actualDB(table).insert(reqData);
//         }
//         return this.actualDB(table)
//           .column({ customerId: fields.customerId })
//           .where(searchParams);
//       });
//     const customerId: string = !!customerData[0].customerId
//       ? customerData[0].customerId
//       : customerData[0];
//     const crmStatus = await this.triggerCRM({
//       customerId,
//       name,
//       phone,
//       email,
//       userUniqueId,
//       enquirySource,
//       cityId
//     } as TriggerCRM);

//     return { customerId };
//   };

//   protected triggerCRM = async ({
//     customerId,
//     name,
//     phone,
//     email,
//     userUniqueId,
//     enquirySource,
//     cityId
//   }: TriggerCRM) => {
//     const CRMEnqSource: { [key: number]: string } = {
//       74: "74",
//       51: "37",
//       52: "37",
//       41: "86",
//       47: "87"
//     };

//     const CRMFormData = new FormData();

//     CRMFormData.append("memname", name);
//     CRMFormData.append("leadsrc", CRMEnqSource[enquirySource]);
//     CRMFormData.append("mobilenum", crmEncrypt(phone.toString()));
//     CRMFormData.append("email", crmEncrypt(email));
//     CRMFormData.append("assistid", customerId);
//     CRMFormData.append("districtid", cityId);

//     const CRMData = {
//       memname: name,
//       leadsrc: CRMEnqSource[enquirySource],
//       mobilenum: crmEncrypt(phone.toString()),
//       email: crmEncrypt(email),
//       assistid: customerId,
//       districtid: cityId
//     };

//     const options = {
//       method: "POST",
//       url: "http://service.matrimonybazaar.com/mphotographytrackapi.php",
//       headers: {
//         authorization: "Basic bWJhemFhcmFwaXVzZXI6bWJhemFhcmFwaTEyMw==",
//         "content-type":
//           "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW"
//       },
//       formData: CRMData
//     };

//     const resp = await this.context.serviceAPI<{
//       ResCode: string;
//       ResMsg: string;
//       MemberId?: string;
//     }>("/mphotographytrackapi.php", CRMData);

//     return await this.actualDB(customerRequest.table)
//       .update({
//         [customerRequest.fields.crmId]: resp.MemberId
//       })
//       .where({ [customerRequest.fields.customerId]: customerId });
//   };
// }
