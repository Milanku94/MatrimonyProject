// import { MutationPostContactFormArgs } from "../../../generated/portal.models";
import { MutationPostContactArgs } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
import { provider as PostContact } from "../PostContactForm";

const enquirySrc: { [key: string]: number } = {
  home: 53,
  listing: 54,
  profile: 55,
  sempage: 56,
  default: 2002, // 2001
  waportal: 57,
  wasem: 58
};

export default {
  Mutation: {
    postContact: async (
      _: null,
      { postData }: MutationPostContactArgs,
      context: PortalContext
    ) => {
      const response = await context.leadsAPI.post(`leads/basic/`, {
        ...postData,
        enquirySource: enquirySrc[postData.enquirySource] || enquirySrc.default
      });
      return await response.data.data;
    }
  }

  // Mutation: {
  //   postContact: async (
  //     _: any,
  //     { postData }: MutationPostContactArgs,
  //     context: PortalContext
  //   ) => {
  //     return await new PostContact(context).getCustomerId({ postData });
  //   }
  // }
};
