import { MutationPostNeedArgs } from "../../../generated/portal.models";
import { PortalContext } from "../../../types";
import { provider as PostNeed } from "../PostNeed";
export default {
  Mutation: {
    postNeed: async (
      _: any,
      { postData }: MutationPostNeedArgs,
      context: PortalContext
    ) => {
      return await new PostNeed(context).getNeed({ postData });
    }
  }
};
