import { PostNeedModel as category } from ".";
import { PostNeedModel as customer_category_request } from ".";
import TEMPLATE from "../../../config/config.message";
import {
  CustomerFields,
  MutationPostNeedArgs
} from "../../../generated/portal.models";
import AuthProvider from "../auth.provider";
export default class PostNeedProvider extends AuthProvider {
  public getNeed = async ({
    postData: { categoryId, customerId, isDate }
  }: MutationPostNeedArgs) => {
    if (isDate === "True") {
      throw new Error(TEMPLATE.postNeed.isDateConfirmed);
    }
    //  else{
    // //   return{ error: "Error" };
    // //  }
    //   const ReqData= await this.actualDB(customer_category_request.table )
    //   .column(customer_category_request.fields)
    //   .where({
    //     [customer_category_request.fields.customerId]: customerId,
    //     [customer_category_request.fields.categoryId]:categoryId
    //   })
    //    const CatData= await this. actualDB(category.table)
    //    .column(category.fields)
    //    .where({
    //      [category.fields.categoryId]:categoryId
    //    })
  };
}
