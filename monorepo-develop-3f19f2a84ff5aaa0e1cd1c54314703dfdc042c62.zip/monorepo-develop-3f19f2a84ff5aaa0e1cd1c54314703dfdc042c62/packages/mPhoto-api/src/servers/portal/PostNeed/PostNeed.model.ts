import { mBazaar } from "../../../config/config.db";
export default mBazaar.categories;
// tslint:disable-next-line: no-unused-expression
mBazaar.postNeed;
