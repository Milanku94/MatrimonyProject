import AuthProvider from "../auth.provider";

export default class ProfileProvider extends AuthProvider {}
