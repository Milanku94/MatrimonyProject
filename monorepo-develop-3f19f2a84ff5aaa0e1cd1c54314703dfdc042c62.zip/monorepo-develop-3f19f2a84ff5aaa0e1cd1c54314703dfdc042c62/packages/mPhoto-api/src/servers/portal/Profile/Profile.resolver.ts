import { provider as ProfileProvider } from ".";
import {
  AttributesInput,
  Profile,
  QueryGetProfilesArgs,
  QueryGetProfilesByIdArgs,
  QueryGetTotalProfilesCountArgs
} from "../../../generated/portal.models";
import { getSlug, getSlugId } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";
const formatAttributes = (attributes: Array<AttributesInput | null>) =>
  attributes.map(attr => {
    if (attr) {
      return { [attr.attributeId as string]: attr.optionIds };
    }
    return null;
  });
// attributes.reduce((acc: any, attr: any) => {
//   acc[+attr.attributeId] = attr.optionIds;
//   return acc;
// }, {});
export default {
  Profile: {
    slug: async (parent: Profile) => {
      return getSlug(parent);
    },
    slugId: async (parent: Profile) => {
      return getSlugId(parent);
    }
  },
  DisplayAttribute: {
    slug: async (parent: Profile) => {
      return getSlug(parent);
    }
  },
  Query: {
    getProfiles: async (
      _: null,
      {
        postData: { categoryId, cityId, attributes },
        page = 1,
        limit = 10
      }: QueryGetProfilesArgs, // QueryGetProfilesArgs
      context: PortalContext
    ) => {
      const response = await context.axios.post(
        `profiles/p/${page}/r/${limit}/`,
        {
          category_id: categoryId.toString(),
          city_id: cityId.toString(),
          attributes: formatAttributes(attributes)
        }
      );
      return await response.data.data;
    },
    getTotalProfilesCount: async (
      _: null,
      {
        postData: { categoryId, cityId, attributes }
      }: QueryGetTotalProfilesCountArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.post(`profiles/p/1/r/10/`, {
        category_id: categoryId,
        city_id: cityId,
        attributes: formatAttributes(attributes)
      });
      return await response.headers["x-total-items"];
    },
    getProfilesByID: async (
      _: null,
      { profileID }: QueryGetProfilesByIdArgs,
      context: PortalContext
    ) => {
      console.log(profileID);
      if (!!profileID) {
        const response = await context.axios.get(`profiles/${profileID}/`);
        return await response.data.data[0];
      }
      return null;
    }
  }
};
