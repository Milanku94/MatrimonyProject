import {
  City,
  QueryGetCitiesByIdArgs,
  QueryGetCitiesBySlugArgs
} from "../../../generated/portal.models";
import { getSlug, getSlugId } from "../../../services/slugify.utils";
import { PortalContext } from "../../../types";

const BASE_PATH = `/cities/`;

export default {
  City: {
    slug: async (parent: City) => {
      return getSlug(parent);
    },
    slugId: async (parent: City) => {
      return getSlugId(parent);
    }
  },
  Query: {
    getCities: async (_: null, __: null, context: PortalContext) => {
      const response = await context.axios.get(BASE_PATH);
      return await response.data.data;
    },
    getCitiesByID: async (
      _: null,
      args: QueryGetCitiesByIdArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(`${BASE_PATH}${args.cityId}/`);
      return await response.data.data[0];
    },
    getCitiesBySlug: async (
      _: null,
      { slug }: QueryGetCitiesBySlugArgs,
      context: PortalContext
    ) => {
      const response = await context.axios.get(BASE_PATH);
      const temp = await response.data.data;
      return temp.find((t: any) => t.slug === slug);
    }
  }
};
