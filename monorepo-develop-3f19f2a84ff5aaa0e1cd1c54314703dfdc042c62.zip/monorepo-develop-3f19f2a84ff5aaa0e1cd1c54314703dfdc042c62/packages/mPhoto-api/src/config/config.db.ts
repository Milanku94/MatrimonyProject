import { ReferenceDatabase } from "../types";

const mBazaar: ReferenceDatabase = {
  /**
   * VirtualTable: contains the common field from Actual/Prospect
   */
  userOtp: {
    table: "customer_vendor_otp",
    fields: {
      otpid: "otpid",
      vendorId: "vendor_id",
      customerId: "customer_id",
      mobileNumber: "mobile_number",
      mobileNumberEnc: "mobile_number_enc",
      otp: "otp",
      otpGeneratedTime: "otp_generated_time",
      otpVerifiedTime: "otp_verified_time",
      otpExpiryTime: "otp_expiry_time",
      source: "source",
      status: "status",
      createdOn: "created_on",
      updatedAt: "updated_at"
    }
  },
  PostContactForm: {
    table: "customerRequest",
    fields: {
      name: "Name",
      phone: "MobileNo",
      email: "EmailId",
      cityId: "CityId",
      enquirySource: "EnqSource",
      status: "status",
      userUniqueId: "useruniqid",
      customerId: "AssitId",
      crmId: "crm_ref_id",

      groupId: "groupId",
      MatriId: "MatriId",
      EventType: "EventType",
      EventDate: "EventDate",
      Stateid: "Stateid",
      LocationId: "LocationId",
      ServiceNeeded: "ServiceNeeded",
      CreatedOn: "CreatedOn",
      UpdatedOn: "UpdatedOn"
    }
  },
  postNeed: {
    table: "customer_category_request",
    fields: {
      id: "id",
      categoryId: "category_id",
      customerId: "customer_id"
    }
  },
  categories: {
    table: "category",
    fields: {
      id: "categoryId",
      name: "categoryName",
      displayName: "displaycategoryname",
      seoName: "seo_category_name",
      parentId: "parentId",
      stateId: "stateId",
      domain: "domain",
      commissionStatus: "commissionStatus",
      status: "status",
      displayOrder: "DisplayOrder",
      layeredFormTitle: "layered_form_title"
    }
  },
  vendorValidate: {
    table: "vendor_details",
    fields: {
      userId: "primary_contact_1",
      vendorId: "vendor_id",
      prospectId: "prospect_id",
      businessName: "company_name",
      status: "status"
    }
  },
  states: {
    table: "states",
    fields: {
      id: "state_id",
      name: "state_name",
      countryId: "country_id",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  cities: {
    table: "cities",
    fields: {
      id: "city_id",
      name: "city_name",
      crmDistrictId: "crm_district_id",
      seoCityName: "seo_city_name",
      countryId: "country_id",
      stateId: "state_id",
      districtId: "district_id",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  attributeHeader: {
    table: "categoryHeaderFields",
    fields: {
      id: "CatHdrFieldId",
      value: "HdrFieldValue",
      categoryId: "CategoryId",
      displayOrder: "displayorder",
      visibleField: "visibilefield",
      // portalLabel: "portal_label",
      // layeredFieldLabel: "layered_field_label",
      // 1, 3 enable for bazaar
      crmFlag: "crm_flag",
      status: "ActiveStatus",
      createdOn: "CreatedOn",
      updatedOn: "UpdatedOn"
    }
  },
  attributeSubHeader: {
    table: "categorySubHeaderfields",
    fields: {
      id: "CatSubHdrFieldId",
      name: "SubHdrFieldValue",
      displayOrder: "displayorder",
      categoryId: "CategoryId",
      headerFieldId: "CatHdrFieldId",
      fieldType: "fieldtype",
      fieldValidation: "customer_form_rules",
      crmFlag: "crm_flag",
      vendorMandatory: "vendor_mandatory",

      fieldtypeCustomer: "fieldtype_customer",
      mandatory: "mandatory",
      visibilefield: "visibilefield",
      distributeFlag: "distribute_flag",
      filterFlag: "filter_flag",
      customerForm: "customer_form",
      layeredFormDisplayOrder: "layered_form_display_order",
      searchFlag: "search_flag",
      listFlag: "list_flag",
      informationFlag: "information_flag",
      fieldrules: "fieldrules",
      portalLabel: "portal_label",
      question: "vendor_field_label",
      layeredFieldLabel: "layered_field_label",
      status: "ActiveStatus",
      createdOn: "CreatedOn",
      updatedOn: "UpdatedOn"
    }
  },
  fieldOptions: {
    table: "fieldOptions",
    fields: {
      id: "id",
      subHeaderId: "subhdrid",
      displayOrder: "displayorder",
      value: "value",
      isDefault: "is_default",
      createdOn: "createdon",
      updatedOn: "updatedon"
    }
  },
  textMessage: {
    table: "smslogs",
    fields: {
      id: "LogId",
      senderId: "SenderId",
      serviceProvider: "ServiceProvider",
      accountUser: "AccountUsed",
      mobileNumber: "MobileNumber",
      message: "Message",
      referenceNumber: "ReferenceNumber",
      messageSplitCount: "MessageSpltiCount",
      deliveryStatus: "DeliveryStatus",
      failureReason: "FailureReason",
      enqSource: "EnqSource",
      dateSentOn: "DateSentOn",
      dateUpdatedOn: "DateUpdatedOn"
    }
  }
};
const mBazaarServiceDB: ReferenceDatabase = {
  serviceableCities: {
    table: "mb_serviceable_city",
    fields: {
      districtId: "DistrictId",
      stateId: "StateId",
      eprDistrictId: "EPRDistrictId",
      bmDistrictId: "BMDistrictId",
      cbsDistrictId: "CBSDistrictId",
      districtName: "DistrictName",
      vendorEnableMBZ: "VendorEnable_MBZ",
      vendorEnableMM: "VendorEnable_MM",
      vendorEnablePG: "VendorEnable_PG",
      vendorEnableMMA: "VendorEnable_MMA",
      isOSC: "IsOsc",
      portalVisibility: "PortalVisibility",
      status: "Status",
      createdOn: "CreatedOn"
    }
  },
  locality: {
    table: "mb_localitydet",
    fields: {
      id: "LocalityId",
      name: "LocalityName",
      pincode: "Pincode",
      cityId: "CityId",
      districtId: "DistrictId",
      stateId: "StateId",
      status: "Status"
    }
  },
  salesState: {
    table: "mb_statedet",
    fields: {
      id: "StateId",
      name: "StateName",
      address: "StateAddress",
      enable: "VendorEnable_MBZ",
      status: "Status"
    }
  },
  salesCities: {
    table: "mb_citydet",
    fields: {
      id: "CityId",
      name: "CityName",
      districtId: "DistrictId",
      stateId: "StateId",
      status: "Status"
    }
  }
};

const mBazaarProspectDB: ReferenceDatabase = {
  vendorDetails: {
    table: "vendor_details",
    fields: {
      prospectId: "prospect_id",
      vendorId: "vendor_id",

      businessName: "company_name",
      description: "description",

      // info: Primary Contact
      "primary.name": "primary_contact_name",
      "primary.role": "primary_contactperson_role",
      "primary.email": "email",

      // "primary.phone1.isd": "primary_contact_1_isd",
      "primary.phone1.phone": "primary_contact_1",
      "primary.phone1.verifyStatus": "primary_contact1_verify_status",
      "primary.phone1.verifySource": "primary_contact1_verify_source",
      "primary.phone1.verifyOn": "primary_contact1_verifyon",

      // "primary.phone2.isd": "primary_contact_2_isd",
      "primary.phone2.phone": "primary_contact_2",
      "primary.phone2.verifyStatus": "primary_contact2_verify_status",
      "primary.phone2.verifySource": "primary_contact2_verify_source",
      "primary.phone2.verifyOn": "primary_contact2_verifyon",

      // info: Secondary Contact
      "secondary.name": "secondary_contact_name",
      "secondary.role": "secondary_contactperson_role",
      "secondary.email": "secondary_email",

      // "secondary.phone1.isd": "secondary_contact_1_isd",
      "secondary.phone1.phone": "secondary_contact_1",
      "secondary.phone1.verify.status": "secondary_contact1_verify_status",
      "secondary.phone1.verify.source": "secondary_contact1_verify_source",
      "secondary.phone1.verifyon": "secondary_contact1_verifyon",

      // "secondary.phone2.isd": "secondary_contact_2_isd",
      "secondary.phone2.phone": "secondary_contact_2",
      "secondary.phone2.verifyStatus": "secondary_contact2_verify_status",
      "secondary.phone2.verifySource": "secondary_contact2_verify_source",
      "secondary.phone2.verifyOn": "secondary_contact2_verifyon",

      // info: Address of Business Reg.
      "address.address": "address",
      // "address.location": "location",
      "address.localityId": "location",
      "address.cityId": "city",
      "address.stateId": "state",
      "address.pincode": "pincode",
      "address.latitude": "latitude",
      "address.longitude": "longitude",

      // info: Billing and GST info
      "billingInfo.gstNo": "gst_no",
      "billingInfo.gstBusinessName": "gst_business_name",
      "billingInfo.gstState": "gst_state",
      "billingInfo.billingName": "billing_name",
      "billingInfo.billingAddress": "billing_address",
      "billingInfo.salesCityId": "sales_city_id",
      "billingInfo.salesStateId": "sales_state_id",

      // info: Social network
      "socialLinks.webUrl": "web_url",
      "socialLinks.fbUrl": "fb_url",
      "socialLinks.instagramUrl": "instagram_url",
      "socialLinks.pinterestUrl": "pinterest_url",
      "socialLinks.twitterUrl": "twittter_url",

      // info: KYC number and src files
      "document.panNo": "pan_no",
      "document.aadharNo": "aadhar_no",
      "document.fathersNameKyc": "fathers_name_kyc",
      "document.dobKyc": "dob_kyc",

      // info:
      "onBoardStatus.status": "status",
      "onBoardStatus.onboardState": "onboard_state",
      // "onBoardStatus.progressStatus": "progress_status",
      "onBoardStatus.activatedOn": "activated_on",
      "onBoardStatus.progressLevel": "app_progress_level",

      // info: Payment
      "payment.paidStatus": "paid_status",
      "payment.paidType": "paid_type",
      "payment.noOfPayments": "no_of_payments",
      "payment.isFeatured": "is_featured",
      "payment.featuredStartDate": "featured_start_date",
      "payment.featuredEndDate": "featured_end_date",

      // info: Features
      "misc.listingWithCompetition": "listing_with_competition",
      "misc.operatingOutOf": "operating_out_of",
      "misc.numberOfEmployees": "number_of_employees",
      "misc.eventsConductedSoFar": "events_conducted_so_far",

      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  category: {
    table: "categories",
    fields: {
      id: "categoryId",
      name: "categoryName",
      displayName: "displaycategoryname",
      status: "status",
      displayOrder: "DisplayOrder",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  subCategory: {
    table: "category",
    fields: {
      id: "categoryId",
      name: "categoryName",
      displayName: "displaycategoryname",
      seoCategoryName: "seo_category_name",
      state: "stateId",
      domain: "domain",
      commissionStatus: "commissionStatus",
      status: "status",
      displayOrder: "DisplayOrder",
      layeredFormTitle: "layered_form_title",
      createdOn: "createdOn"
    }
  },
  profiles: {
    table: "vendor_category_settings",
    fields: {
      id: "vendor_category_setting_id",
      vendorId: "vendor_id",
      categoryId: "parent_category_id",
      subCategoryId: "category_id",
      cityId: "city_id",
      stateId: "state_id",

      status: "status",
      // isActive: "is_active",
      serviceable: "is_osc",
      currentPackage: "current_package",

      "leadManagement.status": "lms_user_status",
      "leadManagement.count": "vendor_custom_lead_count",
      "leadManagement.maxCount": "lms_custom_lead_count",

      // "pricing.approved": "is_commission_approved",
      // "pricing.disposition": "commission_disposition",
      "pricing.commissionPercentage": "approved_commission_percentage",
      "pricing.discount": "approved_customer_discount",
      "pricing.leadFee": "lead_price",
      "pricing.listingFee": "listing_fee",

      createdOn: "created_on",
      updatedOn: "updated_at"
    }
  },
  profileAttributes: {
    table: "vendor_category_details",
    fields: {
      id: "vendor_category_detail_id",
      vendorId: "vendor_id",
      cityId: "city_id",
      categoryId: "category_id",
      header: "category_header_id",
      subHeaderId: "category_subheader_id",
      fields: "category_fieldoption_id",
      values: "category_field_value",
      // parentCatId: "parent_cat_id",
      startDate: "start_date",
      endDate: "end_date",
      txtVal: "txt_val",
      fieldType: "field_type",
      createdOn: "created_on",
      updatedOn: "updated_on"
    }
  },
  profileGallery: {
    table: "vendor_images",
    fields: {
      id: "PhotoId",
      vendorId: "vendor_id",
      categoryId: "category_id",
      cityId: "city_id",
      filePath: "PhotoPath",
      fileName: "PhotoName",
      title: "PhotoTitle",
      subTitle: "PhotoSubTitle",
      isHero: "PhotoBaseImage",
      isLogo: "is_logo_image",
      displayOrder: "displayorder",
      description: "PhotoDescription",
      status: "PhotoStatus",
      createdDate: "CreatedDate",
      updatedDate: "UpdatedDate"
    }
  },
  vendorDocument: {
    table: "vendor_documents",
    fields: {
      id: "vendor_document_id",
      vendorId: "vendor_id",
      docType: "doc_type",
      docSubType: "sub_doc_type",
      // fileType: "file_type",
      // categoryId: "category_id",
      paymentId: "payment_id",
      name: "name",
      size: "size",
      comments: "comments",
      status: "status",
      createdOn: "created_on",
      updatedOn: "updated_on",
      updatedAt: "updated_at"
    }
  },
  userOtp: {
    table: "customer_vendor_otp",
    fields: {
      id: "otpid",
      vendorId: "vendor_id",
      mobileNumber: "mobile_number",
      otp: "otp",
      otpGeneratedTime: "otp_generated_time",
      otpVerifiedTime: "otp_verified_time",
      otpExpiryTime: "otp_expiry_time",
      source: "source",
      status: "status",
      createdOn: "created_on",
      updatedAt: "updated_at"
    }
  }
};
export { mBazaar, mBazaarServiceDB, mBazaarProspectDB };
