export default {
  appLog: {
    initSuccess: `Initiation completed successfully`,
    initFailed: `Initiation failed`
  },
  smsProvider: {
    // updated SMS content need to whitelist on SMS service provider
    otpMessage: `{{otp}} is your One time password (OTP) for WeddingBazaar.com. Please use this to verify your mobile number. This OTP will expire in 2 minutes`,
    errorMessage: `Something broke. Please try again in sometime.`
  },
  imageUrl: {
    categoryIcon: `http://www.weddingbazaar.com/assets/icons/{{categoryName}}.png`
  },
  attributesGroup: {
    basic: `Basic Details`,
    organization: `Organization Details`,
    service: `Service Details`,
    others: `Others`
  },
  profile: {
    duplicateProfileERR: `A profile with this city-category exists`
  },
  customerLogin: {
    otpMisMatch: `Please enter the correct OTP.`,
    otpRequest: `OTP will expire in {{otpInterval}} sec.`,
    otpRequestFailed: `OTP request failed.`
  },
  vendorDetails: {
    mobileNumberAlreadyTaken: `This number is already registered.`
  },
  vendorValidate: {
    actual: `The profiles are active.`,
    prospect: `The profiles are under review.`,
    new: `No profiles`
  },
  vendorKyc: {
    verified: `Verified`,
    rejected: `Rejected`,
    reviewing: `Reviewing`
  },
  PostContactForm: {
    phone: "Mobile no.missing",
    name: "name Missing",
    email: "Email-Id Missing",
    cityId: "cityId Missing",
    sourceUrl: "sourceUrl Incorrect",
    enqsource: "Invalid EnqSource",
    userUniqueId: "userUniqueId Invalids"
  },
  postNeed: {
    categoryId: "CategoryId Missing",
    customerId: "CoustomerId MissMatch",
    isDateConfirmed: "Date is Missmatch"
  }
};
