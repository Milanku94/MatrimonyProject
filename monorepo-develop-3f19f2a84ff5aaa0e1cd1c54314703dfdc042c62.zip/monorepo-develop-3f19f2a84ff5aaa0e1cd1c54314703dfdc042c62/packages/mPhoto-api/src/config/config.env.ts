import { config } from "dotenv";
import path from "path";
config({
  path: path.join(
    __dirname,
    process.env.NODE_ENV === "development"
      ? `../../.env.local`
      : `../../.env.production`
  )
});
const MONGO_COLLECTION = {
  eventType: "event_type",
  vendorLead: "vendor_lead",
  person: "people",
  participant: "participant",
  address: "address",
  event: "event",
  profile: "profile"
};
export default {
  PORT: process.env.SERVER_PORT || 4000,

  PROFILE_COMPL_LEVEL_SCHEDULE:
    process.env.PROFILE_COMPL_LEVEL_SCHEDULE || "0 0 2 * * *",
  MONGO_URI: process.env.MONGO_URI || "mongodb://localhost:27017/test",
  MONGO_COLLECTION,

  JWT: {
    SECRET: process.env.JWT_SECRET || "",
    AUTH_TOKEN_NAME: process.env.JWT_AUTH_TOKEN_NAME || "x-access-token",
    EXPIRES_IN: process.env.JWT_EXPIRES_IN || "1d"
  },
  VENDOR_LEAD_ENDPOINT: {
    TSE_URL: process.env.VENDOR_LEAD_TSE_URL || ""
  },
  DEVICE_TOKEN_NAME: process.env.DEVICE_TOKEN_NAME || "x-device-token",
  HASH_SALT_KEY: process.env.HASH_SALT_KEY || "",

  IMAGE_DOC_PATH: process.env.IMAGE_DOC_PATH || "uploads/",
  IMAGE_ASSET_BASE_URL: process.env.IMAGE_ASSET_BASE_URL || "",

  SMS_PROVIDER: {
    URL: process.env.SMS_PROVIDER_URL || "",
    USERNAME: process.env.SMS_PROVIDER_USERNAME || "",
    PASSWORD: process.env.SMS_PROVIDER_PASSWORD || ""
  },
  LDAP_CONFIG: {
    URL: process.env.LDAP_URL || "",
    BIND_DN: process.env.LDAP_BIND_DN || "",
    BIND_CRED: process.env.LDAP_BIND_CRED || "",
    SEARCH_BASE: process.env.LDAP_SEARCH_BASE || "",
    SEARCH_FILTER: process.env.LDAP_SEARCH_FILTER || ""
  },
  DB_MBAZAAR: {
    HOST: process.env.DB_MBAZAAR_HOST || "",
    DB: process.env.DB_MBAZAAR_DB || "",
    USER_NAME: process.env.DB_MBAZAAR_USER_NAME || "",
    PWD: process.env.DB_MBAZAAR_PWD || ""
  },
  DB_MBAZAAR_SERVICES: {
    HOST: process.env.DB_MBAZAAR_SERVICES_HOST || "",
    DB: process.env.DB_MBAZAAR_SERVICES_DB || "",
    USER_NAME: process.env.DB_MBAZAAR_SERVICES_USER_NAME || "",
    PWD: process.env.DB_MBAZAAR_SERVICES_PWD || ""
  },
  DB_MBAZAAR_PROSPECT: {
    HOST: process.env.DB_MBAZAAR_PROSPECT_HOST || "",
    DB: process.env.DB_MBAZAAR_PROSPECT_DB || "",
    USER_NAME: process.env.DB_MBAZAAR_PROSPECT_USER_NAME || "",
    PWD: process.env.DB_MBAZAAR_PROSPECT_PWD || ""
  }
};
