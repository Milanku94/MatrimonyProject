/**
 * Vendor onBoard
 */
export enum verifiedSource {
  CUSTOMER = 1,
  VENDOR = 2,
  PROSPECT = 3,
  VENDOR_APP = 4
}

export enum textMessageEnqSrc {
  VENDOR_ONBOARD_OTP = 1
}

export enum checkPointList {
  BUSINESS = 15,
  PROFILE = 20,
  KYC = 30,
  PROFILE_DETAILS = 40,
  DASHBOARD = 50
}
export enum userRole {
  VENDOR = "VENDOR",
  ADMIN = "ADMIN"
}
export enum vendorRole {
  NO_ROLE = 0,
  DIRECTOR = 1,
  MANAGER = 2,
  TRUSTEE = 3,
  PARTNER = 4,
  PROPRIETOR = 5
}
export enum paidStatus {
  FREE = 0,
  PAID = 1
}
export enum vendorDocStatus {
  REMOVED = 0,
  ACTIVE = 1,
  UNDER_REVIEW = 2,
  REJECTED = 3
}
export enum vendorDocCategory {
  AGREEMENT_DOC = 1,
  KYC_DOC = 2,
  BUSINESS_DOC = 3,
  PAYMENT_DOC = 4,
  PO_DOC = 5
}
export enum onBoardProgressStatus {
  VENDOR_DETAILS = 1,
  CATEGORY_DETAILS = 2,
  CATEGORY_SETTINGS_DETAILS = 3,
  CITY_DETAILS = 4,
  WALLET_DETAILS = 5,
  WALLET_LOG_DETAILS = 6,
  IMAGES_DETAILS = 7,
  DOCUMENTS_DETAILS = 8,
  BANNER_PAYMENT_DETAILS = 9,
  BANNER_IMAGES = 10,
  BANNER_TAG_IMAGES = 11,
  CATEGORY_PAYMENT_DETAILS = 12
}
export enum miscListCompetition {
  JUST_DIAL = 1,
  SULEKHA = 2,
  WED_ME_GOOD = 3,
  OTHERS = 4
}
export enum miscOperatingOutOf {
  NOT_AVAILABLE = 0,
  HOME = 1,
  OFFICE = 2,
  OTHERS = 3
}
export enum miscEventConducted {
  NOT_AVAILABLE = 0,
  LESS_THEN_10 = 1,
  LESS_THEN_50 = 2,
  LESS_THEN_100 = 3,
  LESS_THEN_500 = 4,
  LESS_THEN_1000 = 5,
  MORE_THEN_1000 = 6
}
export enum miscMiscNosEmployees {
  NOT_AVAILABLE = 0,
  LESS_THEN_10 = 1,
  LESS_THEN_25 = 2,
  LESS_THEN_50 = 3,
  LESS_THEN_100 = 4,
  MORE_THEN_101 = 5
}

export enum profileStatus {
  INACTIVE = 0,
  ACTIVE = 1,
  DELETE = 2
}
export enum profileLeadManagementStatus {
  DISABLE = 0,
  ON = 1,
  OFF = 3,
  DELETE = 4
}
export enum profileCommissionApproved {
  NO = 0,
  YES = 1
}
export enum profilePackage {
  OLD = 0,
  NEW = 1
}
export enum profileServiceable {
  SERVICEABLE_CITY = 0,
  OTHER_SERVICEABLE_CITY = 1
}
export enum profileAttributeFieldType {
  TEXT_BOX = 0,
  TEXT_AREA = 1,
  RADIO_BUTTON = 2,
  CHECKBOX = 3,
  SELECT_BOX = 4,
  MULTIPLE_SELECT_BOX = 5,
  PASSWORD = 6,
  RANGE = 7,
  SPLIT_TEXT = 8,
  SPLIT_OPTION = 9,
  SPLIT_FIELD_OPTION = 14,
  DATE = 15,
  MULTIPLE_DATE = 16
}

/**
 * RM Toolkit
 */
export enum profession {
  SALARIED = "Salaried",
  SELF_EMPLOYED = "Selfemployed",
  RETIRED = "Retired",
  PROFESSIONAL = "Professional",
  BUSINESS = "Business"
}
export enum industry {
  BANKING = "Banking",
  HOSPITALITY = "Hospitality",
  GOVT = "Govt",
  IT_ITES = "IT/ ITES",
  MEDICAL_PHARMA = "Medical/ Pharma",
  MANUFACTURING = "Manufacturing",
  OTHERS = "Others"
}
export enum relationship {
  MY_SELF = "My Self",
  RELATIVE = "Relative",
  FRIEND = "Friend",
  SON = "Son",
  DAUGHTER = "Daughter",
  BROTHER = "Brother",
  SISTER = "Sister"
}
export enum hindu {
  BRAHMIN_BHATT = "Brahmin - Bhatt",
  BRAHMIN_DESHASTHA = "Brahmin - Deshastha",
  BRAHMIN_DRAVIDA = "Brahmin - Dravida",
  BRAHMIN_HAVYAKA = "Brahmin - Havyaka",
  BRAHMIN_HOYSALA = "Brahmin - Hoysala",
  BRAHMIN_IYENGAR = "Brahmin - Iyengar",
  BRAHMIN_IYER = "Brahmin - Iyer",
  BRAHMIN_MADHWA = "Brahmin - Madhwa",
  BRAHMIN_RIGVEDI = "Brahmin - Rigvedi",
  BRAHMIN_SANKETI = "Brahmin - Sanketi",
  BRAHMIN_SARASWAT = "Brahmin - Saraswat",
  BRAHMIN_SHIVHALLI = "Brahmin - Shivhalli",
  BRAHMIN_SMARTHA = "Brahmin - Smartha",
  BRAHMIN_VYAS = "Brahmin - Vyas",
  AGARWAL = "Agarwal",
  ARYA_VYSYA = "Arya Vysya",
  BUNT_SHETTY = "Bunt (Shetty)",
  CHETTIAR = "Chettiar",
  COORGI = "Coorgi",
  DEVANGA = "Devanga",
  GOAN = "Goan",
  GOWDA = "Gowda",
  GUPTA = "Gupta",
  KASHYAP = "Kashyap",
  KAYASTHA = "Kayastha",
  KHANDELWAL = "Khandelwal",
  KONKANI = "Konkani",
  KSHATRIYA = "Kshatriya",
  LINGAYATH = "Lingayath",
  MANGALOREAN = "Mangalorean",
  NAICKER = "Naicker",
  NAIDU = "Naidu",
  NAIK = "Naik",
  NAIR = "Nair",
  PATEL = "Patel",
  RAJASTANI = "Rajastani",
  RAJPUT = "Rajput",
  REDDY = "Reddy",
  SC = "SC",
  SOURASHTRA = "Sourashtra",
  ST = "ST",
  SUNDHI = "Sundhi",
  URS = "Urs",
  VAISH = "Vaish",
  VAISHNAV = "Vaishnav",
  VAISHNAVA = "Vaishnava",
  VAISHYA = "Vaishya",
  VISWABRAHMIN = "Viswabrahmin",
  VISWAKARMA = "Viswakarma",
  VOKKALIGA = "Vokkaliga",
  VYSYA = "Vysya",
  YADAV = "Yadav"
}
